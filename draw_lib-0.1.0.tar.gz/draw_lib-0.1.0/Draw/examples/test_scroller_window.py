"""
examples/test_scroller_window.py
================================
Interactive Window Test demonstrating the new Draw.scroller(...) API!

Features demonstrated:
- High-level Draw.scroller(display=..., show_thumb=True) API
- Senses + Connectors gesture composition (Mouse wheel, Touch swipe, Drag thumb, Arrow/Page keys)
- Programmatic scroll control (Draw.scroller.scroll_by, Draw.scroller.scroll_to)
- Interactive draggable shapes across a tall page layout
"""

import os
import sys

# Ensure repository root is on sys.path
THIS_DIR = os.path.dirname(os.path.abspath(__file__))
REPO_ROOT = os.path.dirname(os.path.dirname(THIS_DIR))
if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)

import Draw


def main():
    win_tag = "scroller_demo_win"
    win_w, win_h = 960, 720

    print("[Draw] Creating Window...")
    Draw.window(
        tag=win_tag,
        title="📜 Draw.scroller Interactive Window Test",
        width=win_w,
        height=win_h,
        background_color="#0F172A",
    )

    # 1. Initialize the new Scroller API
    print("🚀 Initializing Draw.scroller(...) API...")
    Draw.scroller(
        display=win_tag,
        direction="vertical",
        show_thumb=True,
        thumb_color="#38BDF8",
        track_color="#1E293B",
        thumb_width=14,
        speed=1.2,
        keyboard=True,
    )

    # 2. Main Background Card Panel (Tall Content Page)
    Draw.shapes(
        display=win_tag,
        shape=[
            {
                "ip": "main_card",
                "vertices": 4,
                "border_radius": 16,
                "size": [880, 1800],  # Tall content page (1800px tall)
                "color": "#1E293B",
                "border_width": 2,
                "border_color": "#334155",
                "x": 40,
                "y": 40,
                "z": 100,             # Background card
                "locked": True,       # Stationary background
            }
        ],
    )

    # 3. Header Text
    Draw.text(
        tag=win_tag,
        text="📜 Draw.scroller Interactive Demo",
        ip="header_title",
        customise={
            "font_size": 24,
            "font_family": "Inter",
            "color": "#F8FAFC",
            "bold": True,
            "x": 70,
            "y": 70,
            "z": 10,
        },
    )

    Draw.text(
        tag=win_tag,
        text="Try Mouse Wheel, Drag Right Thumb, or Arrow Keys / Page Up / Page Down to scroll!",
        ip="header_subtitle",
        customise={
            "font_size": 14,
            "font_family": "Inter",
            "color": "#38BDF8",
            "x": 70,
            "y": 110,
            "z": 10,
        },
    )

    # 4. Content Cards on top section
    Draw.shapes(
        display=win_tag,
        shape=[
            {
                "ip": "card_1",
                "vertices": 4,
                "border_radius": 12,
                "size": [380, 200],
                "color": "#334155",
                "border_width": 2,
                "border_color": "#475569",
                "x": 70,
                "y": 170,
                "z": 20,
            },
            {
                "ip": "card_2",
                "vertices": 4,
                "border_radius": 12,
                "size": [380, 200],
                "color": "#334155",
                "border_width": 2,
                "border_color": "#475569",
                "x": 500,
                "y": 170,
                "z": 20,
            },
            {
                "ip": "cyan_circle",
                "vertices": 64,
                "size": [120, 120],
                "color": "#06B6D4",
                "border_width": 3,
                "border_color": "#67E8F9",
                "x": 200,
                "y": 420,
                "z": 5,
            },
            {
                "ip": "pink_triangle",
                "vertices": 3,
                "size": [140, 130],
                "color": "#EC4899",
                "border_width": 3,
                "border_color": "#F472B6",
                "x": 580,
                "y": 420,
                "z": 5,
            },
        ],
    )

    Draw.text(
        tag=win_tag,
        text="Card 1: Senses Redesign",
        ip="card1_text",
        customise={
            "font_size": 16,
            "font_family": "Inter",
            "color": "#F8FAFC",
            "bold": True,
            "x": 90,
            "y": 200,
            "z": 15,
        },
    )

    Draw.text(
        tag=win_tag,
        text="Card 2: Connectors Wiring",
        ip="card2_text",
        customise={
            "font_size": 16,
            "font_family": "Inter",
            "color": "#F8FAFC",
            "bold": True,
            "x": 520,
            "y": 200,
            "z": 15,
        },
    )

    # 5. Middle Section
    Draw.text(
        tag=win_tag,
        text="👇 Scroll Down to See Lower Content Sections",
        ip="mid_header",
        customise={
            "font_size": 18,
            "font_family": "Inter",
            "color": "#F59E0B",
            "bold": True,
            "x": 70,
            "y": 620,
            "z": 10,
        },
    )

    # 6. Lower Content Section (At Y=900 to Y=1700)
    for idx, (y_pos, bg_col, title) in enumerate([
        (700, "#1E1B4B", "Section A: Dynamic Motion Integration"),
        (1050, "#064E3B", "Section B: AlignCalc Primitives"),
        (1400, "#4C1D95", "Section C: End of Page Content"),
    ]):
        Draw.shapes(
            display=win_tag,
            shape=[
                {
                    "ip": f"lower_sec_{idx}",
                    "vertices": 4,
                    "border_radius": 12,
                    "size": [800, 280],
                    "color": bg_col,
                    "border_width": 2,
                    "border_color": "#64748B",
                    "x": 80,
                    "y": y_pos,
                    "z": 50,
                }
            ],
        )
        Draw.text(
            tag=win_tag,
            text=f"✨ {title}",
            ip=f"lower_title_{idx}",
            customise={
                "font_size": 18,
                "font_family": "Inter",
                "color": "#F8FAFC",
                "bold": True,
                "x": 110,
                "y": y_pos + 30,
                "z": 10,
            },
        )

    # 7. Start App Window Loop
    print("✨ Running Window Event Loop...")
    Draw.window.run(win_tag)


if __name__ == "__main__":
    main()
