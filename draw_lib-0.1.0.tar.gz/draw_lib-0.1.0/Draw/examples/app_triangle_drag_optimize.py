"""
examples/app_triangle_drag_optimize.py
======================================
Interactive Showcase for Draw library:
- Draggable Triangle shapes (vertices=3)
- Built-in Canvas Page Scroller (properties=["scroller"])
- High-Performance Optimization Engine (_optimize.py / Draw.optimize)
"""

import os
import sys

# Ensure repository root is on sys.path
REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)

import Draw


def main():
    win_tag = "triangle_scroller_demo"
    win_w, win_h = 1000, 800

    # 1. Initialize Window
    Draw.window(
        tag=win_tag,
        title="🔺 Draggable Triangles & Page Scroller Showcase",
        width=win_w,
        height=win_h,
        background_color="#0F172A",
    )

    # 2. Attach Built-in Scroller Overlay
    Draw.shapes(
        display=win_tag,
        properties=["scroller"],
        shape=[{
            "place": "right",
            "color": "#1E293B",
            "thumb_color": "#38BDF8",
            "width": 14,
            "z": 1,
        }],
    )

    # 3. Main Background Card Panel (z=100 -> Background)
    Draw.shapes(
        display=win_tag,
        shape=[
            {
                "ip": "main_card",
                "vertices": 4,
                "size": [900, 1500],  # Tall content page
                "color": "#1E293B",
                "border_width": 2,
                "border_color": "#334155",
                "x": 40,
                "y": 60,
                "z": 100,             # Background card (drawn first)
                "locked": True,       # Background stays stationary
            }
        ],
    )

    # 4. Header Titles (z=10 -> Foreground text)
    Draw.text(
        tag=win_tag,
        text="🔺 Interactive Draggable Triangles & Page Scroller",
        ip="header_title",
        customise={
            "font_size": 22,
            "font_family": "Outfit",
            "color": "#F8FAFC",
            "bold": True,
            "x": 70,
            "y": 90,
            "z": 10,
        },
    )

    Draw.text(
        tag=win_tag,
        text="Drag the Cyan, Pink & Emerald Green triangles! Scroll down using mouse wheel or slider thumb.",
        ip="header_subtitle",
        customise={
            "font_size": 14,
            "font_family": "Outfit",
            "color": "#94A3B8",
            "x": 70,
            "y": 130,
            "z": 10,
        },
    )

    # 5. Foreground Draggable Triangles (z=5 -> Foreground shape, drawn on top of background)
    Draw.shapes(
        display=win_tag,
        shape=[
            {
                "ip": "cyan_triangle",
                "vertices": 3,               # Regular Triangle
                "size": [180, 160],
                "color": "#06B6D4",          # Cyan
                "border_width": 3,
                "border_color": "#67E8F9",
                "x": 200,
                "y": 240,
                "z": 5,                      # Foreground shape
            },
            {
                "ip": "pink_triangle",
                "vertices": 3,               # Regular Triangle
                "size": [150, 130],
                "color": "#EC4899",          # Vibrant Pink
                "border_width": 3,
                "border_color": "#F472B6",
                "x": 560,
                "y": 380,
                "z": 5,                      # Foreground shape
            }
        ],
    )

    # 6. Lower Page Content Section (Visible when scrolled down)
    Draw.shapes(
        display=win_tag,
        shape=[
            {
                "ip": "lower_card",
                "vertices": 4,
                "size": [820, 380],
                "color": "#0F172A",
                "border_width": 2,
                "border_color": "#475569",
                "x": 80,
                "y": 1000,
                "z": 80,
                "locked": True,
            },
            {
                "ip": "emerald_triangle",
                "vertices": 3,               # Triangle in lower section
                "size": [160, 140],
                "color": "#10B981",          # Emerald Green
                "border_width": 3,
                "border_color": "#6EE7B7",
                "x": 400,
                "y": 1100,
                "z": 5,                      # Draggable shape inside lower section
            }
        ],
    )

    Draw.text(
        tag=win_tag,
        text="👇 Lower Page Section - Emerald Green Triangle is also Draggable!",
        ip="lower_header",
        customise={
            "font_size": 16,
            "font_family": "Outfit",
            "color": "#A7F3D0",
            "bold": True,
            "x": 110,
            "y": 1030,
            "z": 10,
        },
    )

    # 7. Apply High-Performance Optimization Engine (_optimize.py)
    Draw.set_performance_mode("max")
    opt_info = Draw.optimize(mode="max", gc_tune=True, render_profile="high_fps")
    print("⚡ Draw._optimize Engine Initialized:", opt_info)

    # 8. Run Window
    print("🚀 Launching App...")
    Draw.window.run(win_tag)


if __name__ == "__main__":
    main()
