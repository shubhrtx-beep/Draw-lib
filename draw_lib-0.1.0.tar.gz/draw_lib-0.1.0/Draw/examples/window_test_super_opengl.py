"""
examples/window_test_super_opengl.py
====================================
Interactive Visual Window Test for Draw.super OpenGL Hardware Acceleration.
"""

import os
import sys
import time
import math
import random

# Fix stdout/stderr for Windows console
if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
if hasattr(sys.stderr, "reconfigure"):
    try:
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

# Ensure repository root is on sys.path
THIS_DIR = os.path.dirname(os.path.abspath(__file__))
REPO_ROOT = os.path.dirname(THIS_DIR)
PARENT_ROOT = os.path.dirname(REPO_ROOT)
if PARENT_ROOT not in sys.path:
    sys.path.insert(0, PARENT_ROOT)
if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)

import Draw


def main():
    win_tag = "super_gl_test_win"
    win_w, win_h = 1280, 840

    print("=" * 70)
    print(" [Draw] Launching Draw.super OpenGL Hardware Accelerated Window Test")
    print("=" * 70)

    # 1. Initialize Window
    Draw.window(
        tag=win_tag,
        title="Draw.super -- OpenGL 3.3 GPU Hardware Accelerated Viewport",
        width=win_w,
        height=win_h,
        background_color="#080C14",
    )

    # 2. Main Dashboard Cards (Locked to prevent dragging background cards)
    Draw.shape(
        display=win_tag,
        shape=[
            # Top Header Bar Card
            {
                "ip": "header_card",
                "vertices": 4,
                "border_radius": 14,
                "size": [1200, 95],
                "color": "#111827",
                "border_width": 2,
                "border_color": "#1F2937",
                "x": 40,
                "y": 20,
                "z": 100,
                "locked": True,
            },
            # Live Metrics Card
            {
                "ip": "metrics_card",
                "vertices": 4,
                "border_radius": 12,
                "size": [340, 75],
                "color": "#0F172A",
                "border_width": 2,
                "border_color": "#38BDF8",
                "x": 880,
                "y": 30,
                "z": 90,
                "locked": True,
            },
            # Interactive Arena Card
            {
                "ip": "arena_card",
                "vertices": 4,
                "border_radius": 16,
                "size": [1200, 670],
                "color": "#0D131F",
                "border_width": 2,
                "border_color": "#1E293B",
                "x": 40,
                "y": 135,
                "z": 110,
                "locked": True,
            },
        ]
    )

    # 3. Header Typography
    Draw.text(
        tag=win_tag,
        text="Draw.super -- OpenGL Hardware Acceleration Engine",
        ip="title_txt",
        customise={
            "font_size": 20,
            "font_family": "Segoe UI",
            "bold": True,
            "color": "#60A5FA",
            "x": 65,
            "y": 35,
            "z": 10,
        }
    )

    Draw.text(
        tag=win_tag,
        text="VBO GPU Batching  *  Zero Viewport Glitches  *  Instantaneous 1:1 Dragging  *  60-144+ FPS",
        ip="subtitle_txt",
        customise={
            "font_size": 12,
            "font_family": "Segoe UI",
            "color": "#94A3B8",
            "x": 65,
            "y": 70,
            "z": 10,
        }
    )

    # 4. Live FPS & Draw Stats Binding
    frame_counter = [0]
    last_time = [time.perf_counter()]
    fps_display = ["60.0 FPS"]

    def get_live_fps():
        frame_counter[0] += 1
        now = time.perf_counter()
        elapsed = now - last_time[0]
        if elapsed >= 0.5:
            fps = frame_counter[0] / elapsed
            fps_display[0] = f"{fps:.1f} FPS ({elapsed*1000/frame_counter[0]:.1f}ms)"
            frame_counter[0] = 0
            last_time[0] = now
        return f"GPU Live: {fps_display[0]}"

    Draw.text(
        tag=win_tag,
        text=get_live_fps,
        ip="live_fps_txt",
        customise={
            "font_size": 14,
            "font_family": "Consolas",
            "bold": True,
            "color": "#34D399",
            "x": 900,
            "y": 42,
            "z": 10,
        }
    )

    Draw.text(
        tag=win_tag,
        text="Backend: OpenGL 3.3 Core Profile",
        ip="backend_info_txt",
        customise={
            "font_size": 11,
            "font_family": "Segoe UI",
            "color": "#38BDF8",
            "x": 900,
            "y": 70,
            "z": 10,
        }
    )

    # 5. Populate Grid with 176 GPU-Batched Geometric Shapes (Midground, Z=50)
    palette = [
        "#00E676", "#00B0FF", "#E040FB", "#FFD600",
        "#FF1744", "#00E5FF", "#76FF03", "#FF9100",
        "#F50057", "#651FFF", "#3D5AFE", "#00B8D4",
    ]

    shapes_batch = []
    cols = 16
    rows = 11
    spacing_x = 68
    spacing_y = 52
    origin_x = 75
    origin_y = 165

    print(f"[Draw] Generating {cols * rows} dynamic GPU-batched shapes in grid...")
    for r in range(rows):
        for c in range(cols):
            idx = r * cols + c
            v_count = [3, 4, 5, 6, 8][(r + c) % 5]
            color_choice = palette[idx % len(palette)]
            size_px = 36 + (idx % 4) * 4
            px = origin_x + c * spacing_x
            py = origin_y + r * spacing_y

            shapes_batch.append({
                "ip": f"node_{idx}",
                "vertices": v_count,
                "size": [size_px, size_px],
                "color": color_choice,
                "x": px,
                "y": py,
                "rotation": (idx * 23) % 360,
                "z": 50,
            })

    # Add 3 Large Interactive Draggable Hero Shapes (Foreground, Z=15)
    shapes_batch.extend([
        {
            "ip": "hero_sun",
            "vertices": 8,
            "size": [140, 140],
            "color": "#FF6D00",
            "border_width": 4,
            "border_color": "#FFE082",
            "x": 160,
            "y": 380,
            "z": 15,
        },
        {
            "ip": "hero_diamond",
            "vertices": 4,
            "size": [130, 130],
            "color": "#D500F9",
            "border_width": 4,
            "border_color": "#EA80FC",
            "rotation": 45,
            "x": 560,
            "y": 380,
            "z": 15,
        },
        {
            "ip": "hero_star",
            "vertices": 6,
            "size": [140, 140],
            "color": "#00E5FF",
            "border_width": 4,
            "border_color": "#E0F7FA",
            "x": 960,
            "y": 380,
            "z": 15,
        },
    ])

    Draw.shape(
        display=win_tag,
        shape=shapes_batch,
    )

    # 6. Activate Draw.super Hardware Accelerated Engine!
    print("[Draw] Activating Draw.super GPU Acceleration Subsystem...")
    gl_canvas = Draw.super(
        display=win_tag,
        precompile=True,   # Warm-up caches & pre-tessellate geometry
        mode="max",        # Tunes GC thresholds & builds spatial grid index
        vsync=False,       # Zero frame limiter for ultra-smooth responsiveness
        batch_capacity=65536,
    )
    print(f"[OK] OpenGL Canvas Active: {type(gl_canvas)}")
    print("\n-------------------------------------------------------------------")
    print(" Interactive Controls:")
    print("   * Click & Drag the 3 large Hero shapes (Sun, Diamond, Star)")
    print("   * Click & Drag any individual grid node shape")
    print("   * Silky smooth 60-144+ FPS hardware-accelerated tracking")
    print("-------------------------------------------------------------------\n")

    # 7. Start Window Event Loop
    Draw.window.run(win_tag)


if __name__ == "__main__":
    main()
