"""
Draw Framework — 3-Engine Graph Comparison Suite
=================================================
A pure Draw-framework application comparing all three graph engine files:
- Tab 1: Draw.graph (graph.py) — 3-step Qt delegation engine
- Tab 2: Draw._graph (_graph.py) — Comprehensive chart engine
- Tab 3: backup_graph/_graph.py — Baseline comparison engine (Final)

Run with:
    D:\\python\\python.exe D:\\pg\\draw2\\Draw\\examples\\app_three_graph_comparison.py
"""

import os
import sys
import random
import importlib.util

# Add parent workspace directory to sys.path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
import Draw

# Import Engine 1 (graph.py)
from Draw.graph import graph as graph_engine_1

# Import Engine 2 (_graph.py)
from Draw._graph import graph as graph_engine_2

# Import Engine 3 (backup_graph/_graph.py) via dynamic spec
backup_file_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "backup_graph", "_graph.py")
spec = importlib.util.spec_from_file_location("backup_graph_mod", backup_file_path)
backup_mod = importlib.util.module_from_spec(spec)
sys.modules["backup_graph_mod"] = backup_mod
spec.loader.exec_module(backup_mod)
graph_engine_3 = backup_mod.graph


WIN = "graph_comparison_app"
ACTIVE_TAB = 1

# Initialize 1280x850 Window
Draw.window(
    tag=WIN,
    title="Draw Framework — 3-Engine Graph Comparison Suite",
    width=1280,
    height=850,
    resizable=True
)


def _render_background_and_header():
    """Render background gradient card and header bar using pure Draw shapes & text."""
    # Dark canvas background
    Draw.shapes(
        display=WIN,
        shape=[{
            "ip": "app_bg",
            "vertices": 4,
            "x": 0,
            "y": 0,
            "size": [1280, 850],
            "color": "#0B0F17",
            "z": 100000,
            "locked": True,
        }]
    )

    # Header Card
    Draw.shapes(
        display=WIN,
        shape=[{
            "ip": "header_card",
            "vertices": 4,
            "x": 20,
            "y": 15,
            "size": [1240, 65],
            "color": "#131B2E",
            "border_color": "#1E293B",
            "border_width": 1,
            "border_radius": 10,
            "z": 90000,
        }]
    )

    Draw.text(
        display=WIN,
        ip="header_title",
        text="📊 Draw Framework — 3-Engine Graph Comparison Suite",
        x=40,
        y=28,
        color="#F8FAFC",
        font_size=18,
        bold=True,
    )

    Draw.text(
        display=WIN,
        ip="header_subtitle",
        text="Interactive tab switching between graph.py (Tab 1), _graph.py (Tab 2), and backup_graph/_graph.py (Tab 3)",
        x=40,
        y=53,
        color="#94A3B8",
        font_size=11,
    )


def _render_tab_buttons():
    """Render interactive tab navigation buttons using Draw shapes & text."""
    tabs_info = [
        (1, "Tab 1: graph.py Engine", 20, "#3B82F6"),
        (2, "Tab 2: _graph.py Engine", 435, "#10B981"),
        (3, "Tab 3: backup_graph/_graph.py (Final)", 850, "#F59E0B"),
    ]

    for tab_num, label, x_pos, active_color in tabs_info:
        is_active = (tab_num == ACTIVE_TAB)
        bg_color = active_color if is_active else "#1E293B"
        text_color = "#FFFFFF" if is_active else "#94A3B8"
        btn_ip = f"tab_btn_{tab_num}"
        txt_ip = f"tab_txt_{tab_num}"

        Draw.shapes(
            display=WIN,
            shape=[{
                "ip": btn_ip,
                "vertices": 4,
                "x": x_pos,
                "y": 95,
                "size": [410, 42],
                "color": bg_color,
                "border_color": active_color if is_active else "#334155",
                "border_width": 2 if is_active else 1,
                "border_radius": 8,
                "z": 80000,
            }]
        )

        Draw.text(
            display=WIN,
            ip=txt_ip,
            text=label,
            x=x_pos + 20,
            y=108,
            color=text_color,
            font_size=13,
            bold=is_active,
        )

        _wire_tab_click(btn_ip, tab_num)


def _wire_tab_click(btn_ip: str, tab_num: int):
    """Attach interactive click listener to tab button using Draw senses & connectors."""
    try:
        click_sense = Draw.senses("click", ip=btn_ip)
        Draw.connectors(
            from_ip=btn_ip,
            sense=click_sense,
            work=lambda _rec, t=tab_num: switch_tab(t)
        )
    except Exception:
        pass


def clear_active_scene():
    """Clear all active graph, shape, and text items from the canvas."""
    Draw.shapes.clear(WIN)
    Draw.text.clear(WIN)
    for engine in (graph_engine_1, graph_engine_2, graph_engine_3):
        try:
            engine.clear(WIN)
        except Exception:
            pass
    _render_background_and_header()
    _render_tab_buttons()


def switch_tab(tab_num: int):
    """Switch active tab and render corresponding engine charts."""
    global ACTIVE_TAB
    if ACTIVE_TAB == tab_num:
        return
    ACTIVE_TAB = tab_num
    render_current_tab()


def render_tab_1():
    """Tab 1: Render charts using graph.py (3-step Qt delegation engine)."""
    clear_active_scene()

    # Section Banner
    Draw.text(
        display=WIN,
        ip="tab1_banner",
        text="⚡ TAB 1: Powered by Draw.graph (graph.py — Modern Qt Delegation Engine)",
        x=30,
        y=155,
        color="#60A5FA",
        font_size=14,
        bold=True,
    )

    # 1. Bar & Line Chart (Sales & Profit) - Top Left
    graph_engine_1(
        ip="tab1_sales_bar",
        type="bar",
        tag=WIN,
        x=30,
        y=190,
        width=590,
        height=300,
        draggable=True,
        graph=[
            {
                "x": ["Q1", "Q2", "Q3", "Q4"],
                "y": [180, 290, 240, 380],
                "title": "Revenue ($K)",
                "customise": {
                    "color": "#3B82F6",
                    "title": "Quarterly Financial Overview (Draggable)",
                    "title_color": "#93C5FD",
                    "x_title": "Quarter",
                    "y_title": "Amount ($K)",
                    "show_line": True,
                    "show_values": True,
                    "show_legend": True,
                }
            },
            {
                "x": ["Q1", "Q2", "Q3", "Q4"],
                "y": [75, 130, 110, 195],
                "type": "line",
                "title": "Net Profit ($K)",
                "customise": {
                    "line_color": "#10B981",
                    "line_width": 4,
                    "smooth": True,
                }
            }
        ]
    )

    # 2. Donut Chart (Traffic Share) - Top Right
    graph_engine_1(
        ip="tab1_traffic_donut",
        type="donut",
        tag=WIN,
        x=650,
        y=190,
        width=590,
        height=300,
        draggable=True,
        graph=[
            {
                "x": ["Organic", "Direct", "Referral", "Social"],
                "y": [45, 30, 15, 10],
                "title": "Traffic Sources",
                "customise": {
                    "color": ["#6366F1", "#10B981", "#F59E0B", "#EC4899"],
                    "title": "Channel Share (Donut)",
                    "title_color": "#A7F3D0",
                    "center_text": "100%",
                    "hole_color": "#0B0F17",
                    "show_legend": True,
                }
            }
        ]
    )

    # 3. Radar Chart (System Audit) - Bottom Left
    graph_engine_1(
        ip="tab1_system_radar",
        type="radar",
        tag=WIN,
        x=30,
        y=510,
        width=590,
        height=290,
        draggable=True,
        graph=[
            {
                "x": ["Performance", "Security", "Uptime", "Scaling", "UX"],
                "y": [92, 98, 99, 88, 95],
                "title": "Audit 2026",
                "customise": {
                    "color": "#8B5CF6",
                    "title": "System Audit Score (Radar)",
                    "title_color": "#DDD6FE",
                    "spider_levels": 5,
                }
            }
        ]
    )


def render_tab_2():
    """Tab 2: Render charts using Draw._graph (_graph.py)."""
    clear_active_scene()

    # Section Banner
    Draw.text(
        display=WIN,
        ip="tab2_banner",
        text="🌿 TAB 2: Powered by Draw._graph (_graph.py — Comprehensive Chart Engine)",
        x=30,
        y=155,
        color="#34D399",
        font_size=14,
        bold=True,
    )

    # 1. Stacked Bar Chart - Top Left
    graph_engine_2(
        ip="tab2_stacked_bar",
        type="stacked_bar",
        tag=WIN,
        x=30,
        y=190,
        width=590,
        height=300,
        graph=[
            {
                "x": ["Product A", "Product B", "Product C"],
                "y": [120, 210, 160],
                "title": "Region North",
                "customise": {
                    "color": "#10B981",
                    "title": "Regional Product Sales (Stacked Bar)",
                    "title_color": "#6EE7B7",
                    "show_line": True,
                    "show_legend": True,
                }
            },
            {
                "x": ["Product A", "Product B", "Product C"],
                "y": [90, 150, 110],
                "title": "Region South",
                "customise": {
                    "color": "#F59E0B",
                }
            }
        ]
    )

    # 2. Area Chart - Top Right
    graph_engine_2(
        ip="tab2_area_chart",
        type="area",
        tag=WIN,
        x=650,
        y=190,
        width=590,
        height=300,
        graph=[
            {
                "x": ["Mon", "Tue", "Wed", "Thu", "Fri"],
                "y": [35, 60, 45, 80, 95],
                "title": "Active Users",
                "customise": {
                    "color": "#06B6D4",
                    "title": "Daily Active Users (Area Chart)",
                    "title_color": "#67E8F9",
                    "area_opacity": 50,
                    "smooth": True,
                    "show_line": True,
                }
            }
        ]
    )

    # 3. Pie Chart - Bottom Left
    graph_engine_2(
        ip="tab2_pie_chart",
        type="pie",
        tag=WIN,
        x=30,
        y=510,
        width=590,
        height=290,
        graph=[
            {
                "x": ["Mobile", "Desktop", "Tablet"],
                "y": [55, 35, 10],
                "title": "Device Distribution",
                "customise": {
                    "color": ["#EC4899", "#8B5CF6", "#3B82F6"],
                    "title": "Device Breakdown (Pie Chart)",
                    "title_color": "#F472B6",
                    "show_values": True,
                }
            }
        ]
    )


def render_tab_3():
    """Tab 3: Render charts using backup_graph/_graph.py (Final Baseline Comparison)."""
    clear_active_scene()

    # Section Banner
    Draw.text(
        display=WIN,
        ip="tab3_banner",
        text="🔥 TAB 3: Powered by backup_graph/_graph.py (Final Baseline Engine)",
        x=30,
        y=155,
        color="#FBBF24",
        font_size=14,
        bold=True,
    )

    # 1. Multi-Series Bar Chart - Top Left
    graph_engine_3(
        ip="tab3_baseline_bar",
        type="bar",
        tag=WIN,
        x=30,
        y=190,
        width=590,
        height=300,
        graph=[
            {
                "x": ["2023", "2024", "2025", "2026"],
                "y": [300, 450, 620, 890],
                "title": "ARR Growth ($K)",
                "customise": {
                    "color": "#F59E0B",
                    "title": "Annual Recurring Revenue (Backup Baseline)",
                    "title_color": "#FDE047",
                    "show_line": True,
                    "show_values": True,
                    "show_legend": True,
                }
            }
        ]
    )

    # 2. Donut Chart with Center Text - Top Right
    graph_engine_3(
        ip="tab3_baseline_donut",
        type="donut",
        tag=WIN,
        x=650,
        y=190,
        width=590,
        height=300,
        graph=[
            {
                "x": ["Completed", "In Progress", "Pending"],
                "y": [70, 20, 10],
                "title": "Tasks",
                "customise": {
                    "color": ["#10B981", "#3B82F6", "#EF4444"],
                    "title": "Project Completion Status (Backup Donut)",
                    "title_color": "#A7F3D0",
                    "center_text": "70% DONE",
                    "hole_color": "#0B0F17",
                }
            }
        ]
    )

    # 3. Dot / Scatter Plot - Bottom Left
    graph_engine_3(
        ip="tab3_baseline_dot",
        type="dot",
        tag=WIN,
        x=30,
        y=510,
        width=590,
        height=290,
        graph=[
            {
                "x": ["P1", "P2", "P3", "P4", "P5"],
                "y": [15, 38, 24, 49, 62],
                "title": "Cluster A",
                "customise": {
                    "color": "#EF4444",
                    "title": "Scatter Distribution (Backup Dot)",
                    "title_color": "#FCA5A5",
                    "point_size": 14,
                    "show_line": True,
                }
            }
        ]
    )


def render_current_tab():
    """Render the currently active tab."""
    if ACTIVE_TAB == 1:
        render_tab_1()
    elif ACTIVE_TAB == 2:
        render_tab_2()
    elif ACTIVE_TAB == 3:
        render_tab_3()


def main():
    _render_background_and_header()
    _render_tab_buttons()
    render_current_tab()

    print("\n========================================================")
    print("🚀 Draw Framework 3-Engine Graph Comparison App Ready!")
    print("Tab 1 -> Draw.graph (graph.py)")
    print("Tab 2 -> Draw._graph (_graph.py)")
    print("Tab 3 -> backup_graph/_graph.py (Final Baseline)")
    print("========================================================\n")

    Draw.window.run(WIN)


if __name__ == "__main__":
    main()
