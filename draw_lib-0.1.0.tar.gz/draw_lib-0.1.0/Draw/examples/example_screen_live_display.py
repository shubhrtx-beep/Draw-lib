"""
Example: Draw.screen Live Display & Interaction Surface

Demonstrates:
1. Creating a Draw.screen live display surface.
2. Streaming host frames (QImage, numpy-compatible buffers, pixel buffers).
3. Receiving real-time mouse/touch coordinates and interactions.
4. Drawing mode: host stores points and draws lines onto its buffer while Draw.screen
   simply displays the frames and streams user interaction.
"""
import os ,sys
REPO_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)
import math
import time
from PySide6.QtGui import QImage, QPainter, QPen, QColor, QBrush
from PySide6.QtCore import Qt, QPointF

import Draw

def main():
    # 1. Create main host window
    win = Draw.window(
        tag="display_demo",
        title="Draw.screen Live Display Demo",
        width=900,
        height=700,
        background_color="#181825",
    )

    # 2. Create the Draw.screen live display surface
    scr = Draw.screen(
        ip="live_viewport",
        size=[800, 600],
        align="center",
        display="display_demo",
        drawing_mode=True,
    )

    # 3. Host manages the frame buffer (Draw.screen never owns data or renders shapes)
    host_buffer = QImage(800, 600, QImage.Format.Format_RGB888)
    host_buffer.fill(QColor("#11111b"))
    last_point = None

    # 4. Host drawing mode handlers
    @scr.on("mouse_down")
    def on_down(x, y, btn="left"):
        nonlocal last_point
        last_point = (x, y)

    @scr.on("mouse_move")
    def on_move(x, y, btn="left"):
        nonlocal last_point
        if last_point is not None:
            # Host draws onto its own buffer
            painter = QPainter(host_buffer)
            pen = QPen(QColor("#89b4fa"), 4, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin)
            painter.setPen(pen)
            painter.drawLine(QPointF(last_point[0], last_point[1]), QPointF(x, y))
            painter.end()

            last_point = (x, y)
            # Host sends updated frame to Draw.screen
            scr.update(host_buffer)

    @scr.on("mouse_up")
    def on_up(x, y, btn="left"):
        nonlocal last_point
        last_point = None

    # Initial frame update
    scr.update(host_buffer)

    print("Draw.screen demo initialized. Screen size:", scr.size)
    Draw.window.run()

if __name__ == "__main__":
    main()
