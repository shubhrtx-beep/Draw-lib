"""
examples/test_motion_window.py
==============================
Draw.motion Studio & Comprehensive Interactive Test Window
----------------------------------------------------------
Features:
- Leftmost Pane: Interactive 60 FPS Motion Screen (Stage) with small yellow ball,
  live motion guides, trajectory preview, particle trail, coordinate grid, and HUD.
- Rightmost Pane: Control Panel with Category Filter Buttons, Dropdown Motion Menu,
  Dynamic Contextual Parameter Sliders, Universal Speed/Size Controls, Playback Actions,
  Quick Presets, and Live Mathematical Telemetry.
- Full test coverage for all 38+ motion types in Draw._motion (Analytical Physics O(1),
  Procedural Curves, Kinematics & Easings, Bezier Paths, AST Solvers, 3D Transforms,
  Visual FX, Multi-Ball Timelines, and Custom Callbacks).

Run with:
    D:/python/python.exe examples/test_motion_window.py
"""

from __future__ import annotations

import math
import os
import sys
import time
from typing import Any, Callable, Dict, List, Optional, Tuple

# Ensure workspace root and parent root are on sys.path
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
WORKSPACE_ROOT = os.path.dirname(SCRIPT_DIR)
PARENT_ROOT = os.path.dirname(WORKSPACE_ROOT)
for path in (PARENT_ROOT, WORKSPACE_ROOT):
    if path not in sys.path:
        sys.path.insert(0, path)

import Draw
from Draw._motion import (
    MotionRecord,
    MotionRegistry,
    DrawExprSolver,
    Timeline,
    solve_spring,
    solve_gravity_bounce,
    solve_projectile_2d,
    solve_inertia,
    solve_pendulum,
    solve_attractor_2d,
    solve_stretch_squash,
    solve_cubic_bezier,
    solve_wiggle,
    solve_wave,
    solve_lissajous,
    solve_spiral,
    solve_polygon_orbit,
    sample_polyline_at,
    resolve_motion_path_vertices,
    resolve_morph_vertices,
    shape_spec_to_path,
    path_to_vertices,
)
from Draw._colour import _parse_color

from PySide6.QtCore import QPointF, QRectF, QSize, Qt, QTimer
from PySide6.QtGui import (
    QBrush,
    QColor,
    QFont,
    QLinearGradient,
    QPainter,
    QPainterPath,
    QPen,
    QPolygonF,
    QRadialGradient,
)
from PySide6.QtWidgets import (
    QApplication,
    QButtonGroup,
    QCheckBox,
    QComboBox,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QPushButton,
    QScrollArea,
    QSlider,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)


# ══════════════════════════════════════════════════════════════════════════════
# Motion Catalog & Specification Definitions (All 38+ Types)
# ══════════════════════════════════════════════════════════════════════════════

CATEGORIES = [
    ("all", "All (38+)"),
    ("physics", "Physics (O(1))"),
    ("procedural", "Procedural & Curves"),
    ("kinematics", "Kinematics & Easing"),
    ("paths", "Paths & Expressions"),
    ("transforms", "3D & Transforms"),
    ("styling", "Visual FX & Color"),
    ("timeline", "Timelines & Custom"),
]

EASING_FUNCTIONS = [
    "linear",
    "ease_in",
    "ease_out",
    "ease_in_out",
    "ease_in_cubic",
    "ease_out_cubic",
    "ease_in_out_cubic",
    "ease_in_quart",
    "ease_out_quart",
    "ease_in_out_quart",
    "ease_in_quint",
    "ease_out_quint",
    "ease_in_out_quint",
    "ease_in_expo",
    "ease_out_expo",
    "ease_in_out_expo",
    "ease_in_circ",
    "ease_out_circ",
    "ease_in_out_circ",
    "ease_in_back",
    "ease_out_back",
    "ease_in_out_back",
    "ease_in_elastic",
    "ease_out_elastic",
    "ease_in_out_elastic",
    "ease_in_bounce",
    "ease_out_bounce",
    "ease_in_out_bounce",
]

MOTION_SPECS: List[Dict[str, Any]] = [
    # ── 1. Analytical Physics ──────────────────────────────────────────────────
    {
        "id": "spring",
        "name": "Spring Kinetics (2nd-Order Harmonic)",
        "category": "physics",
        "type": "spring",
        "description": "Exact O(1) damped harmonic oscillator: underdamped, critical & overdamped regimes.",
        "formula": "m*d²x/dt² + c*dx/dt + k*x = 0",
        "params": [
            {"id": "stiffness", "label": "Stiffness (k)", "min": 20, "max": 1000, "default": 280, "step": 10, "unit": "N/m"},
            {"id": "damping", "label": "Damping (c)", "min": 1, "max": 60, "default": 14, "step": 1, "unit": "N·s/m"},
            {"id": "mass", "label": "Mass (m)", "min": 1, "max": 50, "default": 10, "scale": 0.1, "unit": "kg"},
            {"id": "distance", "label": "Displacement (dx)", "min": 40, "max": 350, "default": 180, "step": 10, "unit": "px"},
            {"id": "v0", "label": "Initial Velocity (v0)", "min": -500, "max": 500, "default": 0, "step": 25, "unit": "px/s"},
        ],
    },
    {
        "id": "gravity",
        "name": "Gravity & Ground Bounce (Analytical)",
        "category": "physics",
        "type": "gravity",
        "description": "O(1) closed-form vertical gravity with coefficient of restitution ground bounce.",
        "formula": "y(t) = y0 + v0*t + 0.5*g*t²; v' = -e*v",
        "params": [
            {"id": "g", "label": "Gravity Acceleration (g)", "min": 100, "max": 3000, "default": 980, "step": 50, "unit": "px/s²"},
            {"id": "restitution", "label": "Restitution (e)", "min": 10, "max": 98, "default": 76, "scale": 0.01, "unit": ""},
            {"id": "drop_height", "label": "Drop Height", "min": 50, "max": 450, "default": 260, "step": 10, "unit": "px"},
            {"id": "v0", "label": "Initial Velocity (v0)", "min": -600, "max": 600, "default": 0, "step": 25, "unit": "px/s"},
        ],
    },
    {
        "id": "projectile",
        "name": "2D Parabolic Ballistics (Drag & Walls)",
        "category": "physics",
        "type": "projectile",
        "description": "2D ballistics with quadratic air drag, floor bounces, and wall reflections.",
        "formula": "dx/dt = vx0*e^(-d*t), dy/dt = vy0*e^(-d*t) + (g/d)*(1-e^(-d*t))",
        "params": [
            {"id": "vx0", "label": "Launch Speed Vx0", "min": 50, "max": 600, "default": 240, "step": 10, "unit": "px/s"},
            {"id": "vy0", "label": "Launch Speed Vy0", "min": 100, "max": 800, "default": 420, "step": 20, "negate": True, "unit": "px/s"},
            {"id": "g", "label": "Gravity (g)", "min": 200, "max": 2500, "default": 850, "step": 50, "unit": "px/s²"},
            {"id": "drag", "label": "Air Drag Coeff (d)", "min": 0, "max": 10, "default": 2, "scale": 0.01, "unit": ""},
            {"id": "restitution", "label": "Restitution (e)", "min": 20, "max": 95, "default": 75, "scale": 0.01, "unit": ""},
        ],
    },
    {
        "id": "inertia",
        "name": "Kinetic Inertia & Boundary Drag",
        "category": "physics",
        "type": "inertia",
        "description": "Exponential momentum decay with left and right wall boundary clamp.",
        "formula": "v(t) = v0 * f^t, x(t) = x0 + v0 * (1 - f^t) / (-ln f)",
        "params": [
            {"id": "velocity", "label": "Impulse Velocity (v0)", "min": 100, "max": 1500, "default": 650, "step": 50, "unit": "px/s"},
            {"id": "friction", "label": "Friction Retention (f)", "min": 80, "max": 99, "default": 94, "scale": 0.01, "unit": ""},
            {"id": "distance", "label": "Travel Span", "min": 100, "max": 400, "default": 240, "step": 20, "unit": "px"},
        ],
    },
    {
        "id": "pendulum",
        "name": "Damped Pendulum Oscillation",
        "category": "physics",
        "type": "pendulum",
        "description": "Harmonic angular decay simulation with string suspension and pivot point.",
        "formula": "θ(t) = θ0 * e^(-γ*t) * cos(2π*f*t)",
        "params": [
            {"id": "amplitude", "label": "Max Amplitude (θ0)", "min": 10, "max": 85, "default": 48, "step": 1, "unit": "°"},
            {"id": "frequency", "label": "Frequency (f)", "min": 2, "max": 40, "default": 14, "scale": 0.1, "unit": "Hz"},
            {"id": "damping", "label": "Damping Factor (γ)", "min": 0, "max": 100, "default": 18, "scale": 0.01, "unit": ""},
            {"id": "arm_length", "label": "Arm Length", "min": 80, "max": 300, "default": 180, "step": 10, "unit": "px"},
        ],
    },
    {
        "id": "attractor",
        "name": "Attractor & Magnetic Pull",
        "category": "physics",
        "type": "attractor",
        "description": "Exponential asymptotic pull towards an interactive target position.",
        "formula": "r(t) = r_target + (r0 - r_target) * e^(-k*t)",
        "params": [
            {"id": "strength", "label": "Attraction Strength (k)", "min": 1, "max": 100, "default": 45, "scale": 0.1, "unit": ""},
            {"id": "offset_x", "label": "Target Offset X", "min": -250, "max": 250, "default": 140, "step": 10, "unit": "px"},
            {"id": "offset_y", "label": "Target Offset Y", "min": -180, "max": 180, "default": -60, "step": 10, "unit": "px"},
        ],
    },

    # ── 2. Procedural & Parametric Curves ──────────────────────────────────────
    {
        "id": "wave",
        "name": "Sinusoidal Wave Bobbing",
        "category": "procedural",
        "type": "wave",
        "description": "Harmonic sinusoidal displacement with adjustable frequency, amplitude & phase.",
        "formula": "y(t) = y0 + A * sin(2π*f*t + φ)",
        "params": [
            {"id": "frequency", "label": "Wave Frequency (f)", "min": 2, "max": 80, "default": 22, "scale": 0.1, "unit": "Hz"},
            {"id": "amplitude", "label": "Wave Amplitude (A)", "min": 5, "max": 180, "default": 65, "step": 5, "unit": "px"},
            {"id": "phase", "label": "Phase Offset (φ)", "min": 0, "max": 360, "default": 0, "step": 15, "unit": "°"},
        ],
    },
    {
        "id": "wiggle",
        "name": "Simplex Noise 2D Wiggle (Shake)",
        "category": "procedural",
        "type": "wiggle",
        "description": "Multi-octave continuous 2D simplex/pseudo-random Brownian jitter.",
        "formula": "dx, dy = SimplexNoise2D(t * f, octaves) * A",
        "params": [
            {"id": "frequency", "label": "Jitter Frequency", "min": 10, "max": 150, "default": 45, "scale": 0.1, "unit": "Hz"},
            {"id": "amplitude", "label": "Jitter Amplitude", "min": 4, "max": 120, "default": 42, "step": 2, "unit": "px"},
            {"id": "octaves", "label": "Noise Octaves", "min": 1, "max": 4, "default": 2, "step": 1, "unit": ""},
        ],
    },
    {
        "id": "pulse",
        "name": "Dynamic Pulse & Breathing",
        "category": "procedural",
        "type": "pulse",
        "description": "Periodic harmonic scale breathing and expansion.",
        "formula": "Scale(t) = 1.0 + (A / 100) * sin(2π*f*t)",
        "params": [
            {"id": "frequency", "label": "Pulse Rate (f)", "min": 5, "max": 60, "default": 25, "scale": 0.1, "unit": "Hz"},
            {"id": "amplitude", "label": "Scale Amplitude (%)", "min": 10, "max": 150, "default": 60, "step": 5, "unit": "%"},
        ],
    },
    {
        "id": "stretch_squash",
        "name": "Area-Preserving Squash & Stretch",
        "category": "procedural",
        "type": "stretch_squash",
        "description": "Non-linear elastic deformation maintaining volume: Sy = 1 / Sx.",
        "formula": "Sx(t) = 1 + A*e^(-γ*t)*sin(ω*t), Sy(t) = 1 / Sx(t)",
        "params": [
            {"id": "amplitude", "label": "Squash Intensity (A)", "min": 10, "max": 90, "default": 45, "scale": 0.01, "unit": ""},
            {"id": "frequency", "label": "Oscillation Freq", "min": 5, "max": 50, "default": 22, "scale": 0.1, "unit": "Hz"},
            {"id": "damping", "label": "Damping Rate (γ)", "min": 0, "max": 20, "default": 5, "scale": 0.1, "unit": ""},
        ],
    },
    {
        "id": "orbit",
        "name": "Circular & Polygon Orbit (Benzene)",
        "category": "procedural",
        "type": "orbit",
        "description": "Orbital traversal along circles, hexagons (benzene ring), or custom N-gons.",
        "formula": "P(t) = PolygonVertex(sides, radius, 2π*f*t)",
        "params": [
            {"id": "radius", "label": "Orbit Radius (R)", "min": 30, "max": 300, "default": 140, "step": 5, "unit": "px"},
            {"id": "sides", "label": "Polygon Sides (0=Circle)", "min": 0, "max": 12, "default": 6, "step": 1, "unit": ""},
            {"id": "frequency", "label": "Orbital Speed (f)", "min": 2, "max": 40, "default": 8, "scale": 0.1, "unit": "Hz"},
        ],
    },
    {
        "id": "lissajous",
        "name": "Parametric Lissajous Knot (3:2)",
        "category": "procedural",
        "type": "lissajous",
        "description": "Complex 2D harmonic motion knot with independent frequencies & phase difference.",
        "formula": "x = Ax*sin(2π*fx*t + φx), y = Ay*sin(2π*fy*t + φy)",
        "params": [
            {"id": "amplitude_x", "label": "Amplitude X (Ax)", "min": 30, "max": 300, "default": 180, "step": 10, "unit": "px"},
            {"id": "amplitude_y", "label": "Amplitude Y (Ay)", "min": 30, "max": 250, "default": 110, "step": 10, "unit": "px"},
            {"id": "freq_x", "label": "Frequency X (fx)", "min": 1, "max": 8, "default": 3, "step": 1, "unit": "Hz"},
            {"id": "freq_y", "label": "Frequency Y (fy)", "min": 1, "max": 8, "default": 2, "step": 1, "unit": "Hz"},
            {"id": "phase_y", "label": "Phase Shift (φy)", "min": 0, "max": 180, "default": 90, "step": 15, "unit": "°"},
        ],
    },
    {
        "id": "spiral",
        "name": "Archimedean & Logarithmic Spiral",
        "category": "procedural",
        "type": "spiral",
        "description": "Expanding spiral orbit with linear (Archimedean) or exponential growth.",
        "formula": "r(θ) = a + b*θ, θ = 2π*f*t",
        "params": [
            {"id": "a", "label": "Inner Radius (a)", "min": 0, "max": 60, "default": 10, "step": 2, "unit": "px"},
            {"id": "b", "label": "Spiral Expansion (b)", "min": 2, "max": 30, "default": 12, "step": 1, "unit": "px/rad"},
            {"id": "frequency", "label": "Rotation Speed (f)", "min": 2, "max": 30, "default": 8, "scale": 0.1, "unit": "Hz"},
            {"id": "logarithmic", "label": "Logarithmic Mode", "min": 0, "max": 1, "default": 0, "step": 1, "unit": ""},
        ],
    },

    # ── 3. Kinematics & Easing Functions ───────────────────────────────────────
    {
        "id": "move",
        "name": "Linear & Eased Interpolation",
        "category": "kinematics",
        "type": "move",
        "description": "Deterministic point-to-point motion with selectable easing curves.",
        "formula": "P(t) = P_start + Easing(t / duration) * (P_end - P_start)",
        "params": [
            {"id": "duration", "label": "Duration (s)", "min": 3, "max": 60, "default": 20, "scale": 0.1, "unit": "s"},
            {"id": "distance", "label": "Travel Distance", "min": 50, "max": 500, "default": 280, "step": 10, "unit": "px"},
            {"id": "easing_idx", "label": "Easing Function Index", "min": 0, "max": len(EASING_FUNCTIONS) - 1, "default": 6, "step": 1, "is_easing": True},
        ],
    },
    {
        "id": "x",
        "name": "1D Horizontal Axis Motion (x)",
        "category": "kinematics",
        "type": "x",
        "description": "Independent 1D X-axis translation with spring / cubic bounce easing.",
        "formula": "x(t) = x_from + Graph(t) * (x_to - x_from)",
        "params": [
            {"id": "duration", "label": "Duration (s)", "min": 3, "max": 50, "default": 18, "scale": 0.1, "unit": "s"},
            {"id": "span_x", "label": "Horizontal Span", "min": 60, "max": 480, "default": 300, "step": 10, "unit": "px"},
        ],
    },
    {
        "id": "y",
        "name": "1D Vertical Axis Motion (y)",
        "category": "kinematics",
        "type": "y",
        "description": "Independent 1D Y-axis translation with elastic bounce curves.",
        "formula": "y(t) = y_from + Graph(t) * (y_to - y_from)",
        "params": [
            {"id": "duration", "label": "Duration (s)", "min": 3, "max": 50, "default": 18, "scale": 0.1, "unit": "s"},
            {"id": "span_y", "label": "Vertical Span", "min": 40, "max": 360, "default": 220, "step": 10, "unit": "px"},
        ],
    },

    # ── 4. Paths, Keyframes & Expressions ──────────────────────────────────────
    {
        "id": "path",
        "name": "SVG Polyline & Bezier Follower",
        "category": "paths",
        "type": "path",
        "description": "Traverses complex cubic bezier paths with automatic heading rotation.",
        "formula": "B(u) = (1-u)³P0 + 3(1-u)²uP1 + 3(1-u)u²P2 + u³P3; heading = atan2(dy, dx)",
        "params": [
            {"id": "duration", "label": "Traversal Time", "min": 10, "max": 80, "default": 30, "scale": 0.1, "unit": "s"},
            {"id": "orient", "label": "Auto-Orient Heading", "min": 0, "max": 1, "default": 1, "step": 1, "unit": ""},
            {"id": "path_preset", "label": "Path Preset (0-3)", "min": 0, "max": 3, "default": 0, "step": 1, "unit": ""},
        ],
    },
    {
        "id": "keyframes",
        "name": "Multi-Point Keyframe Trajectory",
        "category": "paths",
        "type": "keyframes",
        "description": "Multi-segment keyframed curve path with bezier control handles.",
        "formula": "SplineInterpolation(K0, K1, K2, K3, K4, t)",
        "params": [
            {"id": "duration", "label": "Cycle Duration", "min": 15, "max": 80, "default": 35, "scale": 0.1, "unit": "s"},
            {"id": "radius_scale", "label": "Path Scale", "min": 50, "max": 200, "default": 120, "step": 10, "unit": "%"},
        ],
    },
    {
        "id": "morph",
        "name": "Polygon Vertex Morphing",
        "category": "paths",
        "type": "morph",
        "description": "Real-time morphing of the yellow ball into stars, hexagons, and polygons.",
        "formula": "V(t) = (1 - t)*V_circle + t*V_star",
        "params": [
            {"id": "duration", "label": "Morph Duration", "min": 5, "max": 50, "default": 20, "scale": 0.1, "unit": "s"},
            {"id": "target_shape", "label": "Target (0=Star,1=Hex,2=Tri,3=Oct)", "min": 0, "max": 3, "default": 0, "step": 1, "unit": ""},
        ],
    },
    {
        "id": "solver",
        "name": "AST Sandboxed Math Expression",
        "category": "paths",
        "type": "vertices",
        "description": "Sandboxed Python AST mathematical formula evaluated live every frame.",
        "formula": "x = cx + sin(t*3)*160; y = cy + cos(t*2)*80",
        "params": [
            {"id": "expr_preset", "label": "Formula Preset (0-3)", "min": 0, "max": 3, "default": 0, "step": 1, "unit": ""},
            {"id": "speed", "label": "Time Multiplier", "min": 2, "max": 40, "default": 10, "scale": 0.1, "unit": "x"},
        ],
    },

    # ── 5. 3D Transforms & Deformations ────────────────────────────────────────
    {
        "id": "rotate",
        "name": "2D Continuous Rotation",
        "category": "transforms",
        "type": "rotate",
        "description": "Continuous 2D rotation with adjustable pivot and angular speed.",
        "formula": "θ(t) = θ_start + (360° / duration) * t",
        "params": [
            {"id": "duration", "label": "Rotation Speed (s/rev)", "min": 5, "max": 60, "default": 20, "scale": 0.1, "unit": "s"},
            {"id": "orbit_offset", "label": "Pivot Arm Offset", "min": 0, "max": 120, "default": 0, "step": 5, "unit": "px"},
        ],
    },
    {
        "id": "rotate_3d",
        "name": "3D Perspective Pitch & Yaw",
        "category": "transforms",
        "type": "rotate_3d",
        "description": "3D projective matrix transformation simulating 3D sphere/disc rotation.",
        "formula": "M_3d = Perspective(d) * RotX(θx) * RotY(θy)",
        "params": [
            {"id": "rotate_x", "label": "Max Pitch (Rot X)", "min": 0, "max": 75, "default": 45, "step": 5, "unit": "°"},
            {"id": "rotate_y", "label": "Max Yaw (Rot Y)", "min": 0, "max": 80, "default": 60, "step": 5, "unit": "°"},
            {"id": "duration", "label": "Cycle Time", "min": 8, "max": 50, "default": 24, "scale": 0.1, "unit": "s"},
        ],
    },
    {
        "id": "scale",
        "name": "Anisotropic 2D Scale / Size",
        "category": "transforms",
        "type": "scale",
        "description": "Independent horizontal and vertical scale expansion.",
        "formula": "Sx(t) = Sx0 + t*(Sx1 - Sx0), Sy(t) = Sy0 + t*(Sy1 - Sy0)",
        "params": [
            {"id": "scale_x", "label": "Max Scale X (%)", "min": 20, "max": 350, "default": 220, "step": 10, "unit": "%"},
            {"id": "scale_y", "label": "Max Scale Y (%)", "min": 20, "max": 350, "default": 70, "step": 10, "unit": "%"},
            {"id": "duration", "label": "Cycle Duration", "min": 5, "max": 40, "default": 16, "scale": 0.1, "unit": "s"},
        ],
    },
    {
        "id": "skew",
        "name": "Affine Matrix Skew & Shear",
        "category": "transforms",
        "type": "skew",
        "description": "2D affine matrix shearing deformation along X and Y axes.",
        "formula": "[x', y'] = [x + y*tan(α), y + x*tan(β)]",
        "params": [
            {"id": "skew_x", "label": "Shear Angle X", "min": -45, "max": 45, "default": 30, "step": 2, "unit": "°"},
            {"id": "skew_y", "label": "Shear Angle Y", "min": -45, "max": 45, "default": 0, "step": 2, "unit": "°"},
            {"id": "duration", "label": "Cycle Duration", "min": 5, "max": 40, "default": 18, "scale": 0.1, "unit": "s"},
        ],
    },

    # ── 6. Visual Styling & Color FX ───────────────────────────────────────────
    {
        "id": "color",
        "name": "Dynamic Color Shift & Neon Hue",
        "category": "styling",
        "type": "color",
        "description": "Live RGB color interpolation: golden yellow to fiery crimson and cyan.",
        "formula": "C(t) = LerpRGBA(C_start, C_end, t)",
        "params": [
            {"id": "duration", "label": "Transition Time", "min": 5, "max": 40, "default": 18, "scale": 0.1, "unit": "s"},
            {"id": "palette_idx", "label": "Color Target (0=Red,1=Cyan,2=Purple,3=Green)", "min": 0, "max": 3, "default": 0, "step": 1, "unit": ""},
        ],
    },
    {
        "id": "glow",
        "name": "Pulsating Glow & Bloom",
        "category": "styling",
        "type": "glow",
        "description": "Dynamic radial bloom glow with variable radius and intensity.",
        "formula": "GlowRadius(t) = R_min + (R_max - R_min)*sin²(π*f*t)",
        "params": [
            {"id": "max_radius", "label": "Max Glow Radius", "min": 10, "max": 60, "default": 32, "step": 2, "unit": "px"},
            {"id": "frequency", "label": "Glow Pulse Speed", "min": 5, "max": 50, "default": 20, "scale": 0.1, "unit": "Hz"},
        ],
    },
    {
        "id": "opacity",
        "name": "Ghost Opacity & Blur Fading",
        "category": "styling",
        "type": "opacity",
        "description": "Dynamic alpha transparency fading and gaussian blur depth-of-field.",
        "formula": "Alpha(t) = A_min + (A_max - A_min)*t, Blur(t) = B_max*(1 - t)",
        "params": [
            {"id": "min_opacity", "label": "Min Opacity (%)", "min": 5, "max": 90, "default": 20, "step": 5, "unit": "%"},
            {"id": "max_blur", "label": "Max Blur Depth", "min": 0, "max": 25, "default": 12, "step": 1, "unit": "px"},
            {"id": "duration", "label": "Fade Duration", "min": 5, "max": 40, "default": 16, "scale": 0.1, "unit": "s"},
        ],
    },

    # ── 7. Timelines & Custom Callbacks ────────────────────────────────────────
    {
        "id": "timeline",
        "name": "Orchestrated Multi-Ball Timeline",
        "category": "timeline",
        "type": "timeline",
        "description": "Draw.timeline orchestration: staggered wave across multiple yellow balls.",
        "formula": "Target_i(t) = Motion(t - i * stagger_delay)",
        "params": [
            {"id": "ball_count", "label": "Yellow Balls Count", "min": 2, "max": 7, "default": 4, "step": 1, "unit": ""},
            {"id": "stagger", "label": "Stagger Delay", "min": 5, "max": 60, "default": 20, "scale": 0.01, "unit": "s"},
            {"id": "amplitude", "label": "Wave Amplitude", "min": 20, "max": 120, "default": 60, "step": 5, "unit": "px"},
        ],
    },
    {
        "id": "custom",
        "name": "Custom Parametric Callback (Lemniscate)",
        "category": "timeline",
        "type": "custom",
        "description": "Draw.custom.motion: Bernoulli Lemniscate (Figure-8 Infinity ∞ curve).",
        "formula": "x = (a*cos(t)) / (1 + sin²(t)), y = (a*sin(t)*cos(t)) / (1 + sin²(t))",
        "params": [
            {"id": "size", "label": "Curve Scale (a)", "min": 50, "max": 300, "default": 180, "step": 10, "unit": "px"},
            {"id": "duration", "label": "Loop Duration", "min": 10, "max": 80, "default": 32, "scale": 0.1, "unit": "s"},
            {"id": "preset_type", "label": "Curve (0=Infinity, 1=Cardioid, 2=Astroid)", "min": 0, "max": 2, "default": 0, "step": 1, "unit": ""},
        ],
    },
]


# ══════════════════════════════════════════════════════════════════════════════
# Left Pane: Interactive Motion Screen (Stage Canvas)
# ══════════════════════════════════════════════════════════════════════════════

class MotionScreenWidget(QWidget):
    """
    High-performance interactive motion canvas displaying the yellow ball,
    motion trail, physics guides, and live HUD overlay.
    """

    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setMouseTracking(True)
        self.setAttribute(Qt.WidgetAttribute.WA_OpaquePaintEvent, True)

        # Presentation State
        self.ball_pos = QPointF(400.0, 350.0)
        self.ball_base_size = 22.0
        self.ball_scale_x = 1.0
        self.ball_scale_y = 1.0
        self.ball_rotation = 0.0
        self.ball_rotate_x = 0.0
        self.ball_rotate_y = 0.0
        self.ball_skew_x = 0.0
        self.ball_skew_y = 0.0
        self.ball_opacity = 1.0
        self.ball_blur = 0.0
        self.ball_color = QColor("#facc15")
        self.ball_glow_radius = 12.0
        self.ball_vertices: Optional[List[Tuple[float, float]]] = None

        # Multi-ball timeline state
        self.timeline_balls: List[Dict[str, Any]] = []

        # Physics & motion telemetry
        self.velocity = (0.0, 0.0)
        self.speed = 0.0
        self.cycle_t = 0.0
        self.elapsed_time = 0.0
        self.fps = 60.0

        # Visual Overlays
        self.show_trail = True
        self.show_guides = True
        self.show_hud = True
        self.interactive_drag_enabled = True

        # Trail History
        self.trail_points: List[Tuple[float, float, float]] = []  # (x, y, timestamp)
        self.max_trail_len = 36

        # Interactive Drag / Aim
        self._dragging_target = False
        self._drag_start_pos = QPointF()
        self.custom_center = QPointF(400.0, 350.0)
        self.custom_target = QPointF(540.0, 290.0)

        # Active Motion reference
        self.active_spec: Dict[str, Any] = MOTION_SPECS[0]
        self.current_params: Dict[str, Any] = {}
        self.current_easing = "ease_in_out_cubic"

    def reset_trail(self):
        self.trail_points.clear()

    def set_active_motion(self, spec: Dict[str, Any], params: Dict[str, Any], easing: str):
        self.active_spec = spec
        self.current_params = dict(params)
        self.current_easing = easing
        self.reset_trail()

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            pos = event.position()
            self._dragging_target = True
            self._drag_start_pos = pos
            # Set target position for attractor / spring / projectile
            self.custom_target = pos
            self.update()

    def mouseMoveEvent(self, event):
        if self._dragging_target:
            self.custom_target = event.position()
            self.update()

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self._dragging_target = False
            self.update()

    def update_frame(
        self,
        pos: Tuple[float, float],
        vel: Tuple[float, float],
        cycle_t: float,
        elapsed: float,
        fps: float,
        visuals: Dict[str, Any],
    ):
        now = time.perf_counter()
        px, py = pos
        self.ball_pos = QPointF(px, py)
        self.velocity = vel
        self.speed = math.hypot(vel[0], vel[1])
        self.cycle_t = cycle_t
        self.elapsed_time = elapsed
        self.fps = fps

        # Apply Visuals
        self.ball_scale_x = visuals.get("scale_x", 1.0)
        self.ball_scale_y = visuals.get("scale_y", 1.0)
        self.ball_rotation = visuals.get("rotation", 0.0)
        self.ball_rotate_x = visuals.get("rotate_x", 0.0)
        self.ball_rotate_y = visuals.get("rotate_y", 0.0)
        self.ball_skew_x = visuals.get("skew_x", 0.0)
        self.ball_skew_y = visuals.get("skew_y", 0.0)
        self.ball_opacity = visuals.get("opacity", 1.0)
        self.ball_blur = visuals.get("blur", 0.0)
        self.ball_color = visuals.get("color", QColor("#facc15"))
        self.ball_glow_radius = visuals.get("glow_radius", 12.0)
        self.ball_vertices = visuals.get("vertices", None)
        self.timeline_balls = visuals.get("timeline_balls", [])

        # Record Trail
        if self.show_trail:
            self.trail_points.append((px, py, now))
            if len(self.trail_points) > self.max_trail_len:
                self.trail_points.pop(0)

        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        painter.setRenderHint(QPainter.RenderHint.TextAntialiasing, True)

        w = self.width()
        h = self.height()

        # 1. Background Fill
        painter.fillRect(0, 0, w, h, QColor("#090d13"))

        # 2. Coordinate Grid
        grid_pen = QPen(QColor("#161f2e"), 1, Qt.PenStyle.SolidLine)
        painter.setPen(grid_pen)
        grid_size = 50
        for gx in range(0, w, grid_size):
            painter.drawLine(gx, 0, gx, h)
        for gy in range(0, h, grid_size):
            painter.drawLine(0, gy, w, gy)

        # Center Crosshair
        cx, cy = w / 2.0, h / 2.0
        axis_pen = QPen(QColor("#22334b"), 1, Qt.PenStyle.DashLine)
        painter.setPen(axis_pen)
        painter.drawLine(0, int(cy), w, int(cy))
        painter.drawLine(int(cx), 0, int(cx), h)

        # 3. Dynamic Motion Guides
        if self.show_guides:
            self._draw_motion_guides(painter, w, h, cx, cy)

        # 4. Motion Particle Trail
        if self.show_trail and len(self.trail_points) > 1:
            for i, (tx, ty, _) in enumerate(self.trail_points):
                alpha = int((i + 1) / len(self.trail_points) * 160)
                trail_radius = (self.ball_base_size * 0.45) * ((i + 1) / len(self.trail_points))
                t_color = QColor(self.ball_color)
                t_color.setAlpha(alpha)
                painter.setPen(Qt.PenStyle.NoPen)
                painter.setBrush(QBrush(t_color))
                painter.drawEllipse(QPointF(tx, ty), trail_radius, trail_radius)

        # 5. Timeline Multi-Balls (if active)
        if self.timeline_balls:
            for b_info in self.timeline_balls:
                bx, by = b_info["pos"]
                b_col = b_info.get("color", QColor("#fde047"))
                painter.setPen(QPen(QColor("#fef08a"), 1.5))
                painter.setBrush(QBrush(b_col))
                painter.drawEllipse(QPointF(bx, by), 12, 12)

        # 6. Primary Yellow Ball
        self._draw_yellow_ball(painter, self.ball_pos.x(), self.ball_pos.y())

        # 7. Telemetry HUD Overlay
        if self.show_hud:
            self._draw_hud(painter, w, h)

    def _draw_yellow_ball(self, painter: QPainter, x: float, y: float):
        painter.save()
        painter.translate(x, y)

        # 2D & 3D Transformations
        if self.ball_rotation != 0.0:
            painter.rotate(self.ball_rotation)
        if self.ball_skew_x != 0.0 or self.ball_skew_y != 0.0:
            rad_x = math.radians(self.ball_skew_x)
            rad_y = math.radians(self.ball_skew_y)
            painter.shear(math.tan(rad_x), math.tan(rad_y))

        # 3D Scale Projections
        scale_x = self.ball_scale_x
        scale_y = self.ball_scale_y
        if self.ball_rotate_y != 0.0:
            scale_x *= math.cos(math.radians(self.ball_rotate_y))
        if self.ball_rotate_x != 0.0:
            scale_y *= math.cos(math.radians(self.ball_rotate_x))

        painter.scale(scale_x, scale_y)

        # Glow halo
        if self.ball_glow_radius > 0:
            glow_col = QColor(self.ball_color)
            glow_col.setAlpha(int(min(255, 120 * self.ball_opacity)))
            outer_glow = QRadialGradient(0, 0, self.ball_base_size + self.ball_glow_radius)
            outer_glow.setColorAt(0.0, glow_col)
            outer_glow.setColorAt(0.6, QColor(glow_col.red(), glow_col.green(), glow_col.blue(), 40))
            outer_glow.setColorAt(1.0, QColor(0, 0, 0, 0))
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QBrush(outer_glow))
            glow_d = (self.ball_base_size + self.ball_glow_radius) * 2
            painter.drawEllipse(QPointF(0, 0), glow_d / 2, glow_d / 2)

        # Shape Body (Morphed Polygon or Circle)
        body_col = QColor(self.ball_color)
        body_col.setAlpha(int(255 * max(0.0, min(1.0, self.ball_opacity))))
        border_col = QColor("#fef08a")
        border_col.setAlpha(int(255 * max(0.0, min(1.0, self.ball_opacity))))

        painter.setPen(QPen(border_col, 2.0))
        painter.setBrush(QBrush(body_col))

        if self.ball_vertices:
            poly = QPolygonF([QPointF(vx - x, vy - y) for vx, vy in self.ball_vertices])
            painter.drawPolygon(poly)
        else:
            r = self.ball_base_size / 2.0
            painter.drawEllipse(QPointF(0, 0), r, r)

            # Specular Highlight
            spec_col = QColor(255, 255, 255, int(180 * self.ball_opacity))
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QBrush(spec_col))
            painter.drawEllipse(QPointF(-r * 0.3, -r * 0.3), r * 0.25, r * 0.25)

        # Velocity Vector Arrow
        if self.speed > 5.0 and self.show_guides:
            vx, vy = self.velocity
            angle = math.atan2(vy, vx)
            v_len = min(60.0, self.speed * 0.12)
            painter.setPen(QPen(QColor("#38bdf8"), 1.8, Qt.PenStyle.SolidLine))
            painter.drawLine(0, 0, int(math.cos(angle) * v_len), int(math.sin(angle) * v_len))

        painter.restore()

    def _draw_motion_guides(self, painter: QPainter, w: int, h: int, cx: float, cy: float):
        mtype = self.active_spec.get("id")
        guide_pen = QPen(QColor("#334155"), 1.5, Qt.PenStyle.DashLine)
        accent_pen = QPen(QColor("#38bdf8"), 1.5, Qt.PenStyle.SolidLine)

        # ── Gravity & Projectile: Floor Line ──
        if mtype in ("gravity", "projectile"):
            floor_y = int(cy + 180)
            painter.setPen(QPen(QColor("#ef4444"), 2, Qt.PenStyle.SolidLine))
            painter.drawLine(40, floor_y, w - 40, floor_y)
            painter.setPen(QPen(QColor("#f87171"), 1))
            painter.drawText(50, floor_y - 8, "FLOOR LEVEL (y = floor_y)")

            if mtype == "projectile":
                wall_x = int(w - 70)
                painter.drawLine(wall_x, 40, wall_x, floor_y)
                painter.drawText(wall_x - 90, 60, "WALL (x = wall_x)")

        # ── Spring: Equilibrium line & Target ──
        elif mtype == "spring":
            target_x = cx + self.current_params.get("distance", 180)
            painter.setPen(guide_pen)
            painter.drawLine(int(cx - 200), int(cy), int(cx + 200), int(cy))
            painter.setPen(accent_pen)
            painter.drawEllipse(QPointF(target_x, cy), 8, 8)
            painter.drawText(int(target_x + 12), int(cy + 4), "Target Equilibrium")

        # ── Pendulum: Pivot & Arc ──
        elif mtype == "pendulum":
            pivot_y = cy - 140
            painter.setPen(QPen(QColor("#64748b"), 2))
            painter.drawEllipse(QPointF(cx, pivot_y), 5, 5)
            painter.drawLine(int(cx), int(pivot_y), int(self.ball_pos.x()), int(self.ball_pos.y()))

        # ── Orbit & Benzene: Orbital Path ──
        elif mtype == "orbit":
            radius = self.current_params.get("radius", 140)
            sides = int(self.current_params.get("sides", 6))
            painter.setPen(guide_pen)
            if sides <= 0:
                painter.drawEllipse(QPointF(cx, cy), radius, radius)
            else:
                pts = []
                for s_i in range(sides):
                    ang = s_i * (2.0 * math.pi / sides) - math.pi / 2.0
                    pts.append(QPointF(cx + radius * math.cos(ang), cy + radius * math.sin(ang)))
                pts.append(pts[0])
                painter.drawPolyline(pts)

        # ── Lissajous: Harmonic Curve Guide ──
        elif mtype == "lissajous":
            ax = self.current_params.get("amplitude_x", 180)
            ay = self.current_params.get("amplitude_y", 110)
            fx = self.current_params.get("freq_x", 3)
            fy = self.current_params.get("freq_y", 2)
            py = math.radians(self.current_params.get("phase_y", 90))
            pts = []
            for step in range(201):
                t_val = step / 200.0
                lx, ly = solve_lissajous(t_val, ax, ay, fx, fy, 0.0, py)
                pts.append(QPointF(cx + lx, cy + ly))
            painter.setPen(guide_pen)
            painter.drawPolyline(pts)

        # ── Wave: Sine Curve Baseline ──
        elif mtype == "wave":
            amp = self.current_params.get("amplitude", 65)
            freq = self.current_params.get("frequency", 2.2)
            pts = []
            for step in range(int(w - 80)):
                gx = 40 + step
                t_step = step / (w - 80)
                gy = cy + amp * math.sin(2.0 * math.pi * freq * t_step)
                pts.append(QPointF(gx, gy))
            painter.setPen(guide_pen)
            painter.drawPolyline(pts)

        # ── Attractor: Target Magnet Node ──
        elif mtype == "attractor":
            tx = self.ball_pos.x() + self.current_params.get("offset_x", 140)
            ty = self.ball_pos.y() + self.current_params.get("offset_y", -60)
            painter.setPen(QPen(QColor("#f43f5e"), 2))
            painter.drawEllipse(QPointF(tx, ty), 10, 10)
            painter.drawText(int(tx + 14), int(ty + 4), "Magnetic Node")

    def _draw_hud(self, painter: QPainter, w: int, h: int):
        # Semi-transparent HUD Panel
        hud_w = 460
        hud_h = 105
        hud_rect = QRectF(16, 16, hud_w, hud_h)

        painter.setPen(QPen(QColor("#1e293b"), 1))
        painter.setBrush(QBrush(QColor(15, 23, 42, 220)))
        painter.drawRoundedRect(hud_rect, 8, 8)

        # Motion Badge & Title
        painter.setPen(QPen(QColor("#facc15"), 1))
        f_title = QFont("Segoe UI", 11, QFont.Weight.Bold)
        painter.setFont(f_title)
        painter.drawText(30, 40, f"🟡 {self.active_spec['name']}")

        # Telemetry Text
        f_body = QFont("Segoe UI", 9)
        painter.setFont(f_body)
        painter.setPen(QPen(QColor("#94a3b8"), 1))

        pos_str = f"Pos: ({self.ball_pos.x():.1f}, {self.ball_pos.y():.1f}) px"
        vel_str = f"Speed: {self.speed:.1f} px/s  |  Cycle t: {self.cycle_t:.2f}  |  FPS: {self.fps:.1f}"
        form_str = f"Formula: {self.active_spec.get('formula', 'N/A')}"

        painter.drawText(30, 62, pos_str)
        painter.drawText(30, 82, vel_str)

        painter.setPen(QPen(QColor("#38bdf8"), 1))
        painter.drawText(30, 102, form_str)


# ══════════════════════════════════════════════════════════════════════════════
# Right Pane: Control Panel (Category Tabs, Menu, Sliders, Actions, Presets)
# ══════════════════════════════════════════════════════════════════════════════

class ControlPanelWidget(QWidget):
    """
    Rich interactive control panel featuring category filters, motion dropdown menu,
    dynamic contextual parameter sliders, playback action buttons, and presets.
    """

    def __init__(self, on_motion_change: Callable, on_param_change: Callable, on_action: Callable, parent=None):
        super().__init__(parent)
        self.on_motion_change = on_motion_change
        self.on_param_change = on_param_change
        self.on_action = on_action

        self.active_category = "all"
        self.active_spec = MOTION_SPECS[0]
        self.param_sliders: Dict[str, Tuple[QSlider, QLabel, Dict[str, Any]]] = {}

        self._build_ui()

    def _build_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(14, 14, 14, 14)
        main_layout.setSpacing(12)

        # ── 1. Header & Title ──
        header_box = QFrame()
        header_box.setStyleSheet("background-color: #161f2e; border-radius: 8px; padding: 6px;")
        hb_layout = QVBoxLayout(header_box)
        hb_layout.setContentsMargins(10, 8, 10, 8)
        lbl_title = QLabel("🎛️ DRAW MOTION STUDIO")
        lbl_title.setStyleSheet("color: #facc15; font-size: 14px; font-weight: bold;")
        lbl_sub = QLabel("Interactive Physics, Kinematics & Solvers Control")
        lbl_sub.setStyleSheet("color: #8b949e; font-size: 10px;")
        hb_layout.addWidget(lbl_title)
        hb_layout.addWidget(lbl_sub)
        main_layout.addWidget(header_box)

        # ── 2. Category Filter Buttons ──
        cat_group_box = QFrame()
        cat_layout = QGridLayout(cat_group_box)
        cat_layout.setContentsMargins(0, 0, 0, 0)
        cat_layout.setSpacing(6)

        self.cat_buttons: Dict[str, QPushButton] = {}
        for idx, (cat_id, cat_name) in enumerate(CATEGORIES):
            btn = QPushButton(cat_name)
            btn.setCheckable(True)
            btn.setChecked(cat_id == "all")
            btn.setStyleSheet(self._cat_btn_style(cat_id == "all"))
            btn.clicked.connect(lambda _, c=cat_id: self._select_category(c))
            self.cat_buttons[cat_id] = btn
            cat_layout.addWidget(btn, idx // 2, idx % 2)
        main_layout.addWidget(cat_group_box)

        # ── 3. Motion Dropdown Menu (QComboBox) ──
        lbl_menu = QLabel("📋 ACTIVE MOTION TYPE:")
        lbl_menu.setStyleSheet("color: #e2e8f0; font-size: 11px; font-weight: bold; margin-top: 4px;")
        main_layout.addWidget(lbl_menu)

        menu_row = QHBoxLayout()
        self.combo_motion = QComboBox()
        self.combo_motion.setStyleSheet(
            "QComboBox { background-color: #1e293b; color: #f8fafc; border: 1px solid #334155; border-radius: 6px; padding: 6px 10px; font-size: 12px; font-weight: bold; }"
            "QComboBox::drop-down { border: none; width: 24px; }"
            "QComboBox QAbstractItemView { background-color: #0f172a; color: #f8fafc; selection-background-color: #eab308; selection-color: #000; }"
        )
        self.combo_motion.currentIndexChanged.connect(self._on_combo_changed)
        menu_row.addWidget(self.combo_motion)

        btn_prev = QPushButton("◀")
        btn_prev.setFixedSize(30, 32)
        btn_prev.setStyleSheet("background-color: #1e293b; color: #f8fafc; border: 1px solid #334155; border-radius: 6px;")
        btn_prev.clicked.connect(self._prev_motion)
        btn_next = QPushButton("▶")
        btn_next.setFixedSize(30, 32)
        btn_next.setStyleSheet("background-color: #1e293b; color: #f8fafc; border: 1px solid #334155; border-radius: 6px;")
        btn_next.clicked.connect(self._next_motion)
        menu_row.addWidget(btn_prev)
        menu_row.addWidget(btn_next)
        main_layout.addLayout(menu_row)

        # Motion Description Box
        self.lbl_desc = QLabel()
        self.lbl_desc.setWordWrap(True)
        self.lbl_desc.setStyleSheet("color: #94a3b8; font-size: 10px; background-color: #0d1522; padding: 6px; border-radius: 6px; border-left: 3px solid #facc15;")
        main_layout.addWidget(self.lbl_desc)

        # ── 4. Dynamic Parameter Sliders Container ──
        lbl_sliders = QLabel("🎚️ LIVE PARAMETER SLIDERS:")
        lbl_sliders.setStyleSheet("color: #e2e8f0; font-size: 11px; font-weight: bold; margin-top: 4px;")
        main_layout.addWidget(lbl_sliders)

        self.sliders_container = QFrame()
        self.sliders_layout = QVBoxLayout(self.sliders_container)
        self.sliders_layout.setContentsMargins(0, 0, 0, 0)
        self.sliders_layout.setSpacing(8)
        main_layout.addWidget(self.sliders_container)

        self._populate_motion_combo()

        # ── 5. Universal Sliders (Global Speed & Ball Size) ──
        univ_box = QFrame()
        univ_box.setStyleSheet("background-color: #111827; border-radius: 6px; padding: 8px;")
        univ_layout = QVBoxLayout(univ_box)
        univ_layout.setContentsMargins(6, 6, 6, 6)
        univ_layout.setSpacing(6)

        # Speed Multiplier Slider
        s_row = QHBoxLayout()
        lbl_speed = QLabel("Global Time Scale / Speed:")
        lbl_speed.setStyleSheet("color: #cbd5e1; font-size: 10px; font-weight: bold;")
        self.lbl_speed_val = QLabel("1.0x")
        self.lbl_speed_val.setStyleSheet("color: #facc15; font-size: 10px; font-weight: bold;")
        s_row.addWidget(lbl_speed)
        s_row.addStretch()
        s_row.addWidget(self.lbl_speed_val)
        univ_layout.addLayout(s_row)

        self.slider_speed = QSlider(Qt.Orientation.Horizontal)
        self.slider_speed.setRange(1, 40)
        self.slider_speed.setValue(10)
        self.slider_speed.setStyleSheet(self._slider_style())
        self.slider_speed.valueChanged.connect(self._on_speed_changed)
        univ_layout.addWidget(self.slider_speed)

        # Ball Size Slider
        b_row = QHBoxLayout()
        lbl_bsize = QLabel("Yellow Ball Diameter:")
        lbl_bsize.setStyleSheet("color: #cbd5e1; font-size: 10px; font-weight: bold;")
        self.lbl_bsize_val = QLabel("22 px")
        self.lbl_bsize_val.setStyleSheet("color: #facc15; font-size: 10px; font-weight: bold;")
        b_row.addWidget(lbl_bsize)
        b_row.addStretch()
        b_row.addWidget(self.lbl_bsize_val)
        univ_layout.addLayout(b_row)

        self.slider_bsize = QSlider(Qt.Orientation.Horizontal)
        self.slider_bsize.setRange(8, 60)
        self.slider_bsize.setValue(22)
        self.slider_bsize.setStyleSheet(self._slider_style())
        self.slider_bsize.valueChanged.connect(self._on_bsize_changed)
        univ_layout.addWidget(self.slider_bsize)

        main_layout.addWidget(univ_box)

        # ── 6. Playback & State Control Buttons ──
        lbl_playback = QLabel("⏯️ PLAYBACK & ACTIONS:")
        lbl_playback.setStyleSheet("color: #e2e8f0; font-size: 11px; font-weight: bold; margin-top: 4px;")
        main_layout.addWidget(lbl_playback)

        play_row1 = QHBoxLayout()
        self.btn_play_pause = QPushButton("⏸ Pause")
        self.btn_play_pause.setStyleSheet("background-color: #facc15; color: #000; font-weight: bold; padding: 7px; border-radius: 6px;")
        self.btn_play_pause.clicked.connect(lambda: self.on_action("toggle_play"))
        btn_reset = QPushButton("↺ Reset")
        btn_reset.setStyleSheet("background-color: #334155; color: #f8fafc; font-weight: bold; padding: 7px; border-radius: 6px;")
        btn_reset.clicked.connect(lambda: self.on_action("reset"))
        btn_reverse = QPushButton("⇄ Reverse")
        btn_reverse.setStyleSheet("background-color: #334155; color: #f8fafc; font-weight: bold; padding: 7px; border-radius: 6px;")
        btn_reverse.clicked.connect(lambda: self.on_action("reverse"))
        play_row1.addWidget(self.btn_play_pause)
        play_row1.addWidget(btn_reset)
        play_row1.addWidget(btn_reverse)
        main_layout.addLayout(play_row1)

        # Toggles Row
        tog_row = QHBoxLayout()
        self.chk_trail = QCheckBox("✨ Trail")
        self.chk_trail.setChecked(True)
        self.chk_trail.setStyleSheet("color: #cbd5e1; font-size: 11px;")
        self.chk_trail.toggled.connect(lambda v: self.on_action("toggle_trail", v))

        self.chk_guides = QCheckBox("📐 Guides")
        self.chk_guides.setChecked(True)
        self.chk_guides.setStyleSheet("color: #cbd5e1; font-size: 11px;")
        self.chk_guides.toggled.connect(lambda v: self.on_action("toggle_guides", v))

        self.chk_loop = QCheckBox("🔁 Loop")
        self.chk_loop.setChecked(True)
        self.chk_loop.setStyleSheet("color: #cbd5e1; font-size: 11px;")
        self.chk_loop.toggled.connect(lambda v: self.on_action("toggle_loop", v))

        tog_row.addWidget(self.chk_trail)
        tog_row.addWidget(self.chk_guides)
        tog_row.addWidget(self.chk_loop)
        main_layout.addLayout(tog_row)

        # ── 7. Quick Showcase Presets ──
        lbl_presets = QLabel("⚡ QUICK SHOWCASE PRESETS:")
        lbl_presets.setStyleSheet("color: #e2e8f0; font-size: 11px; font-weight: bold; margin-top: 4px;")
        main_layout.addWidget(lbl_presets)

        p_grid = QGridLayout()
        p_grid.setSpacing(6)
        presets = [
            ("Bouncing Ball", "gravity"),
            ("Harmonic Spring", "spring"),
            ("Parabolic Shot", "projectile"),
            ("Lissajous Knot", "lissajous"),
            ("Infinity Curve", "custom"),
            ("Benzene Ring", "orbit"),
            ("Simplex Jitter", "wiggle"),
            ("Vertex Morph", "morph"),
        ]
        for idx, (p_name, p_id) in enumerate(presets):
            p_btn = QPushButton(p_name)
            p_btn.setStyleSheet(
                "QPushButton { background-color: #1e293b; color: #38bdf8; border: 1px solid #334155; border-radius: 5px; padding: 5px; font-size: 10px; }"
                "QPushButton:hover { background-color: #0284c7; color: #fff; }"
            )
            p_btn.clicked.connect(lambda _, mid=p_id: self._select_motion_by_id(mid))
            p_grid.addWidget(p_btn, idx // 2, idx % 2)
        main_layout.addLayout(p_grid)

        main_layout.addStretch()

        # Rebuild initial dynamic sliders
        self._rebuild_sliders_for_active_motion()

    def _select_category(self, cat_id: str):
        self.active_category = cat_id
        for cid, btn in self.cat_buttons.items():
            btn.setChecked(cid == cat_id)
            btn.setStyleSheet(self._cat_btn_style(cid == cat_id))
        self._populate_motion_combo()

    def _populate_motion_combo(self):
        self.combo_motion.blockSignals(True)
        self.combo_motion.clear()

        filtered = [
            s for s in MOTION_SPECS
            if self.active_category == "all" or s.get("category") == self.active_category
        ]
        for spec in filtered:
            self.combo_motion.addItem(f"{spec['name']}", spec["id"])

        self.combo_motion.blockSignals(False)
        if self.combo_motion.count() > 0:
            self.combo_motion.setCurrentIndex(0)
            self._on_combo_changed(0)

    def _select_motion_by_id(self, motion_id: str):
        self.active_category = "all"
        for cid, btn in self.cat_buttons.items():
            btn.setChecked(cid == "all")
            btn.setStyleSheet(self._cat_btn_style(cid == "all"))
        self._populate_motion_combo()

        for idx in range(self.combo_motion.count()):
            if self.combo_motion.itemData(idx) == motion_id:
                self.combo_motion.setCurrentIndex(idx)
                break

    def _prev_motion(self):
        idx = self.combo_motion.currentIndex()
        if idx > 0:
            self.combo_motion.setCurrentIndex(idx - 1)

    def _next_motion(self):
        idx = self.combo_motion.currentIndex()
        if idx < self.combo_motion.count() - 1:
            self.combo_motion.setCurrentIndex(idx + 1)

    def _on_combo_changed(self, index: int):
        motion_id = self.combo_motion.itemData(index)
        spec = next((s for s in MOTION_SPECS if s["id"] == motion_id), None)
        if spec:
            self.active_spec = spec
            self.lbl_desc.setText(spec.get("description", ""))
            self._rebuild_sliders_for_active_motion()
            self._fire_motion_update()

    def _rebuild_sliders_for_active_motion(self):
        # Clear existing slider widgets
        while self.sliders_layout.count() > 0:
            item = self.sliders_layout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()

        self.param_sliders.clear()
        params = self.active_spec.get("params", [])

        for p_def in params:
            pid = p_def["id"]
            p_label = p_def["label"]
            p_min = p_def.get("min", 0)
            p_max = p_def.get("max", 100)
            p_def_val = p_def.get("default", 50)
            p_scale = p_def.get("scale", 1.0)
            p_unit = p_def.get("unit", "")
            is_easing = p_def.get("is_easing", False)

            p_box = QFrame()
            p_box.setStyleSheet("background-color: #111827; border-radius: 5px; padding: 4px;")
            pb_layout = QVBoxLayout(p_box)
            pb_layout.setContentsMargins(4, 4, 4, 4)
            pb_layout.setSpacing(3)

            # Label Row
            l_row = QHBoxLayout()
            lbl_name = QLabel(p_label)
            lbl_name.setStyleSheet("color: #cbd5e1; font-size: 10px;")

            if is_easing:
                val_text = EASING_FUNCTIONS[p_def_val]
            else:
                real_val = p_def_val * p_scale
                val_text = f"{real_val:.2f} {p_unit}".rstrip("0").rstrip(".") + f" {p_unit}" if isinstance(real_val, float) else f"{real_val} {p_unit}"

            lbl_val = QLabel(val_text)
            lbl_val.setStyleSheet("color: #facc15; font-size: 10px; font-weight: bold;")

            l_row.addWidget(lbl_name)
            l_row.addStretch()
            l_row.addWidget(lbl_val)
            pb_layout.addLayout(l_row)

            # Slider
            slider = QSlider(Qt.Orientation.Horizontal)
            slider.setRange(p_min, p_max)
            slider.setValue(p_def_val)
            slider.setStyleSheet(self._slider_style())
            slider.valueChanged.connect(lambda v, p=p_def, lv=lbl_val: self._on_slider_changed(p, v, lv))
            pb_layout.addWidget(slider)

            self.sliders_layout.addWidget(p_box)
            self.param_sliders[pid] = (slider, lbl_val, p_def)

    def _on_slider_changed(self, p_def: Dict[str, Any], raw_val: int, lbl_val: QLabel):
        p_scale = p_def.get("scale", 1.0)
        p_unit = p_def.get("unit", "")
        is_easing = p_def.get("is_easing", False)

        if is_easing:
            idx = max(0, min(len(EASING_FUNCTIONS) - 1, raw_val))
            lbl_val.setText(EASING_FUNCTIONS[idx])
        else:
            real_val = raw_val * p_scale
            if isinstance(real_val, float) and not real_val.is_integer():
                lbl_val.setText(f"{real_val:.2f} {p_unit}")
            else:
                lbl_val.setText(f"{int(real_val)} {p_unit}")

        self._fire_motion_update()

    def _on_speed_changed(self, val: int):
        speed_mult = val * 0.1
        self.lbl_speed_val.setText(f"{speed_mult:.1f}x")
        self.on_action("speed", speed_mult)

    def _on_bsize_changed(self, val: int):
        self.lbl_bsize_val.setText(f"{val} px")
        self.on_action("ball_size", val)

    def _fire_motion_update(self):
        curr_params = {}
        easing_fn = "ease_in_out_cubic"
        for pid, (slider, _, p_def) in self.param_sliders.items():
            raw_v = slider.value()
            if p_def.get("is_easing"):
                idx = max(0, min(len(EASING_FUNCTIONS) - 1, raw_v))
                easing_fn = EASING_FUNCTIONS[idx]
            else:
                scale = p_def.get("scale", 1.0)
                curr_params[pid] = raw_v * scale

        self.on_motion_change(self.active_spec, curr_params, easing_fn)

    def _cat_btn_style(self, active: bool) -> str:
        if active:
            return "QPushButton { background-color: #facc15; color: #000; font-weight: bold; border-radius: 5px; padding: 6px 4px; font-size: 10px; border: none; }"
        return "QPushButton { background-color: #1e293b; color: #94a3b8; border-radius: 5px; padding: 6px 4px; font-size: 10px; border: 1px solid #334155; } QPushButton:hover { background-color: #334155; color: #fff; }"

    def _slider_style(self) -> str:
        return (
            "QSlider::groove:horizontal { height: 4px; background: #334155; border-radius: 2px; }"
            "QSlider::sub-page:horizontal { background: #eab308; border-radius: 2px; }"
            "QSlider::handle:horizontal { background: #facc15; border: 1px solid #fef08a; width: 12px; margin-top: -4px; margin-bottom: -4px; border-radius: 6px; }"
        )


# ══════════════════════════════════════════════════════════════════════════════
# Main Host Window Application Controller
# ══════════════════════════════════════════════════════════════════════════════

class MotionStudioWindow(QMainWindow):
    """
    Main Application Window integrating the Left Screen Viewport and Right Control Panel.
    """

    def __init__(self):
        super().__init__()
        self.setWindowTitle("🟡 Draw.motion Studio — Comprehensive Motion & Solvers Test Window")
        self.resize(1380, 880)
        self.setStyleSheet("QMainWindow { background-color: #0b0f17; }")

        # Runtime Engine State
        self.is_playing = True
        self.speed_multiplier = 1.0
        self.ball_diameter = 22.0
        self.loop_mode = True
        self.is_reversed = False

        self.start_time = time.perf_counter()
        self.motion_elapsed = 0.0
        self.last_frame_time = time.perf_counter()
        self.frame_count = 0
        self.fps = 60.0
        self.fps_timer_accum = 0.0

        # Active Motion Configuration
        self.active_spec: Dict[str, Any] = MOTION_SPECS[0]
        self.active_params: Dict[str, Any] = {}
        self.active_easing = "ease_in_out_cubic"

        # Precompiled AST Solver cache
        self.cached_solvers: Dict[str, DrawExprSolver] = {}

        self._init_ui()
        self._init_timer()

    def _init_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        root_layout = QHBoxLayout(central_widget)
        root_layout.setContentsMargins(10, 10, 10, 10)
        root_layout.setSpacing(12)

        # ── Leftmost Area: Screen Viewport (Stage) ──
        self.screen_widget = MotionScreenWidget(self)
        root_layout.addWidget(self.screen_widget, stretch=7)

        # ── Rightmost Area: Control Panel (Sidebar in ScrollArea) ──
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setStyleSheet(
            "QScrollArea { background-color: #0d1117; border: 1px solid #21262d; border-radius: 8px; }"
            "QScrollBar:vertical { background: #0d1117; width: 8px; margin: 0; }"
            "QScrollBar::handle:vertical { background: #30363d; border-radius: 4px; min-height: 20px; }"
        )

        self.control_panel = ControlPanelWidget(
            on_motion_change=self.on_motion_changed,
            on_param_change=self.on_param_changed,
            on_action=self.on_action_triggered,
        )
        scroll_area.setWidget(self.control_panel)
        root_layout.addWidget(scroll_area, stretch=3)

    def _init_timer(self):
        self.anim_timer = QTimer(self)
        self.anim_timer.setInterval(16)  # 60 FPS
        self.anim_timer.timeout.connect(self._on_animation_tick)
        self.anim_timer.start()

    def on_motion_changed(self, spec: Dict[str, Any], params: Dict[str, Any], easing: str):
        self.active_spec = spec
        self.active_params = dict(params)
        self.active_easing = easing
        self.motion_elapsed = 0.0
        self.start_time = time.perf_counter()
        self.screen_widget.set_active_motion(spec, params, easing)

    def on_param_changed(self, param_id: str, value: Any):
        self.active_params[param_id] = value
        self.screen_widget.set_active_motion(self.active_spec, self.active_params, self.active_easing)

    def on_action_triggered(self, action_name: str, value: Any = None):
        if action_name == "toggle_play":
            self.is_playing = not self.is_playing
            self.control_panel.btn_play_pause.setText("▶ Play" if not self.is_playing else "⏸ Pause")
            self.control_panel.btn_play_pause.setStyleSheet(
                "background-color: #22c55e; color: #000; font-weight: bold; padding: 7px; border-radius: 6px;"
                if not self.is_playing else
                "background-color: #facc15; color: #000; font-weight: bold; padding: 7px; border-radius: 6px;"
            )
        elif action_name == "reset":
            self.motion_elapsed = 0.0
            self.start_time = time.perf_counter()
            self.screen_widget.reset_trail()
        elif action_name == "reverse":
            self.is_reversed = not self.is_reversed
        elif action_name == "toggle_trail":
            self.screen_widget.show_trail = bool(value)
            if not value:
                self.screen_widget.reset_trail()
        elif action_name == "toggle_guides":
            self.screen_widget.show_guides = bool(value)
        elif action_name == "toggle_loop":
            self.loop_mode = bool(value)
        elif action_name == "speed":
            self.speed_multiplier = float(value)
        elif action_name == "ball_size":
            self.ball_diameter = float(value)
            self.screen_widget.ball_base_size = self.ball_diameter

    def _on_animation_tick(self):
        now = time.perf_counter()
        dt = now - self.last_frame_time
        self.last_frame_time = now

        # Update FPS
        self.frame_count += 1
        self.fps_timer_accum += dt
        if self.fps_timer_accum >= 0.5:
            self.fps = (self.frame_count / self.fps_timer_accum)
            self.frame_count = 0
            self.fps_timer_accum = 0.0

        if self.is_playing:
            self.motion_elapsed += dt * self.speed_multiplier

        t = self.motion_elapsed
        sw = float(self.screen_widget.width()) if self.screen_widget.width() > 0 else 800.0
        sh = float(self.screen_widget.height()) if self.screen_widget.height() > 0 else 700.0
        cx = sw / 2.0
        cy = sh / 2.0

        # Evaluate Active Motion
        pos, vel, cycle_t, visuals = self._evaluate_motion(t, cx, cy, sw, sh)

        self.screen_widget.update_frame(
            pos=pos,
            vel=vel,
            cycle_t=cycle_t,
            elapsed=t,
            fps=self.fps,
            visuals=visuals,
        )

    def _evaluate_motion(self, t: float, cx: float, cy: float, sw: float, sh: float) -> Tuple[Tuple[float, float], Tuple[float, float], float, Dict[str, Any]]:
        m_id = self.active_spec["id"]
        p = self.active_params
        visuals: Dict[str, Any] = {
            "scale_x": 1.0,
            "scale_y": 1.0,
            "rotation": 0.0,
            "rotate_x": 0.0,
            "rotate_y": 0.0,
            "skew_x": 0.0,
            "skew_y": 0.0,
            "opacity": 1.0,
            "blur": 0.0,
            "color": QColor("#facc15"),
            "glow_radius": 12.0,
            "vertices": None,
            "timeline_balls": [],
        }

        # ── 1. Analytical Physics ──────────────────────────────────────────────
        if m_id == "spring":
            k = p.get("stiffness", 280.0)
            c = p.get("damping", 14.0)
            m = p.get("mass", 1.0)
            dist = p.get("distance", 180.0)
            v0 = p.get("v0", 0.0)

            # Oscillate between -dist and +dist
            cycle_dur = 3.0
            raw_t = (t % cycle_dur) if self.loop_mode else t
            t_eval = raw_t
            x_val = solve_spring(t_eval, -dist, dist, v0, k, c, m)
            vx_val = (solve_spring(t_eval + 0.016, -dist, dist, v0, k, c, m) - x_val) / 0.016
            return (cx + x_val, cy), (vx_val, 0.0), min(1.0, raw_t / cycle_dur), visuals

        elif m_id == "gravity":
            g = p.get("g", 980.0)
            rest = p.get("restitution", 0.76)
            drop_h = p.get("drop_height", 260.0)
            v0 = p.get("v0", 0.0)
            floor_y = cy + 180.0
            start_y = floor_y - drop_h

            cycle_dur = 4.0
            raw_t = (t % cycle_dur) if self.loop_mode else t
            y_val = solve_gravity_bounce(raw_t, v0, g, rest, floor_y, start_y)
            vy_val = (solve_gravity_bounce(raw_t + 0.016, v0, g, rest, floor_y, start_y) - y_val) / 0.016
            return (cx, y_val), (0.0, vy_val), min(1.0, raw_t / cycle_dur), visuals

        elif m_id == "projectile":
            vx0 = p.get("vx0", 240.0)
            vy0 = -p.get("vy0", 420.0)
            g = p.get("g", 850.0)
            drag = p.get("drag", 0.02)
            rest = p.get("restitution", 0.75)
            floor_y = cy + 180.0
            wall_x = sw - 70.0
            start_x = 80.0
            start_y = floor_y - 20.0

            cycle_dur = 4.5
            raw_t = (t % cycle_dur) if self.loop_mode else t
            px, py = solve_projectile_2d(raw_t, vx0, vy0, g, drag, rest, floor_y, wall_x, start_x, start_y)
            px_next, py_next = solve_projectile_2d(raw_t + 0.016, vx0, vy0, g, drag, rest, floor_y, wall_x, start_x, start_y)
            vx = (px_next - px) / 0.016
            vy = (py_next - py) / 0.016
            return (px, py), (vx, vy), min(1.0, raw_t / cycle_dur), visuals

        elif m_id == "inertia":
            v0 = p.get("velocity", 650.0)
            f = p.get("friction", 0.94)
            span = p.get("distance", 240.0)

            cycle_dur = 3.0
            raw_t = (t % cycle_dur) if self.loop_mode else t
            x_val = solve_inertia(raw_t, -span, v0, f, bounds={"min": -span, "max": span})
            x_next = solve_inertia(raw_t + 0.016, -span, v0, f, bounds={"min": -span, "max": span})
            return (cx + x_val, cy), ((x_next - x_val) / 0.016, 0.0), min(1.0, raw_t / cycle_dur), visuals

        elif m_id == "pendulum":
            amp = p.get("amplitude", 48.0)
            freq = p.get("frequency", 1.4)
            damp = p.get("damping", 0.18)
            arm = p.get("arm_length", 180.0)
            pivot_y = cy - 140.0

            ang_deg = solve_pendulum(t, amp, freq, damp)
            ang_rad = math.radians(ang_deg)
            px = cx + arm * math.sin(ang_rad)
            py = pivot_y + arm * math.cos(ang_rad)
            visuals["rotation"] = ang_deg
            return (px, py), (0.0, 0.0), (t % 2.0) / 2.0, visuals

        elif m_id == "attractor":
            strength = p.get("strength", 4.5)
            off_x = p.get("offset_x", 140.0)
            off_y = p.get("offset_y", -60.0)
            target_x = cx + off_x
            target_y = cy + off_y
            start_x = cx - 180.0
            start_y = cy + 120.0

            cycle_dur = 3.0
            raw_t = (t % cycle_dur) if self.loop_mode else t
            px, py = solve_attractor_2d(raw_t, target_x, target_y, start_x, start_y, strength)
            return (px, py), (0.0, 0.0), min(1.0, raw_t / cycle_dur), visuals

        # ── 2. Procedural & Parametric Curves ──────────────────────────────────
        elif m_id == "wave":
            freq = p.get("frequency", 2.2)
            amp = p.get("amplitude", 65.0)
            phase = math.radians(p.get("phase", 0.0))
            wv = solve_wave(t, freq, amp, phase)
            return (cx, cy + wv), (0.0, 0.0), (t * freq) % 1.0, visuals

        elif m_id == "wiggle":
            freq = p.get("frequency", 4.5)
            amp = p.get("amplitude", 42.0)
            octs = int(p.get("octaves", 2))
            dx, dy = solve_wiggle(t, freq, amp, octs)
            return (cx + dx, cy + dy), (0.0, 0.0), 0.5, visuals

        elif m_id == "pulse":
            freq = p.get("frequency", 2.5)
            amp = p.get("amplitude", 60.0)
            pulse_scale = 1.0 + (amp / 100.0) * math.sin(2.0 * math.pi * freq * t)
            visuals["scale_x"] = pulse_scale
            visuals["scale_y"] = pulse_scale
            return (cx, cy), (0.0, 0.0), (t * freq) % 1.0, visuals

        elif m_id == "stretch_squash":
            amp = p.get("amplitude", 0.45)
            freq = p.get("frequency", 2.2)
            damp = p.get("damping", 0.5)
            sx, sy = solve_stretch_squash(t, amp, freq, damp)
            visuals["scale_x"] = sx
            visuals["scale_y"] = sy
            return (cx, cy), (0.0, 0.0), (t * freq) % 1.0, visuals

        elif m_id == "orbit":
            radius = p.get("radius", 140.0)
            sides = int(p.get("sides", 6))
            freq = p.get("frequency", 0.8)
            dx, dy = solve_polygon_orbit(t, radius, sides, freq)
            return (cx + dx, cy + dy), (0.0, 0.0), (t * freq) % 1.0, visuals

        elif m_id == "lissajous":
            ax = p.get("amplitude_x", 180.0)
            ay = p.get("amplitude_y", 110.0)
            fx = p.get("freq_x", 3.0)
            fy = p.get("freq_y", 2.0)
            py = math.radians(p.get("phase_y", 90.0))
            dx, dy = solve_lissajous(t, ax, ay, fx, fy, 0.0, py)
            return (cx + dx, cy + dy), (0.0, 0.0), (t * 0.5) % 1.0, visuals

        elif m_id == "spiral":
            a = p.get("a", 10.0)
            b = p.get("b", 12.0)
            freq = p.get("frequency", 0.8)
            is_log = bool(p.get("logarithmic", 0))
            dx, dy = solve_spiral(t % 6.0, a, b, freq, is_log)
            return (cx + dx, cy + dy), (0.0, 0.0), (t % 6.0) / 6.0, visuals

        # ── 3. Kinematics & Easing ─────────────────────────────────────────────
        elif m_id in ("move", "x", "y"):
            dur = p.get("duration", 2.0)
            dist = p.get("distance", p.get("span_x", p.get("span_y", 280.0)))
            raw_t = (t / max(0.1, dur))
            cycle_idx = int(raw_t)
            u = raw_t - cycle_idx
            if self.is_reversed or (cycle_idx % 2 == 1):
                u = 1.0 - u

            # Apply selected easing function
            easing_name = self.active_easing
            graph_fn = Draw.motion._graphs.get(easing_name, Draw.motion._graphs["linear"])
            eased_u = graph_fn(max(0.0, min(1.0, u)))

            if m_id == "x":
                return (cx - dist / 2.0 + eased_u * dist, cy), (0.0, 0.0), u, visuals
            elif m_id == "y":
                return (cx, cy - dist / 2.0 + eased_u * dist), (0.0, 0.0), u, visuals
            else:
                # 2D diagonal move
                return (cx - dist / 2.0 + eased_u * dist, cy - dist * 0.4 / 2.0 + eased_u * dist * 0.4), (0.0, 0.0), u, visuals

        # ── 4. Paths, Keyframes & Expressions ──────────────────────────────────
        elif m_id == "path":
            dur = p.get("duration", 3.0)
            orient = bool(p.get("orient", 1))
            preset = int(p.get("path_preset", 0))

            path_defs = [
                f"M {cx-180} {cy} C {cx-90} {cy-140}, {cx+90} {cy+140}, {cx+180} {cy}",
                f"M {cx-160} {cy} C {cx-80} {cy-120}, {cx} {cy+120}, {cx+80} {cy-120} S {cx+160} {cy}, {cx+160} {cy}",
                f"M {cx} {cy+120} C {cx-160} {cy-20}, {cx-160} {cy-140}, {cx} {cy-60} C {cx+160} {cy-140}, {cx+160} {cy-20}, {cx} {cy+120}",
                f"M {cx-150} {cy-100} L {cx+150} {cy-100} L {cx-150} {cy+100} L {cx+150} {cy+100} Z",
            ]
            svg_path = path_defs[preset % len(path_defs)]
            raw_t = (t / max(0.1, dur))
            u = (raw_t % 1.0) if self.loop_mode else min(1.0, raw_t)
            if int(raw_t) % 2 == 1:
                u = 1.0 - u

            vertices = resolve_motion_path_vertices(svg_path, closed=True)
            px, py, heading = sample_polyline_at(vertices, u)
            if orient:
                visuals["rotation"] = heading
            return (px, py), (0.0, 0.0), u, visuals

        elif m_id == "keyframes":
            dur = p.get("duration", 3.5)
            scale = p.get("radius_scale", 120.0) / 100.0
            kfs = [
                {"time": 0.0, "value": [cx - 160 * scale, cy - 80 * scale]},
                {"time": 0.25, "value": [cx + 160 * scale, cy - 80 * scale]},
                {"time": 0.5, "value": [cx + 160 * scale, cy + 80 * scale]},
                {"time": 0.75, "value": [cx - 160 * scale, cy + 80 * scale]},
                {"time": 1.0, "value": [cx - 160 * scale, cy - 80 * scale]},
            ]
            raw_t = (t / max(0.1, dur))
            u = raw_t % 1.0
            val = Draw.motion.evaluate_keyframes(u, kfs)
            return (val[0], val[1]), (0.0, 0.0), u, visuals

        elif m_id == "morph":
            dur = p.get("duration", 2.0)
            target_shape_idx = int(p.get("target_shape", 0))
            raw_t = (t / max(0.1, dur))
            cycle_idx = int(raw_t)
            u = raw_t - cycle_idx
            if cycle_idx % 2 == 1:
                u = 1.0 - u

            eased_u = Draw.motion._graphs["ease_in_out_cubic"](u)

            target_specs = [
                {"shape": "star", "points": 5, "outer_radius": 34, "inner_radius": 14, "cx": cx, "cy": cy},
                {"shape": "polygon", "sides": 6, "radius": 32, "cx": cx, "cy": cy},
                {"shape": "polygon", "sides": 3, "radius": 34, "cx": cx, "cy": cy},
                {"shape": "star", "points": 8, "outer_radius": 36, "inner_radius": 18, "cx": cx, "cy": cy},
            ]
            to_spec = target_specs[target_shape_idx % len(target_specs)]
            from_spec = {"shape": "circle", "radius": 16, "cx": cx, "cy": cy}

            rf, rt = resolve_morph_vertices(from_spec, to_spec, "distribute")
            interpolated = [
                (p1[0] + eased_u * (p2[0] - p1[0]), p1[1] + eased_u * (p2[1] - p1[1]))
                for p1, p2 in zip(rf, rt)
            ]
            visuals["vertices"] = interpolated
            return (cx, cy), (0.0, 0.0), u, visuals

        elif m_id == "solver":
            expr_idx = int(p.get("expr_preset", 0))
            speed = p.get("speed", 1.0)
            expressions = [
                "x = cx + sin(time * 3) * 160\ny = cy + cos(time * 2) * 80",
                "x = cx + cos(time * 2) * (140 + sin(time * 8) * 35)\ny = cy + sin(time * 2) * (140 + sin(time * 8) * 35)",
                "x = cx + (130 * cos(time * 3) - 35 * cos(time * 12))\ny = cy + (130 * sin(time * 3) - 35 * sin(time * 12))",
                "x = cx + sin(time * 4) * cos(time * 2) * 180\ny = cy + sin(time * 3) * 90",
            ]
            expr_str = expressions[expr_idx % len(expressions)]
            if expr_str not in self.cached_solvers:
                self.cached_solvers[expr_str] = DrawExprSolver(expr_str)

            solver = self.cached_solvers[expr_str]
            res = solver.evaluate({"time": t * speed, "cx": cx, "cy": cy, "dt": 0.016})
            px = float(res.get("x", cx))
            py = float(res.get("y", cy))
            return (px, py), (0.0, 0.0), (t * speed) % 1.0, visuals

        # ── 5. 3D Transforms & Deformations ────────────────────────────────────
        elif m_id == "rotate":
            dur = p.get("duration", 2.0)
            orbit_off = p.get("orbit_offset", 0.0)
            ang = (t / max(0.1, dur) * 360.0) % 360.0
            visuals["rotation"] = ang
            px = cx + orbit_off * math.cos(math.radians(ang))
            py = cy + orbit_off * math.sin(math.radians(ang))
            return (px, py), (0.0, 0.0), (t / max(0.1, dur)) % 1.0, visuals

        elif m_id == "rotate_3d":
            rx_max = p.get("rotate_x", 45.0)
            ry_max = p.get("rotate_y", 60.0)
            dur = p.get("duration", 2.4)
            u = (t / max(0.1, dur)) % 1.0
            visuals["rotate_x"] = rx_max * math.sin(2.0 * math.pi * u)
            visuals["rotate_y"] = ry_max * math.cos(2.0 * math.pi * u)
            return (cx, cy), (0.0, 0.0), u, visuals

        elif m_id == "scale":
            sx = p.get("scale_x", 220.0) / 100.0
            sy = p.get("scale_y", 70.0) / 100.0
            dur = p.get("duration", 1.6)
            u = math.sin(2.0 * math.pi * (t / max(0.1, dur)))
            visuals["scale_x"] = 1.0 + (sx - 1.0) * (0.5 + 0.5 * u)
            visuals["scale_y"] = 1.0 + (sy - 1.0) * (0.5 + 0.5 * u)
            return (cx, cy), (0.0, 0.0), (t / max(0.1, dur)) % 1.0, visuals

        elif m_id == "skew":
            sk_x = p.get("skew_x", 30.0)
            sk_y = p.get("skew_y", 0.0)
            dur = p.get("duration", 1.8)
            u = math.sin(2.0 * math.pi * (t / max(0.1, dur)))
            visuals["skew_x"] = sk_x * u
            visuals["skew_y"] = sk_y * u
            return (cx, cy), (0.0, 0.0), (t / max(0.1, dur)) % 1.0, visuals

        # ── 6. Visual Styling & Color FX ───────────────────────────────────────
        elif m_id == "color":
            dur = p.get("duration", 1.8)
            pal_idx = int(p.get("palette_idx", 0))
            palettes = [
                (QColor("#facc15"), QColor("#f43f5e")),  # Gold -> Crimson
                (QColor("#facc15"), QColor("#06b6d4")),  # Gold -> Cyan
                (QColor("#facc15"), QColor("#a855f7")),  # Gold -> Purple
                (QColor("#facc15"), QColor("#10b981")),  # Gold -> Emerald
            ]
            c1, c2 = palettes[pal_idx % len(palettes)]
            raw_t = (t / max(0.1, dur))
            cycle_idx = int(raw_t)
            u = raw_t - cycle_idx
            if cycle_idx % 2 == 1:
                u = 1.0 - u
            eased_u = Draw.motion._graphs["ease_in_out_cubic"](u)

            r = int(c1.red() + eased_u * (c2.red() - c1.red()))
            g = int(c1.green() + eased_u * (c2.green() - c1.green()))
            b = int(c1.blue() + eased_u * (c2.blue() - c1.blue()))
            visuals["color"] = QColor(r, g, b)
            return (cx, cy), (0.0, 0.0), u, visuals

        elif m_id == "glow":
            max_r = p.get("max_radius", 32.0)
            freq = p.get("frequency", 2.0)
            visuals["glow_radius"] = max_r * (0.5 + 0.5 * math.sin(2.0 * math.pi * freq * t))
            return (cx, cy), (0.0, 0.0), (t * freq) % 1.0, visuals

        elif m_id == "opacity":
            min_op = p.get("min_opacity", 20.0) / 100.0
            max_b = p.get("max_blur", 12.0)
            dur = p.get("duration", 1.6)
            u = 0.5 + 0.5 * math.sin(2.0 * math.pi * (t / max(0.1, dur)))
            visuals["opacity"] = min_op + (1.0 - min_op) * u
            visuals["blur"] = max_b * (1.0 - u)
            return (cx, cy), (0.0, 0.0), (t / max(0.1, dur)) % 1.0, visuals

        # ── 7. Timelines & Custom Callbacks ────────────────────────────────────
        elif m_id == "timeline":
            count = int(p.get("ball_count", 4))
            stagger = p.get("stagger", 0.2)
            amp = p.get("amplitude", 60.0)
            balls = []
            span_w = 260.0
            start_x = cx - span_w / 2.0
            step_x = span_w / max(1, count - 1)

            for bi in range(count):
                bx = start_x + bi * step_x
                t_b = t - bi * stagger
                by = cy + amp * math.sin(2.0 * math.pi * 1.5 * t_b)
                balls.append({"pos": (bx, by), "color": QColor("#facc15") if bi == 0 else QColor("#fde047")})

            visuals["timeline_balls"] = balls
            main_b = balls[0]["pos"]
            return main_b, (0.0, 0.0), (t * 1.5) % 1.0, visuals

        elif m_id == "custom":
            size = p.get("size", 180.0)
            dur = p.get("duration", 3.2)
            preset_type = int(p.get("preset_type", 0))
            u = (t / max(0.1, dur)) % 1.0
            tau_t = u * math.tau

            if preset_type == 0:
                # Bernoulli Lemniscate (Figure-8 Infinity ∞)
                den = 1.0 + math.sin(tau_t) ** 2
                px = cx + (size * math.cos(tau_t)) / den
                py = cy + (size * 0.5 * math.sin(tau_t) * math.cos(tau_t)) / den
            elif preset_type == 1:
                # Cardioid Heart
                r = size * 0.4 * (1.0 - math.sin(tau_t))
                px = cx + r * math.cos(tau_t)
                py = cy - r * math.sin(tau_t) + 30.0
            else:
                # Astroid
                px = cx + size * 0.7 * (math.cos(tau_t) ** 3)
                py = cy + size * 0.7 * (math.sin(tau_t) ** 3)

            return (px, py), (0.0, 0.0), u, visuals

        return (cx, cy), (0.0, 0.0), 0.0, visuals


# ══════════════════════════════════════════════════════════════════════════════
# Application Entry Point
# ══════════════════════════════════════════════════════════════════════════════

def main():
    app = Draw._app.get_app()
    window = MotionStudioWindow()
    window.show()
    print("=" * 74)
    print(" [Draw.motion Studio] Interactive Test Window Running at 60 FPS")
    print(f"    - Left Pane: Interactive Motion Screen with Yellow Ball & Guides")
    print(f"    - Right Pane: Control Panel with All 38+ Motion Types & Live Sliders")
    print("=" * 74)
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
