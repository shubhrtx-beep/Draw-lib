import os
import sys
import math
import time
import json
import queue
import threading
import urllib.request
import urllib.error

# Ensure we can import the Draw package from the parent directory
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
import Draw

from PySide6.QtGui import QTextDocument, QFont

# Initialize Window - set background color natively to avoid white flicker
Draw.window(tag="chatbot", title="Gemini Chatbot", width=800, height=600, resizable=False, background_color="#16161d")

# Shared Threading Queue for API Responses
api_queue = queue.Queue()

# Pre-load Gemini API Key from environment if available
env_api_key = os.environ.get("GEMINI_API_KEY", "")

# Application State
state = {
    "api_key": env_api_key,
    "messages": [
        {
            "sender": "model",
            "text": "Hello! I am Gemini. Please enter your Gemini API Key in the settings menu (⚙) at the top to start chatting!",
            "scale": 1.0,
            "opacity": 100.0,
            "y_offset": 0.0
        }
    ],
    "history": [],
    "thinking": False,
    "settings_open": False,
    "settings_hovered": False,
    "settings_rotation": 0.0,
    "panel_y": -150.0,
    "target_panel_y": -150.0,
    "settings_label_text": "Enter Gemini API Key:" if not env_api_key else "Gemini API Key Loaded from Env ✓",
    "settings_label_color": "#b0b0b0" if not env_api_key else "#2ec4b6",
    "save_hovered": False,
    "save_scale": 1.0,
    "clear_hovered": False,
    "clear_scale": 1.0,
    "send_hovered": False,
    "send_scale": 1.0,
    "scroll_target_y": 0.0,
    "auto_scroll_active": True,
}

# ── Helper: Measure wrapped text dimensions ──
def measure_wrapped_text(text, font_family="Segoe UI", font_size=14, max_width=380):
    doc = QTextDocument()
    font = QFont(font_family)
    font.setPixelSize(font_size)
    doc.setDefaultFont(font)
    doc.setPlainText(text)
    
    # Measure the ideal width of text without constraints
    ideal_w = doc.idealWidth()
    
    if ideal_w <= max_width:
        # Fits on a single line! Return exact width (with small buffer) and single-line height
        return math.ceil(ideal_w) + 4, doc.size().height()
    else:
        # Exceeds max width, set wrap constraint and measure height
        doc.setTextWidth(max_width)
        return max_width, doc.size().height()

# ── Gemini API client ──
def call_gemini(api_key, history):
    # Using Gemini 2.5 Flash for fast responses
    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key={api_key}"
    headers = {"Content-Type": "application/json"}
    payload = {"contents": history}
    
    req = urllib.request.Request(
        url,
        data=json.dumps(payload).encode("utf-8"),
        headers=headers,
        method="POST"
    )
    
    try:
        with urllib.request.urlopen(req, timeout=20) as response:
            res_data = json.loads(response.read().decode("utf-8"))
            model_text = res_data["candidates"][0]["content"]["parts"][0]["text"]
            return {"status": "success", "text": model_text}
    except urllib.error.HTTPError as e:
        try:
            err_data = json.loads(e.read().decode("utf-8"))
            err_msg = err_data["error"]["message"]
            return {"status": "error", "text": f"API Error: {err_msg}"}
        except Exception:
            return {"status": "error", "text": f"HTTP Error {e.code}: {e.reason}"}
    except Exception as e:
        return {"status": "error", "text": f"Connection Error: {str(e)}"}

def async_call_gemini(api_key, history):
    def run():
        res = call_gemini(api_key, history)
        api_queue.put(res)
    threading.Thread(target=run, daemon=True).start()

# ── UI Builder ──
def rebuild_ui():
    shapes_list = []
    text_list = []
    
    canvas = Draw.window.get_canvas("chatbot")
    width = canvas.width()
    height = canvas.height()
    
    # 1. Background Shape & Gradient (Dynamic size matching window)
    shapes_list.append({
        "ip": "scroller_bg",
        "vertices": 4,
        "x": 0,
        "y": 0,
        "width": width,
        "height": height,
        "z": 1000,
        "overlap": True,
        "locked": True
    })
    
    # 2. Main scrollable chat viewport
    current_y = 90
    for idx, msg in enumerate(state["messages"]):
        sender = msg["sender"]
        text_content = msg["text"]
        scale = msg["scale"]
        opacity = int(msg["opacity"])
        y_off = msg["y_offset"]
        
        # Measure wrapped text dimensions dynamically
        text_w, text_h = measure_wrapped_text(text_content, "Segoe UI", 14, 380)
        bubble_w = text_w + 30
        bubble_h = text_h + 20
        
        if sender == "user":
            target_x = width - bubble_w - 40
            draw_x = target_x + (1.0 - scale) * 40
            bubble_color = "#3a0ca3"
            border_color = "#4cc9f0"
            text_color = "#ffffff"
        else:
            target_x = 40
            draw_x = target_x - (1.0 - scale) * 40
            bubble_color = "#1e1e24"
            border_color = "#7b2cbf"
            text_color = "#f0f0f0"
            
        draw_y = current_y + y_off
        
        # Centering pivot for scaling animation
        scaled_w = int(bubble_w * scale)
        scaled_h = int(bubble_h * scale)
        final_x = draw_x + (bubble_w - scaled_w) / 2
        final_y = draw_y + (bubble_h - scaled_h) / 2
        
        shapes_list.append({
            "ip": f"bubble_{idx}",
            "vertices": 4,
            "x": int(final_x),
            "y": int(final_y),
            "width": scaled_w,
            "height": scaled_h,
            "border_radius": 14,
            "color": bubble_color,
            "border_color": border_color,
            "border_width": 2,
            "opacity": opacity,
            "z": 100
        })
        
        if scale > 0.3:
            t_x = final_x + (scaled_w - text_w * scale) / 2
            t_y = final_y + (scaled_h - text_h * scale) / 2
            
            text_list.append({
                "ip": f"text_{idx}",
                "text": text_content,
                "x": int(t_x),
                "y": int(t_y),
                "customise": {
                    "font_family": "Segoe UI",
                    "font_size": int(14 * scale),
                    "color": text_color,
                    "max_width": int(text_w * scale),
                    "opacity": opacity
                }
            })
            
        current_y += bubble_h + 15
        
    # 3. Thinking indicator
    if state["thinking"]:
        bubble_w = 95
        bubble_h = 45
        draw_x = 40
        draw_y = current_y
        
        shapes_list.append({
            "ip": "thinking_bubble",
            "vertices": 4,
            "x": int(draw_x),
            "y": int(draw_y),
            "width": bubble_w,
            "height": bubble_h,
            "border_radius": 14,
            "color": "#1e1e24",
            "border_color": "#7b2cbf",
            "border_width": 2,
            "opacity": 100,
            "z": 100
        })
        
        now_time = time.perf_counter()
        dy1 = math.sin(now_time * 12) * 5
        dy2 = math.sin(now_time * 12 - 1.2) * 5
        dy3 = math.sin(now_time * 12 - 2.4) * 5
        
        shapes_list.append({
            "ip": "think_dot_1",
            "vertices": 32,
            "x": int(draw_x + 22),
            "y": int(draw_y + 20 + dy1),
            "size": [8, 8],
            "color": "#4cc9f0",
            "border_width": 0,
            "opacity": 100,
            "z": 95
        })
        shapes_list.append({
            "ip": "think_dot_2",
            "vertices": 32,
            "x": int(draw_x + 42),
            "y": int(draw_y + 20 + dy2),
            "size": [8, 8],
            "color": "#7b2cbf",
            "border_width": 0,
            "opacity": 100,
            "z": 95
        })
        shapes_list.append({
            "ip": "think_dot_3",
            "vertices": 32,
            "x": int(draw_x + 62),
            "y": int(draw_y + 20 + dy3),
            "size": [8, 8],
            "color": "#4cc9f0",
            "border_width": 0,
            "opacity": 100,
            "z": 95
        })
        
        current_y += bubble_h + 15
        
    state["scroll_target_y"] = max(0.0, current_y - (height - 110))
    
    # 4. Static Header Elements
    shapes_list.append({
        "ip": "scroller_header_bg",
        "vertices": 4,
        "x": 0,
        "y": 0,
        "width": width,
        "height": 70,
        "color": "#16161d",
        "z": 50,
        "locked": True
    })
    shapes_list.append({
        "ip": "scroller_header_border",
        "vertices": 4,
        "x": 0,
        "y": 68,
        "width": width,
        "height": 2,
        "color": "#6200ea",
        "z": 49,
        "locked": True
    })
    text_list.append({
        "ip": "scroller_title",
        "text": "Gemini AI",
        "x": 30,
        "y": 24,
        "customise": {
            "font_family": "Segoe UI",
            "font_size": 20,
            "color": "white",
            "bold": True,
            "opacity": 100
        }
    })
    
    # Settings toggle button (aligned to the right dynamically)
    settings_scale = 1.15 if state["settings_hovered"] else 1.0
    btn_w = int(40 * settings_scale)
    btn_h = int(40 * settings_scale)
    btn_x = int((width - 80) + (40 - btn_w) / 2)
    btn_y = int(15 + (40 - btn_h) / 2)
    
    shapes_list.append({
        "ip": "scroller_settings_btn",
        "vertices": 4,
        "x": btn_x,
        "y": btn_y,
        "width": btn_w,
        "height": btn_h,
        "border_radius": 10,
        "color": "#252530" if not state["settings_open"] else "#7b2cbf",
        "border_color": "#7b2cbf",
        "border_width": 1,
        "z": 45
    })
    text_list.append({
        "ip": "scroller_settings_btn_txt",
        "text": "⚙",
        "x": int(btn_x + (btn_w - 20) / 2) - 1,
        "y": int(btn_y + (btn_h - 22) / 2),
        "customise": {
            "font_family": "Segoe UI",
            "font_size": int(18 * settings_scale),
            "color": "white",
            "opacity": 100,
            "rotation": state["settings_rotation"]
        }
    })
    
    # 5. Settings Panel (Slide-down card - dynamic width)
    panel_y = int(state["panel_y"])
    shapes_list.append({
        "ip": "scroller_settings_panel",
        "vertices": 4,
        "x": 20,
        "y": panel_y,
        "width": width - 40,
        "height": 105,
        "border_radius": 15,
        "color": "#1e1e24",
        "border_color": "#7b2cbf",
        "border_width": 2,
        "z": 30,
        "locked": True
    })
    text_list.append({
        "ip": "scroller_settings_label",
        "text": state["settings_label_text"],
        "x": 40,
        "y": panel_y + 15,
        "customise": {
            "font_family": "Segoe UI",
            "font_size": 12,
            "color": state["settings_label_color"],
            "bold": True,
            "opacity": 100
        }
    })
    
    # Save Button (aligned relative to panel right)
    save_scale = state["save_scale"]
    save_btn_w = int(90 * save_scale)
    save_btn_h = int(35 * save_scale)
    save_btn_x = int((width - 240) + (90 - save_btn_w) / 2)
    save_btn_y = int((panel_y + 45) + (35 - save_btn_h) / 2)
    
    shapes_list.append({
        "ip": "scroller_settings_save_btn",
        "vertices": 4,
        "x": save_btn_x,
        "y": save_btn_y,
        "width": save_btn_w,
        "height": save_btn_h,
        "border_radius": 8,
        "color": "#7b2cbf",
        "border_color": "#9d4edd",
        "border_width": 1,
        "z": 28
    })
    text_list.append({
        "ip": "scroller_settings_save_txt",
        "text": "Save",
        "x": int(save_btn_x + (save_btn_w - 40) / 2),
        "y": int(save_btn_y + (save_btn_h - 18) / 2),
        "customise": {
            "font_family": "Segoe UI",
            "font_size": int(12 * save_scale),
            "color": "white",
            "bold": True,
            "opacity": 100
        }
    })

    # Clear Chat Button (aligned relative to panel right)
    clear_scale = state["clear_scale"]
    clear_btn_w = int(90 * clear_scale)
    clear_btn_h = int(35 * clear_scale)
    clear_btn_x = int((width - 130) + (90 - clear_btn_w) / 2)
    clear_btn_y = int((panel_y + 45) + (35 - clear_btn_h) / 2)
    
    shapes_list.append({
        "ip": "scroller_settings_clear_btn",
        "vertices": 4,
        "x": clear_btn_x,
        "y": clear_btn_y,
        "width": clear_btn_w,
        "height": clear_btn_h,
        "border_radius": 8,
        "color": "#2a2b36",
        "border_color": "#ff4d6d",
        "border_width": 1,
        "z": 28
    })
    text_list.append({
        "ip": "scroller_settings_clear_txt",
        "text": "Clear",
        "x": int(clear_btn_x + (clear_btn_w - 40) / 2),
        "y": int(clear_btn_y + (clear_btn_h - 18) / 2),
        "customise": {
            "font_family": "Segoe UI",
            "font_size": int(12 * clear_scale),
            "color": "#ff4d6d",
            "bold": True,
            "opacity": 100
        }
    })
    
    # 6. Bottom Input Bar (Dynamic size matching window)
    shapes_list.append({
        "ip": "scroller_input_bg",
        "vertices": 4,
        "x": 0,
        "y": height - 80,
        "width": width,
        "height": 80,
        "color": "#16161d",
        "z": 50,
        "locked": True
    })
    shapes_list.append({
        "ip": "scroller_input_border",
        "vertices": 4,
        "x": 0,
        "y": height - 80,
        "width": width,
        "height": 2,
        "color": "#6200ea",
        "z": 49,
        "locked": True
    })
    
    # Send Button (aligned to right)
    send_scale = state["send_scale"]
    send_w = int(90 * send_scale)
    send_h = int(40 * send_scale)
    send_x = int((width - 115) + (90 - send_w) / 2)
    send_y = int((height - 60) + (40 - send_h) / 2)
    
    shapes_list.append({
        "ip": "scroller_send_btn",
        "vertices": 4,
        "x": send_x,
        "y": send_y,
        "width": send_w,
        "height": send_h,
        "border_radius": 12,
        "color": "#7b2cbf",
        "border_color": "#9d4edd",
        "border_width": 1,
        "z": 45
    })
    text_list.append({
        "ip": "scroller_send_txt",
        "text": "Send",
        "x": int(send_x + (send_w - 40) / 2),
        "y": int(send_y + (send_h - 18) / 2),
        "customise": {
            "font_family": "Segoe UI",
            "font_size": int(14 * send_scale),
            "color": "white",
            "bold": True,
            "opacity": 100
        }
    })
    
    # Apply to Canvas
    Draw.shapes(
        display="chatbot",
        shape=shapes_list,
        text=text_list
    )

# ── Message sending logic ──
def send_message(text=None):
    if state["thinking"]:
        return
        
    input_text = Draw.lineedit.get_text("chat_input").strip()
    if not input_text:
        return
        
    # Validation: API key presence check
    if not state["api_key"]:
        state["settings_open"] = True
        state["target_panel_y"] = 75
        state["settings_label_text"] = "⚠️ Gemini API Key Required to Chat!"
        state["settings_label_color"] = "#ff4d6d"
        
        def reset_label():
            if state["settings_label_text"] == "⚠️ Gemini API Key Required to Chat!":
                state["settings_label_text"] = "Enter Gemini API Key:"
                state["settings_label_color"] = "#b0b0b0"
        Draw.after(3.0, reset_label)
        return
        
    # Clear input field
    Draw.lineedit.set_text("chat_input", "")
    
    # Add message bubble
    state["messages"].append({
        "sender": "user",
        "text": input_text,
        "scale": 0.5,
        "opacity": 0.0,
        "y_offset": 30.0
    })
    
    # Append to api history
    state["history"].append({"role": "user", "parts": [{"text": input_text}]})
    state["thinking"] = True
    
    # Ensure view starts auto-scrolling to show user bubble
    state["auto_scroll_active"] = True
    
    # Trigger rebuild
    rebuild_ui()
    
    # Threaded async API call
    async_call_gemini(state["api_key"], state["history"])

# ── Animation frame tick loop ──
def tick():
    if "chatbot" not in Draw.window.list_tags():
        return
        
    canvas = Draw.window.get_canvas("chatbot")
    width = canvas.width()
    height = canvas.height()
    
    # 1. Slide settings panel
    state["panel_y"] += (state["target_panel_y"] - state["panel_y"]) * 0.15
    
    # 2. Settings button rotation
    if state["settings_hovered"]:
        state["settings_rotation"] = (state["settings_rotation"] + 6) % 360
    else:
        diff = 0.0 - state["settings_rotation"]
        if abs(diff) > 1.0:
            state["settings_rotation"] += diff * 0.15
        else:
            state["settings_rotation"] = 0.0
            
    # 3. Secure input QLineEdit coordinates & visibility (dynamically placed and sized)
    if state["settings_open"]:
        if state["panel_y"] > -140:
            Draw.lineedit.show("api_key_input")
            Draw.lineedit.move("api_key_input", x=40, y=int(state["panel_y"] + 45))
            Draw.lineedit.resize("api_key_input", width=width - 300, height=35)
    else:
        if state["panel_y"] > -140:
            Draw.lineedit.move("api_key_input", x=40, y=int(state["panel_y"] + 45))
            Draw.lineedit.resize("api_key_input", width=width - 300, height=35)
        else:
            Draw.lineedit.hide("api_key_input")
            
    # 4. Message Input field dynamic positioning
    Draw.lineedit.move("chat_input", x=25, y=height - 60)
    Draw.lineedit.resize("chat_input", width=width - 160, height=40)
            
    # 5. Message bubble zoom entrance interpolation
    msg_changed = False
    for msg in state["messages"]:
        scale_diff = 1.0 - msg["scale"]
        opacity_diff = 100.0 - msg["opacity"]
        y_off_diff = 0.0 - msg["y_offset"]
        
        if abs(scale_diff) > 0.01 or abs(opacity_diff) > 0.1 or abs(y_off_diff) > 0.1:
            msg["scale"] += scale_diff * 0.15
            msg["opacity"] += opacity_diff * 0.15
            msg["y_offset"] += y_off_diff * 0.15
            msg_changed = True
            
    # 6. Check asynchronous API responses
    if not api_queue.empty():
        res = api_queue.get()
        state["thinking"] = False
        
        state["messages"].append({
            "sender": "model",
            "text": res["text"],
            "scale": 0.5,
            "opacity": 0.0,
            "y_offset": 30.0
        })
        
        if res["status"] == "success":
            state["history"].append({"role": "model", "parts": [{"text": res["text"]}]})
            
        msg_changed = True
        state["auto_scroll_active"] = True
        
    # 7. Scroll yield logic (detect user scroll and disable auto-scroll)
    dragged = getattr(canvas, "_dragged_shape", None)
    if dragged is not None and getattr(dragged, "ip", None) == "scroller_right_thumb":
        state["auto_scroll_active"] = False

    if sense_scroll_up.consume() or sense_scroll_down.consume():
        state["auto_scroll_active"] = False

    # 8. Smooth viewport scrolling interpolation
    if state["auto_scroll_active"]:
        scroll_diff = state["scroll_target_y"] - canvas._scroll_y
        if abs(scroll_diff) > 0.5:
            canvas._scroll_y += scroll_diff * 0.12
            canvas._update_scroller_thumbs()
            msg_changed = True
        else:
            canvas._scroll_y = state["scroll_target_y"]
            state["auto_scroll_active"] = False
        
    # 9. Button hover scale animations
    target_save_scale = 1.12 if state["save_hovered"] else 1.0
    save_scale_diff = target_save_scale - state["save_scale"]
    if abs(save_scale_diff) > 0.01:
        state["save_scale"] += save_scale_diff * 0.2
        msg_changed = True

    target_clear_scale = 1.12 if state["clear_hovered"] else 1.0
    clear_scale_diff = target_clear_scale - state["clear_scale"]
    if abs(clear_scale_diff) > 0.01:
        state["clear_scale"] += clear_scale_diff * 0.2
        msg_changed = True
        
    target_send_scale = 1.12 if state["send_hovered"] else 1.0
    send_scale_diff = target_send_scale - state["send_scale"]
    if abs(send_scale_diff) > 0.01:
        state["send_scale"] += send_scale_diff * 0.2
        msg_changed = True
        
    # 10. Senses event handling
    if sense_hover_settings.consume():
        state["settings_hovered"] = True
    if sense_leave_settings.consume():
        state["settings_hovered"] = False
    if sense_click_settings.consume():
        state["settings_open"] = not state["settings_open"]
        if state["settings_open"]:
            state["target_panel_y"] = 75
        else:
            state["target_panel_y"] = -150
            
    if sense_hover_save.consume():
        state["save_hovered"] = True
    if sense_leave_save.consume():
        state["save_hovered"] = False
    if sense_click_save.consume():
        key_val = Draw.lineedit.get_text("api_key_input").strip()
        state["api_key"] = key_val
        if key_val:
            state["settings_label_text"] = "API Key Saved! ✓"
            state["settings_label_color"] = "#2ec4b6"
        else:
            state["settings_label_text"] = "API Key Cleared!"
            state["settings_label_color"] = "#ff4d6d"
            
        def close_settings():
            state["settings_open"] = False
            state["target_panel_y"] = -150
            state["settings_label_text"] = "Enter Gemini API Key:"
            state["settings_label_color"] = "#b0b0b0"
        Draw.after(1.0, close_settings)

    if sense_hover_clear.consume():
        state["clear_hovered"] = True
    if sense_leave_clear.consume():
        state["clear_hovered"] = False
    if sense_click_clear.consume():
        state["messages"] = [
            {
                "sender": "model",
                "text": "Hello! I am Gemini. Let's start a fresh conversation!",
                "scale": 1.0,
                "opacity": 100.0,
                "y_offset": 0.0
            }
        ]
        state["history"] = []
        state["scroll_target_y"] = 0.0
        state["auto_scroll_active"] = True
        
    if sense_hover_send.consume():
        state["send_hovered"] = True
    if sense_leave_send.consume():
        state["send_hovered"] = False
    if sense_click_send.consume():
        send_message()
        
    # Rebuild UI if thinking (bouncing dots), sliding panel, or resizing/scrolling
    panel_animating = abs(state["target_panel_y"] - state["panel_y"]) > 0.5
    if msg_changed or state["thinking"] or panel_animating or state["settings_hovered"]:
        rebuild_ui()

# ── Initialization ──

# 1. Background Shape & Gradient (Initialized to match default 800x600 size)
Draw.shapes(
    display="chatbot",
    shape=[
        {
            "ip": "scroller_bg",
            "vertices": 4,
            "x": 0,
            "y": 0,
            "size": [800, 600],
            "z": 1000,
            "overlap": True,
            "locked": True
        }
    ]
)
Draw.color(
    ip="scroller_bg",
    color=[
        {
            "for": "body",
            "gradient": "linear",
            "angle": 45,
            "stops": [
                [0, [11, 12, 16]],       # #0b0c10
                [100, [31, 40, 51]]      # #1f2833
            ]
        }
    ]
)

# 2. Scrollbar vertical tracker and thumb
Draw.shapes(
    display="chatbot",
    properties=["scroller"],
    shapes=[
        {"place": "right", "color": "#16161d", "thumb_color": "#4a4a5a", "width": 8}
    ]
)

# 3. Settings Input Secure Lineedit
Draw.lineedit(
    ip="api_key_input",
    display="chatbot",
    x=40,
    y=-100,
    width=500,
    height=35,
    placeholder="Enter your Gemini API key...",
    password=True,
    style={
        "background_color": "#252530",
        "text_color": "#ffffff",
        "border_color": "#7b2cbf",
        "border_width": 1,
        "border_radius": 8,
        "font_size": 12
    }
)
Draw.lineedit.hide("api_key_input")
if state["api_key"]:
    Draw.lineedit.set_text("api_key_input", state["api_key"])

# 4. Message Input Lineedit
Draw.lineedit(
    ip="chat_input",
    display="chatbot",
    x=25,
    y=540,
    width=640,
    height=40,
    placeholder="Type a message...",
    style={
        "background_color": "#252530",
        "text_color": "#ffffff",
        "border_color": "#7b2cbf",
        "border_width": 1,
        "border_radius": 12,
        "font_size": 14
    },
    on_submit=send_message
)

# 5. Interactive Event Senses
sense_hover_settings = Draw.senses("mouse_hover", id="hover_settings", ip="scroller_settings_btn")
sense_leave_settings = Draw.senses("mouse_leave", id="leave_settings", ip="scroller_settings_btn")
sense_click_settings = Draw.senses("mouse_click", id="click_settings", ip="scroller_settings_btn")

sense_hover_save = Draw.senses("mouse_hover", id="hover_save", ip="scroller_settings_save_btn")
sense_leave_save = Draw.senses("mouse_leave", id="leave_save", ip="scroller_settings_save_btn")
sense_click_save = Draw.senses("mouse_click", id="click_save", ip="scroller_settings_save_btn")

sense_hover_clear = Draw.senses("mouse_hover", id="hover_clear", ip="scroller_settings_clear_btn")
sense_leave_clear = Draw.senses("mouse_leave", id="leave_clear", ip="scroller_settings_clear_btn")
sense_click_clear = Draw.senses("mouse_click", id="click_clear", ip="scroller_settings_clear_btn")

sense_hover_send = Draw.senses("mouse_hover", id="hover_send", ip="scroller_send_btn")
sense_leave_send = Draw.senses("mouse_leave", id="leave_send", ip="scroller_send_btn")
sense_click_send = Draw.senses("mouse_click", id="click_send", ip="scroller_send_btn")

# Senses for scroll-wheel yielding
sense_scroll_up = Draw.senses("mouse_scroll_up", id="scroll_up", ip="scroller_bg")
sense_scroll_down = Draw.senses("mouse_scroll_down", id="scroll_down", ip="scroller_bg")

# 6. Render Initial View
rebuild_ui()

# 7. Start 60 FPS tick callback and window loop
Draw.every(0.016, tick)
Draw.window.run("chatbot")
