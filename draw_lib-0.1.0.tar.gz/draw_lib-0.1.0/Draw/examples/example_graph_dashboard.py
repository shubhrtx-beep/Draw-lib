import os
import sys
import random

# Add parent directory to sys.path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
import Draw

# Initialize Main Window (1000x700)
Draw.window(tag="main", title="Interactive Graph & Live Analytics Dashboard", width=1000, height=700, resizable=False)

# 1. Background Shape
Draw.shapes(
    display="main",
    shape=[
        {
            "ip": "bg",
            "vertices": 4,
            "x": 0,
            "y": 0,
            "size": [1000, 700],
            "z": 1000,
            "color": "#0F172A",
            "overlap": True,
            "locked": True
        }
    ]
)

# 2. Header Text
Draw.text(
    tag="main",
    text="📊 Real-Time Graph Analytics & Interactive Suite",
    ip="header_title",
    x=40,
    y=25,
    customise={
        "font_size": 22,
        "font_family": "Outfit",
        "color": "#F8FAFC",
        "bold": True
    }
)

Draw.text(
    tag="main",
    text="Features: Live Streaming Data (Draw.live), Hold & Move Dragging, Hover Tooltips, Catmull-Rom Vector Splines",
    ip="header_sub",
    x=40,
    y=58,
    customise={
        "font_size": 12,
        "font_family": "Outfit",
        "color": "#94A3B8"
    }
)

# 3. Setup Reactive State via Draw.live
Draw.live.set("categories", ["Q1", "Q2", "Q3", "Q4", "Q5"])
Draw.live.set("revenue_vals", [120, 240, 180, 310, 290])
Draw.live.set("profit_vals", [45, 95, 70, 140, 125])

# 4. Render Grouped Bar & Line Chart (Live + Draggable)
Draw.graph(
    ip="sales_graph",
    type="bar",
    tag="main",
    align="top-left",
    draggable=True,   # Hold & Move enabled!
    animate=True,     # 2D Motion Engine entry!
    hover=True,       # Interactive hover tooltips!
    graph=[
        # Series 1: Bar Revenue
        {
            "x": Draw.live.ref("categories"),
            "y": Draw.live.ref("revenue_vals"),
            "title": "Revenue ($K)",
            "customise": {
                "color": "#3B82F6",
                "show_values": True,
                "value_decimals": 0,
                "title": "Sales & Profit Performance (Draggable)",
                "x_title": "Quarter / Period",
                "y_title": "Amount ($K)",
                "show_line": True,
                "show_legend": True,
                "legend_position": "top-left",
                "margin": 45,
            }
        },
        # Series 2: Smooth Spline Line Profit
        {
            "x": Draw.live.ref("categories"),
            "y": Draw.live.ref("profit_vals"),
            "type": "line",
            "title": "Net Profit ($K)",
            "customise": {
                "line_color": "#10B981",
                "line_width": 4,
                "smooth": True,     # Catmull-Rom vector path spline
                "point_size": 10,
            }
        }
    ]
)

# 5. Render Donut Chart (Market Share)
Draw.graph(
    ip="donut_chart",
    type="donut",
    tag="main",
    align="top-right",
    draggable=True,
    animate=True,
    graph=[
        {
            "x": ["Direct", "Organic", "Referral", "Social"],
            "y": [40, 30, 18, 12],
            "title": "Traffic Share",
            "customise": {
                "color": ["#6366F1", "#10B981", "#F59E0B", "#EC4899"],
                "center_text": "100%",
                "hole_color": "#0F172A",
                "margin": 30,
            }
        }
    ]
)

# 6. Render Radar / Spider Chart (Performance Metrics)
Draw.graph(
    ip="radar_chart",
    type="radar",
    tag="main",
    align="bottom-left",
    draggable=True,
    graph=[
        {
            "x": ["Speed", "Uptime", "Security", "Scale", "UX"],
            "y": [88, 99, 94, 90, 96],
            "title": "System Audit",
            "customise": {
                "margin": 35,
            }
        }
    ]
)

# 7. Live Stream Simulation Loop (Updates values continuously)
def stream_tick():
    # Simulate real-time fluctuating revenue/profit values
    revenue = Draw.live.get("revenue_vals")
    profit = Draw.live.get("profit_vals")

    new_rev = [max(50, min(400, v + random.randint(-15, 20))) for v in revenue]
    new_prof = [max(20, min(200, int(v * 0.45))) for v in new_rev]

    Draw.live.set("revenue_vals", new_rev)
    Draw.live.set("profit_vals", new_prof)

    # Refresh live charts smoothly
    Draw.graph.update_live("main")

# Run live stream updates every 1.5 seconds
Draw.every(1.5, stream_tick)

# Launch Main GUI Loop
Draw.window.run("main")
