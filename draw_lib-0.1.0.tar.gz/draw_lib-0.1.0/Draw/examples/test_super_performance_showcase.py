"""
Draw.super Performance Showcase
===============================
Demonstrates Draw.super OpenGL Hardware Acceleration with 300+ animated shapes,
spring physics, dragging, smooth scrolling, and live FPS metrics.
"""

import os
import sys
import random

SYS_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PARENT_ROOT = os.path.dirname(SYS_ROOT)
if PARENT_ROOT not in sys.path:
    sys.path.insert(0, PARENT_ROOT)
if SYS_ROOT not in sys.path:
    sys.path.insert(0, SYS_ROOT)

import Draw

def main():
    print("Initializing Window...")
    Draw.window(
        tag="super_showcase",
        title="Draw.super — OpenGL Hardware Acceleration Showcase",
        width=1200,
        height=800,
        background_color="#0D1117",
    )

    # 1. Header & Live Dashboard Text
    Draw.text(
        tag="super_showcase",
        text="⚡ Draw.super — OpenGL Hardware Accelerated Engine",
        customise={
            "x": 40,
            "y": 30,
            "font_size": 24,
            "bold": True,
            "color": "#58A6FF",
        }
    )

    Draw.text(
        tag="super_showcase",
        text="Rendering 300+ dynamic shapes with GPU batching, O(1) frustum culling, and zero micro-stutters.",
        customise={
            "x": 40,
            "y": 70,
            "font_size": 13,
            "color": "#8B949E",
        }
    )

    # 2. Generate 300 animated/interactive geometric shapes
    colors = ["#FF5722", "#00E676", "#00B0FF", "#E040FB", "#FFD600", "#FF1744", "#00E5FF", "#76FF03"]
    shape_list = []

    cols = 20
    rows = 15
    spacing_x = 55
    spacing_y = 55
    start_x = 40
    start_y = 120

    print("Generating 300 shapes...")
    for r in range(rows):
        for c in range(cols):
            idx = r * cols + c
            v_count = random.choice([3, 4, 5, 6, 8])
            col = random.choice(colors)
            size = random.randint(32, 48)
            px = start_x + c * spacing_x
            py = start_y + r * spacing_y

            shape_list.append({
                "vertices": v_count,
                "size": [size, size],
                "color": col,
                "x": px,
                "y": py,
                "rotation": random.randint(0, 360),
                "ip": f"node_{idx}",
            })

    Draw.shape(
        display="super_showcase",
        shape=shape_list
    )

    # 3. Add Motion & Physics triggers to shapes
    print("Configuring motion & physics triggers...")
    for i in range(0, min(50, len(shape_list))):
        Draw.motion(
            target=f"node_{i}",
            type="rotate",
            to=360,
            time={"start": 0.0, "end": random.uniform(2.0, 5.0)},
            repeat=True,
        )

    # 4. Activate Draw.super OpenGL Hardware Acceleration Engine!
    print("Activating Draw.super (Upfront pre-compilation, GPU buffer allocation, GC tuning)...")
    Draw.super(
        display="super_showcase",
        precompile=True,   # Slower init, ultra-smooth runtime!
        mode="max",        # Tunes GC thresholds & builds spatial index
        vsync=False,       # Uncapped FPS
        batch_capacity=65536,
    )

    print("\n[OK] Draw.super is ready. Starting window event loop...")
    Draw.window.run("super_showcase")

if __name__ == "__main__":
    main()
