"""
examples/dodge_game.py
======================
Falling Obstacles Dodge Game built with the Draw library.

Features:
- Draw.loader spinning startup animation.
- Draw.room declarative relative layout engine.
- 60 FPS physics loop via Draw.every.
- Pure Draw API.

Run with:
    D:/python/python.exe examples/dodge_game.py
"""
import os
import sys

# Ensure repository root is on sys.path
REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PARENT_ROOT = os.path.dirname(REPO_ROOT)
if PARENT_ROOT not in sys.path:
    sys.path.insert(0, PARENT_ROOT)
if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)

import dodge_game

if __name__ == "__main__":
    dodge_game.main()
