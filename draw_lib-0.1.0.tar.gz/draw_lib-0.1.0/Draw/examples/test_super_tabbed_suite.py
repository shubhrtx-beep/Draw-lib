"""
Draw.super Tabbed Interactive Test Suite (100% Pure Draw Engine + Live FPS)
===========================================================================
Interactive tabbed test suite powered entirely by the Draw engine & Draw.super (OpenGL):
Allows switching between tabs at the top:
  [ 🎨 Color ] [ 🌀 Motion ] [ 🔷 Shapes ] [ 📊 Graph ] [ ⚡ Live ] [ 🖱️ Mouse ] [ ⌨️ Keyboard ]

Features:
- Pure Draw Architecture: Tabs, buttons, inputs, HUDs rendered exclusively via Draw.shape, Draw.text, and Draw.senses (No Qt widgets).
- 100% Clean Tab Switching: Automatically purges old tab geometry, stopping previous motions/timelines without residue.
- Real-Time Hardware FPS Counter: Live OpenGL rendering FPS badge displayed directly in the top navigation bar.
- Full Hardware Sensor Support: 1:1 shape dragging, mouse clicks/right-clicks, keyboard events, and live typed text buffer.

Run with:
    D:/python/python.exe Draw/examples/test_super_tabbed_suite.py
"""

import os
import sys
import math
import random
import time

SYS_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PARENT_ROOT = os.path.dirname(SYS_ROOT)
if PARENT_ROOT not in sys.path:
    sys.path.insert(0, PARENT_ROOT)
if SYS_ROOT not in sys.path:
    sys.path.insert(0, SYS_ROOT)

import Draw

WIN_TAG = "super_tabbed_suite"
WIN_W = 1260
WIN_H = 820

# Active Tab State
_current_tab = "Color"
TABS = ["Color", "Motion", "Shapes", "Graph", "Live", "Mouse", "Keyboard"]

# Keep-list of top navigation item IPs so they never get wiped when changing tabs
NAV_IPS = {
    "nav_top_bg", "nav_fps_badge", "nav_fps_text"
}
for _t in TABS:
    NAV_IPS.add(f"nav_tab_{_t.lower()}")
    NAV_IPS.add(f"nav_tab_txt_{_t.lower()}")

# Telemetry & Sensor States
_state = {
    "clicks": 0,
    "rclicks": 0,
    "dblclicks": 0,
    "last_key": "None",
    "typed_text": "Draw.super pure engine test...",
    "live_counter": 0,
    "live_val1": 45,
    "live_val2": 80,
    "live_val3": 60,
}


def get_fps_hud_text() -> str:
    """Return live FPS telemetry from Draw.super OpenGL engine."""
    gl_canvas = Draw.super.get(WIN_TAG)
    fps_val = gl_canvas.fps if gl_canvas is not None else 60.0
    return f"⚡ {int(round(fps_val))} FPS | GL"


def clear_content_area():
    """
    Completely and cleanly wipe all old tab elements from the canvas using
    Draw.super.clear(), preserving only the top navigation bar.
    """
    # 1. Stop any active timelines
    try:
        Draw._motion.motion._active_timelines.clear()
    except Exception:
        pass

    # 2. Clear previous graphs
    try:
        Draw.graph.clear(WIN_TAG)
    except Exception:
        pass

    # 3. Cleanly clear all non-navigation shapes, texts, and GPU batch buffers
    Draw.super.clear(WIN_TAG, keep_ips=NAV_IPS)


def set_tab(tab_name: str):
    """Switch active tab cleanly."""
    global _current_tab
    if tab_name not in TABS:
        return
    _current_tab = tab_name
    print(f"[Tab] Switched to -> {tab_name}")

    # 1. Clear previous tab items completely
    clear_content_area()

    # 2. Update navigation tab button highlights
    update_top_navigation_highlights()

    # 3. Mount new tab content
    if tab_name == "Color":
        mount_color_tab()
    elif tab_name == "Motion":
        mount_motion_tab()
    elif tab_name == "Shapes":
        mount_shapes_tab()
    elif tab_name == "Graph":
        mount_graph_tab()
    elif tab_name == "Live":
        mount_live_tab()
    elif tab_name == "Mouse":
        mount_mouse_tab()
    elif tab_name == "Keyboard":
        mount_keyboard_tab()

    # Request canvas repaint
    canvas = Draw.super.get(WIN_TAG)
    if canvas is not None:
        canvas.update()


# ─────────────────────────────────────────────────────────────────────────────
# TAB 1: COLOR SHOWCASE
# ─────────────────────────────────────────────────────────────────────────────

def mount_color_tab():
    bx, by = 40, 95

    # Header info
    Draw.text(
        tag=WIN_TAG, ip="t_col_hdr",
        text="🎨 Universal Color & Shader Pipeline",
        customise={"x": bx, "y": by, "font_size": 18, "bold": True, "color": "#38BDF8"}
    )
    Draw.text(
        tag=WIN_TAG, ip="t_col_sub",
        text="Demonstrating Hex (#RRGGBB), Named colors, Alpha Opacity Blending, Dynamic HSV Math Expressions, and Glow / Shadows.",
        customise={"x": bx, "y": by + 26, "font_size": 11, "color": "#94A3B8"}
    )

    # 1. Solid & Named Colors
    palette = [
        ("#EF4444", "Red\n#EF4444"),
        ("#F97316", "Orange\n#F97316"),
        ("#EAB308", "Yellow\n#EAB308"),
        ("#10B981", "Green\n#10B981"),
        ("#06B6D4", "Cyan\n#06B6D4"),
        ("#3B82F6", "Blue\n#3B82F6"),
        ("#8B5CF6", "Purple\n#8B5CF6"),
        ("#EC4899", "Pink\n#EC4899"),
    ]

    for i, (hex_col, label) in enumerate(palette):
        px = bx + (i % 4) * 140
        py = by + 65 + (i // 4) * 90
        Draw.shape(display=WIN_TAG, shape=[{
            "ip": f"col_box_{i}", "vertices": 4, "size": [120, 55],
            "x": px, "y": py,
            "color": hex_col, "border_radius": 8,
        }])
        Draw.text(tag=WIN_TAG, ip=f"col_lbl_{i}", text=label, customise={
            "x": px + 8, "y": py + 60,
            "font_size": 10, "color": "#CBD5E1"
        })

    # 2. Alpha Opacity Demonstration
    op_y = by + 260
    Draw.text(tag=WIN_TAG, ip="t_col_op_hdr", text="Alpha Opacity Levels (100% -> 15%)", customise={
        "x": bx, "y": op_y, "font_size": 13, "bold": True, "color": "#F1F5F9"
    })

    opacities = [100, 75, 50, 25, 15]
    for i, op in enumerate(opacities):
        px = bx + i * 115
        py = op_y + 25
        Draw.shape(display=WIN_TAG, shape=[{
            "ip": f"col_op_{i}", "vertices": 4, "size": [95, 50],
            "x": px, "y": py,
            "color": "#00E5FF", "opacity": op, "border_radius": 6,
        }])
        Draw.text(tag=WIN_TAG, ip=f"col_op_lbl_{i}", text=f"{op}%", customise={
            "x": px + 34, "y": py + 55,
            "font_size": 10, "color": "#94A3B8"
        })

    # 3. Dynamic HSV Math Expressions
    dyn_x = bx + 620
    Draw.text(tag=WIN_TAG, ip="t_col_dyn_hdr", text="Dynamic HSV Math Expression (h = time * 60)", customise={
        "x": dyn_x, "y": by + 65, "font_size": 13, "bold": True, "color": "#F1F5F9"
    })

    Draw.shape(display=WIN_TAG, shape=[{
        "ip": "dyn_hsv_shape", "vertices": 6, "size": [130, 130],
        "x": dyn_x + 50, "y": by + 95, "color": "#3B82F6",
    }])
    Draw.color(ip="dyn_hsv_shape", color=[{"for": "body", "h": "time * 60", "s": 90, "v": 100}])

    # 4. Glow & Shadows
    Draw.text(tag=WIN_TAG, ip="t_col_glow_hdr", text="Glow & Drop Shadow Effects", customise={
        "x": dyn_x, "y": by + 260, "font_size": 13, "bold": True, "color": "#F1F5F9"
    })

    Draw.shape(display=WIN_TAG, shape=[
        {
            "ip": "col_glow_box", "vertices": 4, "size": [110, 55],
            "x": dyn_x, "y": by + 290, "color": "#EC4899", "border_radius": 10,
            "glow_color": "#EC4899", "glow_blur": 18,
        },
        {
            "ip": "col_shadow_box", "vertices": 4, "size": [110, 55],
            "x": dyn_x + 140, "y": by + 290, "color": "#10B981", "border_radius": 10,
            "shadow_color": "rgba(0,0,0,0.7)", "shadow_blur": 12, "shadow_offset": [5, 5],
        },
    ])


# ─────────────────────────────────────────────────────────────────────────────
# TAB 2: MOTION & PHYSICS SHOWCASE
# ─────────────────────────────────────────────────────────────────────────────

def mount_motion_tab():
    bx, by = 40, 95

    Draw.text(
        tag=WIN_TAG, ip="t_mot_hdr",
        text="🌀 2D Motion Engine & Real-Time Physics",
        customise={"x": bx, "y": by, "font_size": 18, "bold": True, "color": "#38BDF8"}
    )
    Draw.text(
        tag=WIN_TAG, ip="t_mot_sub",
        text="Hardware-accelerated interpolation for move, rotate, scale, opacity, spring physics, wave, and shake.",
        customise={"x": bx, "y": by + 26, "font_size": 11, "color": "#94A3B8"}
    )

    items = [
        ("m_move_node", "Ping-Pong Move", "#3B82F6", 4, 8, bx, by + 75, [50, 50]),
        ("m_rot_node", "Rotate 360°", "#F43F5E", 6, 0, bx + 280, by + 75, [55, 55]),
        ("m_scale_node", "Scale / Pulse", "#10B981", 4, 25, bx + 560, by + 75, [45, 45]),
        ("m_spring_node", "Spring Oscillator", "#F59E0B", 4, 6, bx, by + 210, [50, 50]),
        ("m_wave_node", "Harmonic Wave", "#8B5CF6", 4, 25, bx + 280, by + 210, [50, 50]),
        ("m_shake_node", "Vibration Shake", "#EC4899", 4, 6, bx + 560, by + 210, [50, 50]),
    ]

    for ip, label, color, verts, rad, x, y, sz in items:
        Draw.shape(display=WIN_TAG, shape=[{
            "ip": ip, "vertices": verts, "size": sz,
            "x": x, "y": y, "color": color, "border_radius": rad,
        }])
        Draw.text(tag=WIN_TAG, ip=f"{ip}_lbl", text=label, customise={
            "x": x, "y": y + 62, "font_size": 11, "bold": True, "color": "#E2E8F0"
        })

    # Attach Motion Definitions
    Draw.motion(ip="m_move_node", motion=[{"type": "move", "from": [bx, by + 75], "to": [bx + 160, by + 75], "time": {"start": 0, "end": 2.0}, "repeat": True, "pingpong": True}])
    Draw.motion(ip="m_rot_node", motion=[{"type": "rotate", "from": 0, "to": 360, "time": {"start": 0, "end": 3.0}, "repeat": True}])
    Draw.motion(ip="m_scale_node", motion=[{"type": "scale", "from": [1.0, 1.0], "to": [1.6, 1.6], "time": {"start": 0, "end": 1.2}, "repeat": True, "pingpong": True}])
    Draw.motion(ip="m_spring_node", motion=[{"type": "spring", "stiffness": 160, "damping": 10, "from": [bx, by + 210], "to": [bx + 180, by + 210], "time": {"start": 0, "end": 2.5}, "repeat": True, "pingpong": True}])
    Draw.motion(ip="m_wave_node", motion=[{"type": "wave", "amplitude": 25, "frequency": 2.0, "time": {"start": 0, "end": 4.0}, "repeat": True}])
    Draw.motion(ip="m_shake_node", motion=[{"type": "shake", "intensity": 8, "frequency": 5, "time": {"start": 0, "end": 10.0}, "repeat": True}])

    # Timeline demo at bottom
    time_y = by + 350
    Draw.text(tag=WIN_TAG, ip="t_tl_hdr", text="Sequential Keyframe Timeline (Move -> Rotate -> Scale)", customise={
        "x": bx, "y": time_y, "font_size": 13, "bold": True, "color": "#F1F5F9"
    })

    Draw.shape(display=WIN_TAG, shape=[{
        "ip": "timeline_demo_node", "vertices": 5, "size": [50, 50],
        "x": bx, "y": time_y + 30, "color": "#06B6D4",
    }])

    Draw.timeline(tag=WIN_TAG, motion=[
        {"ip": "timeline_demo_node", "type": "move", "from": [bx, time_y + 30], "to": [bx + 350, time_y + 30], "time": {"start": 0.0, "end": 1.5}},
        {"ip": "timeline_demo_node", "type": "rotate", "from": 0, "to": 360, "time": {"start": 1.5, "end": 3.0}},
        {"ip": "timeline_demo_node", "type": "scale", "from": [1.0, 1.0], "to": [1.5, 1.5], "time": {"start": 3.0, "end": 4.0}, "pingpong": True},
    ])


# ─────────────────────────────────────────────────────────────────────────────
# TAB 3: SHAPES & GEOMETRY SHOWCASE
# ─────────────────────────────────────────────────────────────────────────────

def mount_shapes_tab():
    bx, by = 40, 95

    Draw.text(
        tag=WIN_TAG, ip="t_shp_hdr",
        text="🔷 GPU Dynamic Polygons & Complex Geometry",
        customise={"x": bx, "y": by, "font_size": 18, "bold": True, "color": "#38BDF8"}
    )
    Draw.text(
        tag=WIN_TAG, ip="t_shp_sub",
        text="Batches regular N-gons directly into VBOs, plus QPainter fallback for borders, radius, bend, and vector paths.",
        customise={"x": bx, "y": by + 26, "font_size": 11, "color": "#94A3B8"}
    )

    # 1. Regular GPU-batched Polygons
    poly_list = [
        (3, "Triangle", "#EF4444"),
        (4, "Quad", "#F97316"),
        (5, "Pentagon", "#EAB308"),
        (6, "Hexagon", "#10B981"),
        (7, "Heptagon", "#06B6D4"),
        (8, "Octagon", "#3B82F6"),
        (10, "Decagon", "#8B5CF6"),
        (12, "Dodecagon", "#EC4899"),
    ]

    for i, (v, name, col) in enumerate(poly_list):
        px = bx + i * 140
        py = by + 75
        Draw.shape(display=WIN_TAG, shape=[{
            "ip": f"poly_demo_{v}", "vertices": v, "size": [55, 55],
            "x": px, "y": py, "color": col,
        }])
        Draw.text(tag=WIN_TAG, ip=f"poly_lbl_{v}", text=f"{v} sides\n{name}", customise={
            "x": px, "y": py + 62, "font_size": 10, "color": "#CBD5E1"
        })

    # 2. Complex Stylized Shapes
    c_y = by + 225
    Draw.text(tag=WIN_TAG, ip="t_shp_c_hdr", text="Stylized Shapes (Borders, Dashes, Bend Deformation)", customise={
        "x": bx, "y": c_y, "font_size": 13, "bold": True, "color": "#F1F5F9"
    })

    complex_shapes = [
        {"ip": "c_border", "vertices": 4, "size": [80, 55], "x": bx, "y": c_y + 30, "color": "#1E293B", "border_width": 3, "border_color": "#38BDF8"},
        {"ip": "c_dash", "vertices": 4, "size": [80, 55], "x": bx + 110, "y": c_y + 30, "color": "#1E293B", "border_width": 2, "border_color": "#F59E0B", "border_style": "dashed"},
        {"ip": "c_round", "vertices": 4, "size": [80, 55], "x": bx + 220, "y": c_y + 30, "color": "#8B5CF6", "border_radius": 20},
        {"ip": "c_circle", "vertices": 4, "size": [55, 55], "x": bx + 330, "y": c_y + 30, "color": "#06B6D4", "border_radius": 30},
        {"ip": "c_bend", "vertices": 4, "size": [90, 55], "x": bx + 420, "y": c_y + 30, "color": "#EC4899", "curve_mode": "bend_all", "bend_amount": 25},
    ]
    Draw.shape(display=WIN_TAG, shape=complex_shapes)

    # 3. Vector Path Line Splines
    v_y = c_y + 150
    Draw.text(tag=WIN_TAG, ip="t_shp_v_hdr", text="Vector Paths & Smooth Splines (Draw.point)", customise={
        "x": bx, "y": v_y, "font_size": 13, "bold": True, "color": "#F1F5F9"
    })

    Draw.point(
        tag=WIN_TAG,
        graph=[WIN_W, WIN_H],
        points=[
            {
                "path": f"{bx},{v_y + 55} ; {bx + 150},{v_y + 20} ; {bx + 300},{v_y + 75} ; {bx + 450},{v_y + 25} ; {bx + 600},{v_y + 65}",
                "colour": "#38BDF8",
                "width": 3,
                "edge": "curve",
                "smooth": "50%",
                "fill": False,
            }
        ]
    )


# ─────────────────────────────────────────────────────────────────────────────
# TAB 4: GRAPH & CHARTS SHOWCASE
# ─────────────────────────────────────────────────────────────────────────────

def mount_graph_tab():
    bx, by = 40, 95

    Draw.text(
        tag=WIN_TAG, ip="t_grp_hdr",
        text="📊 Chart & Data Visualization Engine",
        customise={"x": bx, "y": by, "font_size": 18, "bold": True, "color": "#38BDF8"}
    )
    Draw.text(
        tag=WIN_TAG, ip="t_grp_sub",
        text="Render high-performance Bar, Line, Pie, Donut, and Area charts with hardware acceleration.",
        customise={"x": bx, "y": by + 26, "font_size": 11, "color": "#94A3B8"}
    )

    # 1. Bar Chart
    Draw.graph(
        ip="g_bar", type="bar", display=WIN_TAG,
        graph=[
            {
                "x": ["Q1", "Q2", "Q3", "Q4"],
                "y": [320, 580, 490, 810],
                "title": "Revenue",
                "customise": {"color": "#3B82F6", "show_values": True, "show_line": True}
            }
        ],
        x=bx, y=by + 70, width=300, height=210,
    )

    # 2. Line Chart
    Draw.graph(
        ip="g_line", type="line", display=WIN_TAG,
        graph=[
            {
                "x": ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],
                "y": [25, 45, 38, 70, 62, 95],
                "title": "Active Users",
                "customise": {"color": "#10B981", "show_line": True}
            }
        ],
        x=bx + 330, y=by + 70, width=320, height=210,
    )

    # 3. Pie Chart
    Draw.graph(
        ip="g_pie", type="pie", display=WIN_TAG,
        graph=[
            {
                "x": ["Direct", "Search", "Social", "Referral"],
                "y": [40, 30, 20, 10],
                "title": "Traffic",
                "customise": {"color": ["#8B5CF6", "#06B6D4", "#F59E0B", "#EF4444"]}
            }
        ],
        x=bx + 680, y=by + 70, width=200, height=210,
    )

    # 4. Donut Chart
    Draw.graph(
        ip="g_donut", type="donut", display=WIN_TAG,
        graph=[
            {
                "x": ["Python", "Rust", "C++", "JS"],
                "y": [55, 25, 15, 5],
                "title": "Languages",
                "customise": {"color": ["#3B82F6", "#F97316", "#10B981", "#EAB308"], "inner_radius": 45}
            }
        ],
        x=bx, y=by + 310, width=200, height=200,
    )

    # 5. Area Chart
    Draw.graph(
        ip="g_area", type="area", display=WIN_TAG,
        graph=[
            {
                "x": ["2020", "2021", "2022", "2023", "2024"],
                "y": [100, 220, 380, 520, 780],
                "title": "Growth",
                "customise": {"color": "#EC4899", "show_line": True}
            }
        ],
        x=bx + 230, y=by + 310, width=420, height=200,
    )


# ─────────────────────────────────────────────────────────────────────────────
# TAB 5: LIVE DATA & REACTIVE STATE SHOWCASE
# ─────────────────────────────────────────────────────────────────────────────

def mount_live_tab():
    bx, by = 40, 95

    Draw.text(
        tag=WIN_TAG, ip="t_liv_hdr",
        text="⚡ Live Reactive Pipeline & State Streaming",
        customise={"x": bx, "y": by, "font_size": 18, "bold": True, "color": "#38BDF8"}
    )
    Draw.text(
        tag=WIN_TAG, ip="t_liv_sub",
        text="Demonstrates 60Hz live data streaming via Draw.live, reactive text lambdas, and auto-updating charts.",
        customise={"x": bx, "y": by + 26, "font_size": 11, "color": "#94A3B8"}
    )

    # Telemetry live indicators
    Draw.text(
        tag=WIN_TAG, ip="t_liv_val1",
        text=lambda: f"⏱️ Simulation Ticks: {_state['live_counter']}",
        customise={"x": bx, "y": by + 75, "font_size": 16, "bold": True, "color": "#F8FAFC"}
    )
    Draw.text(
        tag=WIN_TAG, ip="t_liv_val2",
        text=lambda: f"📈 Sine Harmonic Stream: {math.sin(_state['live_counter'] * 0.05):.3f}",
        customise={"x": bx, "y": by + 105, "font_size": 14, "bold": True, "color": "#38BDF8"}
    )

    # Live Bar Chart
    Draw.graph(
        ip="g_live_stream", type="bar", display=WIN_TAG,
        graph=[
            {
                "x": ["Sensor Alpha", "Sensor Beta", "Sensor Gamma"],
                "y": [_state["live_val1"], _state["live_val2"], _state["live_val3"]],
                "title": "Live Sensor Readings",
                "customise": {"color": "#10B981", "show_values": True, "show_line": True}
            }
        ],
        x=bx, y=by + 155, width=420, height=230,
    )


# ─────────────────────────────────────────────────────────────────────────────
# TAB 6: MOUSE & DRAG HARDWARE SENSORS
# ─────────────────────────────────────────────────────────────────────────────

def mount_mouse_tab():
    bx, by = 40, 95

    Draw.text(
        tag=WIN_TAG, ip="t_mse_hdr",
        text="🖱️ Hardware Mouse Sensors & 1:1 Drag Engine",
        customise={"x": bx, "y": by, "font_size": 18, "bold": True, "color": "#38BDF8"}
    )
    Draw.text(
        tag=WIN_TAG, ip="t_mse_sub",
        text="Test Click, Right-Click, Double-Click, Hover detection, 1:1 Zero-Lag Dragging, and Mouse Wheel.",
        customise={"x": bx, "y": by + 26, "font_size": 11, "color": "#94A3B8"}
    )

    # 1. Interactive Draggable Shapes
    Draw.shape(display=WIN_TAG, shape=[
        {
            "ip": "drag_box_1", "vertices": 4, "size": [130, 75],
            "x": bx, "y": by + 75, "color": "#3B82F6", "border_radius": 10,
        },
        {
            "ip": "drag_box_2", "vertices": 6, "size": [85, 85],
            "x": bx + 160, "y": by + 75, "color": "#8B5CF6",
        },
    ])
    Draw.text(tag=WIN_TAG, ip="t_drag_lbl1", text="🖱️ Drag Me!", customise={"x": bx + 22, "y": by + 102, "font_size": 12, "bold": True, "color": "white"})
    Draw.text(tag=WIN_TAG, ip="t_drag_lbl2", text="Drag Hex", customise={"x": bx + 175, "y": by + 108, "font_size": 11, "bold": True, "color": "white"})

    # 2. Clickable Target Buttons
    Draw.shape(display=WIN_TAG, shape=[
        {"ip": "click_btn_l", "vertices": 4, "size": [140, 45], "x": bx, "y": by + 190, "color": "#10B981", "border_radius": 8, "locked": True},
        {"ip": "click_btn_r", "vertices": 4, "size": [140, 45], "x": bx + 160, "y": by + 190, "color": "#F59E0B", "border_radius": 8, "locked": True},
        {"ip": "click_btn_d", "vertices": 4, "size": [150, 45], "x": bx + 320, "y": by + 190, "color": "#EC4899", "border_radius": 8, "locked": True},
    ])
    Draw.text(tag=WIN_TAG, ip="t_btn_l_lbl", text="Left Click Me", customise={"x": bx + 26, "y": by + 204, "font_size": 11, "bold": True, "color": "white"})
    Draw.text(tag=WIN_TAG, ip="t_btn_r_lbl", text="Right Click Me", customise={"x": bx + 185, "y": by + 204, "font_size": 11, "bold": True, "color": "white"})
    Draw.text(tag=WIN_TAG, ip="t_btn_d_lbl", text="Double Click Me", customise={"x": bx + 340, "y": by + 204, "font_size": 11, "bold": True, "color": "white"})

    def on_lclick(r):
        _state["clicks"] += 1
        canvas = Draw.super.get(WIN_TAG)
        if canvas: canvas.update()

    def on_rclick(r):
        _state["rclicks"] += 1
        canvas = Draw.super.get(WIN_TAG)
        if canvas: canvas.update()

    def on_dclick(r):
        _state["dblclicks"] += 1
        canvas = Draw.super.get(WIN_TAG)
        if canvas: canvas.update()

    # Senses Wiring (both shape and label)
    Draw.senses("mouse_click", ip="click_btn_l", id="s_tab_lclick")
    Draw.senses("mouse_click", ip="t_btn_l_lbl", id="s_tab_lclick_txt")
    Draw.connectors(sense="s_tab_lclick", work=on_lclick)
    Draw.connectors(sense="s_tab_lclick_txt", work=on_lclick)

    Draw.senses("mouse_rightclick", ip="click_btn_r", id="s_tab_rclick")
    Draw.senses("mouse_rightclick", ip="t_btn_r_lbl", id="s_tab_rclick_txt")
    Draw.connectors(sense="s_tab_rclick", work=on_rclick)
    Draw.connectors(sense="s_tab_rclick_txt", work=on_rclick)

    Draw.senses("mouse_doubleclick", ip="click_btn_d", id="s_tab_dclick")
    Draw.senses("mouse_doubleclick", ip="t_btn_d_lbl", id="s_tab_dclick_txt")
    Draw.connectors(sense="s_tab_dclick", work=on_dclick)
    Draw.connectors(sense="s_tab_dclick_txt", work=on_dclick)

    # Live Counters HUD
    hud_x = bx + 520
    Draw.text(tag=WIN_TAG, ip="t_mse_hud_hdr", text="Live Mouse Senses Telemetry", customise={"x": hud_x, "y": by + 75, "font_size": 13, "bold": True, "color": "#F1F5F9"})
    Draw.text(tag=WIN_TAG, ip="t_mse_hud_1", text=lambda: f"Left Clicks: {_state['clicks']}", customise={"x": hud_x, "y": by + 105, "font_size": 12, "color": "#10B981"})
    Draw.text(tag=WIN_TAG, ip="t_mse_hud_2", text=lambda: f"Right Clicks: {_state['rclicks']}", customise={"x": hud_x, "y": by + 130, "font_size": 12, "color": "#F59E0B"})
    Draw.text(tag=WIN_TAG, ip="t_mse_hud_3", text=lambda: f"Double Clicks: {_state['dblclicks']}", customise={"x": hud_x, "y": by + 155, "font_size": 12, "color": "#EC4899"})


# ─────────────────────────────────────────────────────────────────────────────
# TAB 7: KEYBOARD HARDWARE SENSORS & TYPING
# ─────────────────────────────────────────────────────────────────────────────

def mount_keyboard_tab():
    bx, by = 40, 95

    Draw.text(
        tag=WIN_TAG, ip="t_kbd_hdr",
        text="⌨️ Hardware Keyboard Sensors & Input",
        customise={"x": bx, "y": by, "font_size": 18, "bold": True, "color": "#38BDF8"}
    )
    Draw.text(
        tag=WIN_TAG, ip="t_kbd_sub",
        text="Press any key on your keyboard to test live event dispatching, arrow keys, and pure Draw typed buffer.",
        customise={"x": bx, "y": by + 26, "font_size": 11, "color": "#94A3B8"}
    )

    # Live Key Logger HUD
    Draw.text(
        tag=WIN_TAG, ip="t_kbd_last",
        text=lambda: f"⌨️ Last Key Detected: {_state['last_key'].upper()}",
        customise={"x": bx, "y": by + 75, "font_size": 17, "bold": True, "color": "#FBBF24"}
    )

    # Arrow Keys Pad
    arr_x, arr_y = bx + 40, by + 125
    arrow_keys = [
        ("t_arr_up", "↑", arr_x + 45, arr_y),
        ("t_arr_left", "←", arr_x, arr_y + 45),
        ("t_arr_down", "↓", arr_x + 45, arr_y + 45),
        ("t_arr_right", "→", arr_x + 90, arr_y + 45),
    ]

    for ip, sym, ax, ay in arrow_keys:
        Draw.shape(display=WIN_TAG, shape=[{
            "ip": ip, "vertices": 4, "size": [38, 38], "x": ax, "y": ay,
            "color": "#1E293B", "border_radius": 6, "border_width": 1, "border_color": "#475569",
        }])
        Draw.text(tag=WIN_TAG, ip=f"{ip}_lbl", text=sym, customise={
            "x": ax + 13, "y": ay + 9, "font_size": 14, "bold": True, "color": "white"
        })

    # Pure Draw Interactive Typing Field Box
    Draw.text(tag=WIN_TAG, ip="t_inp_hdr", text="Pure Draw Keyboard Buffer (Type letters / Space / Backspace):", customise={
        "x": bx, "y": by + 240, "font_size": 13, "bold": True, "color": "#F1F5F9"
    })

    Draw.shape(display=WIN_TAG, shape=[{
        "ip": "pure_draw_input_box", "vertices": 4, "size": [500, 45],
        "x": bx, "y": by + 270, "color": "#1E293B", "border_radius": 8,
        "border_width": 1, "border_color": "#475569",
    }])

    Draw.text(
        tag=WIN_TAG, ip="pure_draw_input_text",
        text=lambda: f"{_state['typed_text']}_",
        customise={"x": bx + 15, "y": by + 284, "font_size": 13, "color": "#38BDF8", "font_family": "Consolas"}
    )

    # Keyboard Senses
    def make_key_handler(k):
        def _handler(rec):
            _state["last_key"] = k
            if k == "backspace":
                _state["typed_text"] = _state["typed_text"][:-1]
            elif k == "space":
                _state["typed_text"] += " "
            elif len(k) == 1 and k.isprintable():
                _state["typed_text"] += k
        return _handler

    keys_to_track = [
        "space", "return", "escape", "backspace", "up", "down", "left", "right",
        "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m",
        "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z",
        "1", "2", "3", "4", "5", "6", "7", "8", "9", "0",
    ]
    for k in keys_to_track:
        sid = f"s_key_{k}"
        Draw.senses("key_press", id=sid, key=[k])
        Draw.connectors(sense=sid, work=make_key_handler(k))


# ─────────────────────────────────────────────────────────────────────────────
# TOP NAVIGATION BAR & LIVE FPS HUD
# ─────────────────────────────────────────────────────────────────────────────

def init_top_navigation():
    """Initialize top navigation bar shape buttons and FPS badge."""
    # Navigation background
    Draw.shape(display=WIN_TAG, shape=[{
        "ip": "nav_top_bg", "vertices": 4, "size": [WIN_W - 20, 52],
        "x": 10, "y": 10, "color": "#0F172A", "border_radius": 10,
        "border_width": 1, "border_color": "#1E293B", "z": 100,
    }])

    tab_w = 110
    tab_h = 36
    start_x = 24
    start_y = 18

    for i, tab in enumerate(TABS):
        is_active = (tab == _current_tab)
        btn_ip = f"nav_tab_{tab.lower()}"
        txt_ip = f"nav_tab_txt_{tab.lower()}"
        bg_col = "#3B82F6" if is_active else "#1E293B"
        border_col = "#60A5FA" if is_active else "#334155"
        txt_col = "#FFFFFF" if is_active else "#94A3B8"

        Draw.shape(display=WIN_TAG, shape=[{
            "ip": btn_ip, "vertices": 4, "size": [tab_w, tab_h],
            "x": start_x + i * (tab_w + 10), "y": start_y,
            "color": bg_col, "border_radius": 6,
            "border_width": 1, "border_color": border_col, "z": 90,
        }])
        Draw.text(
            tag=WIN_TAG, ip=txt_ip, text=tab,
            customise={
                "x": start_x + i * (tab_w + 10) + (tab_w // 2) - (len(tab) * 4),
                "y": start_y + 10, "font_size": 12, "bold": is_active,
                "color": txt_col, "z": 80,
            }
        )

        # Wire mouse click sense on pure Draw shape
        sense_id = f"s_nav_{tab.lower()}"
        Draw.senses("mouse_click", ip=btn_ip, id=sense_id)
        Draw.connectors(sense=sense_id, work=(lambda rec, t=tab: set_tab(t)))

    # Real-Time Live FPS Badge at Top Right
    fps_badge_x = WIN_W - 180
    Draw.shape(display=WIN_TAG, shape=[{
        "ip": "nav_fps_badge", "vertices": 4, "size": [155, tab_h],
        "x": fps_badge_x, "y": start_y, "color": "#022C22",
        "border_radius": 8, "border_width": 1, "border_color": "#059669", "z": 90,
    }])
    Draw.text(
        tag=WIN_TAG, ip="nav_fps_text",
        text=get_fps_hud_text,
        customise={
            "x": fps_badge_x + 16, "y": start_y + 10, "font_size": 12, "bold": True,
            "color": "#34D399", "z": 80, "font_family": "Consolas",
        }
    )


def update_top_navigation_highlights():
    """Update button colors to reflect active tab."""
    canvas = Draw.super.get(WIN_TAG)
    if canvas is None:
        return

    for tab in TABS:
        is_active = (tab == _current_tab)
        btn_ip = f"nav_tab_{tab.lower()}"
        txt_ip = f"nav_tab_txt_{tab.lower()}"

        # Update shape button color
        for s in canvas.shape_items:
            if s.ip == btn_ip:
                s.color = Draw._colour._parse_color("#3B82F6" if is_active else "#1E293B")
                s.border_color = Draw._colour._parse_color("#60A5FA" if is_active else "#334155")
                s.dirty = True

        # Update text label
        for t in canvas.text_items:
            if t.ip == txt_ip:
                t.color = Draw._colour._parse_color("#FFFFFF" if is_active else "#94A3B8")
                t.bold = is_active


# ─────────────────────────────────────────────────────────────────────────────
# MAIN APPLICATION LOOP
# ─────────────────────────────────────────────────────────────────────────────

def live_stream_tick():
    """Simulate live data stream."""
    _state["live_counter"] += 1
    _state["live_val1"] = max(20, min(100, _state["live_val1"] + random.randint(-8, 8)))
    _state["live_val2"] = max(20, min(100, _state["live_val2"] + random.randint(-8, 8)))
    _state["live_val3"] = max(20, min(100, _state["live_val3"] + random.randint(-8, 8)))


def main():
    print("Launching Draw.super Tabbed Test Suite (Pure Draw Engine)...")
    Draw.window(
        tag=WIN_TAG,
        title="⚡ Draw.super — Pure Draw Tabbed Suite + Live FPS HUD",
        width=WIN_W,
        height=WIN_H,
        background_color="#070B14",
    )

    # Initialize Top Navigation
    init_top_navigation()

    # Initial Tab Mount
    set_tab("Color")

    # Start live background data stream
    Draw.every(0.25, live_stream_tick)

    # ── Activate Draw.super Hardware Acceleration Engine! ─────────────────────
    print("Activating Draw.super Engine...")
    Draw.super(
        display=WIN_TAG,
        precompile=True,
        mode="max",
        vsync=False,
        batch_capacity=65536,
    )

    print("\n[OK] Pure Draw Tabbed test window running with Draw.super.")
    print("     Click tabs at the top to switch between Color, Motion, Shapes, Graph, Live, Mouse, Keyboard.")
    Draw.window.run(WIN_TAG)


if __name__ == "__main__":
    main()
