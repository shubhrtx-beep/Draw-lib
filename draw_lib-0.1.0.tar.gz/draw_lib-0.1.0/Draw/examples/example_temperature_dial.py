import os
import sys
import math

# Add parent directory to sys.path so we can import Draw package
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
import Draw

# Initialize window: 800x600, not resizable to keep coordinates stable
Draw.window(tag="main", title="Interactive Temperature Dial", width=800, height=600, resizable=False)

# Define the center coordinates for the temperature dial
cx = 480
cy = 300

# 1. Create shapes on the canvas
Draw.shapes(
    display="main",
    shape=[
        # Background shape (z=1000)
        {
            "ip": "bg_shape",
            "vertices": 4,
            "x": 0,
            "y": 0,
            "size": [800, 600],
            "z": 1000,
            "overlap": True,
            "locked": True
        },
        # White dial circle at center (z=10)
        {
            "ip": "dial_circle",
            "vertices": 64,  # high number of vertices = smooth circle
            "x": int(cx - 100),
            "y": int(cy - 100),
            "size": [200, 200],
            "z": 10,
            "overlap": True,
            "locked": True
        },
        # Dial pointer hand (looks like a physical pointer, z=5)
        {
            "ip": "dial_hand",
            "vertices": 4,
            "x": int(cx - 3),
            "y": int(cy - 90),
            "size": [6, 90],
            "z": 5,
            "overlap": True,
            "locked": True
        },
        # Center Cap circle covering the hand pivot (z=4)
        {
            "ip": "dial_cap",
            "vertices": 64,
            "x": int(cx - 8),
            "y": int(cy - 8),
            "size": [16, 16],
            "z": 4,
            "overlap": True,
            "locked": True
        },
        # Ice Button (z=5)
        {
            "ip": "btn_ice",
            "vertices": 64,
            "x": 80,
            "y": 180,
            "size": [80, 80],
            "z": 5,
            "overlap": True
        },
        # Fire Button (z=5)
        {
            "ip": "btn_fire",
            "vertices": 64,
            "x": 80,
            "y": 340,
            "size": [80, 80],
            "z": 5,
            "overlap": True
        }
    ]
)

# 2. Create text elements for buttons (aligned inside shapes using relative layout)
Draw.text(
    tag="main",
    text="👀\n🧊",
    ip="text_ice",
    customise={
        "font_size": 22,
        "font_family": "Outfit",
        "align_text": "center",
        "color": "#006064",
        "bold": True
    }
)

Draw.text(
    tag="main",
    text="👀\n🔥",
    ip="text_fire",
    customise={
        "font_size": 22,
        "font_family": "Outfit",
        "align_text": "center",
        "color": "#e65100",
        "bold": True
    }
)

# Shark text pointer rotating around dial
Draw.text(
    tag="main",
    text="🦈",
    ip="shark_ptr",
    customise={
        "font_size": 36,
        "align_text": "center",
        "bold": True
    }
)

# Apply relative layout: center text inside corresponding buttons
Draw.room(
    display="main",
    scene={
        "text_ice": ["btn_ice", "center", "inside"],
        "text_fire": ["btn_fire", "center", "inside"]
    }
)

# Style text and shapes with colors & shadows/glows (shaders)
Draw.color(
    ip="dial_circle",
    color=[
        {"for": "body", "color": "white"},
        {"for": "border", "color": "#dcdcdc", "width": 3},
        {"for": "shadow", "color": "gray", "blur": 15, "offset": [0, 5]}
    ]
)

Draw.color(
    ip="dial_hand",
    color=[
        {"for": "body", "color": "#ff3333"},
        {"for": "border", "color": "#cc0000", "width": 1}
    ]
)

Draw.color(
    ip="dial_cap",
    color=[
        {"for": "body", "color": "#cc0000"},
        {"for": "border", "color": "#990000", "width": 1}
    ]
)

Draw.color(
    ip="btn_ice",
    color=[
        {"for": "body", "color": "#e0f7fa"},
        {"for": "border", "color": "#00acc1", "width": 3},
        {"for": "shadow", "color": "gray", "blur": 10, "offset": [0, 4]}
    ]
)

Draw.color(
    ip="btn_fire",
    color=[
        {"for": "body", "color": "#ffe0b2"},
        {"for": "border", "color": "#fb8c00", "width": 3},
        {"for": "shadow", "color": "gray", "blur": 10, "offset": [0, 4]}
    ]
)

Draw.color(
    ip="shark_ptr",
    color=[
        {"for": "shadow", "color": "black", "blur": 8, "offset": [2, 2]}
    ]
)

# Generate Celsius scale labels around the dial (from -100 to 100 in steps of 10)
for t_val in range(-100, 101, 10):
    # Calculate angular placement (T=-100 at 135 deg, T=0 at 270 deg, T=100 at 405 deg)
    angle = 270 + t_val * 1.35
    rad = math.radians(angle)
    # labels are placed outside the circle (radius = 135)
    lx = cx + 135 * math.cos(rad) - 20
    ly = cy + 135 * math.sin(rad) - 10
    label_ip = f"label_{t_val}"

    Draw.text(
        tag="main",
        text=f"{t_val}°C" if t_val in (-100, 0, 100) else f"{t_val}",
        ip=label_ip,
        x=int(lx),
        y=int(ly),
        customise={
            "font_size": 14,
            "font_family": "Outfit",
            "align_text": "center",
            "color": "#333333",
            "bold": True if t_val in (-100, 0, 100) else False
        }
    )

# Current temperature and animation states
state = {
    "temperature": 0.0,
    "target_temperature": 0.0,
    "ice_hovered": False,
    "ice_scale": 1.0,
    "fire_hovered": False,
    "fire_scale": 1.0
}

# Register senses for keys and mouse interactions
sense_z = Draw.senses("key_press", id="z_press", key="z")
sense_m = Draw.senses("key_press", id="m_press", key="m")

hover_ice = Draw.senses("mouse_hover", id="hover_ice", ip="btn_ice")
leave_ice = Draw.senses("mouse_leave", id="leave_ice", ip="btn_ice")
click_ice = Draw.senses("mouse_click", id="click_ice", ip="btn_ice")

hover_fire = Draw.senses("mouse_hover", id="hover_fire", ip="btn_fire")
leave_fire = Draw.senses("mouse_leave", id="leave_fire", ip="btn_fire")
click_fire = Draw.senses("mouse_click", id="click_fire", ip="btn_fire")

# Text block showing current temperature in numbers
Draw.text(
    tag="main",
    text="0.0°C",
    ip="temp_display",
    x=int(cx - 50),
    y=int(cy + 220),
    customise={
        "font_size": 28,
        "font_family": "Outfit",
        "align_text": "center",
        "color": "#222222",
        "bold": True
    }
)


def update_dial_view(temp):
    # Map temperature (-100 to 100) to angle (135 to 405 deg)
    angle = 270 + temp * 1.35

    # 1. Rotate the Dial Circle
    dial = Draw.shapes.get_by_ip("main", "dial_circle")
    if dial:
        dial.rotation = angle
        dial.dirty = True

    # 2. Rotate Dial Hand around its fixed bottom pivot (cx, cy)
    hand = Draw.shapes.get_by_ip("main", "dial_hand")
    if hand:
        hand.x = int(cx - 3)
        hand.y = int(cy - 90)
        hand.pivot = (float(cx), float(cy))
        hand.rotation = angle - 270.0
        hand.dirty = True

    # 3. Position and rotate the Shark text pointer (placed at radius = 110)
    canvas = Draw.window.get_canvas("main")
    shark = None
    if canvas:
        for t in canvas.text_items:
            if t.ip == "shark_ptr":
                shark = t
                break

    if shark:
        rad = math.radians(angle)
        shark.x = int(cx + 110 * math.cos(rad) - 18)
        shark.y = int(cy + 110 * math.sin(rad) - 18)
        shark.rotation = angle + 90

    # 4. Update the digital display text
    if canvas:
        for t in canvas.text_items:
            if t.ip == "temp_display":
                t.text = f"{temp:.1f}°C"
                break

    # 5. Calculate background gradient shift with bounds clamping
    # Blue: cold (-100), White: neutral (0), Red: hot (100)
    if temp < 0:
        r = max(0, min(255, int(255 + temp * 2.55)))
        g = max(0, min(255, int(255 + temp * 1.53)))
        b = 255
    else:
        r = 255
        g = max(0, min(255, int(255 - temp * 2.04)))
        b = max(0, min(255, int(255 - temp * 2.04)))

    color_hex = f"#{r:02x}{g:02x}{b:02x}"

    # Dynamic vertical gradient on background shape
    Draw.color(
        ip="bg_shape",
        color=[
            {
                "for": "body",
                "gradient": "linear",
                "angle": 90,
                "stops": [
                    [0, "#ffffff"],
                    [100, color_hex]
                ]
            }
        ]
    )


# Animation / Frame Tick loop running every 16ms
def tick():
    if "main" not in Draw.window.list_tags():
        return

    # Keyboard controls ('Z' to cool, 'M' to heat)
    if sense_z.consume():
        state["target_temperature"] = max(-100.0, state["target_temperature"] - 10.0)
    if sense_m.consume():
        state["target_temperature"] = min(100.0, state["target_temperature"] + 10.0)

    # Mouse Click actions
    if click_ice.consume():
        state["target_temperature"] = -100.0
    if click_fire.consume():
        state["target_temperature"] = 100.0

    # Hover updates for Ice Button
    if hover_ice.consume():
        state["ice_hovered"] = True
    if leave_ice.consume():
        state["ice_hovered"] = False

    # Hover updates for Fire Button
    if hover_fire.consume():
        state["fire_hovered"] = True
    if leave_fire.consume():
        state["fire_hovered"] = False

    # Smooth scale animations on buttons
    target_scale_ice = 1.2 if state["ice_hovered"] else 1.0
    state["ice_scale"] += (target_scale_ice - state["ice_scale"]) * 0.15
    btn_ice = Draw.shapes.get_by_ip("main", "btn_ice")
    if btn_ice:
        size_val = int(80 * state["ice_scale"])
        offset = (size_val - 80) // 2
        btn_ice.x = 80 - offset
        btn_ice.y = 180 - offset
        btn_ice.size_raw = [size_val, size_val]
        btn_ice.dirty = True

    target_scale_fire = 1.2 if state["fire_hovered"] else 1.0
    state["fire_scale"] += (target_scale_fire - state["fire_scale"]) * 0.15
    btn_fire = Draw.shapes.get_by_ip("main", "btn_fire")
    if btn_fire:
        size_val = int(80 * state["fire_scale"])
        offset = (size_val - 80) // 2
        btn_fire.x = 80 - offset
        btn_fire.y = 340 - offset
        btn_fire.size_raw = [size_val, size_val]
        btn_fire.dirty = True

    # Re-apply layout constraints to keep text centered inside scaled buttons
    Draw.room(
        display="main",
        scene={
            "text_ice": ["btn_ice", "center", "inside"],
            "text_fire": ["btn_fire", "center", "inside"]
        }
    )

    # Smooth temperature transition interpolation (lerp)
    if abs(state["temperature"] - state["target_temperature"]) > 0.01:
        state["temperature"] += (state["target_temperature"] - state["temperature"]) * 0.1
        update_dial_view(state["temperature"])
    else:
        state["temperature"] = state["target_temperature"]
        update_dial_view(state["temperature"])


# Initialize starting view
update_dial_view(0.0)

# Run the frame updates every 16ms
Draw.every(0.016, tick)

# Run the main window loop
Draw.window.run("main")
