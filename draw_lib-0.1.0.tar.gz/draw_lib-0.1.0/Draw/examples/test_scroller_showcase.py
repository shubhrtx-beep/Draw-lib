"""
examples/test_scroller_showcase.py
==================================
Comprehensive Interactive Window Test & Progress Showcase for Draw.scroller.

Demonstrates:
- Public API with all parameters from prompt.txt:
    ip="main_scroll",
    room="page",
    scroll="vertical",   # or "horizontal", "both"
    max_x=1200,
    max_y=2400,
    speed=1.5,
    align="right",
    thumb="thumb_shape",
    motion="spring",
    senses="scroll_sense",
    connectors="scroll_connector",
- auto_align_in_ip: bool (auto-fits and auto-wraps text inside parent hitbox)
- Touch & Mouse Wheel Gestures
- Dragging Scrollbar Thumb
- Keyboard Navigation (Up/Down arrows, Page Up/Down, Home/End)
- Programmatic Navigation:
    Draw.scroller.scroll_to(...)
    Draw.scroller.scroll_by(...)
    Draw.scroller.scroll_to_ip(...)
    Draw.scroller.center_ip(...)
    Draw.scroller.get_scroll(...)
    Draw.scroller.lock() / unlock()
    Draw.scroller.enable() / disable()
"""

import os
import sys

# Set stdout/stderr encoding safely for Windows consoles
if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

# Ensure repository root is on sys.path
THIS_DIR = os.path.dirname(os.path.abspath(__file__))
REPO_ROOT = os.path.dirname(os.path.dirname(THIS_DIR))
if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)

import Draw


def main():
    win_tag = "scroller_showcase_win"
    win_w, win_h = 1080, 820

    print("-------------------------------------------------------------------")
    print(" [Draw] Launching Draw.scroller Progress Showcase & Window Test")
    print("-------------------------------------------------------------------")

    # 1. Initialize Window
    Draw.window(
        tag=win_tag,
        title="Draw.scroller - High-Level Controller & Progress Showcase",
        width=win_w,
        height=win_h,
        background_color="#0B0F19",
    )

    # 2. Initialize Draw.scroller with full prompt.txt parameter set
    print("[Draw] Initializing Draw.scroller(...) controller...")
    cfg = Draw.scroller(
        ip="main_scroll",
        room="page",
        scroll="vertical",
        max_y=2400,
        speed=1.2,
        align="right",
        thumb="thumb_shape",
        motion="spring",
        senses="scroll_sense",
        connectors="scroll_connector",
        display=win_tag,
        thumb_color="#38BDF8",
        track_color="#1E293B",
        thumb_width=14,
        track_opacity=95,
        keyboard=True,
    )
    print(f"[Draw] Scroller Config Created: ID='{cfg.id}', direction='{cfg.direction}', align='{cfg.align}', speed={cfg.speed}")

    # 3. Main Background Canvas Container (Tall Page Layout)
    Draw.shapes(
        display=win_tag,
        shape=[
            {
                "ip": "page_bg_card",
                "vertices": 4,
                "border_radius": 20,
                "size": [1000, 2400],
                "color": "#111827",
                "border_width": 2,
                "border_color": "#1F2937",
                "x": 30,
                "y": 30,
                "z": 100,       # Background canvas
                "locked": True,
            }
        ],
    )

    # 4. Top Header & Feature Badges
    Draw.text(
        tag=win_tag,
        text="Draw.scroller Controller & Architecture Showcase",
        ip="header_title",
        customise={
            "font_size": 24,
            "font_family": "Outfit",
            "color": "#F9FAFB",
            "bold": True,
            "x": 60,
            "y": 60,
            "z": 10,
        },
    )

    Draw.text(
        tag=win_tag,
        text="Coordinating Draw.shape <-> Draw.motion <-> Draw.senses <-> Draw.connectors <-> Draw.room",
        ip="header_subtitle",
        customise={
            "font_size": 14,
            "font_family": "Outfit",
            "color": "#38BDF8",
            "x": 60,
            "y": 100,
            "z": 10,
        },
    )

    # Feature badges
    badge_items = [
        ("badge_wheel", "Mouse Wheel", "#065F46", "#34D399", 60),
        ("badge_thumb", "Drag Thumb", "#1E3A8A", "#60A5FA", 230),
        ("badge_touch", "Touchpad / Touch", "#701A75", "#F472B6", 390),
        ("badge_keys", "Keyboard Up/Down", "#7C2D12", "#FB923C", 570),
        ("badge_motion", "Spring & Inertia", "#047857", "#A7F3D0", 770),
    ]

    for ip_name, label, bg, fg, x_pos in badge_items:
        Draw.shapes(
            display=win_tag,
            shape=[{
                "ip": f"{ip_name}_box",
                "vertices": 4,
                "border_radius": 8,
                "size": [170, 36],
                "color": bg,
                "border_width": 1,
                "border_color": fg,
                "x": x_pos,
                "y": 140,
                "z": 20,
            }],
        )
        Draw.text(
            tag=win_tag,
            text=label,
            ip=f"{ip_name}_txt",
            customise={
                "font_size": 11,
                "font_family": "Outfit",
                "color": fg,
                "bold": True,
                "x": x_pos + 16,
                "y": 148,
                "z": 15,
            },
        )

    # 5. Section 1: Interactive Cards with auto_align_in_ip=True (Upper Section, Y=220)
    cards = [
        ("card_1", "Module: Draw.senses", "Receives user interaction events (wheel up/down, touch swipe, drag move, keyboard keys)", "#1E293B", "#38BDF8", 60, 220),
        ("card_2", "Module: Draw.connectors", "Synchronizes thumb <-> room, room <-> motion, and thumb <-> senses with reactive work callbacks", "#1E293B", "#818CF8", 520, 220),
        ("card_3", "Module: Draw.motion", "Smooth scrolling, spring physics interpolation, and inertia momentum deceleration", "#1E293B", "#F472B6", 60, 400),
        ("card_4", "Module: Draw.room", "Viewport alignment, relative layout scrolling, and programmatic center_ip / scroll_to_ip", "#1E293B", "#34D399", 520, 400),
    ]

    for c_id, title, desc, bg, border, cx, cy in cards:
        Draw.shapes(
            display=win_tag,
            shape=[{
                "ip": f"{c_id}_shape",
                "vertices": 4,
                "border_radius": 14,
                "size": [430, 150],
                "color": bg,
                "border_width": 2,
                "border_color": border,
                "x": cx,
                "y": cy,
                "z": 20,
            }],
        )
        Draw.text(
            tag=win_tag,
            text=title,
            ip=f"{c_id}_title",
            customise={
                "font_size": 16,
                "font_family": "Outfit",
                "color": "#F9FAFB",
                "bold": True,
                "x": cx + 20,
                "y": cy + 20,
                "z": 15,
            },
        )
        # Using auto_align_in_ip=True to cleanly fit and wrap inside the card hitbox!
        Draw.text(
            tag=win_tag,
            text=desc,
            ip=f"{c_id}_desc",
            customise={
                "font_size": 13,
                "font_family": "Outfit",
                "color": "#94A3B8",
                "x": cx + 20,
                "y": cy + 56,
                "z": 15,
                "auto_align_in_ip": True,
                "hitbox": f"{c_id}_shape",
            },
        )

    # 6. Interactive Shapes & Demonstrations across Page Content (Y=600 to Y=2100)
    # Section Divider 1
    Draw.text(
        tag=win_tag,
        text="Section A: Interactive Draggable Shapes (Y = 620)",
        ip="sec_a_title",
        customise={
            "font_size": 18,
            "font_family": "Outfit",
            "color": "#FBBF24",
            "bold": True,
            "x": 60,
            "y": 620,
            "z": 10,
        },
    )

    Draw.shapes(
        display=win_tag,
        shape=[
            {
                "ip": "hero_circle",
                "vertices": 64,
                "size": [140, 140],
                "color": "#06B6D4",
                "border_width": 4,
                "border_color": "#67E8F9",
                "x": 100,
                "y": 680,
                "z": 5,
            },
            {
                "ip": "hero_triangle",
                "vertices": 3,
                "size": [160, 140],
                "color": "#EC4899",
                "border_width": 4,
                "border_color": "#F472B6",
                "x": 380,
                "y": 680,
                "z": 5,
            },
            {
                "ip": "hero_hexagon",
                "vertices": 6,
                "size": [150, 140],
                "color": "#8B5CF6",
                "border_width": 4,
                "border_color": "#C4B5FD",
                "x": 680,
                "y": 680,
                "z": 5,
            },
        ],
    )

    # Section Divider 2 (Y = 1000)
    Draw.text(
        tag=win_tag,
        text="Section B: Deep Page Content & Target Cards (Y = 1000)",
        ip="sec_b_title",
        customise={
            "font_size": 18,
            "font_family": "Outfit",
            "color": "#A78BFA",
            "bold": True,
            "x": 60,
            "y": 1000,
            "z": 10,
        },
    )

    for i, (y_off, col, name) in enumerate([
        (1080, "#064E3B", "Target Card: Alpha (scroll_to_ip test)"),
        (1360, "#1E1B4B", "Target Card: Beta (smooth momentum test)"),
        (1640, "#701A75", "Target Card: Gamma (room alignment test)"),
        (1920, "#7C2D12", "Target Card: Omega (End of Page test)"),
    ]):
        Draw.shapes(
            display=win_tag,
            shape=[{
                "ip": f"deep_card_{i}",
                "vertices": 4,
                "border_radius": 16,
                "size": [880, 220],
                "color": col,
                "border_width": 2,
                "border_color": "#94A3B8",
                "x": 60,
                "y": y_off,
                "z": 30,
            }],
        )
        Draw.text(
            tag=win_tag,
            text=f"Card {i + 1}: {name}",
            ip=f"deep_card_{i}_txt",
            customise={
                "font_size": 20,
                "font_family": "Outfit",
                "color": "#F8FAFB",
                "bold": True,
                "x": 100,
                "y": y_off + 30,
                "z": 10,
            },
        )
        Draw.text(
            tag=win_tag,
            text=f"Pixel offset Y={y_off}px | Accessible via Draw.scroller.scroll_to_ip('deep_card_{i}')",
            ip=f"deep_card_{i}_sub",
            customise={
                "font_size": 14,
                "font_family": "Outfit",
                "color": "#CBD5E1",
                "x": 100,
                "y": y_off + 75,
                "z": 10,
                "auto_align_in_ip": True,
                "hitbox": f"deep_card_{i}",
            },
        )

    # 7. Wire Interactive Demonstration Keys / Console Helper
    print("\n[Draw] Interactive Controls Ready:")
    print("   * Mouse Wheel Up / Down: Scroll through page")
    print("   * Drag Scrollbar Thumb (Right Edge): Smooth position tracking")
    print("   * Arrow Keys (Up/Down): Step scrolling")
    print("   * Page Up / Page Down: Fast page jumping")
    print("   * Home / End: Origin / Bottom bounds")
    print("   * Programmatic API: Draw.scroller.scroll_to(500), Draw.scroller.center_ip('hero_circle')")
    print("-------------------------------------------------------------------\n")

    # Run the window event loop
    Draw.window.run(win_tag)


if __name__ == "__main__":
    main()
