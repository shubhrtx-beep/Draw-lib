"""
examples/test_motion_window_pure_draw.py
========================================
100% Pure Draw API Motion Studio & Interactive Test Window
----------------------------------------------------------
This implementation uses ONLY the public Draw library API:
- Draw.window: Window management
- Draw.shape / Draw.shapes: Stage card, coordinate grid, guides, yellow ball
- Draw.text: Live telemetry, HUD, and badges
- Draw.motion: Dynamic motion compilation, physics solvers & kinematics
- Draw.slider: Real-time numeric parameter tuning
- Draw.combobox: Motion type selector dropdown
- Draw.button: Playback controls, category filters, and preset loaders
- Draw.checkbox: Trail, guides, and looping toggles
- Draw.box: Native vertical sidebar container management

Run with:
    D:/python/python.exe examples/test_motion_window_pure_draw.py
"""

from __future__ import annotations

import math
import os
import sys
import time
from typing import Any, Dict, List, Optional

# Ensure workspace root is on sys.path
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
WORKSPACE_ROOT = os.path.dirname(SCRIPT_DIR)
PARENT_ROOT = os.path.dirname(WORKSPACE_ROOT)
for path in (PARENT_ROOT, WORKSPACE_ROOT):
    if path not in sys.path:
        sys.path.insert(0, path)

import Draw

WIN_TAG = "pure_motion_studio"
WIN_W = 1380
WIN_H = 880
STAGE_W = 880
STAGE_H = 820
STAGE_X = 20
STAGE_Y = 20
CX = STAGE_X + STAGE_W // 2
CY = STAGE_Y + STAGE_H // 2

# ── Motion Definitions for Pure Draw API ──
PURE_MOTIONS: List[Dict[str, Any]] = [
    {
        "id": "spring",
        "name": "1. Spring Kinetics (2nd-Order Harmonic)",
        "category": "physics",
        "formula": "m*d²x/dt² + c*dx/dt + k*x = 0 (O(1))",
        "spec": lambda p: {
            "type": "spring",
            "attribute": "position",
            "from": [CX - p.get("dist", 180), CY],
            "to": [CX + p.get("dist", 180), CY],
            "stiffness": float(p.get("stiffness", 280)),
            "damping": float(p.get("damping", 14)),
            "mass": float(p.get("mass", 1.0)),
        },
        "sliders": [
            {"id": "stiffness", "label": "Stiffness (k)", "min": 20, "max": 800, "val": 280},
            {"id": "damping", "label": "Damping (c)", "min": 2, "max": 50, "val": 14},
            {"id": "dist", "label": "Displacement (px)", "min": 40, "max": 300, "val": 180},
        ],
    },
    {
        "id": "gravity",
        "name": "2. Gravity & Ground Bounce (Analytical)",
        "category": "physics",
        "formula": "y(t) = y0 + v0*t + 0.5*g*t²; v' = -e*v",
        "spec": lambda p: {
            "type": "gravity",
            "from": CY - p.get("drop_h", 240),
            "floor_y": CY + 180,
            "g": float(p.get("g", 980)),
            "restitution": float(p.get("restitution", 76)) / 100.0,
            "velocity": 0.0,
        },
        "sliders": [
            {"id": "g", "label": "Gravity Acceleration (g)", "min": 100, "max": 2500, "val": 980},
            {"id": "restitution", "label": "Restitution (% e)", "min": 20, "max": 95, "val": 76},
            {"id": "drop_h", "label": "Drop Height (px)", "min": 50, "max": 360, "val": 240},
        ],
    },
    {
        "id": "projectile",
        "name": "3. 2D Parabolic Ballistics (Drag & Walls)",
        "category": "physics",
        "formula": "dx/dt = vx0*e^(-d*t), dy/dt = vy0*e^(-d*t) + (g/d)*(1-e^(-d*t))",
        "spec": lambda p: {
            "type": "projectile",
            "from": [STAGE_X + 60, CY + 180],
            "vx0": float(p.get("vx0", 220)),
            "vy0": -float(p.get("vy0", 400)),
            "g": float(p.get("g", 850)),
            "drag": float(p.get("drag", 2)) / 100.0,
            "restitution": 0.75,
            "floor_y": CY + 180,
            "wall_x": STAGE_X + STAGE_W - 60,
        },
        "sliders": [
            {"id": "vx0", "label": "Horizontal Launch Vx0", "min": 50, "max": 500, "val": 220},
            {"id": "vy0", "label": "Vertical Launch Vy0", "min": 100, "max": 700, "val": 400},
            {"id": "g", "label": "Gravity (g)", "min": 200, "max": 2000, "val": 850},
        ],
    },
    {
        "id": "pendulum",
        "name": "4. Damped Pendulum Oscillation",
        "category": "physics",
        "formula": "θ(t) = θ0 * e^(-γ*t) * cos(2π*f*t)",
        "spec": lambda p: {
            "type": "pendulum",
            "amplitude": float(p.get("amp", 48)),
            "frequency": float(p.get("freq", 14)) / 10.0,
            "damping": float(p.get("damp", 18)) / 100.0,
        },
        "sliders": [
            {"id": "amp", "label": "Max Amplitude (deg)", "min": 10, "max": 80, "val": 48},
            {"id": "freq", "label": "Frequency (x0.1 Hz)", "min": 5, "max": 40, "val": 14},
            {"id": "damp", "label": "Damping Factor (% )", "min": 0, "max": 80, "val": 18},
        ],
    },
    {
        "id": "wave",
        "name": "5. Sinusoidal Wave Bobbing",
        "category": "procedural",
        "formula": "y(t) = y0 + A * sin(2π*f*t + φ)",
        "spec": lambda p: {
            "type": "wave",
            "frequency": float(p.get("freq", 22)) / 10.0,
            "amplitude": float(p.get("amp", 60)),
            "phase": 0.0,
        },
        "sliders": [
            {"id": "freq", "label": "Wave Frequency (x0.1 Hz)", "min": 5, "max": 60, "val": 22},
            {"id": "amp", "label": "Wave Amplitude (px)", "min": 10, "max": 160, "val": 60},
        ],
    },
    {
        "id": "wiggle",
        "name": "6. Simplex Noise 2D Wiggle (Shake)",
        "category": "procedural",
        "formula": "dx, dy = SimplexNoise(t * f, octaves) * A",
        "spec": lambda p: {
            "type": "wiggle",
            "frequency": float(p.get("freq", 45)) / 10.0,
            "amplitude": float(p.get("amp", 38)),
            "octaves": 2,
        },
        "sliders": [
            {"id": "freq", "label": "Jitter Frequency (x0.1 Hz)", "min": 10, "max": 120, "val": 45},
            {"id": "amp", "label": "Jitter Amplitude (px)", "min": 5, "max": 90, "val": 38},
        ],
    },
    {
        "id": "orbit",
        "name": "7. Benzene Hexagon & Circle Orbit",
        "category": "procedural",
        "formula": "P(t) = PolygonVertex(sides, radius, 2π*f*t)",
        "spec": lambda p: {
            "type": "orbit",
            "radius": float(p.get("radius", 130)),
            "sides": int(p.get("sides", 6)),
            "frequency": float(p.get("freq", 8)) / 10.0,
        },
        "sliders": [
            {"id": "radius", "label": "Orbit Radius (px)", "min": 40, "max": 240, "val": 130},
            {"id": "sides", "label": "Polygon Sides (0=Circle)", "min": 0, "max": 12, "val": 6},
            {"id": "freq", "label": "Speed (x0.1 Hz)", "min": 2, "max": 30, "val": 8},
        ],
    },
    {
        "id": "lissajous",
        "name": "8. Parametric Lissajous Knot (3:2)",
        "category": "procedural",
        "formula": "x = Ax*sin(2π*fx*t), y = Ay*sin(2π*fy*t + φy)",
        "spec": lambda p: {
            "type": "lissajous",
            "amplitude_x": float(p.get("ax", 170)),
            "amplitude_y": float(p.get("ay", 100)),
            "freq_x": float(p.get("fx", 3)),
            "freq_y": float(p.get("fy", 2)),
            "phase_x": 0.0,
            "phase_y": math.pi / 2.0,
        },
        "sliders": [
            {"id": "ax", "label": "Amplitude X (px)", "min": 40, "max": 260, "val": 170},
            {"id": "ay", "label": "Amplitude Y (px)", "min": 30, "max": 200, "val": 100},
            {"id": "fx", "label": "Frequency X", "min": 1, "max": 6, "val": 3},
            {"id": "fy", "label": "Frequency Y", "min": 1, "max": 6, "val": 2},
        ],
    },
    {
        "id": "move",
        "name": "9. Linear & Cubic Easing Move",
        "category": "kinematics",
        "formula": "P(t) = P0 + Eased(t / duration) * (P1 - P0)",
        "spec": lambda p: {
            "type": "move",
            "from": [CX - p.get("dist", 240) // 2, CY],
            "to": [CX + p.get("dist", 240) // 2, CY],
            "duration": float(p.get("dur", 20)) / 10.0,
            "repeat": True,
            "reverse": True,
            "graph": "ease_in_out_cubic",
        },
        "sliders": [
            {"id": "dur", "label": "Duration (x0.1 s)", "min": 5, "max": 50, "val": 20},
            {"id": "dist", "label": "Travel Distance (px)", "min": 80, "max": 450, "val": 240},
        ],
    },
    {
        "id": "pulse",
        "name": "10. Dynamic Pulse & Breathing",
        "category": "procedural",
        "formula": "Scale(t) = 1.0 + (A / 100) * sin(2π*f*t)",
        "spec": lambda p: {
            "type": "pulse",
            "frequency": float(p.get("freq", 25)) / 10.0,
            "amplitude": float(p.get("amp", 55)),
        },
        "sliders": [
            {"id": "freq", "label": "Pulse Rate (x0.1 Hz)", "min": 5, "max": 50, "val": 25},
            {"id": "amp", "label": "Scale Amplitude (%)", "min": 15, "max": 120, "val": 55},
        ],
    },
    {
        "id": "rotate3d",
        "name": "11. 3D Spatial Perspective & Gimbal",
        "category": "transforms",
        "formula": "M3D = Perspective(d) * RotX(θx) * RotY(θy)",
        "spec": lambda p: {
            "type": "rotate_3d",
            "from": {"rotate_x": -float(p.get("rx", 40)), "rotate_y": 0.0},
            "to": {"rotate_x": float(p.get("rx", 40)), "rotate_y": float(p.get("ry", 60))},
            "duration": float(p.get("dur", 22)) / 10.0,
            "repeat": True,
            "reverse": True,
        },
        "sliders": [
            {"id": "rx", "label": "Pitch Rot X (deg)", "min": 10, "max": 70, "val": 40},
            {"id": "ry", "label": "Yaw Rot Y (deg)", "min": 10, "max": 80, "val": 60},
            {"id": "dur", "label": "Duration (x0.1 s)", "min": 8, "max": 50, "val": 22},
        ],
    },
    {
        "id": "color_shift",
        "name": "12. Dynamic Color & Neon Bloom",
        "category": "styling",
        "formula": "C(t) = LerpRGBA(Gold, Crimson, t)",
        "spec": lambda p: {
            "type": "color",
            "from": "#facc15",
            "to": "#f43f5e",
            "duration": float(p.get("dur", 18)) / 10.0,
            "repeat": True,
            "reverse": True,
        },
        "sliders": [
            {"id": "dur", "label": "Cycle Time (x0.1 s)", "min": 5, "max": 40, "val": 18},
        ],
    },
]

# Active Runtime State
app_state = {
    "active_idx": 0,
    "param_values": {},
    "is_playing": True,
    "trail_active": True,
}


def build_stage_shapes():
    """Generates pure Draw stage background cards, grid lines, and guides."""
    shapes = []

    # 1. Main Stage Viewport Card
    shapes.append({
        "ip": "stage_card",
        "x": STAGE_X,
        "y": STAGE_Y,
        "size": [STAGE_W, STAGE_H],
        "color": "#090d13",
        "border_color": "#1e293b",
        "border_width": 1,
        "border_radius": 12,
        "z": 100,
    })

    # 2. Coordinate Grid Lines
    for gx in range(STAGE_X + 50, STAGE_X + STAGE_W, 60):
        shapes.append({
            "ip": f"grid_v_{gx}",
            "x": gx,
            "y": STAGE_Y,
            "size": [1, STAGE_H],
            "color": "#111a28",
            "border_color": "#111a28",
            "z": 95,
        })
    for gy in range(STAGE_Y + 50, STAGE_Y + STAGE_H, 60):
        shapes.append({
            "ip": f"grid_h_{gy}",
            "x": STAGE_X,
            "y": gy,
            "size": [STAGE_W, 1],
            "color": "#111a28",
            "border_color": "#111a28",
            "z": 95,
        })

    # 3. Center Crosshairs
    shapes.append({
        "ip": "axis_h",
        "x": STAGE_X + 20,
        "y": CY,
        "size": [STAGE_W - 40, 1],
        "color": "#1e293b",
        "border_color": "#1e293b",
        "z": 90,
    })
    shapes.append({
        "ip": "axis_v",
        "x": CX,
        "y": STAGE_Y + 20,
        "size": [1, STAGE_H - 40],
        "color": "#1e293b",
        "border_color": "#1e293b",
        "z": 90,
    })

    # 4. Floor Line for Gravity / Physics
    shapes.append({
        "ip": "floor_line",
        "x": STAGE_X + 30,
        "y": CY + 180,
        "size": [STAGE_W - 60, 2],
        "color": "#ef4444",
        "border_color": "#ef4444",
        "z": 85,
    })

    # 5. The Small Yellow Ball Entity
    shapes.append({
        "ip": "yellow_ball",
        "x": CX,
        "y": CY,
        "size": [22, 22],
        "color": "#facc15",
        "border_radius": "50%",
        "border_color": "#fef08a",
        "border_width": 2,
        "z": 10,
    })

    return shapes


def build_hud_texts():
    """Generates pure Draw HUD overlay texts."""
    active_m = PURE_MOTIONS[app_state["active_idx"]]
    return [
        {
            "ip": "hud_title",
            "text": f"🟡 DRAW.MOTION STUDIO — {active_m['name']}",
            "x": STAGE_X + 24,
            "y": STAGE_Y + 24,
            "font_size": 13,
            "bold": True,
            "color": "#facc15",
            "z": 5,
        },
        {
            "ip": "hud_formula",
            "text": f"Formula: {active_m['formula']}",
            "x": STAGE_X + 24,
            "y": STAGE_Y + 50,
            "font_size": 10,
            "color": "#38bdf8",
            "z": 5,
        },
        {
            "ip": "hud_telemetry",
            "text": f"Stage Viewport: 880x820 | Engine: 60 FPS Analytical Kinematics | Target: ip='yellow_ball'",
            "x": STAGE_X + 24,
            "y": STAGE_Y + 72,
            "font_size": 9,
            "color": "#94a3b8",
            "z": 5,
        },
    ]


def apply_active_motion():
    """Compiles and binds the selected motion to the yellow ball shape via pure Draw.motion API."""
    active_m = PURE_MOTIONS[app_state["active_idx"]]
    spec_builder = active_m["spec"]
    m_dict = spec_builder(app_state["param_values"])

    # Reset position and reattach motion
    Draw.motion(ip="yellow_ball", motion=[m_dict])

    # Refresh HUD text
    Draw.text(display=WIN_TAG, text=build_hud_texts())


def on_motion_changed(motion_name: str):
    """Callback when user selects a different motion type from dropdown."""
    for idx, m in enumerate(PURE_MOTIONS):
        if m["name"] == motion_name or m["id"] == motion_name:
            app_state["active_idx"] = idx
            app_state["param_values"].clear()
            for s in m.get("sliders", []):
                app_state["param_values"][s["id"]] = s["val"]
            break
    apply_active_motion()


def on_slider_changed(slider_id: str, val: int):
    """Callback when user adjusts any parameter slider."""
    app_state["param_values"][slider_id] = val
    apply_active_motion()


def on_play_pause():
    """Toggles play and pause state."""
    app_state["is_playing"] = not app_state["is_playing"]
    btn_text = "▶ Play" if not app_state["is_playing"] else "⏸ Pause"
    Draw.widget.set_value("btn_play", btn_text)


def on_reset():
    """Resets the motion animation cycle."""
    apply_active_motion()


def setup_pure_draw_studio():
    """Builds the complete motion studio test application using ONLY Draw API."""
    print("=" * 74)
    print(" [Draw] Building 100% Pure Draw.motion Studio Test Window...")
    print("=" * 74)

    # 1. Host Window
    Draw.window(
        tag=WIN_TAG,
        title="🟡 Draw.motion Studio — 100% Pure Draw API Interactive Test Window",
        width=WIN_W,
        height=WIN_H,
        background_color="#0b0f17",
    )

    # 2. Stage Shapes & Yellow Ball
    Draw.shapes(display=WIN_TAG, shape=build_stage_shapes())

    # 3. HUD Overlay Typography
    Draw.text(display=WIN_TAG, text=build_hud_texts())

    # 4. Rightmost Control Panel Sidebar using Draw.box & Draw.widget helpers
    sidebar_x = 920
    sidebar_y = 20
    sidebar_w = 430
    sidebar_h = 820

    # Header Card
    Draw.shape(display=WIN_TAG, shape=[{
        "ip": "sidebar_bg",
        "x": sidebar_x,
        "y": sidebar_y,
        "size": [sidebar_w, sidebar_h],
        "color": "#0d1117",
        "border_color": "#21262d",
        "border_width": 1,
        "border_radius": 10,
        "z": 100,
    }])

    Draw.text(display=WIN_TAG, text=[{
        "ip": "sidebar_title",
        "text": "🎛️ PURE DRAW CONTROL PANEL",
        "x": sidebar_x + 18,
        "y": sidebar_y + 18,
        "font_size": 13,
        "bold": True,
        "color": "#facc15",
    }, {
        "ip": "sidebar_subtitle",
        "text": "Using Draw.slider, Draw.combobox, Draw.button, Draw.box",
        "x": sidebar_x + 18,
        "y": sidebar_y + 40,
        "font_size": 9,
        "color": "#8b949e",
    }])

    # Motion Combobox Dropdown
    motion_names = [m["name"] for m in PURE_MOTIONS]
    Draw.combobox(
        ip="motion_combo",
        display=WIN_TAG,
        x=sidebar_x + 18,
        y=sidebar_y + 70,
        width=sidebar_w - 36,
        height=34,
        items=motion_names,
        on_change=on_motion_changed,
    )

    # Action Buttons: Play/Pause, Reset
    Draw.button(
        ip="btn_play",
        display=WIN_TAG,
        x=sidebar_x + 18,
        y=sidebar_y + 118,
        width=180,
        height=34,
        text="⏸ Pause",
        on_click=on_play_pause,
        style="QPushButton { background-color: #facc15; color: #000; font-weight: bold; border-radius: 6px; }",
    )
    Draw.button(
        ip="btn_reset",
        display=WIN_TAG,
        x=sidebar_x + 210,
        y=sidebar_y + 118,
        width=sidebar_w - 228,
        height=34,
        text="↺ Reset Motion",
        on_click=on_reset,
        style="QPushButton { background-color: #334155; color: #f8fafc; font-weight: bold; border-radius: 6px; }",
    )

    # Primary Parameter Sliders (Stiffness / Gravity / Frequency / Duration)
    slider_start_y = sidebar_y + 175

    Draw.text(display=WIN_TAG, text=[{
        "ip": "lbl_param1",
        "text": "Parameter 1 (Stiffness / Speed / Gravity):",
        "x": sidebar_x + 18,
        "y": slider_start_y,
        "font_size": 10,
        "bold": True,
        "color": "#cbd5e1",
    }])
    Draw.slider(
        ip="slider_param1",
        display=WIN_TAG,
        x=sidebar_x + 18,
        y=slider_start_y + 22,
        width=sidebar_w - 36,
        height=28,
        min=20,
        max=1000,
        value=280,
        on_change=lambda v: on_slider_changed("stiffness", v),
    )

    Draw.text(display=WIN_TAG, text=[{
        "ip": "lbl_param2",
        "text": "Parameter 2 (Damping / Restitution / Amplitude):",
        "x": sidebar_x + 18,
        "y": slider_start_y + 60,
        "font_size": 10,
        "bold": True,
        "color": "#cbd5e1",
    }])
    Draw.slider(
        ip="slider_param2",
        display=WIN_TAG,
        x=sidebar_x + 18,
        y=slider_start_y + 82,
        width=sidebar_w - 36,
        height=28,
        min=2,
        max=60,
        value=14,
        on_change=lambda v: on_slider_changed("damping", v),
    )

    Draw.text(display=WIN_TAG, text=[{
        "ip": "lbl_param3",
        "text": "Parameter 3 (Displacement / Radius / Span):",
        "x": sidebar_x + 18,
        "y": slider_start_y + 120,
        "font_size": 10,
        "bold": True,
        "color": "#cbd5e1",
    }])
    Draw.slider(
        ip="slider_param3",
        display=WIN_TAG,
        x=sidebar_x + 18,
        y=slider_start_y + 142,
        width=sidebar_w - 36,
        height=28,
        min=40,
        max=360,
        value=180,
        on_change=lambda v: on_slider_changed("dist", v),
    )

    # Preset Quick Buttons
    preset_start_y = slider_start_y + 195
    Draw.text(display=WIN_TAG, text=[{
        "ip": "lbl_presets_head",
        "text": "⚡ 1-Click Showcase Presets:",
        "x": sidebar_x + 18,
        "y": preset_start_y,
        "font_size": 10,
        "bold": True,
        "color": "#facc15",
    }])

    presets = [
        ("Harmonic Spring", "spring"),
        ("Gravity Bounce", "gravity"),
        ("Ballistic Shot", "projectile"),
        ("Pendulum", "pendulum"),
        ("Sine Wave", "wave"),
        ("Simplex Wiggle", "wiggle"),
        ("Benzene Ring", "orbit"),
        ("Lissajous Knot", "lissajous"),
    ]
    for idx, (p_name, p_id) in enumerate(presets):
        row = idx // 2
        col = idx % 2
        bx = sidebar_x + 18 + col * ((sidebar_w - 44) // 2 + 8)
        by = preset_start_y + 24 + row * 40
        bw = (sidebar_w - 44) // 2
        Draw.button(
            ip=f"preset_btn_{p_id}",
            display=WIN_TAG,
            x=bx,
            y=by,
            width=bw,
            height=32,
            text=p_name,
            on_click=lambda pid=p_id: on_motion_changed(pid),
            style="QPushButton { background-color: #1e293b; color: #38bdf8; border: 1px solid #334155; border-radius: 5px; font-size: 10px; } QPushButton:hover { background-color: #0284c7; color: #fff; }",
        )

    # Initial Motion Attachment
    apply_active_motion()
    print(" [Draw] Pure Draw.motion Studio Initialized Successfully!")


def main():
    setup_pure_draw_studio()
    Draw.window.run()


if __name__ == "__main__":
    main()
