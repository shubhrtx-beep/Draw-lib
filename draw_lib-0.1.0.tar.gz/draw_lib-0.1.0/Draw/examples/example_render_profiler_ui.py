"""
Draw-lib Rendering Pipeline Profiler Showcase
=============================================
Interactive UI demonstrating real-time high-resolution instrumentation across
the 8 core rendering stages:
1. Motion calculation
2. Geometry generation
3. Spatial grid
4. Shape state/update
5. GPU buffer upload
6. OpenGL draw
7. Qt paint/event processing
8. Text/FPS display
"""

import sys
import os
import random
import time

# Ensure workspace root is on sys.path
_CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
_WORKSPACE_ROOT = os.path.dirname(_CURRENT_DIR)
for p in (_WORKSPACE_ROOT, _CURRENT_DIR):
    if p not in sys.path:
        sys.path.insert(0, p)

import Draw
from Draw._profiler import profiler, attach_profiler_to_canvas, ProfilerCategory

WIN_TAG = "profiler_showcase"
WIN_W = 1280
WIN_H = 820

PALETTE = [
    "#38BDF8", "#34D399", "#F472B6", "#FBBF24",
    "#A78BFA", "#FB7185", "#2DD4BF", "#F97316",
    "#818CF8", "#4ADE80", "#C084FC", "#38BDF8",
]

state = {
    "rect_count": 0,
    "rect_ips": [],
    "total_spawned": 0,
}


def get_live_hud_text() -> str:
    """Returns real-time single line telemetry string for Draw.live text."""
    return profiler.live_hud_string()


def print_full_profiler_report():
    """Prints the complete ASCII report table to the terminal."""
    print("\n" + profiler.format_table())


def export_json_report():
    """Exports profiler metrics to a local JSON file."""
    path = "profiler_report.json"
    profiler.export_json(path)
    print(f"\n[OK] Profiler metrics exported to {os.path.abspath(path)}")


def spawn_rectangles(count: int = 30):
    """Spawns N moving rectangles with continuous kinetic motion."""
    new_shapes = []
    start_idx = state["total_spawned"]

    min_x, max_x = 30, WIN_W - 90
    min_y, max_y = 170, WIN_H - 90

    for i in range(count):
        idx = start_idx + i
        ip = f"shape_{idx}"
        w = random.randint(32, 60)
        h = random.randint(32, 60)
        x0 = random.randint(min_x, max_x)
        y0 = random.randint(min_y, max_y)
        color = random.choice(PALETTE)
        rot0 = float(random.randint(0, 360))
        z_layer = random.randint(15, 65)

        new_shapes.append({
            "vertices": 4,
            "size": [w, h],
            "color": color,
            "x": x0,
            "y": y0,
            "rotation": rot0,
            "border_radius": 6,
            "border_width": 1,
            "border_color": "rgba(255, 255, 255, 0.2)",
            "ip": ip,
            "opacity": 90,
            "z": z_layer,
        })
        state["rect_ips"].append(ip)

    state["rect_count"] += count
    state["total_spawned"] += count

    Draw.shape(display=WIN_TAG, shape=new_shapes)

    for s in new_shapes:
        ip = s["ip"]
        x0, y0 = s["x"], s["y"]
        x1 = random.randint(min_x, max_x)
        y1 = random.randint(min_y, max_y)
        move_dur = random.uniform(3.0, 7.0)
        rot_dur = random.uniform(2.0, 5.0)

        Draw.motion(
            ip=ip,
            motion=[
                {
                    "type": "move",
                    "from": [x0, y0],
                    "to": [x1, y1],
                    "time": {"start": 0.0, "end": move_dur},
                    "repeat": True,
                    "pingpong": True,
                    "ease": "ease_in_out",
                },
                {
                    "type": "rotate",
                    "from": 0.0,
                    "to": 360.0 if random.random() > 0.5 else -360.0,
                    "time": {"start": 0.0, "end": rot_dur},
                    "repeat": True,
                },
            ]
        )


def clear_shapes():
    for ip in state["rect_ips"]:
        try:
            Draw.shapes.remove(ip)
        except Exception:
            pass
    state["rect_ips"].clear()
    state["rect_count"] = 0
    profiler.reset()


def build_ui():
    Draw.window(
        tag=WIN_TAG,
        title="Draw-lib — 8-Stage Rendering Pipeline Profiler",
        width=WIN_W,
        height=WIN_H,
        background_color="#0A0E17",
    )

    # 1. Header Control Panel Card
    Draw.shape(
        display=WIN_TAG,
        shape=[{
            "vertices": 4,
            "size": [WIN_W - 40, 135],
            "color": "#111827",
            "border_color": "#1F2937",
            "border_width": 1,
            "border_radius": 14,
            "x": 20,
            "y": 12,
            "ip": "header_card",
            "z": 85,
        }]
    )

    # 2. Header Text
    Draw.text(
        tag=WIN_TAG,
        text="📊 Draw-lib 8-Stage Rendering Pipeline Profiler",
        customise={
            "x": 40, "y": 24, "font_size": 18, "bold": True, "color": "#60A5FA", "z": 0,
        }
    )

    # 3. Live 8-Stage Telemetry HUD
    Draw.text(
        tag=WIN_TAG,
        text=get_live_hud_text,
        customise={
            "x": 40, "y": 52, "font_size": 12, "bold": True, "color": "#34D399", "z": 0,
        }
    )

    Draw.text(
        tag=WIN_TAG,
        text="Measures: 1.Motion | 2.Geometry | 3.Spatial Grid | 4.Shape State | 5.GPU Upload | 6.OpenGL Draw | 7.Qt Paint | 8.Text/FPS",
        customise={
            "x": 40, "y": 78, "font_size": 11, "color": "#9CA3AF", "z": 0,
        }
    )

    # 4. Action Buttons
    Draw.button(
        ip="btn_spawn30",
        display=WIN_TAG,
        x=40,
        y=102,
        width=120,
        height=32,
        text="+30 Rects",
        style={"background_color": "#059669", "hover_background_color": "#10B981", "color": "#FFF", "font_size": 11, "bold": True, "border_radius": 6},
        on_click=lambda: spawn_rectangles(30),
    )

    Draw.button(
        ip="btn_spawn100",
        display=WIN_TAG,
        x=170,
        y=102,
        width=120,
        height=32,
        text="+100 Rects",
        style={"background_color": "#2563EB", "hover_background_color": "#3B82F6", "color": "#FFF", "font_size": 11, "bold": True, "border_radius": 6},
        on_click=lambda: spawn_rectangles(100),
    )

    Draw.button(
        ip="btn_report",
        display=WIN_TAG,
        x=300,
        y=102,
        width=140,
        height=32,
        text="📋 Print Report Table",
        style={"background_color": "#7C3AED", "hover_background_color": "#8B5CF6", "color": "#FFF", "font_size": 11, "bold": True, "border_radius": 6},
        on_click=print_full_profiler_report,
    )

    Draw.button(
        ip="btn_export",
        display=WIN_TAG,
        x=450,
        y=102,
        width=130,
        height=32,
        text="💾 Export JSON",
        style={"background_color": "#D97706", "hover_background_color": "#F59E0B", "color": "#FFF", "font_size": 11, "bold": True, "border_radius": 6},
        on_click=export_json_report,
    )

    Draw.button(
        ip="btn_clear",
        display=WIN_TAG,
        x=590,
        y=102,
        width=100,
        height=32,
        text="🗑️ Clear All",
        style={"background_color": "#DC2626", "hover_background_color": "#EF4444", "color": "#FFF", "font_size": 11, "bold": True, "border_radius": 6},
        on_click=clear_shapes,
    )

    # 5. Spawn initial 30 shapes
    spawn_rectangles(30)

    # 6. Enable Hardware Acceleration & Attach Profiler Hook
    canvas = Draw.super(
        display=WIN_TAG,
        precompile=True,
        mode="max",
        vsync=False,
        batch_capacity=131072,
    )
    attach_profiler_to_canvas(canvas)
    return canvas


def main():
    build_ui()
    print("\n[OK] Profiler Showcase UI is active. Click 'Print Report Table' anytime to inspect.")
    Draw.window.run(WIN_TAG)


if __name__ == "__main__":
    main()
