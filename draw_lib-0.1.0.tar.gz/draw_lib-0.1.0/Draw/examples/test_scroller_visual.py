"""
test_scroller_visual.py
=======================
Visual test for the redesigned Draw.scroller module.

Demonstrates:
  1. Full-page vertical scroller (right edge)
  2. Container-scoped scroller (inside a sidebar panel)
  3. Tall scrollable content with colourful shapes and text
  4. Programmatic scroll API (scroll_to, scroll_by, scroll_y)

Run:
    D:/python/python.exe test_scroller_visual.py
"""

import os
import sys

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)

import Draw
from Draw.scroller import create_scroller


# ── colour palette ──────────────────────────────────────────────────────────

BG_DARK     = "#0B1120"
CARD_BG     = "#141B2D"
CARD_BORDER = "#1E293B"
ACCENT_CYAN = "#22D3EE"
ACCENT_PINK = "#F472B6"
ACCENT_LIME = "#A3E635"
ACCENT_AMBER= "#FBBF24"
ACCENT_VIOLET="#A78BFA"
TEXT_PRIMARY = "#F1F5F9"
TEXT_MUTED   = "#64748B"
SIDEBAR_BG  = "#111827"
SIDEBAR_BD  = "#1F2937"


def main():
    win_tag = "scroller_test"
    win_w, win_h = 1100, 750

    # ── window ──────────────────────────────────────────────────────────────
    Draw.window(
        tag=win_tag,
        title="🚀 Scroller Redesign — Visual Test",
        width=win_w,
        height=win_h,
        background_color=BG_DARK,
    )

    # ── 1. Full-page scroller (right edge) ──────────────────────────────────
    page_scroller = create_scroller(
        win_tag,
        content_height=2200.0,
        win_w=win_w,
        win_h=win_h,
        track_color="#1E293B",
        thumb_color=ACCENT_CYAN,
        track_width=10,
    )

    # ── 2. Main content card (tall — extends below viewport) ────────────────
    Draw.shapes(
        display=win_tag,
        shape=[
            {
                "ip": "main_card",
                "vertices": 4,
                "x": 30, "y": 30,
                "width": 720, "height": 2100,
                "color": CARD_BG,
                "border_width": 1,
                "border_color": CARD_BORDER,
                "border_radius": "12px",
                "z": 500,
                "locked": True,
            }
        ],
    )

    # ── 3. Header section ───────────────────────────────────────────────────
    Draw.text(
        tag=win_tag,
        text="Scroller Redesign — Visual Test",
        ip="title",
        customise={
            "font_size": 26, "font_family": "Outfit",
            "color": TEXT_PRIMARY, "bold": True,
            "x": 55, "y": 55, "z": 10,
        },
    )
    Draw.text(
        tag=win_tag,
        text="Scroll with mouse wheel · Drag the cyan thumb · Content extends 2100px tall",
        ip="subtitle",
        customise={
            "font_size": 13, "font_family": "Outfit",
            "color": TEXT_MUTED,
            "x": 55, "y": 95, "z": 10,
        },
    )

    # ── 4. Section 1: Draggable shapes row ──────────────────────────────────
    Draw.text(
        tag=win_tag, text="Section 1 — Draggable Shapes", ip="sec1_label",
        customise={
            "font_size": 16, "font_family": "Outfit", "color": ACCENT_CYAN,
            "bold": True, "x": 55, "y": 150, "z": 10,
        },
    )

    shapes_row = []
    colours = [ACCENT_CYAN, ACCENT_PINK, ACCENT_LIME, ACCENT_AMBER, ACCENT_VIOLET]
    vertices = [4, 3, 6, 5, 8]
    for i, (col, v) in enumerate(zip(colours, vertices)):
        shapes_row.append({
            "ip": f"shape_row1_{i}",
            "vertices": v,
            "size": [100, 90],
            "color": col,
            "border_width": 2,
            "border_color": "#FFFFFF22",
            "border_radius": "6px" if v == 4 else "0px",
            "x": 55 + i * 140,
            "y": 190,
            "z": 10,
        })
    Draw.shapes(display=win_tag, shape=shapes_row)

    # ── 5. Section 2: Statistics cards (y=360+) ─────────────────────────────
    Draw.text(
        tag=win_tag, text="Section 2 — Stats Cards", ip="sec2_label",
        customise={
            "font_size": 16, "font_family": "Outfit", "color": ACCENT_PINK,
            "bold": True, "x": 55, "y": 340, "z": 10,
        },
    )

    stats = [
        ("Downloads", "12.4K", ACCENT_CYAN),
        ("Stars", "3.2K", ACCENT_AMBER),
        ("Forks", "891", ACCENT_LIME),
    ]
    for i, (label, value, col) in enumerate(stats):
        cx = 55 + i * 230
        cy = 380
        Draw.shapes(display=win_tag, shape=[{
            "ip": f"stat_card_{i}", "vertices": 4,
            "x": cx, "y": cy, "width": 210, "height": 120,
            "color": "#1A2332", "border_width": 2, "border_color": col,
            "border_radius": "10px", "z": 80, "locked": True,
        }])
        Draw.text(tag=win_tag, text=value, ip=f"stat_val_{i}", customise={
            "font_size": 28, "font_family": "Outfit", "color": col,
            "bold": True, "x": cx + 20, "y": cy + 25, "z": 10,
        })
        Draw.text(tag=win_tag, text=label, ip=f"stat_lbl_{i}", customise={
            "font_size": 12, "font_family": "Outfit", "color": TEXT_MUTED,
            "x": cx + 20, "y": cy + 75, "z": 10,
        })

    # ── 6. Section 3: More content below fold (y=560+) ──────────────────────
    Draw.text(
        tag=win_tag, text="Section 3 — Below the Fold", ip="sec3_label",
        customise={
            "font_size": 16, "font_family": "Outfit", "color": ACCENT_LIME,
            "bold": True, "x": 55, "y": 560, "z": 10,
        },
    )
    Draw.text(
        tag=win_tag,
        text="This section is only visible after scrolling down.\nThe scroller thumb should be partway down the track now.",
        ip="sec3_desc",
        customise={
            "font_size": 13, "font_family": "Outfit", "color": TEXT_MUTED,
            "x": 55, "y": 600, "z": 10, "max_width": 650,
        },
    )

    # Colourful grid of small tiles
    tile_colors = [
        "#EF4444", "#F97316", "#EAB308", "#22C55E", "#06B6D4",
        "#3B82F6", "#8B5CF6", "#EC4899", "#14B8A6", "#F43F5E",
        "#84CC16", "#0EA5E9", "#A855F7", "#FB923C", "#2DD4BF",
    ]
    for idx, tc in enumerate(tile_colors):
        row, col_i = divmod(idx, 5)
        Draw.shapes(display=win_tag, shape=[{
            "ip": f"tile_{idx}", "vertices": 4,
            "x": 55 + col_i * 140, "y": 670 + row * 110,
            "width": 120, "height": 90,
            "color": tc, "border_radius": "8px",
            "z": 20, "locked": True,
        }])

    # ── 7. Section 4: Deep content (y=1050+) ────────────────────────────────
    Draw.text(
        tag=win_tag, text="Section 4 — Deep Scroll Territory", ip="sec4_label",
        customise={
            "font_size": 16, "font_family": "Outfit", "color": ACCENT_VIOLET,
            "bold": True, "x": 55, "y": 1050, "z": 10,
        },
    )

    deep_shapes = [
        {"ip": "deep_hex", "vertices": 6, "size": [160, 140], "color": ACCENT_VIOLET,
         "x": 100, "y": 1110, "z": 10, "border_width": 3, "border_color": "#C4B5FD"},
        {"ip": "deep_tri", "vertices": 3, "size": [150, 130], "color": ACCENT_AMBER,
         "x": 330, "y": 1120, "z": 10, "border_width": 3, "border_color": "#FDE68A"},
        {"ip": "deep_oct", "vertices": 8, "size": [140, 140], "color": ACCENT_PINK,
         "x": 540, "y": 1110, "z": 10, "border_width": 3, "border_color": "#FBCFE8"},
    ]
    Draw.shapes(display=win_tag, shape=deep_shapes)

    # ── 8. Section 5: Bottom marker (y=1400+) ──────────────────────────────
    Draw.shapes(display=win_tag, shape=[{
        "ip": "bottom_bar", "vertices": 4,
        "x": 55, "y": 1400, "width": 680, "height": 4,
        "color": ACCENT_CYAN, "z": 10, "locked": True,
    }])
    Draw.text(
        tag=win_tag, text="✓ You've scrolled to the bottom! The scroller works.",
        ip="bottom_msg",
        customise={
            "font_size": 15, "font_family": "Outfit", "color": ACCENT_CYAN,
            "bold": True, "x": 55, "y": 1430, "z": 10,
        },
    )

    # ── 9. Sidebar panel with scoped scroller ───────────────────────────────
    Draw.shapes(display=win_tag, shape=[{
        "ip": "sidebar_panel",
        "vertices": 4,
        "x": 790, "y": 30,
        "width": 260, "height": 700,
        "color": SIDEBAR_BG,
        "border_width": 1,
        "border_color": SIDEBAR_BD,
        "border_radius": "10px",
        "z": 500,
        "locked": True,
    }])
    Draw.text(
        tag=win_tag, text="Sidebar", ip="sidebar_title",
        customise={
            "font_size": 15, "font_family": "Outfit", "color": TEXT_PRIMARY,
            "bold": True, "x": 810, "y": 50, "z": 10,
        },
    )

    # Sidebar items
    sidebar_items = [
        "Dashboard", "Analytics", "Projects", "Settings",
        "Team", "Reports", "Calendar", "Messages",
        "Files", "Notifications", "Integrations", "Help",
    ]
    for i, name in enumerate(sidebar_items):
        iy = 90 + i * 48
        Draw.shapes(display=win_tag, shape=[{
            "ip": f"sb_item_bg_{i}", "vertices": 4,
            "x": 800, "y": iy,
            "width": 240, "height": 38,
            "color": "#1F2937" if i % 2 == 0 else "#111827",
            "border_radius": "6px",
            "z": 200, "locked": True,
        }])
        Draw.text(tag=win_tag, text=f"  {name}", ip=f"sb_item_{i}", customise={
            "font_size": 13, "font_family": "Outfit",
            "color": ACCENT_CYAN if i == 0 else "#94A3B8",
            "x": 815, "y": iy + 10, "z": 10,
        })

    # ── 10. Programmatic scroll test on startup ─────────────────────────────
    print(f"[scroller] Initial scroll_y: {page_scroller.scroll_y}")
    print("[scroller] Use mouse wheel to scroll or drag the cyan thumb on the right edge")
    print("[scroller] Sidebar panel is a container-scoped demo on the right side")
    print()
    print("[OK] Scroller redesign visual test ready!")

    # ── run ──────────────────────────────────────────────────────────────────
    Draw.window.run(win_tag)


if __name__ == "__main__":
    main()
