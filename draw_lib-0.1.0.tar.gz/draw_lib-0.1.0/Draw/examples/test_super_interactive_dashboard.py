"""
Draw.super Interactive Hardware & Graphics Dashboard
====================================================
A live interactive application showcasing Draw.super (OpenGL Hardware Engine):
- Real-time Motions (Springs, Rotation, Ping-pong scaling, Wave oscillations)
- Vibrant Color System (Hex, RGB, Tokens, Opacity)
- Geometric & Stylized Shapes (GPU-batched polygons, borders, glow, shadows)
- Real-Time Live Graphs (Bar, Line charts with live data stream)
- Full Hardware Sensor Support (Mouse dragging, clicks, live keyboard key logger)

Run directly with:
    D:/python/python.exe Draw/examples/test_super_interactive_dashboard.py
"""

import os
import sys
import random
import time

SYS_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PARENT_ROOT = os.path.dirname(SYS_ROOT)
if PARENT_ROOT not in sys.path:
    sys.path.insert(0, PARENT_ROOT)
if SYS_ROOT not in sys.path:
    sys.path.insert(0, SYS_ROOT)

import Draw

WIN_TAG = "super_dashboard"

# State trackers for hardware sensors
_state = {
    "clicks": 0,
    "last_key": "None",
    "last_mouse_pos": "(0, 0)",
    "active_key_indicator": None,
    "cpu_val": 45,
    "gpu_val": 80,
    "ram_val": 55,
}

def on_shape_click(record):
    _state["clicks"] += 1

def main():
    print("Initializing Window...")
    Draw.window(
        tag=WIN_TAG,
        title="⚡ Draw.super — OpenGL Engine Full-Feature & Hardware Suite",
        width=1280,
        height=820,
        background_color="#0B0F19",
    )

    # ── 1. Header Banner ──────────────────────────────────────────────────────
    Draw.text(
        tag=WIN_TAG,
        text="⚡ Draw.super — Hardware-Accelerated OpenGL Engine",
        ip="hdr_title",
        customise={"x": 40, "y": 25, "font_size": 22, "bold": True, "color": "#58A6FF"}
    )
    Draw.text(
        tag=WIN_TAG,
        text="Real-time multi-threaded GPU dynamic batching, 2D motion physics, live graphs & hardware senses.",
        ip="hdr_subtitle",
        customise={"x": 40, "y": 58, "font_size": 12, "color": "#8B949E"}
    )

    # ── 2. Section 1: Motion Physics Gallery (Left Column) ────────────────────
    Draw.text(
        tag=WIN_TAG,
        text="🌀 Motion & Physics",
        ip="sec1_title",
        customise={"x": 40, "y": 100, "font_size": 15, "bold": True, "color": "#38BDF8"}
    )

    motion_shapes = [
        {"ip": "m_rotate", "vertices": 6, "size": [50, 50], "x": 50, "y": 140, "color": "#F43F5E"},
        {"ip": "m_scale", "vertices": 4, "size": [45, 45], "x": 130, "y": 140, "color": "#A855F7", "border_radius": 8},
        {"ip": "m_wave", "vertices": 4, "size": [45, 45], "x": 210, "y": 140, "color": "#10B981", "border_radius": 22},
        {"ip": "m_spring", "vertices": 4, "size": [45, 45], "x": 50, "y": 230, "color": "#F59E0B", "border_radius": 6},
    ]
    Draw.shape(display=WIN_TAG, shape=motion_shapes)

    # Motion labels
    Draw.text(tag=WIN_TAG, text="Rotate", customise={"x": 55, "y": 195, "font_size": 11, "color": "#94A3B8"})
    Draw.text(tag=WIN_TAG, text="Pulse", customise={"x": 138, "y": 195, "font_size": 11, "color": "#94A3B8"})
    Draw.text(tag=WIN_TAG, text="Wave", customise={"x": 218, "y": 195, "font_size": 11, "color": "#94A3B8"})
    Draw.text(tag=WIN_TAG, text="Spring Physics", customise={"x": 50, "y": 285, "font_size": 11, "color": "#94A3B8"})

    # Attach motion definitions
    Draw.motion(ip="m_rotate", motion=[{"type": "rotate", "from": 0, "to": 360, "time": {"start": 0, "end": 2.5}, "repeat": True}])
    Draw.motion(ip="m_scale", motion=[{"type": "scale", "from": [1.0, 1.0], "to": [1.4, 1.4], "time": {"start": 0, "end": 1.2}, "repeat": True, "pingpong": True}])
    Draw.motion(ip="m_wave", motion=[{"type": "wave", "amplitude": 20, "frequency": 2.0, "time": {"start": 0, "end": 3.0}, "repeat": True}])
    Draw.motion(ip="m_spring", motion=[{"type": "spring", "stiffness": 180, "damping": 12, "from": [50, 230], "to": [220, 230], "time": {"start": 0, "end": 2.0}, "repeat": True, "pingpong": True}])

    # ── 3. Section 2: Shapes & GPU Batching (Center Column) ──────────────────
    Draw.text(
        tag=WIN_TAG,
        text="🔷 GPU-Batched Polygons & Stylized Shapes",
        ip="sec2_title",
        customise={"x": 320, "y": 100, "font_size": 15, "bold": True, "color": "#38BDF8"}
    )

    gallery_shapes = [
        # Regular Polygons (fast GPU-batched path)
        {"ip": "poly_3", "vertices": 3, "size": [44, 44], "x": 330, "y": 140, "color": "#EF4444"},
        {"ip": "poly_4", "vertices": 4, "size": [44, 44], "x": 390, "y": 140, "color": "#F97316"},
        {"ip": "poly_5", "vertices": 5, "size": [44, 44], "x": 450, "y": 140, "color": "#EAB308"},
        {"ip": "poly_6", "vertices": 6, "size": [44, 44], "x": 510, "y": 140, "color": "#22C55E"},
        {"ip": "poly_8", "vertices": 8, "size": [44, 44], "x": 570, "y": 140, "color": "#06B6D4"},

        # Complex Styled Shapes (QPainter fallback pass)
        {"ip": "s_border", "vertices": 4, "size": [50, 50], "x": 330, "y": 210, "color": "#1E293B", "border_width": 2, "border_color": "#38BDF8"},
        {"ip": "s_round", "vertices": 4, "size": [50, 50], "x": 400, "y": 210, "color": "#6366F1", "border_radius": 15},
        {"ip": "s_glow", "vertices": 4, "size": [50, 50], "x": 470, "y": 210, "color": "#EC4899", "glow_color": "#EC4899", "glow_blur": 15},
        {"ip": "s_shadow", "vertices": 4, "size": [50, 50], "x": 540, "y": 210, "color": "#14B8A6", "shadow_color": "rgba(0,0,0,0.6)", "shadow_blur": 8, "shadow_offset": [3, 3]},
    ]
    Draw.shape(display=WIN_TAG, shape=gallery_shapes)

    # ── 4. Section 3: Live Graphs & Data Feeds ────────────────────────────────
    Draw.text(
        tag=WIN_TAG,
        text="📊 Live Visual Graphs",
        ip="sec3_title",
        customise={"x": 40, "y": 340, "font_size": 15, "bold": True, "color": "#38BDF8"}
    )

    Draw.graph(
        ip="dash_bar_chart", type="bar", display=WIN_TAG,
        graph=[
            {
                "x": ["CPU", "GPU", "RAM", "VRAM"],
                "y": [_state["cpu_val"], _state["gpu_val"], _state["ram_val"], 70],
                "title": "Hardware Load",
                "customise": {"color": "#3B82F6", "show_values": True, "show_line": True}
            }
        ],
        x=40, y=380, width=320, height=220,
    )

    Draw.graph(
        ip="dash_donut_chart", type="donut", display=WIN_TAG,
        graph=[
            {
                "x": ["Geometry", "Textures", "Shaders"],
                "y": [50, 30, 20],
                "title": "GPU Budget",
                "customise": {"color": ["#8B5CF6", "#EC4899", "#10B981"], "inner_radius": 40}
            }
        ],
        x=380, y=380, width=220, height=220,
    )

    # ── 5. Section 4: Hardware Sensors Playground (Right Column) ──────────────
    Draw.text(
        tag=WIN_TAG,
        text="🎮 Hardware Input & Sensors",
        ip="sec4_title",
        customise={"x": 680, "y": 100, "font_size": 15, "bold": True, "color": "#38BDF8"}
    )

    # Draggable interactive card
    Draw.shape(display=WIN_TAG, shape=[
        {
            "ip": "drag_card",
            "vertices": 4,
            "size": [160, 90],
            "x": 680,
            "y": 140,
            "color": "#1E293B",
            "border_radius": 10,
            "border_width": 2,
            "border_color": "#475569",
        }
    ])
    Draw.text(
        tag=WIN_TAG,
        text="🖱️ Drag Me Anywhere!",
        customise={"x": 695, "y": 165, "font_size": 12, "bold": True, "color": "#F8FAFC"}
    )
    Draw.text(
        tag=WIN_TAG,
        text="Instant 1:1 mouse tracking",
        customise={"x": 695, "y": 190, "font_size": 10, "color": "#94A3B8"}
    )

    # Clickable interactive counter shape
    Draw.shape(display=WIN_TAG, shape=[
        {
            "ip": "click_btn",
            "vertices": 4,
            "size": [180, 50],
            "x": 860,
            "y": 140,
            "color": "#3B82F6",
            "border_radius": 8,
        }
    ])
    Draw.text(
        tag=WIN_TAG,
        text="Click Me!",
        customise={"x": 920, "y": 155, "font_size": 13, "bold": True, "color": "white"}
    )

    # Live Hardware Telemetry HUD
    Draw.text(
        tag=WIN_TAG,
        text=lambda: f"🖱️ Mouse Clicks: {_state['clicks']}",
        customise={"x": 680, "y": 250, "font_size": 13, "bold": True, "color": "#E2E8F0"}
    )
    Draw.text(
        tag=WIN_TAG,
        text=lambda: f"⌨️ Last Key Pressed: {_state['last_key'].upper()}",
        customise={"x": 680, "y": 280, "font_size": 13, "bold": True, "color": "#FBBF24"}
    )

    # Keyboard Arrow Visual Indicators
    arrow_keys = [
        ("key_up", "↑", 740, 320),
        ("key_left", "←", 695, 360),
        ("key_down", "↓", 740, 360),
        ("key_right", "→", 785, 360),
    ]
    for ip, symbol, ax, ay in arrow_keys:
        Draw.shape(display=WIN_TAG, shape=[{
            "ip": ip, "vertices": 4, "size": [38, 34], "x": ax, "y": ay,
            "color": "#1E293B", "border_radius": 6, "border_width": 1, "border_color": "#475569"
        }])
        Draw.text(tag=WIN_TAG, text=symbol, customise={"x": ax + 12, "y": ay + 7, "font_size": 14, "bold": True, "color": "white"})

    # Interactive Text Input Field
    Draw.lineedit(
        display=WIN_TAG,
        ip="live_typing_box",
        placeholder="Type here to test keyboard input...",
        x=680, y=420, width=360, height=38,
        style={"background": "#1E293B", "color": "white", "border_radius": 6, "border": "1px solid #475569"}
    )

    # Senses & Connectors Wiring
    Draw.senses("mouse_click", ip="click_btn", id="s_btn_click")
    Draw.connectors(sense="s_btn_click", work=on_shape_click)

    # Register Keyboard Senses for Key Logging
    def make_key_handler(k):
        def _handler(rec):
            _state["last_key"] = k
        return _handler

    keys_to_track = ["space", "return", "escape", "up", "down", "left", "right", "a", "b", "c", "w", "s", "d"]
    for k in keys_to_track:
        sid = f"sense_k_{k}"
        Draw.senses("key_press", id=sid, key=[k])
        Draw.connectors(sense=sid, work=make_key_handler(k))

    # ── 6. Activate Draw.super Hardware Acceleration Engine! ─────────────────
    print("Activating Draw.super OpenGL Engine...")
    gl_canvas = Draw.super(
        display=WIN_TAG,
        precompile=True,
        mode="max",
        vsync=False,
        batch_capacity=65536,
    )

    print("\n[OK] Draw.super Interactive Dashboard Running. Press Ctrl+C or close window to exit.")
    Draw.window.run(WIN_TAG)

if __name__ == "__main__":
    main()
