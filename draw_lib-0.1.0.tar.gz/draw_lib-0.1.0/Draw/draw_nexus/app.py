"""
DRAW.NEXUS Master Application Orchestrator
===========================================
Integrates all 5 Draw subsystems into a high-performance interactive multi-window environment:
1. Center Particle Universe (1,000–50,000 particles)
2. Motion Laboratory (10 motion modes)
3. Live Object Inspector & 21-Subsystem Engine HUD
4. Real-Time Performance Graph
5. Motion Timeline & 3-Node Connected Joint Physics Sandbox
6. Automated "WOW" Demo, 5-Stage Benchmark Suite & Chaos Mode
7. Multi-Window Satellite Telemetry Monitor (Secondary Window)
"""

from __future__ import annotations

import math
import os
import sys
import time
from typing import Any, Dict, List, Optional

# UTF-8 stdout/stderr safety on Windows
try:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

_NEXUS_DIR = os.path.dirname(os.path.abspath(__file__))
_DRAW_DIR = os.path.dirname(_NEXUS_DIR)
_ROOT_DIR = os.path.dirname(_DRAW_DIR)

for p in [_ROOT_DIR, _DRAW_DIR, _NEXUS_DIR]:
    if p not in sys.path:
        sys.path.insert(0, p)

import Draw
from Draw.debug import debug
from draw_nexus.benchmark import BenchmarkSuite
from draw_nexus.chaos import ChaosController
from draw_nexus.config import THEME, WINDOW_HEIGHT, WINDOW_WIDTH
from draw_nexus.drag_experiment import DragExperiment
from draw_nexus.graph_hud import PerformanceGraph
from draw_nexus.inspector import InspectorHUD
from draw_nexus.motion_lab import MotionLab
from draw_nexus.particles import ParticleUniverse
from draw_nexus.satellite_window import SatelliteMonitorWindow
from draw_nexus.timeline import MotionTimeline
from draw_nexus.wow_sequence import WowDirector


class DrawNexusApp:
    """Master application controller for DRAW.NEXUS."""

    def __init__(self, tag: str = "nexus_main"):
        self.tag = tag
        self.width = WINDOW_WIDTH
        self.height = WINDOW_HEIGHT
        
        # Subsystems & Controllers
        arena_bounds = (258.0, 60.0, 812.0, 530.0)
        self.universe = ParticleUniverse(count=1500, arena_bounds=arena_bounds)
        self.motion_lab = MotionLab(panel_bounds=(16.0, 60.0, 230.0, 530.0), on_mode_changed=self.on_mode_changed)
        self.inspector = InspectorHUD(panel_bounds=(1080.0, 60.0, 264.0, 530.0))
        self.perf_graph = PerformanceGraph(bounds=(16.0, 600.0, 540.0, 205.0))
        self.drag_exp = DragExperiment(arena_bounds=arena_bounds)
        self.timeline = MotionTimeline(bounds=(568.0, 600.0, 776.0, 205.0), on_speed_changed=self.on_speed_changed)
        self.wow = WowDirector(self.universe)
        self.benchmark = BenchmarkSuite(self.universe)
        self.chaos = ChaosController(self.universe)
        self.satellite = SatelliteMonitorWindow(tag="nexus_satellite", app_controller=self)
        
        self.last_tick = time.perf_counter()
        self.last_graph_sample_time = time.time()
        self.is_initialized = False
        self._timer_handle = None

    def on_mode_changed(self, new_mode: str):
        self.universe.set_mode(new_mode)

    def on_speed_changed(self, speed: float):
        self.universe.speed_multiplier = speed

    def on_main_window_closed(self) -> bool:
        """Executed when user closes the main workstation window."""
        print("[DRAW.NEXUS] Main window closed. Closing all windows and terminating cleanly...")
        if self._timer_handle:
            self._timer_handle.stop()
        try:
            Draw.close_all()
        except Exception:
            pass
        return True

    def setup_window(self, open_satellite: bool = True):
        """Initializes the Draw window, sets up safety watchdog, and binds events."""
        print("[DRAW.NEXUS] Initializing Window & Subsystems...")
        
        # 1. Activate safeplay watchdog
        Draw.debug.safeplay()
        Draw.debug.settings().fps_limit = 144
        Draw.debug.settings().infinite_loop_detector_enabled = False
        Draw.debug.settings().render_timeout_enabled = False
        
        # 2. Create Main Window
        win = Draw.window(
            tag=self.tag,
            title="DRAW.NEXUS — Unified Multi-System Showcase & Hardware Engine",
            width=self.width,
            height=self.height,
            x=40,
            y=40,
            background_color=THEME["bg_main"],
            on_close=self.on_main_window_closed,
        )

        # 3. Initial Scene Assembly
        self._sync_scene()

        # 4. Activate Draw.super Hardware-Accelerated OpenGL Engine
        print("[DRAW.NEXUS] Activating Draw.super Hardware Acceleration...")
        Draw.super(
            display=self.tag,
            mode="max",
            precompile=True,
            vsync=False,
            batch_capacity=65536,
        )

        # 5. Bind mouse & interaction handlers on the active accelerated canvas
        win = Draw._window.window.get(self.tag)
        if win and hasattr(win, "_draw_canvas"):
            canvas = win._draw_canvas
            canvas.mousePressEvent = self._wrap_mouse_press(canvas.mousePressEvent)
            canvas.mouseMoveEvent = self._wrap_mouse_move(canvas.mouseMoveEvent)
            canvas.mouseReleaseEvent = self._wrap_mouse_release(canvas.mouseReleaseEvent)

        # 6. Bring main window to front
        try:
            win.show()
            win.raise_()
            win.activateWindow()
        except Exception:
            pass

        # 7. Open secondary satellite telemetry window
        if open_satellite:
            self.satellite.open()

        # 8. Schedule fast animation tick (~60-120Hz)
        self._timer_handle = Draw.every(0.016, self._tick)

        self.is_initialized = True
        print("[DRAW.NEXUS] Ready! Multi-Window Engine Online.")

    def _wrap_mouse_press(self, original_fn):
        def handler(event):
            pos = event.position()
            px, py = float(pos.x()), float(pos.y())
            self._handle_click(px, py)
            original_fn(event)
        return handler

    def _wrap_mouse_move(self, original_fn):
        def handler(event):
            pos = event.position()
            px, py = float(pos.x()), float(pos.y())
            self.universe.mouse_x = px
            self.universe.mouse_y = py
            self.universe.mouse_active = (258 <= px <= 1070 and 60 <= py <= 590)
            self.drag_exp.update_drag(px, py)
            original_fn(event)
        return handler

    def _wrap_mouse_release(self, original_fn):
        def handler(event):
            self.drag_exp.end_drag()
            original_fn(event)
        return handler

    def _handle_click(self, px: float, py: float):
        """Processes UI clicks across top action buttons, Motion Lab, timeline, and arena."""
        # 1. Top Header Action Buttons
        if 10 <= py <= 46:
            if 540 <= px <= 650:
                print("[ACTION] RUN DEMO pressed!")
                self.wow.start()
                return
            elif 660 <= px <= 780:
                print("[ACTION] BENCHMARK pressed!")
                self.benchmark.start_full_benchmark()
                return
            elif 790 <= px <= 910:
                print("[ACTION] CHAOS MODE toggled!")
                self.chaos.toggle()
                return
            elif 920 <= px <= 1060:
                print("[ACTION] SATELLITE MONITOR opened!")
                self.satellite.open()
                return
            elif 1030 <= px <= 1115:
                print("[ACTION] RESET / STOP pressed!")
                self.wow.stop()
                if self.chaos.is_active:
                    self.chaos.toggle()
                self.universe.set_count(1500)
                self.universe.set_mode("SPIRAL")
                return
            elif 1125 <= px <= 1210:
                print("[ACTION] EXIT pressed! Terminating application...")
                self.on_main_window_closed()
                return

        # 2. Motion Lab Mode Buttons
        if 20 <= px <= 236 and 110 <= py <= 570:
            btn_start_y = self.motion_lab.panel_y + 48
            btn_h = 32
            gap = 6
            for idx, mode_name in enumerate([
                "SPRING", "ORBIT", "GRAVITY", "PROJECTILE", "LISSAJOUS",
                "SPIRAL", "ATTRACTOR", "MORPH", "WAVE", "ELASTIC"
            ]):
                by = btn_start_y + idx * (btn_h + gap)
                if by <= py <= by + btn_h:
                    self.motion_lab.select_mode(mode_name)
                    return

        # 3. Timeline Buttons
        if 600 <= py <= 645:
            # Play / Pause / Reset
            if 656 <= px <= 708:
                self.timeline.is_playing = True
                return
            elif 714 <= px <= 766:
                self.timeline.is_playing = False
                return
            elif 772 <= px <= 824:
                self.timeline.reset()
                return
            # Speed buttons
            speed_start_x = self.timeline.panel_x + self.timeline.panel_w - 240
            for idx, spd in enumerate([0.25, 0.5, 1.0, 2.0, 4.0]):
                sx = speed_start_x + idx * 45
                if sx <= px <= sx + 40 and 610 <= py <= 632:
                    self.timeline.set_speed(spd)
                    return

        # 4. Drag experiment nodes
        for node in self.drag_exp.nodes:
            if math.hypot(px - node.x, py - node.y) <= node.radius + 6:
                self.drag_exp.start_drag(node.ip)
                return

        # 5. Particle Selection in Center Arena
        if 258 <= px <= 1070 and 60 <= py <= 590:
            closest_p = None
            min_d = 25.0
            for p in self.universe.particles:
                d = math.hypot(px - p.x, py - p.y)
                if d < min_d:
                    min_d = d
                    closest_p = p
            if closest_p:
                self.universe.select_particle(closest_p.ip)
                self.inspector.set_selected_particle(closest_p)

    def _tick(self):
        """Main simulation and telemetry tick."""
        if not self.is_initialized:
            return
        if self.tag not in Draw._window.window._windows:
            if self._timer_handle:
                self._timer_handle.stop()
            return

        now = time.perf_counter()
        dt = now - self.last_tick
        self.last_tick = now
        if dt > 0.1:
            dt = 0.016

        # 1. Update Controllers
        try:
            self.universe.update(dt)
            self.timeline.update(dt)
            self.wow.update(dt)
            self.benchmark.update(dt)
            self.chaos.update(dt)
            self.satellite.update()
            
            # 2. Sample live graph telemetry every 0.3s
            cur_wall_time = time.time()
            if cur_wall_time - self.last_graph_sample_time >= 0.3:
                self.last_graph_sample_time = cur_wall_time
                stats = debug._frame_history.get_stats()
                fps_val = stats.get("avg_fps", 60.0) or 60.0
                frame_ms = stats.get("worst_frame_ms", 16.4) or 16.4
                self.perf_graph.record_sample(fps_val, frame_ms, len(self.universe.particles))

            # 3. Synchronize Selected Particle
            self.inspector.set_selected_particle(self.universe.get_selected_particle())

            # 4. Push updated state to main canvas
            self._sync_scene()
        except Exception as e:
            # Prevent unhandled exceptions from terminating event loop
            pass

    def _sync_scene(self):
        """Assembles all subsystem UI and particle shapes/texts into the Draw canvas."""
        if self.tag not in Draw._window.window._windows:
            return

        all_shapes: List[Dict[str, Any]] = []
        all_texts: List[Dict[str, Any]] = []

        # --- A. Header Bar ---
        all_shapes.append({
            "ip": "header_bar_bg",
            "vertices": 4,
            "size": [self.width - 32, 44],
            "x": 16,
            "y": 8,
            "color": THEME["bg_panel"],
            "border_color": THEME["border_subtle"],
            "border_width": 1,
            "border_radius": 8,
            "z": 95,
        })

        # Header Title Text
        all_texts.append({
            "ip": "txt_header_title",
            "text": "DRAW.NEXUS",
            "x": 30,
            "y": 21,
            "font_size": 13,
            "bold": True,
            "color": THEME["cyan"],
            "z": 90,
        })

        # GPU / Engine Badges
        stats = debug._frame_history.get_stats()
        cur_fps = stats.get("avg_fps", 60.0) or 60.0
        all_texts.append({
            "ip": "txt_header_gpu_badge",
            "text": f"● GPU {cur_fps:.0f} FPS",
            "x": 165,
            "y": 22,
            "font_size": 9,
            "bold": True,
            "color": THEME["emerald"] if cur_fps >= 50 else THEME["amber"],
            "z": 90,
        })
        all_texts.append({
            "ip": "txt_header_engine_badge",
            "text": "● ENGINE ONLINE (Draw.super)",
            "x": 275,
            "y": 22,
            "font_size": 9,
            "bold": True,
            "color": THEME["cyan"],
            "z": 90,
        })

        # Header Action Buttons
        actions = [
            ("btn_act_demo", "RUN DEMO", 540, 105, THEME["emerald"] if self.wow.is_running else THEME["bg_card"], THEME["emerald"]),
            ("btn_act_bench", "BENCHMARK", 655, 115, THEME["amber"] if self.benchmark.is_running else THEME["bg_card"], THEME["amber"]),
            ("btn_act_chaos", "CHAOS MODE", 780, 115, THEME["crimson"] if self.chaos.is_active else THEME["bg_card"], THEME["crimson"]),
            ("btn_act_sat", "SATELLITE", 905, 115, THEME["cyan"] if self.satellite.is_open else THEME["bg_card"], THEME["cyan"]),
            ("btn_act_reset", "RESET", 1030, 85, THEME["bg_card"], THEME["text_muted"]),
            ("btn_act_exit", "✕ EXIT", 1125, 80, THEME["bg_card"], THEME["crimson"]),
        ]
        for ip, label, bx, bw, bg_col, border_col in actions:
            all_shapes.append({
                "ip": ip,
                "vertices": 4,
                "size": [bw, 28],
                "x": bx,
                "y": 16,
                "color": bg_col,
                "border_color": border_col,
                "border_width": 2 if bg_col != THEME["bg_card"] else 1,
                "border_radius": 6,
                "z": 92,
            })
            all_texts.append({
                "ip": f"txt_{ip}",
                "text": label,
                "x": bx + 12,
                "y": 23,
                "font_size": 8,
                "bold": True,
                "color": THEME["text_title"],
                "z": 90,
            })

        # --- B. Center Arena Frame ---
        ax, ay, aw, ah = (258.0, 60.0, 812.0, 530.0)
        all_shapes.append({
            "ip": "center_arena_frame",
            "vertices": 4,
            "size": [aw, ah],
            "x": ax,
            "y": ay,
            "color": THEME["bg_panel"],
            "border_color": THEME["border_subtle"],
            "border_width": 1,
            "border_radius": 8,
            "z": 95,
        })
        all_texts.append({
            "ip": "txt_arena_watermark",
            "text": f"PARTICLE UNIVERSE  •  {len(self.universe.particles):,} NODES  •  MODE: {self.universe.mode}",
            "x": ax + 16,
            "y": ay + 16,
            "font_size": 9,
            "bold": True,
            "color": THEME["text_muted"],
            "z": 90,
        })

        # --- C. Particles Swarm ---
        all_shapes.extend(self.universe.get_shape_defs())

        # --- D. Drag Physics Experiment Struts & Nodes ---
        all_shapes.extend(self.drag_exp.get_ui_shapes())
        all_texts.extend(self.drag_exp.get_ui_texts())

        # --- E. Motion Lab Panel ---
        all_shapes.extend(self.motion_lab.get_ui_shapes())
        all_texts.extend(self.motion_lab.get_ui_texts())

        # --- F. Object Inspector & Diagnostics HUD ---
        all_shapes.extend(self.inspector.get_ui_shapes())
        all_texts.extend(self.inspector.get_ui_texts(total_objects=len(self.universe.particles), active_mode=self.universe.mode))

        # --- G. Live Performance Graph ---
        all_shapes.extend(self.perf_graph.get_ui_shapes())
        all_texts.extend(self.perf_graph.get_ui_texts())

        # --- H. Motion Timeline ---
        all_shapes.extend(self.timeline.get_ui_shapes())
        all_texts.extend(self.timeline.get_ui_texts())

        # --- I. WOW Sequence & Chaos Overlays ---
        all_shapes.extend(self.wow.get_ui_shapes())
        all_texts.extend(self.wow.get_ui_texts())
        all_shapes.extend(self.chaos.get_ui_shapes())
        all_texts.extend(self.chaos.get_ui_texts())

        # Push to main canvas
        Draw.shape(display=self.tag, shape=all_shapes)
        Draw.text(display=self.tag, text=all_texts)


def run_draw_nexus():
    """Entry point function to initialize and run DRAW.NEXUS."""
    app = DrawNexusApp(tag="nexus_main")
    app.setup_window(open_satellite=True)
    # Show all registered windows and run Qt event loop
    Draw.window.show("nexus_main")
    Draw.window.show("nexus_satellite")
    Draw.window.run()


if __name__ == "__main__":
    run_draw_nexus()
