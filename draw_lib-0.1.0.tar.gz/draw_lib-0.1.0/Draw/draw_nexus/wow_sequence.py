"""
DRAW.NEXUS "WOW" Choreographed Showcase Sequence Director
=========================================================
Directs the 10-second automated cinematic demonstration showcasing the full convergence
of GPU OpenGL rendering, typography formation, kinetic explosions, spiral galaxies, and HUD online status.
"""

from __future__ import annotations

import math
from typing import Any, Dict, List, Optional
from draw_nexus.config import THEME
from draw_nexus.particles import ParticleUniverse


class WowDirector:
    """State machine and animation director for the 10-second WOW demo."""

    def __init__(self, universe: ParticleUniverse):
        self.universe = universe
        self.is_running = False
        self.elapsed = 0.0
        self.duration = 10.0
        self.stage = 0
        self.status_banner = "DEMO READY"

    def start(self):
        """Starts the 10-second WOW sequence."""
        self.is_running = True
        self.elapsed = 0.0
        self.stage = 0
        self.status_banner = "INITIALIZING CINEMATIC SEQUENCE..."
        self.universe.prepare_draw_letters()

    def stop(self):
        self.is_running = False
        self.status_banner = "DEMO COMPLETE — ALL SYSTEMS ONLINE"

    def update(self, dt: float):
        if not self.is_running:
            return

        self.elapsed += dt
        t = self.elapsed

        # Phase 1: 0–1s -> Logo appears & particles gather
        if t < 1.0:
            self.stage = 1
            self.status_banner = "STAGE 1: LOGO APPEARS (SCALE + OPACITY PULSE)"
            self.universe.mode = "ATTRACTOR"
            self.universe.mouse_active = False

        # Phase 2: 1–2s -> Thousands of particles fly in
        elif t < 2.0:
            self.stage = 2
            self.status_banner = "STAGE 2: THOUSANDS OF PARTICLES CONVERGE"
            self.universe.mode = "SPIRAL"

        # Phase 3: 2–3s -> Particles form 'D R A W'
        elif t < 3.2:
            self.stage = 3
            self.status_banner = "STAGE 3: PARTICLES FORM 'D R A W' TYPOGRAPHY"
            self.universe.mode = "FORM_LETTERS"

        # Phase 4: 3.2–4.5s -> Explosion shockwave
        elif t < 4.5:
            if self.stage != 4:
                self.stage = 4
                self.universe.trigger_explosion()
            self.status_banner = "STAGE 4: KINETIC SHOCKWAVE EXPLOSION"
            self.universe.mode = "GRAVITY"

        # Phase 5: 4.5–6.0s -> Swirling galaxy sphere
        elif t < 6.0:
            self.stage = 5
            self.status_banner = "STAGE 5: ROTATING GALAXY COALESCENCE"
            self.universe.mode = "SPIRAL"

        # Phase 6: 6.0–7.5s -> Graph and Inspector online
        elif t < 7.5:
            self.stage = 6
            self.status_banner = "STAGE 6: TELEMETRY GRAPHS & INSPECTOR ONLINE"
            self.universe.mode = "LISSAJOUS"

        # Phase 7: 7.5–9.0s -> Motion Morphing & Wave
        elif t < 9.0:
            self.stage = 7
            self.status_banner = "STAGE 7: GEOMETRY MORPHING & WAVE DYNAMICS"
            self.universe.mode = "MORPH"

        # Phase 8: 9.0–10.0s -> Final Convergence
        elif t < 10.0:
            self.stage = 8
            self.status_banner = "STAGE 8: FULL MULTI-SYSTEM HARMONY"
            self.universe.mode = "ATTRACTOR"

        else:
            self.stop()

    def get_ui_shapes(self) -> List[Dict[str, Any]]:
        """Generates overlay shapes and cinematic banners during demo."""
        if not self.is_running:
            return []

        shapes = []
        t = self.elapsed

        # Dramatic Centerpiece Title Banner during 0-1s
        if t < 1.5:
            scale_pulse = 1.0 + 0.15 * math.sin(t * math.pi)
            bw = 360 * scale_pulse
            bh = 90 * scale_pulse
            shapes.append({
                "ip": "wow_center_logo_box",
                "vertices": 4,
                "size": [bw, bh],
                "x": self.universe.center_x - bw / 2.0,
                "y": self.universe.center_y - bh / 2.0,
                "color": THEME["bg_card"],
                "border_color": THEME["cyan"],
                "border_width": 3,
                "border_radius": 12,
                "opacity": int(min(100, t * 100)),
                "z": 10,
            })

        # Top progress bar
        bar_w = (t / self.duration) * (self.universe.arena_w - 40)
        shapes.append({
            "ip": "wow_progress_bar",
            "vertices": 4,
            "size": [bar_w, 4],
            "x": self.universe.arena_x + 20,
            "y": self.universe.arena_y + 8,
            "color": THEME["cyan"],
            "z": 12,
        })

        return shapes

    def get_ui_texts(self) -> List[Dict[str, Any]]:
        """Generates texts for cinematic subtitles and title cards."""
        if not self.is_running:
            return []

        texts = []
        t = self.elapsed

        # Center logo text
        if t < 1.5:
            texts.append({
                "ip": "txt_wow_logo",
                "text": "D R A W",
                "x": self.universe.center_x - 110,
                "y": self.universe.center_y - 18,
                "font_size": 32,
                "bold": True,
                "color": THEME["cyan"],
                "z": 8,
            })

        # Subtitle callout at bottom of arena
        texts.append({
            "ip": "txt_wow_subtitle",
            "text": f"🔥 {self.status_banner}",
            "x": self.universe.arena_x + 30,
            "y": self.universe.arena_y + self.universe.arena_h - 32,
            "font_size": 11,
            "bold": True,
            "color": THEME["emerald"],
            "z": 8,
        })

        return texts
