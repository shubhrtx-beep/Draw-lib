"""
DRAW.NEXUS Satellite Telemetry & Secondary Monitor Window
=========================================================
Dedicated multi-window secondary telemetry monitor providing real-time diagnostics
across all 21 Draw subsystems, memory profiler, frame latency, and remote controls.
"""

from __future__ import annotations

import gc
import os
import sys
import threading
import time
from typing import Any, Dict, List, Optional

try:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

_NEXUS_DIR = os.path.dirname(os.path.abspath(__file__))
_DRAW_DIR = os.path.dirname(_NEXUS_DIR)
_ROOT_DIR = os.path.dirname(_DRAW_DIR)

for p in [_ROOT_DIR, _DRAW_DIR, _NEXUS_DIR]:
    if p not in sys.path:
        sys.path.insert(0, p)

import Draw
from Draw.debug import debug
from draw_nexus.config import THEME


class SatelliteMonitorWindow:
    """Manages the secondary satellite telemetry window and remote controls."""

    def __init__(self, tag: str = "nexus_satellite", app_controller=None):
        self.tag = tag
        self.app = app_controller
        self.width = 540
        self.height = 760
        self.is_open = False

    def on_satellite_closed(self) -> bool:
        """Executed when user closes the satellite telemetry window."""
        print("[DRAW.NEXUS] Satellite window closed.")
        self.is_open = False
        return True

    def open(self):
        """Creates and reveals the secondary telemetry window."""
        if self.is_open and self.tag in Draw._window.window._windows:
            try:
                win = Draw._window.window.get(self.tag)
                win.show()
                win.raise_()
                win.activateWindow()
                return
            except Exception:
                pass

        print("[DRAW.NEXUS] Opening Secondary Satellite Telemetry Window...")
        win = Draw.window(
            tag=self.tag,
            title="DRAW.NEXUS — Satellite Telemetry & 21-Subsystems Monitor",
            width=self.width,
            height=self.height,
            x=1420,
            y=40,
            background_color=THEME["bg_main"],
            on_close=self.on_satellite_closed,
        )

        Draw.super(
            display=self.tag,
            mode="max",
            precompile=True,
            vsync=False,
            batch_capacity=16384,
        )

        win = Draw._window.window.get(self.tag)
        if win and hasattr(win, "_draw_canvas"):
            canvas = win._draw_canvas
            canvas.mousePressEvent = self._wrap_click(canvas.mousePressEvent)

        try:
            win.show()
            win.raise_()
            win.activateWindow()
        except Exception:
            pass

        self.is_open = True
        self.sync_ui()

    def _wrap_click(self, original_fn):
        def handler(event):
            pos = event.position()
            px, py = float(pos.x()), float(pos.y())
            self._handle_click(px, py)
            original_fn(event)
        return handler

    def _handle_click(self, px: float, py: float):
        """Processes remote control clicks in the satellite window."""
        if not self.app:
            return

        # Remote Action Buttons at Top of Satellite Window
        if 54 <= py <= 84:
            if 16 <= px <= 136:
                print("[SATELLITE REMOTE] Triggering RUN DEMO...")
                self.app.wow.start()
            elif 146 <= px <= 276:
                print("[SATELLITE REMOTE] Triggering BENCHMARK...")
                self.app.benchmark.start_full_benchmark()
            elif 286 <= px <= 406:
                print("[SATELLITE REMOTE] Toggling CHAOS MODE...")
                self.app.chaos.toggle()
            elif 416 <= px <= 520:
                print("[SATELLITE REMOTE] Triggering RESET...")
                self.app.wow.stop()
                if self.app.chaos.is_active:
                    self.app.chaos.toggle()
                self.app.universe.set_count(1500)
                self.app.universe.set_mode("SPIRAL")

        # Mode preset shortcuts
        if 684 <= py <= 714:
            modes = ["SPRING", "ORBIT", "GRAVITY", "SPIRAL", "ATTRACTOR", "MORPH"]
            btn_w = 78
            for idx, m in enumerate(modes):
                bx = 16 + idx * 84
                if bx <= px <= bx + btn_w:
                    self.app.motion_lab.select_mode(m)
                    break

    def update(self):
        """Called every frame tick to update satellite telemetry."""
        if not self.is_open or self.tag not in Draw._window.window._windows:
            return
        self.sync_ui()

    def sync_ui(self):
        """Builds and pushes the satellite telemetry UI shapes and texts."""
        if not self.is_open or self.tag not in Draw._window.window._windows:
            return

        shapes: List[Dict[str, Any]] = []
        texts: List[Dict[str, Any]] = []

        # 1. Header Card
        shapes.append({
            "ip": "sat_header_card",
            "vertices": 4,
            "size": [self.width - 32, 38],
            "x": 16,
            "y": 10,
            "color": THEME["bg_panel"],
            "border_color": THEME["border_subtle"],
            "border_width": 1,
            "border_radius": 6,
            "z": 95,
        })
        texts.append({
            "ip": "txt_sat_header_title",
            "text": "DRAW.NEXUS SATELLITE MONITOR",
            "x": 28,
            "y": 23,
            "font_size": 10,
            "bold": True,
            "color": THEME["cyan"],
            "z": 90,
        })
        texts.append({
            "ip": "txt_sat_header_status",
            "text": "● LINK ACTIVE",
            "x": self.width - 130,
            "y": 24,
            "font_size": 8,
            "bold": True,
            "color": THEME["emerald"],
            "z": 90,
        })

        # 2. Remote Command Bar
        actions = [
            ("DEMO", 16, 120, THEME["emerald"]),
            ("BENCHMARK", 146, 130, THEME["amber"]),
            ("CHAOS", 286, 120, THEME["crimson"]),
            ("RESET", 416, 104, THEME["bg_card"]),
        ]
        for label, bx, bw, col in actions:
            shapes.append({
                "ip": f"sat_btn_{label.lower()}",
                "vertices": 4,
                "size": [bw, 30],
                "x": bx,
                "y": 54,
                "color": THEME["bg_card"],
                "border_color": col,
                "border_width": 1,
                "border_radius": 4,
                "z": 92,
            })
            texts.append({
                "ip": f"txt_sat_btn_{label.lower()}",
                "text": f"▶ {label}",
                "x": bx + 14,
                "y": 63,
                "font_size": 8,
                "bold": True,
                "color": THEME["text_title"],
                "z": 90,
            })

        # 3. 21-Subsystems Live Grid Card
        shapes.append({
            "ip": "sat_subsys_card",
            "vertices": 4,
            "size": [self.width - 32, 380],
            "x": 16,
            "y": 92,
            "color": THEME["bg_panel"],
            "border_color": THEME["border_subtle"],
            "border_width": 1,
            "border_radius": 6,
            "z": 95,
        })
        texts.append({
            "ip": "txt_sat_subsys_title",
            "text": "21 ENGINE SUBSYSTEMS LIVE MATRIX",
            "x": 28,
            "y": 104,
            "font_size": 9,
            "bold": True,
            "color": THEME["text_highlight"],
            "z": 90,
        })

        # Query real subsystems from Draw.debug
        subsystems = debug._query_subsystems_status()
        subsys_items = list(subsystems.items())

        col1 = subsys_items[:11]
        col2 = subsys_items[11:]

        # Column 1
        for idx, (name, status) in enumerate(col1):
            sy = 126 + idx * 22
            shapes.append({
                "ip": f"sat_pip_c1_{idx}",
                "vertices": 24,
                "size": [6, 6],
                "x": 28,
                "y": sy + 2,
                "color": THEME["emerald"] if "Active" in status or "OK" in status or "Running" in status else THEME["amber"],
                "z": 92,
            })
            texts.append({
                "ip": f"txt_sat_s1_name_{idx}",
                "text": f"{name:<14}",
                "x": 40,
                "y": sy,
                "font_size": 8,
                "bold": True,
                "color": THEME["text_secondary"],
                "z": 90,
            })
            texts.append({
                "ip": f"txt_sat_s1_stat_{idx}",
                "text": status[:16],
                "x": 136,
                "y": sy,
                "font_size": 7,
                "color": THEME["text_muted"],
                "z": 90,
            })

        # Column 2
        for idx, (name, status) in enumerate(col2):
            sy = 126 + idx * 22
            shapes.append({
                "ip": f"sat_pip_c2_{idx}",
                "vertices": 24,
                "size": [6, 6],
                "x": 270,
                "y": sy + 2,
                "color": THEME["emerald"] if "Active" in status or "OK" in status or "Running" in status else THEME["amber"],
                "z": 92,
            })
            texts.append({
                "ip": f"txt_sat_s2_name_{idx}",
                "text": f"{name:<14}",
                "x": 282,
                "y": sy,
                "font_size": 8,
                "bold": True,
                "color": THEME["text_secondary"],
                "z": 90,
            })
            texts.append({
                "ip": f"txt_sat_s2_stat_{idx}",
                "text": status[:16],
                "x": 378,
                "y": sy,
                "font_size": 7,
                "color": THEME["text_muted"],
                "z": 90,
            })

        # 4. Memory & Garbage Collector Card
        shapes.append({
            "ip": "sat_mem_card",
            "vertices": 4,
            "size": [self.width - 32, 190],
            "x": 16,
            "y": 482,
            "color": THEME["bg_panel"],
            "border_color": THEME["border_subtle"],
            "border_width": 1,
            "border_radius": 6,
            "z": 95,
        })
        texts.append({
            "ip": "txt_sat_mem_title",
            "text": "HEAP & PERFORMANCE PROFILER",
            "x": 28,
            "y": 494,
            "font_size": 9,
            "bold": True,
            "color": THEME["emerald"],
            "z": 90,
        })

        gc_counts = gc.get_count()
        thread_cnt = threading.active_count()
        py_objects = len(gc.get_objects())
        mem_mb = debug._get_memory_mb()

        mem_rows = [
            ("Heap Memory Used", f"{mem_mb:.1f} MB"),
            ("Tracked Python Objects", f"{py_objects:,}"),
            ("Garbage Collector", f"G0: {gc_counts[0]} | G1: {gc_counts[1]} | G2: {gc_counts[2]}"),
            ("Background Threads", f"{thread_cnt} Threads"),
            ("Watchdog Status", "HEALTHY (0 Leaks)"),
        ]
        for idx, (k, v) in enumerate(mem_rows):
            sy = 516 + idx * 24
            texts.append({
                "ip": f"txt_sat_m_lbl_{idx}",
                "text": f"{k:<22}",
                "x": 28,
                "y": sy,
                "font_size": 8,
                "bold": True,
                "color": THEME["text_muted"],
                "z": 90,
            })
            texts.append({
                "ip": f"txt_sat_m_val_{idx}",
                "text": v,
                "x": 190,
                "y": sy,
                "font_size": 8,
                "bold": (idx == 0),
                "color": THEME["cyan"] if idx == 0 else THEME["text_primary"],
                "z": 90,
            })

        # 5. Quick Mode Switching Bar
        modes = ["SPRING", "ORBIT", "GRAVITY", "SPIRAL", "ATTRACTOR", "MORPH"]
        for idx, m in enumerate(modes):
            bx = 16 + idx * 84
            shapes.append({
                "ip": f"sat_mode_btn_{m.lower()}",
                "vertices": 4,
                "size": [78, 26],
                "x": bx,
                "y": 684,
                "color": THEME["bg_surface"],
                "border_color": THEME["border_subtle"],
                "border_width": 1,
                "border_radius": 4,
                "z": 92,
            })
            texts.append({
                "ip": f"txt_sat_m_btn_{m.lower()}",
                "text": m,
                "x": bx + 10,
                "y": 692,
                "font_size": 7,
                "bold": True,
                "color": THEME["text_secondary"],
                "z": 90,
            })

        # Push to secondary window
        Draw.shape(display=self.tag, shape=shapes)
        Draw.text(display=self.tag, text=texts)
