"""
DRAW.NEXUS Motion Timeline & Track Orchestrator
==============================================
Bottom-right multi-track timeline visualization and playback controller,
supporting playhead scrubbing, track keyframes, and speed multipliers (0.25x - 4x).
"""

from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional, Tuple
from draw_nexus.config import THEME

TRACKS = [
    {"name": "TITLE", "start": 0.0, "end": 1.5, "color": THEME["cyan"]},
    {"name": "PARTICLES", "start": 0.5, "end": 5.8, "color": THEME["emerald"]},
    {"name": "GRAPH", "start": 1.2, "end": 4.5, "color": THEME["blue"]},
    {"name": "EXPLOSION", "start": 3.0, "end": 4.0, "color": THEME["crimson"]},
    {"name": "CAMERA", "start": 0.0, "end": 6.0, "color": THEME["purple"]},
]


class MotionTimeline:
    """Manages timeline playback, playhead interpolation, and speed controls."""

    def __init__(self, bounds: Tuple[float, float, float, float] = (598, 674, 826, 215), on_speed_changed: Optional[Callable[[float], None]] = None):
        self.panel_x, self.panel_y, self.panel_w, self.panel_h = bounds
        self.duration = 6.0
        self.playhead_time = 0.0
        self.is_playing = True
        self.speed = 1.0
        self.on_speed_changed = on_speed_changed

    def set_speed(self, speed: float):
        self.speed = speed
        if self.on_speed_changed:
            self.on_speed_changed(speed)

    def toggle_play_pause(self):
        self.is_playing = not self.is_playing

    def reset(self):
        self.playhead_time = 0.0

    def update(self, dt: float):
        if self.is_playing:
            self.playhead_time = (self.playhead_time + dt * self.speed) % self.duration

    def get_ui_shapes(self) -> List[Dict[str, Any]]:
        """Generates shapes for timeline panel, tracks, and active playhead."""
        shapes = []

        # 1. Timeline Container Panel
        shapes.append({
            "ip": "timeline_panel_container",
            "vertices": 4,
            "size": [self.panel_w, self.panel_h],
            "x": self.panel_x,
            "y": self.panel_y,
            "color": THEME["bg_panel"],
            "border_color": THEME["border_subtle"],
            "border_width": 1,
            "border_radius": 8,
            "z": 90,
        })

        # 2. Controls Header Bar
        shapes.append({
            "ip": "timeline_header_bar",
            "vertices": 4,
            "size": [self.panel_w - 24, 30],
            "x": self.panel_x + 12,
            "y": self.panel_y + 10,
            "color": THEME["bg_card"],
            "border_color": THEME["border_medium"],
            "border_width": 1,
            "border_radius": 6,
            "z": 88,
        })

        # 3. Play / Pause / Reset Buttons
        btn_specs = [
            ("btn_tl_play", "PLAY", 88, THEME["emerald"] if self.is_playing else THEME["bg_surface"]),
            ("btn_tl_pause", "PAUSE", 146, THEME["amber"] if not self.is_playing else THEME["bg_surface"]),
            ("btn_tl_reset", "RESET", 204, THEME["bg_surface"]),
        ]
        for ip, label, ox, col in btn_specs:
            shapes.append({
                "ip": ip,
                "vertices": 4,
                "size": [52, 22],
                "x": self.panel_x + ox,
                "y": self.panel_y + 14,
                "color": col,
                "border_color": THEME["border_subtle"],
                "border_width": 1,
                "border_radius": 4,
                "z": 85,
            })

        # 4. Speed Multiplier Buttons (0.25x, 0.5x, 1x, 2x, 4x)
        speeds = [0.25, 0.5, 1.0, 2.0, 4.0]
        speed_start_x = self.panel_x + self.panel_w - 240
        for idx, spd in enumerate(speeds):
            is_active = abs(self.speed - spd) < 0.01
            shapes.append({
                "ip": f"btn_speed_{spd}",
                "vertices": 4,
                "size": [40, 22],
                "x": speed_start_x + idx * 45,
                "y": self.panel_y + 14,
                "color": THEME["cyan"] if is_active else THEME["bg_surface"],
                "border_color": THEME["border_subtle"],
                "border_width": 1,
                "border_radius": 4,
                "z": 85,
            })

        # 5. Timeline Track Area Frame
        track_area_x = self.panel_x + 95
        track_area_y = self.panel_y + 48
        track_area_w = self.panel_w - 110
        track_area_h = self.panel_h - 60

        shapes.append({
            "ip": "timeline_track_area",
            "vertices": 4,
            "size": [track_area_w, track_area_h],
            "x": track_area_x,
            "y": track_area_y,
            "color": THEME["bg_main"],
            "border_color": THEME["border_subtle"],
            "border_width": 1,
            "border_radius": 4,
            "z": 88,
        })

        # 6. Time Ruler Markers (0s, 1s, 2s, 3s, 4s, 5s, 6s)
        for sec in range(int(self.duration) + 1):
            rx = track_area_x + (sec / self.duration) * track_area_w
            shapes.append({
                "ip": f"timeline_ruler_mark_{sec}",
                "vertices": 4,
                "size": [1, track_area_h],
                "x": rx,
                "y": track_area_y,
                "color": THEME["border_subtle"],
                "opacity": 40,
                "z": 86,
            })

        # 7. Render 5 Track Spans
        track_h = 18
        track_gap = 6
        for idx, trk in enumerate(TRACKS):
            ty = track_area_y + 24 + idx * (track_h + track_gap)
            span_x0 = track_area_x + (trk["start"] / self.duration) * track_area_w
            span_x1 = track_area_x + (trk["end"] / self.duration) * track_area_w
            span_w = max(10.0, span_x1 - span_x0)

            # Track block span
            shapes.append({
                "ip": f"timeline_track_block_{idx}",
                "vertices": 4,
                "size": [span_w, track_h],
                "x": span_x0,
                "y": ty,
                "color": trk["color"],
                "border_color": THEME["text_title"],
                "border_width": 1,
                "border_radius": 4,
                "opacity": 75,
                "z": 82,
            })

        # 8. Active Scrubbing Playhead Indicator Line
        playhead_x = track_area_x + (self.playhead_time / self.duration) * track_area_w
        shapes.append({
            "ip": "timeline_playhead_line",
            "vertices": 4,
            "size": [2, track_area_h + 8],
            "x": playhead_x - 1,
            "y": track_area_y - 4,
            "color": THEME["crimson"],
            "z": 70,
        })
        shapes.append({
            "ip": "timeline_playhead_head",
            "vertices": 3,
            "size": [10, 10],
            "x": playhead_x - 5,
            "y": track_area_y - 8,
            "rotation": 180,
            "color": THEME["crimson"],
            "z": 69,
        })

        return shapes

    def get_ui_texts(self) -> List[Dict[str, Any]]:
        """Generates timeline labels, track names, ruler markers, and button texts."""
        texts = []

        # Title
        texts.append({
            "ip": "txt_timeline_title",
            "text": "⏱ TIMELINE",
            "x": self.panel_x + 18,
            "y": self.panel_y + 18,
            "font_size": 10,
            "bold": True,
            "color": THEME["cyan"],
            "z": 80,
        })

        # Play/Pause/Reset button texts
        texts.append({"ip": "txt_btn_play", "text": "▶ PLAY", "x": self.panel_x + 94, "y": self.panel_y + 19, "font_size": 8, "bold": True, "color": THEME["text_title"], "z": 80})
        texts.append({"ip": "txt_btn_pause", "text": "⏸ PAUSE", "x": self.panel_x + 150, "y": self.panel_y + 19, "font_size": 8, "bold": True, "color": THEME["text_title"], "z": 80})
        texts.append({"ip": "txt_btn_reset", "text": "↻ RESET", "x": self.panel_x + 208, "y": self.panel_y + 19, "font_size": 8, "bold": True, "color": THEME["text_title"], "z": 80})

        # Speed button texts
        speeds = [0.25, 0.5, 1.0, 2.0, 4.0]
        speed_start_x = self.panel_x + self.panel_w - 240
        for idx, spd in enumerate(speeds):
            is_active = abs(self.speed - spd) < 0.01
            texts.append({
                "ip": f"txt_btn_spd_{spd}",
                "text": f"{spd:g}x",
                "x": speed_start_x + idx * 45 + 8,
                "y": self.panel_y + 19,
                "font_size": 8,
                "bold": True,
                "color": THEME["bg_main"] if is_active else THEME["text_muted"],
                "z": 80,
            })

        # Time Ruler Markers
        track_area_x = self.panel_x + 95
        track_area_y = self.panel_y + 48
        track_area_w = self.panel_w - 110

        for sec in range(int(self.duration) + 1):
            rx = track_area_x + (sec / self.duration) * track_area_w
            texts.append({
                "ip": f"txt_ruler_{sec}",
                "text": f"{sec}s",
                "x": rx - 6,
                "y": track_area_y + 5,
                "font_size": 8,
                "color": THEME["text_muted"],
                "z": 80,
            })

        # Track Row Titles
        track_h = 18
        track_gap = 6
        for idx, trk in enumerate(TRACKS):
            ty = track_area_y + 24 + idx * (track_h + track_gap)
            texts.append({
                "ip": f"txt_track_name_{idx}",
                "text": trk["name"],
                "x": self.panel_x + 18,
                "y": ty + 3,
                "font_size": 8,
                "bold": True,
                "color": THEME["text_secondary"],
                "z": 80,
            })

        return texts
