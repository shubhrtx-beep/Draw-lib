"""
DRAW.NEXUS - Flagship Multi-System Interactive Showcase
======================================================
"""

import os
import sys

_NEXUS_DIR = os.path.dirname(os.path.abspath(__file__))
_DRAW_DIR = os.path.dirname(_NEXUS_DIR)
_ROOT_DIR = os.path.dirname(_DRAW_DIR)

for p in [_ROOT_DIR, _DRAW_DIR, _NEXUS_DIR]:
    if p not in sys.path:
        sys.path.insert(0, p)

from draw_nexus.app import DrawNexusApp, run_draw_nexus
from draw_nexus.particles import ParticleUniverse, Particle
from draw_nexus.motion_lab import MotionLab
from draw_nexus.inspector import InspectorHUD
from draw_nexus.graph_hud import PerformanceGraph
from draw_nexus.drag_experiment import DragExperiment
from draw_nexus.timeline import MotionTimeline
from draw_nexus.wow_sequence import WowDirector
from draw_nexus.benchmark import BenchmarkSuite
from draw_nexus.chaos import ChaosController
from draw_nexus.satellite_window import SatelliteMonitorWindow

__all__ = [
    "DrawNexusApp",
    "run_draw_nexus",
    "ParticleUniverse",
    "Particle",
    "MotionLab",
    "InspectorHUD",
    "PerformanceGraph",
    "DragExperiment",
    "MotionTimeline",
    "WowDirector",
    "BenchmarkSuite",
    "ChaosController",
    "SatelliteMonitorWindow",
]
