"""
DRAW.NEXUS Drag & Drop Joint Physics Sandbox
=============================================
Demonstrates 3 giant interactive nodes linked with dynamic joint physics,
free/axis-constrained mouse dragging, boundary snapping, rotation, and elastic linkages.
"""

from __future__ import annotations

import math
from typing import Any, Dict, List, Optional, Tuple
from draw_nexus.config import THEME


class JointNode:
    """Represents a major interactive draggable joint node."""
    __slots__ = ("ip", "x", "y", "radius", "color", "label", "is_dragged", "constraint", "rotation", "scale")

    def __init__(self, ip: str, x: float, y: float, color: str, label: str, radius: float = 24.0):
        self.ip = ip
        self.x = float(x)
        self.y = float(y)
        self.radius = float(radius)
        self.color = color
        self.label = label
        self.is_dragged = False
        self.constraint = "free"  # "free" | "horizontal" | "vertical" | "locked"
        self.rotation = 0.0
        self.scale = 1.0


class DragExperiment:
    """Manages the 3-node connected physics triangle and drag constraints."""

    def __init__(self, arena_bounds: Tuple[float, float, float, float] = (270, 70, 850, 590)):
        self.arena_x, self.arena_y, self.arena_w, self.arena_h = arena_bounds
        cx = self.arena_x + self.arena_w / 2.0
        cy = self.arena_y + self.arena_h * 0.45
        
        # 3 Giant Nodes forming a triangle
        self.nodes = [
            JointNode("joint_node_alpha", cx, cy - 110, THEME["cyan"], "ALPHA", radius=28.0),
            JointNode("joint_node_beta", cx - 130, cy + 90, THEME["emerald"], "BETA", radius=28.0),
            JointNode("joint_node_gamma", cx + 130, cy + 90, THEME["magenta"], "GAMMA", radius=28.0),
        ]
        self.snap_enabled = True
        self.active_dragged_node: Optional[JointNode] = None

    def update_drag(self, mouse_x: float, mouse_y: float):
        """Updates position of currently dragged node with constraint enforcement."""
        if not self.active_dragged_node:
            return
            
        node = self.active_dragged_node
        
        if node.constraint == "horizontal":
            target_x = mouse_x
            target_y = node.y
        elif node.constraint == "vertical":
            target_x = node.x
            target_y = mouse_y
        elif node.constraint == "locked":
            return
        else: # "free"
            target_x = mouse_x
            target_y = mouse_y
            
        # Arena boundary clamping
        target_x = max(self.arena_x + node.radius + 10, min(self.arena_x + self.arena_w - node.radius - 10, target_x))
        target_y = max(self.arena_y + node.radius + 10, min(self.arena_y + self.arena_h - node.radius - 10, target_y))
        
        # Optional magnetic snapping to partner nodes
        if self.snap_enabled:
            for other in self.nodes:
                if other is node:
                    continue
                dist = math.hypot(target_x - other.x, target_y - other.y)
                if dist < 60.0:
                    # Snap to equidistant offset
                    target_x = other.x + (target_x - other.x) * 0.5
                    target_y = other.y + (target_y - other.y) * 0.5

        node.x = target_x
        node.y = target_y

    def start_drag(self, node_ip: str):
        for node in self.nodes:
            if node.ip == node_ip:
                node.is_dragged = True
                self.active_dragged_node = node
                break

    def end_drag(self):
        for node in self.nodes:
            node.is_dragged = False
        self.active_dragged_node = None

    def get_ui_shapes(self) -> List[Dict[str, Any]]:
        """Generates shapes for nodes, connecting struts, and joint badges."""
        shapes = []
        
        # 1. Connecting Link Struts between the 3 nodes (Alpha-Beta, Beta-Gamma, Gamma-Alpha)
        edges = [(0, 1), (1, 2), (2, 0)]
        for idx, (i1, i2) in enumerate(edges):
            n1 = self.nodes[i1]
            n2 = self.nodes[i2]
            
            mid_x = (n1.x + n2.x) / 2.0
            mid_y = (n1.y + n2.y) / 2.0
            dist = math.hypot(n2.x - n1.x, n2.y - n1.y)
            angle = math.degrees(math.atan2(n2.y - n1.y, n2.x - n1.x))
            
            # Thick joint strut
            shapes.append({
                "ip": f"joint_strut_{idx}",
                "vertices": 4,
                "size": [dist, 6],
                "x": min(n1.x, n2.x),
                "y": min(n1.y, n2.y),
                "color": THEME["border_glow"],
                "opacity": 70,
                "z": 24,
            })

        # 2. Render the 3 primary nodes
        for node in self.nodes:
            r = node.radius * node.scale
            # Outer glow halo
            shapes.append({
                "ip": f"{node.ip}_halo",
                "vertices": 24,
                "size": [r * 2.8, r * 2.8],
                "x": node.x - r * 1.4,
                "y": node.y - r * 1.4,
                "color": node.color,
                "opacity": 25 if node.is_dragged else 12,
                "z": 22,
            })
            # Main Node Body
            shapes.append({
                "ip": node.ip,
                "vertices": 24,
                "size": [r * 2.0, r * 2.0],
                "x": node.x - r,
                "y": node.y - r,
                "color": node.color,
                "border_color": THEME["text_title"],
                "border_width": 3 if node.is_dragged else 2,
                "z": 25,
            })
            # Inner Center Pip
            shapes.append({
                "ip": f"{node.ip}_pip",
                "vertices": 24,
                "size": [10, 10],
                "x": node.x - 5,
                "y": node.y - 5,
                "color": THEME["bg_main"],
                "z": 26,
            })

        return shapes

    def get_ui_texts(self) -> List[Dict[str, Any]]:
        """Generates node labels and distance telemetry."""
        texts = []
        for node in self.nodes:
            texts.append({
                "ip": f"txt_{node.ip}_label",
                "text": node.label,
                "x": node.x - 22,
                "y": node.y - node.radius - 18,
                "font_size": 9,
                "bold": True,
                "color": node.color,
                "z": 28,
            })
        return texts
