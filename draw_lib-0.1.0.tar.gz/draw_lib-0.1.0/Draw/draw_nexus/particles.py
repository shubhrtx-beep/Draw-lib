"""
DRAW.NEXUS Particle Universe Engine
===================================
Simulates and orchestrates 1,000–50,000 dynamic geometric particles across 10 motion modes,
procedural physics, dynamic mouse attraction, morphing geometry, and choreographed formations.
"""

from __future__ import annotations

import math
import random
import time
from typing import Any, Dict, List, Optional, Tuple

from draw_nexus.config import PARTICLE_COLORS, THEME


class Particle:
    """Represents a single geometric particle in the universe."""
    __slots__ = (
        "index", "ip", "x", "y", "base_x", "base_y", "vx", "vy",
        "size", "scale", "target_scale", "rotation", "rot_speed",
        "opacity", "vertices", "color", "z", "group", "phase",
        "freq", "orbit_radius", "orbit_angle", "orbit_speed",
        "is_selected", "target_x", "target_y", "drag_locked"
    )

    def __init__(self, index: int, x: float, y: float, color: str, vertices: int = 4, size: float = 8.0):
        self.index = index
        self.ip = f"particle_{index}"
        self.x = float(x)
        self.y = float(y)
        self.base_x = float(x)
        self.base_y = float(y)
        self.vx = random.uniform(-20.0, 20.0)
        self.vy = random.uniform(-20.0, 20.0)
        self.size = float(size)
        self.scale = 1.0
        self.target_scale = 1.0
        self.rotation = random.uniform(0.0, 360.0)
        self.rot_speed = random.uniform(-90.0, 90.0)
        self.opacity = random.randint(70, 100)
        self.vertices = vertices
        self.color = color
        self.z = 20
        self.group = random.choice(["core", "arms", "orbiters", "dust"])
        self.phase = random.uniform(0.0, math.pi * 2)
        self.freq = random.uniform(0.8, 2.5)
        self.orbit_radius = random.uniform(40.0, 320.0)
        self.orbit_angle = random.uniform(0.0, math.pi * 2)
        self.orbit_speed = random.uniform(0.3, 1.8) * (1 if random.random() > 0.5 else -1)
        self.is_selected = False
        self.target_x = float(x)
        self.target_y = float(y)
        self.drag_locked = True


class ParticleUniverse:
    """Manages the full particle universe simulation, mode transformations, and rendering."""

    def __init__(self, count: int = 1500, arena_bounds: Tuple[float, float, float, float] = (270, 70, 870, 600)):
        self.count = count
        self.arena_x, self.arena_y, self.arena_w, self.arena_h = arena_bounds
        self.center_x = self.arena_x + self.arena_w / 2.0
        self.center_y = self.arena_y + self.arena_h / 2.0
        
        self.mode = "SPIRAL"
        self.previous_mode = "SPIRAL"
        self.mode_transition_progress = 1.0
        self.time_elapsed = 0.0
        self.speed_multiplier = 1.0
        self.is_paused = False
        
        # Mouse Interaction State
        self.mouse_x = self.center_x
        self.mouse_y = self.center_y
        self.mouse_active = False
        self.mouse_radius = 160.0
        self.mouse_attraction_force = 120.0
        
        # Selection
        self.selected_particle_id: Optional[str] = "particle_0"
        
        # Letter formation targets for WOW Demo
        self._letter_targets: List[Tuple[float, float]] = []
        
        # Particle Storage
        self.particles: List[Particle] = []
        self._init_particles()
        
        # Proximity connector lines
        self.connection_lines: List[Tuple[float, float, float, float, str, float]] = []

    def set_arena_bounds(self, x: float, y: float, w: float, h: float):
        self.arena_x = x
        self.arena_y = y
        self.arena_w = w
        self.arena_h = h
        self.center_x = x + w / 2.0
        self.center_y = y + h / 2.0

    def _init_particles(self):
        """Generates the initial particle population."""
        self.particles.clear()
        cols = int(math.ceil(math.sqrt(self.count * 1.5)))
        rows = int(math.ceil(self.count / max(1, cols)))
        
        spacing_x = self.arena_w / max(1, cols + 1)
        spacing_y = self.arena_h / max(1, rows + 1)

        for i in range(self.count):
            r = i // cols
            c = i % cols
            
            px = self.arena_x + spacing_x * (c + 1) + random.uniform(-spacing_x * 0.3, spacing_x * 0.3)
            py = self.arena_y + spacing_y * (r + 1) + random.uniform(-spacing_y * 0.3, spacing_y * 0.3)
            
            # Constrain to arena
            px = max(self.arena_x + 10, min(self.arena_x + self.arena_w - 10, px))
            py = max(self.arena_y + 10, min(self.arena_y + self.arena_h - 10, py))
            
            color = random.choice(PARTICLE_COLORS)
            v_count = random.choice([3, 4, 5, 6, 8, 24]) # Tri, Quad, Penta, Hex, Octa, Circle
            size = random.uniform(6.0, 14.0) if i < 1000 else random.uniform(4.0, 8.0)
            
            p = Particle(i, px, py, color, vertices=v_count, size=size)
            self.particles.append(p)
            
        if self.particles:
            self.particles[0].is_selected = True

    def set_count(self, new_count: int):
        """Dynamically scales particle population up or down."""
        if new_count == self.count:
            return
        self.count = max(50, min(50000, new_count))
        self._init_particles()
        self.set_mode(self.mode, force=True)

    def set_mode(self, new_mode: str, force: bool = False):
        """Switches the active motion engine mode."""
        if self.mode == new_mode and not force:
            return
        self.previous_mode = self.mode
        self.mode = new_mode
        self.mode_transition_progress = 0.0
        
        # Mode-specific re-initialization
        if new_mode == "PROJECTILE":
            for p in self.particles:
                p.x = self.center_x + random.uniform(-60.0, 60.0)
                p.y = self.arena_y + self.arena_h - 20.0
                angle = random.uniform(math.pi * 0.25, math.pi * 0.75)
                speed = random.uniform(280.0, 650.0)
                p.vx = math.cos(angle) * speed * random.choice([-1, 1])
                p.vy = -math.sin(angle) * speed
        elif new_mode == "GRAVITY":
            for p in self.particles:
                p.y = self.arena_y + random.uniform(10.0, self.arena_h * 0.5)
                p.vy = random.uniform(-50.0, 50.0)
        elif new_mode == "EXPLOSION":
            for p in self.particles:
                angle = random.uniform(0.0, math.pi * 2)
                speed = random.uniform(300.0, 800.0)
                p.vx = math.cos(angle) * speed
                p.vy = math.sin(angle) * speed
                p.target_x = self.center_x + math.cos(angle) * random.uniform(100.0, self.arena_w * 0.48)
                p.target_y = self.center_y + math.sin(angle) * random.uniform(100.0, self.arena_h * 0.48)

    def select_particle(self, particle_ip: str) -> Optional[Particle]:
        """Selects a particle by IP string and marks it."""
        for p in self.particles:
            if p.ip == particle_ip:
                p.is_selected = True
                self.selected_particle_id = particle_ip
            else:
                p.is_selected = False
        return self.get_selected_particle()

    def get_selected_particle(self) -> Optional[Particle]:
        if not self.selected_particle_id:
            return self.particles[0] if self.particles else None
        for p in self.particles:
            if p.ip == self.selected_particle_id:
                return p
        return self.particles[0] if self.particles else None

    def trigger_explosion(self):
        """Triggers a radial kinetic shockwave outward."""
        for p in self.particles:
            dx = p.x - self.center_x
            dy = p.y - self.center_y
            dist = max(1.0, math.hypot(dx, dy))
            force = random.uniform(400.0, 950.0)
            p.vx = (dx / dist) * force
            p.vy = (dy / dist) * force

    def prepare_draw_letters(self):
        """Generates target points forming the typography 'D R A W'."""
        self._letter_targets.clear()
        
        # Generate coordinate paths for D, R, A, W
        letter_w = self.arena_w * 0.18
        letter_h = self.arena_h * 0.45
        gap = self.arena_w * 0.04
        start_x = self.center_x - (letter_w * 4 + gap * 3) / 2.0
        start_y = self.center_y - letter_h / 2.0
        
        targets = []
        
        # 'D'
        dx0 = start_x
        for t in range(25):
            targets.append((dx0, start_y + (t / 25.0) * letter_h))
        for a in range(25):
            rad = -math.pi / 2 + (a / 24.0) * math.pi
            targets.append((dx0 + math.cos(rad) * letter_w * 0.9, start_y + letter_h / 2.0 + math.sin(rad) * (letter_h / 2.0)))
            
        # 'R'
        rx0 = dx0 + letter_w + gap
        for t in range(25):
            targets.append((rx0, start_y + (t / 25.0) * letter_h))
        for a in range(20):
            rad = -math.pi / 2 + (a / 19.0) * math.pi
            targets.append((rx0 + math.cos(rad) * letter_w * 0.8, start_y + letter_h * 0.25 + math.sin(rad) * (letter_h * 0.25)))
        for t in range(15):
            targets.append((rx0 + (t / 14.0) * letter_w, start_y + letter_h * 0.5 + (t / 14.0) * letter_h * 0.5))
            
        # 'A'
        ax0 = rx0 + letter_w + gap
        for t in range(25):
            targets.append((ax0 + (t / 24.0) * (letter_w / 2.0), start_y + letter_h - (t / 24.0) * letter_h))
            targets.append((ax0 + letter_w / 2.0 + (t / 24.0) * (letter_w / 2.0), start_y + (t / 24.0) * letter_h))
        for t in range(15):
            targets.append((ax0 + letter_w * 0.25 + (t / 14.0) * letter_w * 0.5, start_y + letter_h * 0.6))
            
        # 'W'
        wx0 = ax0 + letter_w + gap
        for t in range(20):
            targets.append((wx0 + (t / 19.0) * (letter_w * 0.25), start_y + (t / 19.0) * letter_h))
            targets.append((wx0 + letter_w * 0.25 + (t / 19.0) * (letter_w * 0.25), start_y + letter_h - (t / 19.0) * (letter_h * 0.6)))
            targets.append((wx0 + letter_w * 0.5 + (t / 19.0) * (letter_w * 0.25), start_y + letter_h * 0.4 + (t / 19.0) * (letter_h * 0.6)))
            targets.append((wx0 + letter_w * 0.75 + (t / 19.0) * (letter_w * 0.25), start_y + letter_h - (t / 19.0) * letter_h))
            
        self._letter_targets = targets

    def update(self, dt: float):
        """Vectorized simulation tick updating particle positions and states."""
        if self.is_paused:
            return
            
        effective_dt = dt * self.speed_multiplier
        self.time_elapsed += effective_dt
        t = self.time_elapsed
        
        mode = self.mode
        cx, cy = self.center_x, self.center_y
        aw, ah = self.arena_w, self.arena_h
        ax0, ay0 = self.arena_x, self.arena_y
        ax1, ay1 = ax0 + aw, ay0 + ah
        
        # 1. Simulate Particles per Mode
        for p in self.particles:
            p.rotation = (p.rotation + p.rot_speed * effective_dt) % 360.0
            
            if mode == "SPRING":
                # Damped harmonic spring to base anchor
                dx = p.base_x - p.x
                dy = p.base_y - p.y
                stiffness = 32.0
                damping = 4.0
                
                # Apply spring force
                p.vx += (dx * stiffness - p.vx * damping) * effective_dt
                p.vy += (dy * stiffness - p.vy * damping) * effective_dt
                p.x += p.vx * effective_dt
                p.y += p.vy * effective_dt
                
                # Gentle breathing scale
                p.scale = 1.0 + 0.25 * math.sin(t * p.freq + p.phase)

            elif mode == "ORBIT":
                # Concentric planetary orbit
                p.orbit_angle += p.orbit_speed * effective_dt
                target_x = cx + math.cos(p.orbit_angle) * p.orbit_radius
                target_y = cy + math.sin(p.orbit_angle) * (p.orbit_radius * 0.65) # Elliptical
                p.x += (target_x - p.x) * min(1.0, 5.0 * effective_dt)
                p.y += (target_y - p.y) * min(1.0, 5.0 * effective_dt)
                p.scale = 0.8 + 0.4 * (1.0 + math.sin(p.orbit_angle)) / 2.0

            elif mode == "GRAVITY":
                # Gravity and floor bounce
                g = 980.0
                restitution = 0.76
                p.vy += g * effective_dt
                p.x += p.vx * effective_dt
                p.y += p.vy * effective_dt
                
                # Floor collision
                floor_y = ay1 - p.size
                if p.y > floor_y:
                    p.y = floor_y
                    p.vy = -p.vy * restitution
                    if abs(p.vy) < 40.0:
                        p.vy = -random.uniform(280.0, 600.0) # Re-burst
                        p.vx = random.uniform(-120.0, 120.0)
                        
                # Wall collisions
                if p.x < ax0 + p.size:
                    p.x = ax0 + p.size
                    p.vx = -p.vx * restitution
                elif p.x > ax1 - p.size:
                    p.x = ax1 - p.size
                    p.vx = -p.vx * restitution

            elif mode == "PROJECTILE":
                # 2D Fountain projectile
                g = 650.0
                drag = 0.08
                p.vx *= (1.0 - drag * effective_dt)
                p.vy += g * effective_dt
                p.x += p.vx * effective_dt
                p.y += p.vy * effective_dt
                
                floor_y = ay1 - 10.0
                if p.y > floor_y:
                    # Reset to launch origin
                    p.x = cx + random.uniform(-40.0, 40.0)
                    p.y = floor_y
                    ang = random.uniform(math.pi * 0.3, math.pi * 0.7)
                    spd = random.uniform(320.0, 720.0)
                    p.vx = math.cos(ang) * spd * random.choice([-1, 1])
                    p.vy = -math.sin(ang) * spd

            elif mode == "LISSAJOUS":
                # Harmonic 3:2 parametric Lissajous figure
                freq_x = 1.2
                freq_y = 1.8
                amp_x = aw * 0.40
                amp_y = ah * 0.38
                
                offset_phase = p.phase
                target_x = cx + amp_x * math.sin(freq_x * t + offset_phase)
                target_y = cy + amp_y * math.sin(freq_y * t + offset_phase + math.pi / 4.0)
                
                p.x += (target_x - p.x) * min(1.0, 6.0 * effective_dt)
                p.y += (target_y - p.y) * min(1.0, 6.0 * effective_dt)
                p.scale = 0.9 + 0.3 * math.cos(t * 2.0 + offset_phase)

            elif mode == "SPIRAL":
                # Giant rotating Archimedean/logarithmic galaxy
                arms = 3
                arm_idx = p.index % arms
                base_angle = (arm_idx * (2.0 * math.pi / arms)) + (t * 0.45)
                radius_norm = (p.index / max(1, self.count))
                r = 20.0 + radius_norm * (min(aw, ah) * 0.46)
                spiral_angle = base_angle + radius_norm * 4.5
                
                # Organic noise dispersion
                noise_offset = math.sin(t * 1.5 + p.phase) * 18.0
                target_x = cx + math.cos(spiral_angle) * (r + noise_offset)
                target_y = cy + math.sin(spiral_angle) * ((r + noise_offset) * 0.7) # Tilt galaxy
                
                p.x += (target_x - p.x) * min(1.0, 5.0 * effective_dt)
                p.y += (target_y - p.y) * min(1.0, 5.0 * effective_dt)
                p.scale = 0.7 + 0.5 * (1.0 - radius_norm * 0.4)

            elif mode == "ATTRACTOR":
                # Gravitational pull towards mouse or center
                tx = self.mouse_x if self.mouse_active else cx
                ty = self.mouse_y if self.mouse_active else cy
                
                dx = tx - p.x
                dy = ty - p.y
                dist = max(20.0, math.hypot(dx, dy))
                
                # Swirl force perpendicular to radius + inward attraction
                attract_force = min(800.0, 35000.0 / (dist + 50.0))
                swirl_force = min(400.0, 18000.0 / (dist + 50.0))
                
                nx = dx / dist
                ny = dy / dist
                
                p.vx += (nx * attract_force - ny * swirl_force - p.vx * 2.5) * effective_dt
                p.vy += (ny * attract_force + nx * swirl_force - p.vy * 2.5) * effective_dt
                
                p.x += p.vx * effective_dt
                p.y += p.vy * effective_dt
                p.scale = 0.7 + min(1.5, 80.0 / dist)

            elif mode == "MORPH":
                # Morphing across polygon formations
                morph_stage = int(t * 0.5) % 5
                sub_t = (t * 0.5) % 1.0
                
                # Resample vertices on the fly
                poly_sides = [3, 4, 5, 6, 8][morph_stage]
                p.vertices = poly_sides
                
                # Form polygon boundary
                poly_idx = p.index % max(1, self.count)
                theta = (poly_idx / max(1, self.count)) * 2.0 * math.pi + t * 0.5
                r_target = min(aw, ah) * 0.35 * (0.85 + 0.15 * math.cos(poly_sides * theta))
                
                target_x = cx + math.cos(theta) * r_target
                target_y = cy + math.sin(theta) * r_target
                p.x += (target_x - p.x) * min(1.0, 6.0 * effective_dt)
                p.y += (target_y - p.y) * min(1.0, 6.0 * effective_dt)
                p.scale = 1.0 + 0.3 * math.sin(t * 3.0 + p.phase)

            elif mode == "WAVE":
                # 2D travelling sinusoidal displacement wave
                k_x = 0.015
                k_y = 0.015
                wave_z = math.sin(k_x * p.base_x + k_y * p.base_y - t * 3.5)
                
                p.x = p.base_x + wave_z * 12.0
                p.y = p.base_y + wave_z * 24.0
                p.scale = 0.7 + 0.5 * (wave_z + 1.0) / 2.0
                p.opacity = int(60 + 40 * (wave_z + 1.0) / 2.0)

            elif mode == "ELASTIC":
                # Damped elastic oscillation
                omega = 4.0
                zeta = 0.15
                decay = math.exp(-zeta * omega * ((t + p.phase) % 3.0))
                elastic_val = decay * math.cos(omega * ((t + p.phase) % 3.0))
                
                p.x = p.base_x + elastic_val * 45.0 * math.cos(p.phase)
                p.y = p.base_y + elastic_val * 45.0 * math.sin(p.phase)
                p.scale = 1.0 + elastic_val * 0.4

            elif mode == "FORM_LETTERS":
                # Form the letters 'D R A W'
                if self._letter_targets:
                    tgt_idx = p.index % len(self._letter_targets)
                    tgt_x, tgt_y = self._letter_targets[tgt_idx]
                    p.x += (tgt_x - p.x) * min(1.0, 6.0 * effective_dt)
                    p.y += (tgt_y - p.y) * min(1.0, 6.0 * effective_dt)
                    p.scale = 0.9 + 0.2 * math.sin(t * 4.0 + p.phase)

            # 2. Interactive Mouse Repulsion / Proximity Reaction
            if self.mouse_active:
                mdx = p.x - self.mouse_x
                mdy = p.y - self.mouse_y
                m_dist = math.hypot(mdx, mdy)
                if m_dist < self.mouse_radius and m_dist > 0.1:
                    push_factor = (1.0 - m_dist / self.mouse_radius) * 180.0
                    p.x += (mdx / m_dist) * push_factor * effective_dt
                    p.y += (mdy / m_dist) * push_factor * effective_dt
                    p.scale = max(p.scale, 1.0 + (1.0 - m_dist / self.mouse_radius) * 0.8)

            # 3. Soft Arena Clamping
            p.x = max(ax0 + 5, min(ax1 - 5, p.x))
            p.y = max(ay0 + 5, min(ay1 - 5, p.y))

        # 4. Proximity Connection Lines (sample subset for high FPS)
        self.connection_lines.clear()
        sample_step = max(1, self.count // 120)
        sample_particles = self.particles[::sample_step]
        max_conn_dist = 65.0

        for i in range(len(sample_particles)):
            p1 = sample_particles[i]
            for j in range(i + 1, min(i + 6, len(sample_particles))):
                p2 = sample_particles[j]
                dist = math.hypot(p2.x - p1.x, p2.y - p1.y)
                if dist < max_conn_dist:
                    alpha = (1.0 - dist / max_conn_dist) * 0.6
                    self.connection_lines.append((p1.x, p1.y, p2.x, p2.y, p1.color, alpha))

    def get_shape_defs(self) -> List[Dict[str, Any]]:
        """Exports particle swarm definitions compatible with Draw.shape."""
        shape_list = []
        
        # Add connection lines as thin line shapes or vector paths
        for idx, (x1, y1, x2, y2, color, alpha) in enumerate(self.connection_lines[:150]):
            shape_list.append({
                "ip": f"conn_line_{idx}",
                "vertices": 2,
                "x": (x1 + x2) / 2.0,
                "y": (y1 + y2) / 2.0,
                "size": [max(2.0, abs(x2 - x1)), max(2.0, abs(y2 - y1))],
                "color": color,
                "opacity": int(alpha * 100),
                "z": 15,
            })

        for p in self.particles:
            cur_size = p.size * p.scale
            shape_list.append({
                "ip": p.ip,
                "vertices": p.vertices,
                "size": [cur_size, cur_size],
                "color": THEME["cyan"] if p.is_selected else p.color,
                "x": p.x - cur_size / 2.0,
                "y": p.y - cur_size / 2.0,
                "rotation": p.rotation,
                "opacity": 100 if p.is_selected else p.opacity,
                "z": 30 if p.is_selected else p.z,
                "border_color": THEME["cyan"] if p.is_selected else None,
                "border_width": 2 if p.is_selected else 0,
            })
            
        return shape_list
