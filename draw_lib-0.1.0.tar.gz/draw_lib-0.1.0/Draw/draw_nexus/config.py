"""
DRAW.NEXUS Configuration & Design Tokens
=========================================
Centralized styling, color palette, dimensions, and system constants.
"""

from __future__ import annotations

import os
import sys

_NEXUS_DIR = os.path.dirname(os.path.abspath(__file__))
_DRAW_DIR = os.path.dirname(_NEXUS_DIR)
_ROOT_DIR = os.path.dirname(_DRAW_DIR)

for p in [_ROOT_DIR, _DRAW_DIR, _NEXUS_DIR]:
    if p not in sys.path:
        sys.path.insert(0, p)

# ── 1. Color Palette & Tokens ───────────────────────────────────────────────

THEME = {
    # Backgrounds
    "bg_main": "#070B12",
    "bg_panel": "#0D1524",
    "bg_panel_active": "#131F35",
    "bg_card": "#111C2E",
    "bg_surface": "#16233B",
    
    # Borders & Outlines
    "border_subtle": "#1B2A45",
    "border_medium": "#2A3F66",
    "border_glow": "#38BDF8",
    
    # Text
    "text_title": "#F8FAFC",
    "text_primary": "#E2E8F0",
    "text_secondary": "#94A3B8",
    "text_muted": "#64748B",
    "text_highlight": "#38BDF8",
    
    # Accent & Status Colors
    "cyan": "#00F0FF",
    "blue": "#38BDF8",
    "emerald": "#00E676",
    "magenta": "#D946EF",
    "purple": "#A855F7",
    "amber": "#FFB703",
    "crimson": "#FF2A55",
    
    # System Status Badges
    "online": "#00E676",
    "warning": "#FFB703",
    "critical": "#FF2A55",
    "gpu_badge": "#38BDF8",
}

# Particle palette choices
PARTICLE_COLORS = [
    "#00F0FF",  # Electric Cyan
    "#38BDF8",  # Neon Sky
    "#00E676",  # Vibrant Green
    "#D946EF",  # Bright Magenta
    "#A855F7",  # Neon Purple
    "#FFB703",  # Amber Sun
    "#FF2A55",  # Crimson Flare
    "#818CF8",  # Indigo Pulse
    "#F43F5E",  # Rose Quartz
    "#2DD4BF",  # Aqua Teal
]

# ── 2. Layout Geometry & Dimensions ─────────────────────────────────────────

WINDOW_WIDTH = 1360
WINDOW_HEIGHT = 820

HEADER_HEIGHT = 52
LEFT_PANEL_WIDTH = 230
RIGHT_PANEL_WIDTH = 270
BOTTOM_PANEL_HEIGHT = 200

# ── 3. Engine Modes & Presets ───────────────────────────────────────────────

MOTION_MODES = [
    "SPRING",
    "ORBIT",
    "GRAVITY",
    "PROJECTILE",
    "LISSAJOUS",
    "SPIRAL",
    "ATTRACTOR",
    "MORPH",
    "WAVE",
    "ELASTIC",
]

BENCHMARK_PRESETS = [
    100,
    500,
    1000,
    5000,
    10000,
    25000,
    50000,
]

DEFAULT_PARTICLE_COUNT = 1500
MAX_PARTICLE_CAPACITY = 50000
