"""
DRAW.NEXUS Chaos Mode Controller
================================
Randomly mixes 10 kinetic physics modes simultaneously, color oscillations,
rapid object density scaling, and real-time stability verification via Draw.debug.
"""

from __future__ import annotations

import math
import random
from typing import Any, Dict, List, Optional
from Draw.debug import debug
from draw_nexus.config import MOTION_MODES, PARTICLE_COLORS, THEME
from draw_nexus.particles import ParticleUniverse


class ChaosController:
    """Manages Chaos Mode execution, kinetic randomization, and stability telemetry."""

    def __init__(self, universe: ParticleUniverse):
        self.universe = universe
        self.is_active = False
        self.elapsed = 0.0
        self.random_switch_interval = 1.8
        self.time_since_switch = 0.0

    def toggle(self):
        self.is_active = not self.is_active
        if self.is_active:
            self.elapsed = 0.0
            self.time_since_switch = 0.0
            self.universe.set_count(3500)
        else:
            self.universe.set_count(1500)
            self.universe.set_mode("SPIRAL")

    def update(self, dt: float):
        if not self.is_active:
            return

        self.elapsed += dt
        self.time_since_switch += dt

        # Gradually ramp particle load up to 8,500 objects over 15 seconds
        target_count = min(8500, int(3500 + (self.elapsed / 15.0) * 5000))
        if abs(self.universe.count - target_count) > 200:
            self.universe.set_count(target_count)

        # Periodically shuffle kinetic modes and particle colors
        if self.time_since_switch >= self.random_switch_interval:
            self.time_since_switch = 0.0
            chosen_mode = random.choice(MOTION_MODES)
            self.universe.set_mode(chosen_mode)

            # Randomize group velocities and colors
            for p in self.universe.particles:
                if random.random() < 0.35:
                    p.color = random.choice(PARTICLE_COLORS)
                    p.rot_speed = random.uniform(-180.0, 180.0)
                    p.vx += random.uniform(-150.0, 150.0)
                    p.vy += random.uniform(-150.0, 150.0)

    def get_ui_shapes(self) -> List[Dict[str, Any]]:
        """Generates floating Chaos HUD box in the center viewport."""
        if not self.is_active:
            return []

        shapes = []
        cw = 260
        ch = 130
        cx = self.universe.center_x - cw / 2.0
        cy = self.universe.arena_y + 20

        # Glowing Chaos Box
        shapes.append({
            "ip": "chaos_hud_box",
            "vertices": 4,
            "size": [cw, ch],
            "x": cx,
            "y": cy,
            "color": THEME["bg_card"],
            "border_color": THEME["crimson"],
            "border_width": 2,
            "border_radius": 8,
            "opacity": 92,
            "z": 10,
        })

        return shapes

    def get_ui_texts(self) -> List[Dict[str, Any]]:
        """Generates real-time Chaos stability status and FPS telemetry."""
        if not self.is_active:
            return []

        texts = []
        cw = 260
        cx = self.universe.center_x - cw / 2.0
        cy = self.universe.arena_y + 20

        stats = debug._frame_history.get_stats()
        cur_fps = stats.get("avg_fps", 60.0) or 60.0
        cur_frame = stats.get("worst_frame_ms", 16.4) or 16.4
        obj_count = len(self.universe.particles)

        texts.append({
            "ip": "txt_chaos_title",
            "text": "💥 DRAW CHAOS TEST",
            "x": cx + 44,
            "y": cy + 18,
            "font_size": 11,
            "bold": True,
            "color": THEME["crimson"],
            "z": 8,
        })

        texts.append({
            "ip": "txt_chaos_objs",
            "text": f"OBJECTS:  {obj_count:,}",
            "x": cx + 44,
            "y": cy + 42,
            "font_size": 10,
            "bold": True,
            "color": THEME["text_primary"],
            "z": 8,
        })

        texts.append({
            "ip": "txt_chaos_fps",
            "text": f"FPS:          {cur_fps:.0f} FPS ({cur_frame:.1f}ms)",
            "x": cx + 44,
            "y": cy + 64,
            "font_size": 10,
            "bold": True,
            "color": THEME["emerald"] if cur_fps >= 45 else THEME["amber"],
            "z": 8,
        })

        texts.append({
            "ip": "txt_chaos_status",
            "text": "ENGINE:   STABLE (SAFEPLAY)",
            "x": cx + 44,
            "y": cy + 90,
            "font_size": 10,
            "bold": True,
            "color": THEME["cyan"],
            "z": 8,
        })

        return texts
