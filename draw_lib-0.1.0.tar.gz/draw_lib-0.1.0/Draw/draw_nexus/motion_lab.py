"""
DRAW.NEXUS Motion Laboratory Controller
=======================================
Left-hand interactive control panel for switching particle motion modes,
demonstrating 10 procedural kinematics, physics solvers, and geometry morphing.
"""

from __future__ import annotations

import os
import sys
from typing import Any, Callable, Dict, List, Optional, Tuple

_NEXUS_DIR = os.path.dirname(os.path.abspath(__file__))
_DRAW_DIR = os.path.dirname(_NEXUS_DIR)
_ROOT_DIR = os.path.dirname(_DRAW_DIR)

for p in [_ROOT_DIR, _DRAW_DIR, _NEXUS_DIR]:
    if p not in sys.path:
        sys.path.insert(0, p)

from draw_nexus.config import MOTION_MODES, THEME

# Mode descriptions for UI callouts
MODE_DESCRIPTIONS = {
    "SPRING": "Damped Hooke's law vector springs to elastic anchor points",
    "ORBIT": "Multi-ring planetary orbital dynamics with angular velocities",
    "GRAVITY": "Real-time gravity simulation with multi-bounce floor restitution",
    "PROJECTILE": "2D parabolic fountains with air drag and kinetic bouncing",
    "LISSAJOUS": "Harmonic 3:2 parametric orbital figures and phase shifts",
    "SPIRAL": "Rotating Archimedean & Logarithmic spiral galaxy formation",
    "ATTRACTOR": "Dynamic gravitational field tracking live mouse cursor",
    "MORPH": "Continuous polygon vertex morphing (Circle -> Star -> Hexagon)",
    "WAVE": "Sinusoidal 2D travelling displacement wave across spatial field",
    "ELASTIC": "Damped elastic oscillations with overshoot settling kinetics",
}


class MotionLab:
    """Manages Motion Lab UI layout, buttons, and mode transitions."""

    def __init__(
        self,
        panel_bounds: Optional[Tuple[float, float, float, float]] = None,
        on_mode_changed: Optional[Callable[[str], None]] = None
    ):
        self.active_mode = "SPIRAL"
        self.on_mode_changed = on_mode_changed
        if panel_bounds:
            self.panel_x, self.panel_y, self.panel_w, self.panel_h = panel_bounds
        else:
            self.panel_x = 16.0
            self.panel_y = 60.0
            self.panel_w = 230.0
            self.panel_h = 530.0

    def select_mode(self, mode: str):
        """Sets active mode and dispatches callback."""
        if mode in MOTION_MODES:
            self.active_mode = mode
            if self.on_mode_changed:
                self.on_mode_changed(mode)

    def get_ui_shapes(self) -> List[Dict[str, Any]]:
        """Generates shapes for Motion Lab background panel and button items."""
        shapes = []

        # 1. Panel Background Card
        shapes.append({
            "ip": "motion_lab_panel",
            "vertices": 4,
            "size": [self.panel_w, self.panel_h],
            "x": self.panel_x,
            "y": self.panel_y,
            "color": THEME["bg_panel"],
            "border_color": THEME["border_subtle"],
            "border_width": 1,
            "border_radius": 8,
            "z": 90,
        })

        # 2. Section Header Badge
        shapes.append({
            "ip": "motion_lab_header_bar",
            "vertices": 4,
            "size": [self.panel_w - 24, 28],
            "x": self.panel_x + 12,
            "y": self.panel_y + 10,
            "color": THEME["bg_card"],
            "border_color": THEME["border_medium"],
            "border_width": 1,
            "border_radius": 6,
            "z": 88,
        })

        # 3. 10 Mode Selector Buttons
        btn_start_y = self.panel_y + 44
        btn_height = 31
        btn_gap = 5
        btn_w = self.panel_w - 24

        for idx, mode_name in enumerate(MOTION_MODES):
            by = btn_start_y + idx * (btn_height + btn_gap)
            is_active = (mode_name == self.active_mode)

            btn_color = THEME["bg_surface"] if is_active else THEME["bg_card"]
            border_col = THEME["cyan"] if is_active else THEME["border_subtle"]
            border_w = 2 if is_active else 1

            shapes.append({
                "ip": f"btn_mode_{mode_name.lower()}",
                "vertices": 4,
                "size": [btn_w, btn_height],
                "x": self.panel_x + 12,
                "y": by,
                "color": btn_color,
                "border_color": border_col,
                "border_width": border_w,
                "border_radius": 6,
                "z": 85,
            })

            # Active indicator pip
            if is_active:
                shapes.append({
                    "ip": f"pip_mode_{mode_name.lower()}",
                    "vertices": 24,
                    "size": [6, 6],
                    "x": self.panel_x + 20,
                    "y": by + (btn_height - 6) / 2.0,
                    "color": THEME["cyan"],
                    "z": 84,
                })

        # 4. Info card at bottom of Motion Lab
        info_y = btn_start_y + len(MOTION_MODES) * (btn_height + btn_gap) + 6
        shapes.append({
            "ip": "motion_lab_info_box",
            "vertices": 4,
            "size": [btn_w, 80],
            "x": self.panel_x + 12,
            "y": info_y,
            "color": THEME["bg_card"],
            "border_color": THEME["border_subtle"],
            "border_width": 1,
            "border_radius": 6,
            "z": 88,
        })

        return shapes

    def get_ui_texts(self) -> List[Dict[str, Any]]:
        """Generates text labels for the Motion Lab."""
        texts = []

        # Header Title
        texts.append({
            "ip": "txt_motion_lab_title",
            "text": "MOTION LABORATORY",
            "x": self.panel_x + 18,
            "y": self.panel_y + 17,
            "font_size": 10,
            "bold": True,
            "color": THEME["cyan"],
            "z": 80,
        })

        btn_start_y = self.panel_y + 44
        btn_height = 31
        btn_gap = 5

        for idx, mode_name in enumerate(MOTION_MODES):
            by = btn_start_y + idx * (btn_height + btn_gap)
            is_active = (mode_name == self.active_mode)

            texts.append({
                "ip": f"txt_mode_{mode_name.lower()}",
                "text": f"{'▶ ' if is_active else '   '}{mode_name}",
                "x": self.panel_x + 32,
                "y": by + 8,
                "font_size": 9,
                "bold": is_active,
                "color": THEME["text_title"] if is_active else THEME["text_secondary"],
                "z": 80,
            })

            if is_active:
                texts.append({
                    "ip": f"txt_badge_{mode_name.lower()}",
                    "text": "ACTIVE",
                    "x": self.panel_x + self.panel_w - 60,
                    "y": by + 9,
                    "font_size": 8,
                    "bold": True,
                    "color": THEME["emerald"],
                    "z": 80,
                })

        # Mode description text
        info_y = btn_start_y + len(MOTION_MODES) * (btn_height + btn_gap) + 12
        desc = MODE_DESCRIPTIONS.get(self.active_mode, "")

        texts.append({
            "ip": "txt_motion_lab_desc_title",
            "text": f"SYSTEM: {self.active_mode}",
            "x": self.panel_x + 18,
            "y": info_y,
            "font_size": 9,
            "bold": True,
            "color": THEME["text_highlight"],
            "z": 80,
        })

        texts.append({
            "ip": "txt_motion_lab_desc_body",
            "text": desc,
            "x": self.panel_x + 18,
            "y": info_y + 16,
            "font_size": 8,
            "max_width": self.panel_w - 36,
            "line_height": 1.25,
            "color": THEME["text_muted"],
            "z": 80,
        })

        return texts
