"""
Draw-lib Ultimate Benchmark — Main Application
================================================
100% Feature + FPS Stress Test for the Draw library.

Launches a single window with:
  - Live FPS/CPU/RAM telemetry HUD
  - Sidebar controls for toggling each feature test
  - Central canvas for rendering all test objects
  - Bottom FPS history graph
  - Auto-run stress benchmark mode

Usage:
    D:/python/python main.py
"""
import sys
sys.path.insert(0, r'd:/pg/draw2')

import os
import time
import Draw

# ── Ensure our package is importable ──────────────────────────────────────
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_PARENT_DIR = os.path.dirname(_THIS_DIR)
for p in (_PARENT_DIR, os.path.dirname(_PARENT_DIR)):
    if p not in sys.path:
        sys.path.insert(0, p)

from draw_lib_ultimate_test.config import (
    WIN_TAG, WIN_TITLE, WIN_W, WIN_H, WIN_BG,
    HEADER_H, SIDEBAR_W, FOOTER_H,
    CONTENT_X, CONTENT_Y, CONTENT_W, CONTENT_H,
    PALETTE, UI_BG_DARK, UI_BG_CARD, UI_BORDER,
    UI_TEXT_PRIMARY, UI_TEXT_SECONDARY, UI_TEXT_ACCENT,
    UI_TEXT_SUCCESS, UI_TEXT_DANGER,
    BTN_STYLE_PRIMARY, BTN_STYLE_SECONDARY,
    BTN_STYLE_DANGER, BTN_STYLE_ACCENT,
    Z_BACKGROUND, Z_PANELS, Z_HUD, Z_UI_CONTROLS,
    STRESS_LEVELS, DEFAULT_NORMAL_OBJECTS,
    AUTO_BENCH_DURATION_S, METRICS_SAMPLE_INTERVAL,
    FPS_GRAPH_POINTS, MODE_NORMAL, MODE_STRESS,
)
from draw_lib_ultimate_test.benchmark.fps import FPSTracker
from draw_lib_ultimate_test.benchmark.metrics import SystemMetrics
from draw_lib_ultimate_test.benchmark.report import save_run, print_results_table
from draw_lib_ultimate_test.benchmark import hud

# Test modules
from draw_lib_ultimate_test.tests import (
    shapes_test,
    text_test,
    canvas_test,
    bar_test,
    graph_test,
    image_test,
    animation_test,
    mouse_test,
    keyboard_test,
    scroll_test,
    layout_test,
    live_test,
)

# Stress modules
from draw_lib_ultimate_test.stress import objects as stress_objects
from draw_lib_ultimate_test.stress import particles as stress_particles
from draw_lib_ultimate_test.stress import animation_stress
from draw_lib_ultimate_test.stress import event_stress


# ═══════════════════════════════════════════════════════════════════════════
#  Global State
# ═══════════════════════════════════════════════════════════════════════════

fps_tracker = FPSTracker(window_size=30)
sys_metrics = SystemMetrics()

app_state = {
    "mode": MODE_NORMAL,
    "active_tests": set(),
    "auto_running": False,
    "auto_step": 0,
    "auto_results": [],
    "paused": False,
}

# Map of test name → (activate_fn, deactivate_fn)
TEST_MODULES = {
    "Shapes":    (shapes_test.activate, shapes_test.deactivate),
    "Text":      (text_test.activate, text_test.deactivate),
    "Canvas":    (canvas_test.activate, canvas_test.deactivate),
    "Bars":      (bar_test.activate, bar_test.deactivate),
    "Graphs":    (graph_test.activate, graph_test.deactivate),
    "Images":    (image_test.activate, image_test.deactivate),
    "Animation": (animation_test.activate, animation_test.deactivate),
    "Mouse":     (mouse_test.activate, mouse_test.deactivate),
    "Keyboard":  (keyboard_test.activate, keyboard_test.deactivate),
    "Scroll":    (scroll_test.activate, scroll_test.deactivate),
    "Layout":    (layout_test.activate, layout_test.deactivate),
    "Live":      (live_test.activate, live_test.deactivate),
}

_gl_canvas = None
_metrics_timer = None


# ═══════════════════════════════════════════════════════════════════════════
#  Telemetry Update
# ═══════════════════════════════════════════════════════════════════════════

def _update_metrics():
    """Periodic CPU/RAM/object count sampling."""
    sys_metrics.sample()
    total = stress_objects.get_count() + stress_particles.get_count()
    # Count active test objects approximately
    total += len(app_state["active_tests"]) * 10
    sys_metrics.object_count = total



# ═══════════════════════════════════════════════════════════════════════════
#  Test Toggle
# ═══════════════════════════════════════════════════════════════════════════

def toggle_test(name):
    """Toggle a test module on/off."""
    if name in app_state["active_tests"]:
        # Deactivate
        deactivate_fn = TEST_MODULES[name][1]
        try:
            deactivate_fn(WIN_TAG)
        except Exception as e:
            print(f"[Main] Error deactivating {name}: {e}")
        app_state["active_tests"].discard(name)
    else:
        # Activate
        activate_fn = TEST_MODULES[name][0]
        try:
            activate_fn(WIN_TAG)
        except Exception as e:
            print(f"[Main] Error activating {name}: {e}")
        app_state["active_tests"].add(name)


def activate_all_tests():
    """Activate all feature tests for normal mode."""
    for name in TEST_MODULES:
        if name not in app_state["active_tests"]:
            try:
                TEST_MODULES[name][0](WIN_TAG)
                app_state["active_tests"].add(name)
            except Exception as e:
                print(f"[Main] Error activating {name}: {e}")


def deactivate_all_tests():
    """Deactivate all feature tests."""
    for name in list(app_state["active_tests"]):
        try:
            TEST_MODULES[name][1](WIN_TAG)
        except Exception:
            pass
    app_state["active_tests"].clear()


# ═══════════════════════════════════════════════════════════════════════════
#  Stress Controls
# ═══════════════════════════════════════════════════════════════════════════

def spawn_stress(count):
    """Spawn stress objects with animation."""
    ips = stress_objects.spawn_objects(count, WIN_TAG)
    animation_stress.animate_objects(ips)


def clear_all():
    """Clear everything: tests + stress objects + particles."""
    deactivate_all_tests()
    stress_objects.clear_objects(WIN_TAG)
    stress_particles.clear_particles(WIN_TAG)


def spawn_particles(count=100):
    """Spawn particle burst."""
    stress_particles.spawn_particles(count, WIN_TAG)


# ═══════════════════════════════════════════════════════════════════════════
#  Auto Benchmark
# ═══════════════════════════════════════════════════════════════════════════

def start_auto_benchmark():
    """Start automated stress benchmark sweep."""
    if app_state["auto_running"]:
        return
    app_state["auto_running"] = True
    app_state["auto_step"] = 0
    app_state["auto_results"] = []
    app_state["mode"] = MODE_STRESS

    clear_all()
    fps_tracker.reset()
    print("\n[Auto Benchmark] Starting stress sweep...")
    _auto_next_step()


def _auto_next_step():
    """Execute the next step in the auto benchmark."""
    step = app_state["auto_step"]

    if step >= len(STRESS_LEVELS):
        _auto_finish()
        return

    count = STRESS_LEVELS[step]
    print(f"[Auto Benchmark] Step {step + 1}/{len(STRESS_LEVELS)}: {count:,} objects")

    # Clear previous
    stress_objects.clear_objects(WIN_TAG)
    stress_particles.clear_particles(WIN_TAG)
    fps_tracker.reset()

    # Spawn new batch
    ips = stress_objects.spawn_objects(count, WIN_TAG)
    animation_stress.animate_objects(ips)

    # Wait for benchmark duration, then record
    Draw.after(AUTO_BENCH_DURATION_S, _auto_record_step)


def _auto_record_step():
    """Record results for current auto-benchmark step."""
    step = app_state["auto_step"]
    count = STRESS_LEVELS[step]

    snapshot = fps_tracker.get_snapshot()
    metrics = sys_metrics.get_snapshot()

    result = {
        "object_count": count,
        "avg_fps": snapshot["avg_fps"],
        "min_fps": snapshot["min_fps"],
        "one_pct_low": snapshot["one_pct_low"],
        "point_one_pct_low": snapshot["point_one_pct_low"],
        "avg_frame_ms": snapshot["avg_frame_ms"],
        "max_frame_ms": snapshot["max_frame_ms"],
        "avg_render_ms": snapshot["avg_render_ms"],
        "avg_update_ms": snapshot["avg_update_ms"],
        "cpu_percent": metrics["cpu_percent"],
        "ram_mb": metrics["ram_mb"],
    }
    app_state["auto_results"].append(result)

    print(
        f"  → {count:>7,} objects: "
        f"{result['avg_fps']:>6.1f} FPS  "
        f"(1% low: {result['one_pct_low']:.1f})  "
        f"Frame: {result['avg_frame_ms']:.1f}ms  "
        f"RAM: {result['ram_mb']:.0f}MB"
    )

    # Next step
    app_state["auto_step"] += 1
    _auto_next_step()


def _auto_finish():
    """Finish auto benchmark and save results."""
    app_state["auto_running"] = False
    app_state["mode"] = MODE_NORMAL

    results = app_state["auto_results"]
    print_results_table(results)
    save_run("stress", results, version=Draw.__version__)

    # Clear stress objects
    stress_objects.clear_objects(WIN_TAG)
    print("[Auto Benchmark] Complete! Results saved.\n")


# ═══════════════════════════════════════════════════════════════════════════
#  Build UI
# ═══════════════════════════════════════════════════════════════════════════

# ═══════════════════════════════════════════════════════════════════════════
#  Build UI
# ═══════════════════════════════════════════════════════════════════════════

def build_ui():
    """Build the complete benchmark UI."""
    global _gl_canvas, _metrics_timer

    print("Initializing Draw-lib Ultimate Benchmark...")

    # ── 1. Window ────────────────────────────────────────────────────────────
    Draw.window(
        tag=WIN_TAG,
        title=WIN_TITLE,
        width=WIN_W,
        height=WIN_H,
        background_color=WIN_BG,
    )

    # ── 2. Activate Hardware-Accelerated OpenGL Engine FIRST ──────────────────
    print("Activating Draw.super GPU Engine...")
    try:
        _gl_canvas = Draw.super(
            display=WIN_TAG,
            precompile=True,
            mode="max",
            vsync=False,
            batch_capacity=131072,
        )

        # Hook paint for render time measurement
        orig_paint = _gl_canvas._do_paint_gl

        def hooked_paint():
            t0 = time.perf_counter()
            orig_paint()
            render_ms = (time.perf_counter() - t0) * 1000.0
            fps_tracker.record_frame(render_ms=render_ms)

        _gl_canvas._do_paint_gl = hooked_paint
        print("  GPU engine active with paint hook.")
    except Exception as e:
        print(f"  GPU engine error (falling back to software): {e}")

    # ── 3. Header Background Card ─────────────────────────────────────────────
    Draw.shape(display=WIN_TAG, shape=[{
        "ip": "header_bg",
        "size": [WIN_W - 20, HEADER_H],
        "x": 10, "y": 8,
        "color": UI_BG_DARK,
        "border_color": UI_BORDER,
        "border_width": 1,
        "border_radius": 10,
        "z": Z_BACKGROUND,
    }])

    # ── 4. Sidebar Background Card ────────────────────────────────────────────
    Draw.shape(display=WIN_TAG, shape=[{
        "ip": "sidebar_bg",
        "size": [SIDEBAR_W + 20, WIN_H - HEADER_H - 30],
        "x": 10, "y": HEADER_H + 18,
        "color": UI_BG_DARK,
        "border_color": UI_BORDER,
        "border_width": 1,
        "border_radius": 10,
        "z": Z_BACKGROUND,
    }])

    # ── 5. Header HUD Text (Callable dynamic bindings) ────────────────────────
    Draw.text(
        tag=WIN_TAG, text=hud.get_title_text,
        customise={
            "x": 24, "y": 16, "font_size": 16, "bold": True,
            "color": UI_TEXT_ACCENT, "z": Z_HUD,
            "font_family": "Consolas",
        }
    )

    Draw.text(
        tag=WIN_TAG, text=hud.get_stats_text,
        customise={
            "x": 24, "y": 40, "font_size": 12, "bold": True,
            "color": UI_TEXT_SUCCESS, "z": Z_HUD,
            "font_family": "Consolas",
        }
    )

    Draw.text(
        tag=WIN_TAG, text=hud.get_detailed_text,
        customise={
            "x": 24, "y": 58, "font_size": 11,
            "color": UI_TEXT_SECONDARY, "z": Z_HUD,
            "font_family": "Consolas",
        }
    )

    # ── 6. Sidebar Buttons (Clean 2-column layout) ─────────────────────────────
    col1_x = 18
    col2_x = 98
    btn_w = 74
    btn_h = 26
    btn_gap_y = 5
    curr_y = HEADER_H + 26

    # Section 1: Features
    Draw.text(
        tag=WIN_TAG, text="FEATURES",
        customise={
            "x": 18, "y": curr_y, "font_size": 10, "bold": True,
            "color": UI_TEXT_SECONDARY, "letter_spacing": 2,
            "z": Z_HUD,
        }
    )
    curr_y += 18

    test_names = list(TEST_MODULES.keys())
    for i in range(0, len(test_names), 2):
        name1 = test_names[i]
        Draw.button(
            ip=f"btn_{name1.lower()}", display=WIN_TAG,
            x=col1_x, y=curr_y, width=btn_w, height=btn_h,
            text=name1,
            style=BTN_STYLE_SECONDARY,
            on_click=(lambda n=name1: toggle_test(n)),
        )
        if i + 1 < len(test_names):
            name2 = test_names[i + 1]
            Draw.button(
                ip=f"btn_{name2.lower()}", display=WIN_TAG,
                x=col2_x, y=curr_y, width=btn_w, height=btn_h,
                text=name2,
                style=BTN_STYLE_SECONDARY,
                on_click=(lambda n=name2: toggle_test(n)),
            )
        curr_y += btn_h + btn_gap_y

    # Section 2: Stress Presets
    curr_y += 10
    Draw.text(
        tag=WIN_TAG, text="STRESS",
        customise={
            "x": 18, "y": curr_y, "font_size": 10, "bold": True,
            "color": UI_TEXT_SECONDARY, "letter_spacing": 2,
            "z": Z_HUD,
        }
    )
    curr_y += 18

    stress_pairs = [("×100", 100, "×1K", 1000), ("×10K", 10000, "×50K", 50000)]
    for l1, c1, l2, c2 in stress_pairs:
        Draw.button(
            ip=f"btn_stress_{c1}", display=WIN_TAG,
            x=col1_x, y=curr_y, width=btn_w, height=btn_h,
            text=l1,
            style=BTN_STYLE_ACCENT,
            on_click=(lambda count=c1: spawn_stress(count)),
        )
        Draw.button(
            ip=f"btn_stress_{c2}", display=WIN_TAG,
            x=col2_x, y=curr_y, width=btn_w, height=btn_h,
            text=l2,
            style=BTN_STYLE_ACCENT,
            on_click=(lambda count=c2: spawn_stress(count)),
        )
        curr_y += btn_h + btn_gap_y

    # Particles button (full width)
    Draw.button(
        ip="btn_particles", display=WIN_TAG,
        x=col1_x, y=curr_y, width=btn_w * 2 + 6, height=btn_h,
        text="✨ Particles (200)",
        style=BTN_STYLE_PRIMARY,
        on_click=lambda: spawn_particles(200),
    )
    curr_y += btn_h + btn_gap_y + 10

    # Section 3: Controls
    Draw.text(
        tag=WIN_TAG, text="CONTROLS",
        customise={
            "x": 18, "y": curr_y, "font_size": 10, "bold": True,
            "color": UI_TEXT_SECONDARY, "letter_spacing": 2,
            "z": Z_HUD,
        }
    )
    curr_y += 18

    Draw.button(
        ip="btn_all_tests", display=WIN_TAG,
        x=col1_x, y=curr_y, width=btn_w * 2 + 6, height=btn_h,
        text="⚡ All Tests",
        style=BTN_STYLE_PRIMARY,
        on_click=activate_all_tests,
    )
    curr_y += btn_h + btn_gap_y

    Draw.button(
        ip="btn_clear", display=WIN_TAG,
        x=col1_x, y=curr_y, width=btn_w * 2 + 6, height=btn_h,
        text="🗑️ Clear All",
        style=BTN_STYLE_DANGER,
        on_click=clear_all,
    )
    curr_y += btn_h + btn_gap_y

    Draw.button(
        ip="btn_auto_run", display=WIN_TAG,
        x=col1_x, y=curr_y, width=btn_w * 2 + 6, height=32,
        text="🚀 Auto Run Stress",
        style={
            "background_color": "#7C3AED",
            "hover_background_color": "#8B5CF6",
            "color": "#FFFFFF",
            "font_size": 11,
            "bold": True,
            "border_radius": 6,
        },
        on_click=start_auto_benchmark,
    )

    # ── 7. Initialize Benchmark Systems ───────────────────────────────────────
    hud.init(fps_tracker, sys_metrics, app_state)

    # ── 8. Start Periodic Metrics Timer ───────────────────────────────────────
    _metrics_timer = Draw.every(METRICS_SAMPLE_INTERVAL, _update_metrics)

    print("Ready. Click sidebar buttons to activate features and stress tests.")
    print("UI built successfully.")


# ═══════════════════════════════════════════════════════════════════════════
#  Entry Point
# ═══════════════════════════════════════════════════════════════════════════

def main():
    build_ui()
    print("\n[OK] Draw-lib Ultimate Benchmark is running.")
    print("     Click sidebar buttons to toggle features.")
    print("     Click 'Auto Run' for full stress benchmark.\n")
    Draw.window.run(WIN_TAG)


if __name__ == "__main__":
    main()
