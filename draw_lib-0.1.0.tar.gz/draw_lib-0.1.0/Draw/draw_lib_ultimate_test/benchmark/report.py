"""
Draw-lib Ultimate Benchmark — Report Generator
===============================================
Saves benchmark results to JSON and compares across runs.
"""
import json
import os
import sys
import time
import platform
from datetime import datetime


REPORT_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "benchmark_results.json"
)


def _load_existing():
    """Load existing results file if present."""
    if os.path.exists(REPORT_PATH):
        try:
            with open(REPORT_PATH, "r") as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            pass
    return {"runs": []}


def save_run(mode, results_list, version="0.1.0"):
    """
    Save a benchmark run.
    
    Parameters
    ----------
    mode : str
        "normal" or "stress"
    results_list : list[dict]
        List of result dicts, each with keys:
        object_count, avg_fps, min_fps, one_pct_low, point_one_pct_low,
        avg_frame_ms, max_frame_ms, cpu_percent, ram_mb,
        avg_render_ms, avg_update_ms
    version : str
        Library version tag.
    """
    data = _load_existing()
    
    run_entry = {
        "version": version,
        "mode": mode,
        "timestamp": datetime.now().isoformat(),
        "system": {
            "python": platform.python_version(),
            "platform": platform.platform(),
            "processor": platform.processor(),
        },
        "results": results_list,
    }
    
    data["runs"].append(run_entry)
    
    try:
        with open(REPORT_PATH, "w") as f:
            json.dump(data, f, indent=2)
        print(f"[Benchmark] Results saved to {REPORT_PATH}")
    except IOError as e:
        print(f"[Benchmark] Failed to save results: {e}")
    
    return run_entry


def print_results_table(results_list):
    """Pretty-print an ASCII table of benchmark results."""
    print()
    print("╔" + "═" * 62 + "╗")
    print("║" + "       DRAW-LIB BENCHMARK RESULTS".ljust(62) + "║")
    print("╠" + "═" * 62 + "╣")
    
    header = f"{'Objects':>10}  {'Avg FPS':>8}  {'Min FPS':>8}  {'1% Low':>7}  {'Frame ms':>9}  {'RAM MB':>7}"
    print("║ " + header.ljust(60) + " ║")
    print("║ " + "─" * 60 + " ║")
    
    for r in results_list:
        line = (
            f"{r.get('object_count', 0):>10,}  "
            f"{r.get('avg_fps', 0):>8.1f}  "
            f"{r.get('min_fps', 0):>8.1f}  "
            f"{r.get('one_pct_low', 0):>7.1f}  "
            f"{r.get('avg_frame_ms', 0):>9.2f}  "
            f"{r.get('ram_mb', 0):>7.1f}"
        )
        print("║ " + line.ljust(60) + " ║")
    
    print("╚" + "═" * 62 + "╝")
    print()


def compare_last_two_runs():
    """Compare the last two stress runs and print delta."""
    data = _load_existing()
    stress_runs = [r for r in data.get("runs", []) if r.get("mode") == "stress"]
    if len(stress_runs) < 2:
        print("[Benchmark] Need at least 2 stress runs for comparison.")
        return
    
    prev = stress_runs[-2]
    curr = stress_runs[-1]
    
    print(f"\n  Comparing: {prev['version']} ({prev['timestamp'][:10]})")
    print(f"       vs    {curr['version']} ({curr['timestamp'][:10]})")
    print("  " + "─" * 50)
    
    # Match by object count
    prev_by_count = {r["object_count"]: r for r in prev.get("results", [])}
    for r in curr.get("results", []):
        cnt = r["object_count"]
        if cnt in prev_by_count:
            p = prev_by_count[cnt]
            fps_delta = r["avg_fps"] - p["avg_fps"]
            sign = "+" if fps_delta >= 0 else ""
            print(f"  {cnt:>8,} objects: {r['avg_fps']:>7.1f} FPS ({sign}{fps_delta:.1f})")
