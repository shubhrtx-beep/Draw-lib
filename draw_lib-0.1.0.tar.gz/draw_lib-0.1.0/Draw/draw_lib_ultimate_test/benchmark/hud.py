"""
Draw-lib Ultimate Benchmark — HUD Text Bindings
================================================
Callable functions for live telemetry display.
"""

# These get set by main.py after tracker/metrics are created
_fps_tracker = None
_sys_metrics = None
_app_state = None


def init(fps_tracker, sys_metrics, app_state):
    """Wire up the global references."""
    global _fps_tracker, _sys_metrics, _app_state
    _fps_tracker = fps_tracker
    _sys_metrics = sys_metrics
    _app_state = app_state


def get_title_text():
    if not _fps_tracker:
        return "DRAW-LIB ULTIMATE BENCHMARK"
    fps = _fps_tracker.display_fps
    return f"DRAW-LIB ULTIMATE BENCHMARK                    FPS: {fps:.0f}"


def get_stats_text():
    if not _fps_tracker or not _sys_metrics:
        return "Loading..."
    cpu = _sys_metrics.cpu_percent
    ram = _sys_metrics.ram_mb
    objs = _sys_metrics.object_count
    frame_ms = _fps_tracker.avg_frame_ms
    render_ms = _fps_tracker.avg_render_ms
    mode = _app_state.get("mode", "normal") if _app_state else "normal"
    return (
        f"CPU: {cpu:.0f}%   RAM: {ram:.0f} MB   "
        f"Objects: {objs:,}   Frame: {frame_ms:.1f} ms   "
        f"Render: {render_ms:.1f} ms   Mode: {mode.upper()}"
    )


def get_detailed_text():
    if not _fps_tracker:
        return ""
    s = _fps_tracker.get_snapshot()
    return (
        f"Avg: {s['avg_fps']:.1f}  Min: {s['min_fps']:.1f}  "
        f"1%Low: {s['one_pct_low']:.1f}  0.1%Low: {s['point_one_pct_low']:.1f}  "
        f"Engine: {s['engine_fps']:.0f}"
    )
