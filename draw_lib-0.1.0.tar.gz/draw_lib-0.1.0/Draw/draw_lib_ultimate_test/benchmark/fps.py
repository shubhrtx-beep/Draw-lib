"""
Draw-lib Ultimate Benchmark — FPS Tracker
==========================================
High-precision rolling-window FPS measurement.
"""
import time
import collections


class FPSTracker:
    """Tracks frame timing with rolling window statistics."""
    
    def __init__(self, window_size=300):
        self.window_size = window_size
        self.frame_times = collections.deque(maxlen=window_size)
        self.render_times = collections.deque(maxlen=window_size)
        self.update_times = collections.deque(maxlen=window_size)
        self.event_times = collections.deque(maxlen=window_size)
        self.last_time = time.perf_counter()
        self.total_frames = 0
        
        # Cached stats (updated periodically)
        self._avg_fps = 0.0
        self._min_fps = 0.0
        self._one_pct_low = 0.0
        self._point_one_pct_low = 0.0
        self._avg_frame_ms = 0.0
        self._max_frame_ms = 0.0
        self._avg_render_ms = 0.0
        self._avg_update_ms = 0.0
        self._display_fps = 60.0
        self._engine_fps = 200.0
    
    def record_frame(self, render_ms=0.0, update_ms=0.0, event_ms=0.0):
        """Call once per frame with subsystem timings."""
        now = time.perf_counter()
        dt = now - self.last_time
        self.last_time = now
        self.total_frames += 1
        
        if 0.0005 < dt < 2.0:  # filter out garbage
            self.frame_times.append(dt)
            # Inline display FPS (immediate, like reference app)
            if len(self.frame_times) >= 5:
                avg_dt = sum(self.frame_times) / len(self.frame_times)
                self._display_fps = 1.0 / avg_dt
                self._avg_frame_ms = avg_dt * 1000.0

        if render_ms > 0.001:
            self.render_times.append(render_ms)
            # Inline engine FPS
            avg_render = sum(self.render_times) / len(self.render_times)
            self._engine_fps = 1000.0 / max(avg_render, 0.001)
            self._avg_render_ms = avg_render

        if update_ms > 0.001:
            self.update_times.append(update_ms)
        if event_ms > 0.001:
            self.event_times.append(event_ms)
        
        # Update detailed stats every 5 frames
        if self.total_frames % 5 == 0:
            self._update_stats()
    
    def _update_stats(self):
        """Recompute all stats from rolling windows."""
        if len(self.frame_times) < 5:
            return
        
        times = sorted(self.frame_times)
        n = len(times)
        
        avg_dt = sum(times) / n
        self._avg_fps = 1.0 / avg_dt if avg_dt > 0 else 0.0
        self._avg_frame_ms = avg_dt * 1000.0
        self._max_frame_ms = times[-1] * 1000.0
        
        # Min FPS = from worst frame time
        self._min_fps = 1.0 / times[-1] if times[-1] > 0 else 0.0
        
        # 1% low: average of worst 1% of frame times
        idx_1pct = max(1, int(n * 0.99))
        worst_1pct = times[idx_1pct:]
        if worst_1pct:
            avg_worst = sum(worst_1pct) / len(worst_1pct)
            self._one_pct_low = 1.0 / avg_worst if avg_worst > 0 else 0.0
        
        # 0.1% low: average of worst 0.1%
        idx_01pct = max(1, int(n * 0.999))
        worst_01pct = times[idx_01pct:]
        if worst_01pct:
            avg_worst01 = sum(worst_01pct) / len(worst_01pct)
            self._point_one_pct_low = 1.0 / avg_worst01 if avg_worst01 > 0 else 0.0
        
        # Display FPS (rolling 30-frame average)
        recent = list(self.frame_times)[-30:]
        if recent:
            self._display_fps = 1.0 / (sum(recent) / len(recent))
        
        # Engine FPS (from render times)
        if self.render_times:
            avg_render = sum(self.render_times) / len(self.render_times)
            self._engine_fps = 1000.0 / max(avg_render, 0.001)
            self._avg_render_ms = avg_render
        
        if self.update_times:
            self._avg_update_ms = sum(self.update_times) / len(self.update_times)
    
    @property
    def display_fps(self):
        return self._display_fps
    
    @property
    def avg_fps(self):
        return self._avg_fps
    
    @property
    def min_fps(self):
        return self._min_fps
    
    @property
    def one_pct_low(self):
        return self._one_pct_low
    
    @property
    def point_one_pct_low(self):
        return self._point_one_pct_low
    
    @property
    def avg_frame_ms(self):
        return self._avg_frame_ms
    
    @property
    def max_frame_ms(self):
        return self._max_frame_ms
    
    @property
    def avg_render_ms(self):
        return self._avg_render_ms
    
    @property
    def avg_update_ms(self):
        return self._avg_update_ms
    
    @property
    def engine_fps(self):
        return self._engine_fps
    
    def get_fps_history(self, count=120):
        """Return last N instantaneous FPS values for graphing."""
        recent = list(self.frame_times)[-count:]
        return [1.0 / dt if dt > 0 else 0.0 for dt in recent]
    
    def get_snapshot(self):
        """Return a dict of all current metrics."""
        self._update_stats()
        return {
            "avg_fps": round(self._avg_fps, 1),
            "min_fps": round(self._min_fps, 1),
            "one_pct_low": round(self._one_pct_low, 1),
            "point_one_pct_low": round(self._point_one_pct_low, 1),
            "avg_frame_ms": round(self._avg_frame_ms, 2),
            "max_frame_ms": round(self._max_frame_ms, 2),
            "avg_render_ms": round(self._avg_render_ms, 2),
            "avg_update_ms": round(self._avg_update_ms, 2),
            "engine_fps": round(self._engine_fps, 1),
            "total_frames": self.total_frames,
        }
    
    def reset(self):
        """Clear all data for a fresh benchmark run."""
        self.frame_times.clear()
        self.render_times.clear()
        self.update_times.clear()
        self.event_times.clear()
        self.total_frames = 0
        self.last_time = time.perf_counter()
        self._avg_fps = 0.0
        self._min_fps = 0.0
        self._one_pct_low = 0.0
        self._point_one_pct_low = 0.0
        self._avg_frame_ms = 0.0
        self._max_frame_ms = 0.0
        self._avg_render_ms = 0.0
        self._avg_update_ms = 0.0
        self._display_fps = 60.0
        self._engine_fps = 200.0
