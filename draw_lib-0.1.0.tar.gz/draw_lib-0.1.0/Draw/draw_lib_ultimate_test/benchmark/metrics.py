"""
Draw-lib Ultimate Benchmark — System Metrics
=============================================
CPU, RAM, and object count measurement.
"""
import os
import time

try:
    import psutil
    _HAS_PSUTIL = True
except ImportError:
    _HAS_PSUTIL = False


class SystemMetrics:
    """Measures CPU and RAM usage."""
    
    def __init__(self):
        self._cpu_percent = 0.0
        self._ram_mb = 0.0
        self._object_count = 0
        self._last_sample = 0.0
        self._process = None
        if _HAS_PSUTIL:
            try:
                self._process = psutil.Process(os.getpid())
                self._process.cpu_percent()  # prime the counter
            except Exception:
                self._process = None
    
    def sample(self):
        """Take a CPU/RAM sample. Call periodically (e.g., every 1s)."""
        now = time.perf_counter()
        if now - self._last_sample < 0.5:
            return
        self._last_sample = now
        
        if self._process and _HAS_PSUTIL:
            try:
                self._cpu_percent = self._process.cpu_percent()
                mem = self._process.memory_info()
                self._ram_mb = mem.rss / (1024 * 1024)
            except Exception:
                pass
        else:
            # Fallback: no psutil
            self._cpu_percent = 0.0
            self._ram_mb = 0.0
    
    @property
    def cpu_percent(self):
        return self._cpu_percent
    
    @property
    def ram_mb(self):
        return self._ram_mb
    
    @property
    def object_count(self):
        return self._object_count
    
    @object_count.setter
    def object_count(self, val):
        self._object_count = val
    
    def get_snapshot(self):
        return {
            "cpu_percent": round(self._cpu_percent, 1),
            "ram_mb": round(self._ram_mb, 1),
            "object_count": self._object_count,
        }
