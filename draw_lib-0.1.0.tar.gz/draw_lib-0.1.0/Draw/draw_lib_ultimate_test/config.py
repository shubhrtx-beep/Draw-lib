"""
Draw-lib Ultimate Benchmark — Configuration
============================================
Central configuration for all test parameters, stress levels,
color palettes, layout constants, and z-layer assignments.
"""

# ── Window ────────────────────────────────────────────────────────────────
WIN_TAG = "bench"
WIN_TITLE = "Draw-lib Ultimate Benchmark"
WIN_W = 1400
WIN_H = 900
WIN_BG = "#0A0E17"

# ── Layout Regions ────────────────────────────────────────────────────────
HEADER_H = 70
SIDEBAR_W = 150
FOOTER_H = 160  # FPS graph area
CONTENT_X = SIDEBAR_W + 10
CONTENT_Y = HEADER_H + 10
CONTENT_W = WIN_W - SIDEBAR_W - 30
CONTENT_H = WIN_H - HEADER_H - FOOTER_H - 30

# ── Color Palette ─────────────────────────────────────────────────────────
PALETTE = [
    "#38BDF8",  # Sky Blue
    "#34D399",  # Emerald
    "#F472B6",  # Pink
    "#FBBF24",  # Amber
    "#A78BFA",  # Violet
    "#FB7185",  # Rose
    "#2DD4BF",  # Teal
    "#F97316",  # Orange
    "#818CF8",  # Indigo
    "#4ADE80",  # Light Green
    "#C084FC",  # Purple
    "#E879F9",  # Fuchsia
]

# UI Colors
UI_BG_DARK = "#111827"
UI_BG_CARD = "#1F2937"
UI_BORDER = "#374151"
UI_TEXT_PRIMARY = "#F9FAFB"
UI_TEXT_SECONDARY = "#9CA3AF"
UI_TEXT_ACCENT = "#60A5FA"
UI_TEXT_SUCCESS = "#10B981"
UI_TEXT_WARNING = "#FBBF24"
UI_TEXT_DANGER = "#EF4444"

# Button Styles
BTN_STYLE_PRIMARY = {
    "background_color": "#059669",
    "hover_background_color": "#10B981",
    "color": "#FFFFFF",
    "font_size": 11,
    "bold": True,
    "border_radius": 6,
}
BTN_STYLE_SECONDARY = {
    "background_color": "#1F2937",
    "hover_background_color": "#374151",
    "color": "#E5E7EB",
    "font_size": 11,
    "border_radius": 6,
}
BTN_STYLE_DANGER = {
    "background_color": "#DC2626",
    "hover_background_color": "#EF4444",
    "color": "#FFFFFF",
    "font_size": 11,
    "bold": True,
    "border_radius": 6,
}
BTN_STYLE_ACCENT = {
    "background_color": "#2563EB",
    "hover_background_color": "#3B82F6",
    "color": "#FFFFFF",
    "font_size": 11,
    "bold": True,
    "border_radius": 6,
}

# ── Z-Layer Assignments ──────────────────────────────────────────────────
Z_BACKGROUND = 100
Z_PANELS = 85
Z_STRESS_SHAPES_MIN = 15
Z_STRESS_SHAPES_MAX = 65
Z_TEST_SHAPES = 40
Z_UI_CONTROLS = 5
Z_HUD = 0

# ── Stress Levels ────────────────────────────────────────────────────────
STRESS_LEVELS = [100, 500, 1000, 5000, 10000, 25000, 50000, 100000]
DEFAULT_NORMAL_OBJECTS = 500
AUTO_BENCH_DURATION_S = 5  # seconds per stress level during auto-run

# ── Benchmark ─────────────────────────────────────────────────────────────
FPS_HISTORY_SIZE = 300       # rolling window for FPS stats
FPS_GRAPH_POINTS = 120       # data points shown in FPS graph
METRICS_SAMPLE_INTERVAL = 1.0  # seconds between CPU/RAM samples

# ── Shape Generation Bounds (within content area) ────────────────────────
SHAPE_MIN_SIZE = 16
SHAPE_MAX_SIZE = 64
SHAPE_MIN_X = CONTENT_X + 10
SHAPE_MAX_X = CONTENT_X + CONTENT_W - 70
SHAPE_MIN_Y = CONTENT_Y + 10
SHAPE_MAX_Y = CONTENT_Y + CONTENT_H - 70

# ── Test Mode ─────────────────────────────────────────────────────────────
MODE_NORMAL = "normal"
MODE_STRESS = "stress"
