"""
Draw-lib Ultimate Benchmark — Event Stress
==========================================
Registers mass senses on stress shapes to test event throughput.
"""
import sys
sys.path.insert(0, r'd:/pg/draw2')

import Draw

_sense_ids = []
_event_count = 0


def _on_event(rec):
    """Lightweight event counter callback."""
    global _event_count
    _event_count += 1


def register_events(ips, max_senses=500):
    """
    Register hover senses on up to `max_senses` shapes.
    More than ~500 senses can slow down event dispatch significantly,
    so we cap it for realistic testing.
    """
    global _event_count
    _event_count = 0
    
    subset = ips[:max_senses]
    
    for ip in subset:
        try:
            sense_id = f"sense_{ip}"
            sense = Draw.senses("mouse_hover", ip=ip, id=sense_id)
            Draw.connectors(sense=sense, work=_on_event)
            _sense_ids.append(sense_id)
        except Exception:
            pass


def get_event_count():
    return _event_count


def reset_counter():
    global _event_count
    _event_count = 0
