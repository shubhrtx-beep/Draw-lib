"""
Draw-lib Ultimate Benchmark — Animation Stress
===============================================
Attaches motion animations to stress objects.
Matches the proven reference pattern: move + rotate only.
"""
import sys
sys.path.insert(0, r'd:/pg/draw2')

import random
import Draw

from draw_lib_ultimate_test.config import (
    SHAPE_MIN_X, SHAPE_MAX_X,
    SHAPE_MIN_Y, SHAPE_MAX_Y,
)


def animate_objects(ips):
    """Attach move + rotate motion to a list of shape IPs."""
    min_x = SHAPE_MIN_X
    max_x = SHAPE_MAX_X
    min_y = SHAPE_MIN_Y
    max_y = SHAPE_MAX_Y

    easing_options = ["ease_in_out", "ease_out", "linear"]

    for ip in ips:
        x0 = random.randint(min_x, max_x)
        y0 = random.randint(min_y, max_y)
        x1 = random.randint(min_x, max_x)
        y1 = random.randint(min_y, max_y)
        move_dur = random.uniform(3.0, 8.0)
        rot_dur = random.uniform(2.0, 6.0)
        ease = random.choice(easing_options)

        try:
            Draw.motion(
                ip=ip,
                motion=[
                    {
                        "type": "move",
                        "from": [x0, y0],
                        "to": [x1, y1],
                        "time": {"start": 0.0, "end": move_dur},
                        "repeat": True,
                        "pingpong": True,
                        "ease": ease,
                    },
                    {
                        "type": "rotate",
                        "from": 0.0,
                        "to": 360.0 if random.random() > 0.5 else -360.0,
                        "time": {"start": 0.0, "end": rot_dur},
                        "repeat": True,
                    },
                ]
            )
        except Exception:
            pass

