"""
Draw-lib Ultimate Benchmark — Object Spawner
=============================================
Spawns and manages large numbers of shapes for stress testing.
"""
import sys
sys.path.insert(0, r'd:/pg/draw2')

import random
import Draw

from draw_lib_ultimate_test.config import (
    WIN_TAG, PALETTE,
    Z_STRESS_SHAPES_MIN, Z_STRESS_SHAPES_MAX,
    SHAPE_MIN_SIZE, SHAPE_MAX_SIZE,
    SHAPE_MIN_X, SHAPE_MAX_X,
    SHAPE_MIN_Y, SHAPE_MAX_Y,
)

# Track all spawned stress shape IPs
_stress_ips = []
_total_spawned = 0


def spawn_objects(count, tag=WIN_TAG):
    """Spawn `count` random shapes into the canvas."""
    global _total_spawned
    
    shapes = []
    for i in range(count):
        idx = _total_spawned + i
        ip = f"stress_{idx}"
        
        w = random.randint(SHAPE_MIN_SIZE, SHAPE_MAX_SIZE)
        h = random.randint(SHAPE_MIN_SIZE, SHAPE_MAX_SIZE)
        x = random.randint(SHAPE_MIN_X, SHAPE_MAX_X)
        y = random.randint(SHAPE_MIN_Y, SHAPE_MAX_Y)
        color = random.choice(PALETTE)
        verts = random.choice([4, 4, 4, 3, 6, 8])  # mostly rects
        z = random.randint(Z_STRESS_SHAPES_MIN, Z_STRESS_SHAPES_MAX)
        opacity = random.randint(60, 95)
        radius = random.choice([0, 0, 4, 8, 12])
        rotation = random.uniform(0, 360)
        
        shapes.append({
            "ip": ip,
            "vertices": verts,
            "size": [w, h],
            "x": x,
            "y": y,
            "color": color,
            "border_radius": radius,
            "rotation": rotation,
            "z": z,
            "opacity": opacity,
            "border_color": "rgba(255,255,255,0.15)",
            "border_width": 1,
        })
        _stress_ips.append(ip)
    
    _total_spawned += count
    
    # Batch create all shapes in one call
    Draw.shape(display=tag, shape=shapes)
    
    return [s["ip"] for s in shapes]


def clear_objects(tag=WIN_TAG):
    """Remove all stress-test shapes."""
    global _total_spawned
    for ip in _stress_ips:
        try:
            Draw.shapes.remove(ip)
        except Exception:
            pass
    _stress_ips.clear()
    _total_spawned = 0


def get_count():
    """Return current number of stress shapes."""
    return len(_stress_ips)


def get_ips():
    """Return list of all active stress shape IPs."""
    return list(_stress_ips)
