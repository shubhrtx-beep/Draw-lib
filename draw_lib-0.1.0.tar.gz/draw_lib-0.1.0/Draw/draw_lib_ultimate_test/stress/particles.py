"""
Draw-lib Ultimate Benchmark — Particle System
==============================================
Small fast-moving particle circles for rendering stress.
"""
import sys
sys.path.insert(0, r'd:/pg/draw2')

import random
import Draw

from draw_lib_ultimate_test.config import (
    WIN_TAG, PALETTE,
    CONTENT_X, CONTENT_Y, CONTENT_W, CONTENT_H,
)

_particle_ips = []
_particle_count = 0


def spawn_particles(count, tag=WIN_TAG):
    """Spawn small fast-moving particle circles."""
    global _particle_count
    
    shapes = []
    cx = CONTENT_X + CONTENT_W // 2
    cy = CONTENT_Y + CONTENT_H // 2
    
    for i in range(count):
        idx = _particle_count + i
        ip = f"particle_{idx}"
        sz = random.randint(6, 16)
        # Spawn from center with random offset
        x = cx + random.randint(-100, 100)
        y = cy + random.randint(-100, 100)
        color = random.choice(PALETTE)
        
        shapes.append({
            "ip": ip,
            "vertices": 4,
            "size": [sz, sz],
            "x": x,
            "y": y,
            "color": color,
            "border_radius": sz // 2,  # circle
            "z": random.randint(20, 50),
            "opacity": random.randint(50, 90),
        })
        _particle_ips.append(ip)
    
    _particle_count += count
    Draw.shape(display=tag, shape=shapes)
    
    # Attach motion to each particle
    min_x = CONTENT_X + 20
    max_x = CONTENT_X + CONTENT_W - 40
    min_y = CONTENT_Y + 20
    max_y = CONTENT_Y + CONTENT_H - 40
    
    for s in shapes:
        ip = s["ip"]
        tx = random.randint(min_x, max_x)
        ty = random.randint(min_y, max_y)
        dur = random.uniform(1.5, 5.0)
        
        Draw.motion(
            ip=ip,
            motion=[
                {
                    "type": "move",
                    "from": [s["x"], s["y"]],
                    "to": [tx, ty],
                    "time": {"start": 0, "end": dur},
                    "repeat": True,
                    "pingpong": True,
                    "ease": random.choice(["ease_in_out", "linear", "ease_out"]),
                },
            ]
        )
    
    return [s["ip"] for s in shapes]


def clear_particles(tag=WIN_TAG):
    """Remove all particles."""
    global _particle_count
    for ip in _particle_ips:
        try:
            Draw.shapes.remove(ip)
        except Exception:
            pass
    _particle_ips.clear()
    _particle_count = 0


def get_count():
    return len(_particle_ips)
