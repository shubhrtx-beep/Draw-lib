"""
Draw-lib Ultimate Benchmark — Image Test
=========================================
Tests Draw.image with a procedurally generated test image.
"""
import sys
sys.path.insert(0, r'd:/pg/draw2')

import os
import Draw
from draw_lib_ultimate_test.config import (
    WIN_TAG, CONTENT_X, CONTENT_Y, Z_TEST_SHAPES,
)

_active = False
_TEST_IMG_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "assets", "images", "test_gradient.png"
)


def _generate_test_image():
    """Generate a simple gradient test image using raw bytes."""
    if os.path.exists(_TEST_IMG_PATH):
        return
    
    try:
        # Try PIL first
        from PIL import Image as PILImage
        img = PILImage.new("RGB", (128, 128))
        pixels = img.load()
        for y in range(128):
            for x in range(128):
                r = int(x * 2)
                g = int(y * 2)
                b = 128
                pixels[x, y] = (r, g, b)
        os.makedirs(os.path.dirname(_TEST_IMG_PATH), exist_ok=True)
        img.save(_TEST_IMG_PATH)
    except ImportError:
        # Fallback: create a minimal BMP
        _create_minimal_bmp()


def _create_minimal_bmp():
    """Create a tiny BMP file without any dependencies."""
    import struct
    w, h = 64, 64
    row_size = (w * 3 + 3) & ~3
    pixel_size = row_size * h
    file_size = 54 + pixel_size
    
    os.makedirs(os.path.dirname(_TEST_IMG_PATH), exist_ok=True)
    bmp_path = _TEST_IMG_PATH.replace(".png", ".bmp")
    
    with open(bmp_path, "wb") as f:
        # BMP header
        f.write(b"BM")
        f.write(struct.pack("<I", file_size))
        f.write(struct.pack("<HH", 0, 0))
        f.write(struct.pack("<I", 54))
        # DIB header
        f.write(struct.pack("<I", 40))
        f.write(struct.pack("<i", w))
        f.write(struct.pack("<i", h))
        f.write(struct.pack("<HH", 1, 24))
        f.write(struct.pack("<I", 0))
        f.write(struct.pack("<I", pixel_size))
        f.write(struct.pack("<i", 2835))
        f.write(struct.pack("<i", 2835))
        f.write(struct.pack("<I", 0))
        f.write(struct.pack("<I", 0))
        # Pixel data (BGR, bottom-up)
        for y in range(h):
            row = bytearray()
            for x in range(w):
                b = 128
                g = int(y * 4)
                r = int(x * 4)
                row.extend([b, g, r])
            row.extend(b"\x00" * (row_size - w * 3))
            f.write(bytes(row))


def activate(tag=WIN_TAG):
    """Load and display test images."""
    global _active
    if _active:
        return
    _active = True
    
    _generate_test_image()
    
    bx = CONTENT_X + 20
    by = CONTENT_Y + 20
    
    # Determine which image file exists
    img_path = _TEST_IMG_PATH
    if not os.path.exists(img_path):
        img_path = _TEST_IMG_PATH.replace(".png", ".bmp")
    
    if os.path.exists(img_path):
        try:
            Draw.image(
                display=tag, ip="test_img_1",
                src=img_path, size=[120, 120],
                x=bx, y=by,
            )
            # Second instance at different size
            Draw.image(
                display=tag, ip="test_img_2",
                src=img_path, size=[80, 80],
                x=bx + 140, y=by + 20,
            )
        except Exception as e:
            print(f"[Image Test] Error: {e}")
            # Fallback: show a colored rect as placeholder
            Draw.shape(display=tag, shape=[{
                "ip": "test_img_placeholder", "vertices": 4,
                "size": [120, 120], "x": bx, "y": by,
                "color": "#334155", "border_width": 2,
                "border_color": "#64748B", "z": Z_TEST_SHAPES,
            }])
    else:
        print("[Image Test] No test image available")


def deactivate(tag=WIN_TAG):
    global _active
    for ip in ["test_img_1", "test_img_2", "test_img_placeholder"]:
        try:
            Draw.shapes.remove(ip)
        except Exception:
            pass
    _active = False
