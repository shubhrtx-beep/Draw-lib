"""
Draw-lib Ultimate Benchmark — Layout Test
===========================================
Tests Draw.room relative layouts and Draw.table grids.
"""
import sys
sys.path.insert(0, r'd:/pg/draw2')

import Draw
from draw_lib_ultimate_test.config import (
    WIN_TAG, PALETTE, CONTENT_X, CONTENT_Y, Z_TEST_SHAPES,
    UI_TEXT_PRIMARY,
)

_active = False
_layout_ips = []


def activate(tag=WIN_TAG):
    """Create shapes positioned via room layout."""
    global _active
    if _active:
        return
    _active = True

    bx = CONTENT_X + 20
    by = CONTENT_Y + 20

    # Create a set of shapes that will be positioned by room
    cards = [
        {"ip": "layout_card_1", "color": PALETTE[0], "size": [180, 120]},
        {"ip": "layout_card_2", "color": PALETTE[1], "size": [180, 120]},
        {"ip": "layout_card_3", "color": PALETTE[2], "size": [180, 120]},
        {"ip": "layout_card_4", "color": PALETTE[3], "size": [180, 120]},
    ]

    shapes = []
    for i, card in enumerate(cards):
        col = i % 2
        row = i // 2
        x = bx + col * 200
        y = by + row * 140

        shapes.append({
            "ip": card["ip"], "vertices": 4,
            "size": card["size"], "x": x, "y": y,
            "color": card["color"], "border_radius": 10,
            "border_width": 1, "border_color": "rgba(255,255,255,0.2)",
            "z": Z_TEST_SHAPES,
        })
        _layout_ips.append(card["ip"])

        # Card title text
        Draw.text(tag=tag, text=f"Card {i + 1}", customise={
            "x": x + 15, "y": y + 15, "font_size": 15,
            "bold": True, "color": "white", "z": Z_TEST_SHAPES - 1,
        })
        Draw.text(tag=tag, text=f"Room layout item", customise={
            "x": x + 15, "y": y + 40, "font_size": 11,
            "color": "rgba(255,255,255,0.7)", "z": Z_TEST_SHAPES - 1,
        })

    Draw.shape(display=tag, shape=shapes)

    # Try applying room layout
    try:
        Draw.room(
            display=tag,
            scene={
                "layout_card_1": "top",
                "layout_card_2": ["layout_card_1", "right", 20],
            },
            general={"padding": 10},
        )
    except Exception as e:
        print(f"[Layout Test] Room layout note: {e}")

    # Table grid demonstration
    try:
        Draw.table(
            ip="layout_table",
            display=tag,
            rows=2,
            columns=3,
            margin=10,
            padding=5,
            show_lines=True,
            line_color="#333333",
        )
    except Exception:
        pass


def deactivate(tag=WIN_TAG):
    global _active
    for ip in _layout_ips:
        try:
            Draw.shapes.remove(ip)
        except Exception:
            pass
    _layout_ips.clear()
    _active = False
