"""
Draw-lib Ultimate Benchmark — Mouse Interaction Test
=====================================================
Tests click, hover, drag senses and connectors.
"""
import sys
sys.path.insert(0, r'd:/pg/draw2')

import time
import Draw
from draw_lib_ultimate_test.config import (
    WIN_TAG, PALETTE, CONTENT_X, CONTENT_Y, Z_TEST_SHAPES,
    UI_TEXT_PRIMARY,
)

_active = False
_click_count = 0
_last_hover_ip = ""


def _on_click(rec):
    global _click_count
    _click_count += 1


def _mouse_status():
    return f"Clicks: {_click_count}  Last hover: {_last_hover_ip}"


def activate(tag=WIN_TAG):
    """Create interactive shapes with mouse senses."""
    global _active, _click_count
    if _active:
        return
    _active = True
    _click_count = 0

    bx = CONTENT_X + 20
    by = CONTENT_Y + 20

    # Clickable shapes
    colors = [PALETTE[0], PALETTE[2], PALETTE[4], PALETTE[6]]
    for i, c in enumerate(colors):
        ip = f"mouse_click_{i}"
        Draw.shape(display=tag, shape=[{
            "ip": ip, "vertices": 4,
            "size": [70, 50], "x": bx + i * 90, "y": by,
            "color": c, "border_radius": 8, "z": Z_TEST_SHAPES,
            "border_width": 2, "border_color": "white",
        }])

        try:
            sense = Draw.senses("mouse_click", ip=ip, id=f"sense_click_{i}")
            Draw.connectors(sense=sense, work=_on_click)
        except Exception:
            pass

    # Draggable shape
    Draw.shape(display=tag, shape=[{
        "ip": "mouse_drag_target", "vertices": 4,
        "size": [80, 80], "x": bx, "y": by + 80,
        "color": PALETTE[3], "border_radius": 12,
        "z": Z_TEST_SHAPES - 1,
        "border_width": 2, "border_color": PALETTE[3],
    }])
    Draw.text(tag=tag, text="Drag me", customise={
        "x": bx + 12, "y": by + 108, "font_size": 12,
        "color": "white", "z": Z_TEST_SHAPES - 2,
    })

    try:
        drag_sense = Draw.senses("drag_move", ip="mouse_drag_target",
                                  id="sense_drag_main")
        Draw.connectors(sense=drag_sense, work=lambda rec: None)
    except Exception:
        pass

    # Status text
    Draw.text(tag=tag, text=_mouse_status, customise={
        "x": bx, "y": by + 180, "font_size": 13,
        "color": UI_TEXT_PRIMARY, "z": Z_TEST_SHAPES,
    })

    # Hover indicator shape
    Draw.shape(display=tag, shape=[{
        "ip": "mouse_hover_indicator", "vertices": 4,
        "size": [30, 30], "x": bx + 200, "y": by + 100,
        "color": PALETTE[8], "border_radius": 15,
        "z": Z_TEST_SHAPES, "opacity": 50,
    }])


def deactivate(tag=WIN_TAG):
    global _active
    ips = [f"mouse_click_{i}" for i in range(4)]
    ips += ["mouse_drag_target", "mouse_hover_indicator"]
    for ip in ips:
        try:
            Draw.shapes.remove(ip)
        except Exception:
            pass
    _active = False
