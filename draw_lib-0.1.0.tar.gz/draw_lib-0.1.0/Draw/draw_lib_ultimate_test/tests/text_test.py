"""
Draw-lib Ultimate Benchmark — Text Test
========================================
Tests text rendering: styled, glowing, shadow, callable/live, multi-line.
"""
import sys
sys.path.insert(0, r'd:/pg/draw2')

import time
import Draw
from draw_lib_ultimate_test.config import (
    WIN_TAG, PALETTE, CONTENT_X, CONTENT_Y, Z_TEST_SHAPES,
    UI_TEXT_PRIMARY, UI_TEXT_ACCENT,
)

_active = False


def _dynamic_text():
    """Callable text that updates every frame."""
    t = time.time() % 100
    return f"Dynamic: {t:.1f}s"


def activate(tag=WIN_TAG):
    """Create various text demonstrations."""
    global _active
    if _active:
        return
    _active = True
    
    bx = CONTENT_X + 20
    by = CONTENT_Y + 20
    
    # Basic text
    Draw.text(tag=tag, text="Bold Title Text", customise={
        "x": bx, "y": by, "font_size": 22, "bold": True,
        "color": UI_TEXT_PRIMARY, "z": Z_TEST_SHAPES,
    })
    
    # Italic smaller text
    Draw.text(tag=tag, text="Italic subtitle with spacing", customise={
        "x": bx, "y": by + 35, "font_size": 14, "italic": True,
        "color": UI_TEXT_ACCENT, "letter_spacing": 2, "z": Z_TEST_SHAPES,
    })
    
    # Glow text
    Draw.text(tag=tag, text="✨ Glowing Text", customise={
        "x": bx, "y": by + 65, "font_size": 18, "bold": True,
        "color": PALETTE[0], "glow": True, "glow_color": PALETTE[0],
        "glow_radius": 12, "z": Z_TEST_SHAPES,
    })
    
    # Shadow text
    Draw.text(tag=tag, text="Shadow Text", customise={
        "x": bx + 250, "y": by, "font_size": 20, "bold": True,
        "color": "white", "shadow": True, "shadow_color": "black",
        "shadow_offset": (3, 3), "z": Z_TEST_SHAPES,
    })
    
    # Background box text
    Draw.text(tag=tag, text="Label with BG", customise={
        "x": bx + 250, "y": by + 40, "font_size": 13,
        "color": "white", "background_color": PALETTE[4],
        "background_padding": 8, "border_radius": 6, "z": Z_TEST_SHAPES,
    })
    
    # Multi-line text
    Draw.text(tag=tag, text="Line 1\nLine 2\nLine 3", customise={
        "x": bx + 250, "y": by + 80, "font_size": 13,
        "color": UI_TEXT_PRIMARY, "line_height": 1.5, "z": Z_TEST_SHAPES,
    })
    
    # Callable dynamic text
    Draw.text(tag=tag, text=_dynamic_text, customise={
        "x": bx, "y": by + 100, "font_size": 15, "bold": True,
        "color": PALETTE[1], "z": Z_TEST_SHAPES,
    })
    
    # Different font sizes in a row
    sizes = [10, 14, 18, 24, 32]
    for i, sz in enumerate(sizes):
        Draw.text(tag=tag, text=f"{sz}px", customise={
            "x": bx + i * 70, "y": by + 140,
            "font_size": sz, "color": PALETTE[i % len(PALETTE)],
            "z": Z_TEST_SHAPES,
        })


def deactivate(tag=WIN_TAG):
    """Text items persist; flag as inactive."""
    global _active
    _active = False
