"""
Draw-lib Ultimate Benchmark — Animation Test
=============================================
Tests motion: move, rotate, scale, opacity, spring, orbit, shake, wave.
"""
import sys
sys.path.insert(0, r'd:/pg/draw2')

import random
import Draw
from draw_lib_ultimate_test.config import (
    WIN_TAG, PALETTE, CONTENT_X, CONTENT_Y, Z_TEST_SHAPES,
)

_active_ips = []


def activate(tag=WIN_TAG):
    """Create animated shapes demonstrating various motion types."""
    deactivate(tag)

    bx = CONTENT_X + 20
    by = CONTENT_Y + 20

    # 1. Move animation (pingpong)
    Draw.shape(display=tag, shape=[{
        "ip": "anim_move", "vertices": 4,
        "size": [50, 50], "x": bx, "y": by,
        "color": PALETTE[0], "border_radius": 8, "z": Z_TEST_SHAPES,
    }])
    _active_ips.append("anim_move")
    Draw.motion(ip="anim_move", motion=[{
        "type": "move",
        "from": [bx, by], "to": [bx + 300, by],
        "time": {"start": 0, "end": 3.0},
        "repeat": True, "pingpong": True, "ease": "ease_in_out",
    }])

    # 2. Rotation animation
    Draw.shape(display=tag, shape=[{
        "ip": "anim_rotate", "vertices": 4,
        "size": [45, 45], "x": bx + 400, "y": by,
        "color": PALETTE[1], "z": Z_TEST_SHAPES,
    }])
    _active_ips.append("anim_rotate")
    Draw.motion(ip="anim_rotate", motion=[{
        "type": "rotate",
        "from": 0, "to": 360,
        "time": {"start": 0, "end": 2.0},
        "repeat": True,
    }])

    # 3. Scale/expand animation
    Draw.shape(display=tag, shape=[{
        "ip": "anim_scale", "vertices": 4,
        "size": [40, 40], "x": bx + 500, "y": by,
        "color": PALETTE[2], "border_radius": 20, "z": Z_TEST_SHAPES,
    }])
    _active_ips.append("anim_scale")
    Draw.motion(ip="anim_scale", motion=[{
        "type": "scale",
        "from": [1.0, 1.0], "to": [1.8, 1.8],
        "time": {"start": 0, "end": 1.5},
        "repeat": True, "pingpong": True,
    }])

    # 4. Opacity animation
    Draw.shape(display=tag, shape=[{
        "ip": "anim_opacity", "vertices": 6,
        "size": [50, 50], "x": bx, "y": by + 80,
        "color": PALETTE[3], "z": Z_TEST_SHAPES,
    }])
    _active_ips.append("anim_opacity")
    Draw.motion(ip="anim_opacity", motion=[{
        "type": "opacity",
        "from": 20, "to": 100,
        "time": {"start": 0, "end": 2.0},
        "repeat": True, "pingpong": True,
    }])

    # 5. Spring motion
    Draw.shape(display=tag, shape=[{
        "ip": "anim_spring", "vertices": 4,
        "size": [40, 40], "x": bx + 150, "y": by + 80,
        "color": PALETTE[4], "border_radius": 6, "z": Z_TEST_SHAPES,
    }])
    _active_ips.append("anim_spring")
    Draw.motion(ip="anim_spring", motion=[{
        "type": "spring",
        "stiffness": 180, "damping": 12, "mass": 1.0,
        "from": [bx + 150, by + 80], "to": [bx + 350, by + 80],
        "time": {"start": 0, "end": 3.0},
        "repeat": True, "pingpong": True,
    }])

    # 6. Shake animation
    Draw.shape(display=tag, shape=[{
        "ip": "anim_shake", "vertices": 4,
        "size": [60, 40], "x": bx + 420, "y": by + 80,
        "color": PALETTE[5], "border_radius": 4, "z": Z_TEST_SHAPES,
    }])
    _active_ips.append("anim_shake")
    Draw.motion(ip="anim_shake", motion=[{
        "type": "shake",
        "intensity": 8, "frequency": 5,
        "time": {"start": 0, "end": 10.0},
        "repeat": True,
    }])

    # 7. Wave animation
    Draw.shape(display=tag, shape=[{
        "ip": "anim_wave", "vertices": 4,
        "size": [50, 50], "x": bx + 200, "y": by + 160,
        "color": PALETTE[6], "border_radius": 25, "z": Z_TEST_SHAPES,
    }])
    _active_ips.append("anim_wave")
    Draw.motion(ip="anim_wave", motion=[{
        "type": "wave",
        "amplitude": 40, "frequency": 1.5,
        "time": {"start": 0, "end": 5.0},
        "repeat": True,
    }])

    # 8. Multiple easing demonstrations
    easing_types = ["ease_in", "ease_out", "ease_in_out", "linear"]
    for i, ease in enumerate(easing_types):
        ip = f"anim_ease_{i}"
        y_pos = by + 240 + i * 35
        Draw.shape(display=tag, shape=[{
            "ip": ip, "vertices": 4,
            "size": [30, 24], "x": bx, "y": y_pos,
            "color": PALETTE[7 + i % len(PALETTE)], "border_radius": 4,
            "z": Z_TEST_SHAPES,
        }])
        _active_ips.append(ip)
        Draw.motion(ip=ip, motion=[{
            "type": "move",
            "from": [bx, y_pos], "to": [bx + 400, y_pos],
            "time": {"start": 0, "end": 2.5},
            "repeat": True, "pingpong": True, "ease": ease,
        }])


def deactivate(tag=WIN_TAG):
    """Remove all animation test shapes."""
    for ip in _active_ips:
        try:
            Draw.shapes.remove(ip)
        except Exception:
            pass
    _active_ips.clear()
