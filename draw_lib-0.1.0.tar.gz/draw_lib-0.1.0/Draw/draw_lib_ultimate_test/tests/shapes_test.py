"""
Draw-lib Ultimate Benchmark — Shapes Test
==========================================
Tests all shape types: rect, rounded rect, circle, triangle,
hexagon, polygon, lines, custom vertices, deformations.
"""
import sys
sys.path.insert(0, r'd:/pg/draw2')

import Draw
from draw_lib_ultimate_test.config import (
    WIN_TAG, PALETTE, CONTENT_X, CONTENT_Y, Z_TEST_SHAPES,
)

_active_ips = []


def activate(tag=WIN_TAG):
    """Create a variety of shapes demonstrating all shape features."""
    deactivate(tag)
    
    base_x = CONTENT_X + 20
    base_y = CONTENT_Y + 20
    
    shapes = [
        # Rectangle
        {
            "ip": "test_rect", "vertices": 4,
            "size": [80, 60], "x": base_x, "y": base_y,
            "color": PALETTE[0], "border_width": 2,
            "border_color": "white", "z": Z_TEST_SHAPES, "opacity": 90,
        },
        # Rounded rectangle
        {
            "ip": "test_rrect", "vertices": 4,
            "size": [80, 60], "x": base_x + 100, "y": base_y,
            "color": PALETTE[1], "border_radius": 16,
            "border_width": 1, "border_color": "white",
            "z": Z_TEST_SHAPES, "opacity": 85,
        },
        # Circle
        {
            "ip": "test_circle", "vertices": 4,
            "size": [60, 60], "x": base_x + 200, "y": base_y,
            "color": PALETTE[2], "border_radius": 30,
            "z": Z_TEST_SHAPES,
        },
        # Triangle
        {
            "ip": "test_tri", "vertices": 3,
            "size": [70, 70], "x": base_x + 280, "y": base_y,
            "color": PALETTE[3], "z": Z_TEST_SHAPES,
        },
        # Hexagon
        {
            "ip": "test_hex", "vertices": 6,
            "size": [65, 65], "x": base_x + 370, "y": base_y,
            "color": PALETTE[4], "z": Z_TEST_SHAPES,
        },
        # Octagon
        {
            "ip": "test_oct", "vertices": 8,
            "size": [60, 60], "x": base_x + 450, "y": base_y,
            "color": PALETTE[5], "z": Z_TEST_SHAPES,
        },
        # Shape with glow
        {
            "ip": "test_glow", "vertices": 4,
            "size": [70, 50], "x": base_x, "y": base_y + 90,
            "color": PALETTE[6], "glow_color": PALETTE[6],
            "glow_blur": 15, "border_radius": 8,
            "z": Z_TEST_SHAPES,
        },
        # Shape with shadow
        {
            "ip": "test_shadow", "vertices": 4,
            "size": [70, 50], "x": base_x + 100, "y": base_y + 90,
            "color": PALETTE[7], "shadow_color": "rgba(0,0,0,0.5)",
            "shadow_blur": 10, "shadow_offset": [4, 4],
            "border_radius": 8, "z": Z_TEST_SHAPES,
        },
        # Rotated shape
        {
            "ip": "test_rotated", "vertices": 4,
            "size": [60, 60], "x": base_x + 200, "y": base_y + 90,
            "color": PALETTE[8], "rotation": 45,
            "z": Z_TEST_SHAPES,
        },
        # Semi-transparent
        {
            "ip": "test_alpha", "vertices": 4,
            "size": [80, 60], "x": base_x + 290, "y": base_y + 90,
            "color": PALETTE[9], "opacity": 40,
            "border_width": 2, "border_color": PALETTE[9],
            "z": Z_TEST_SHAPES,
        },
        # Dashed border
        {
            "ip": "test_dashed", "vertices": 4,
            "size": [80, 50], "x": base_x + 400, "y": base_y + 90,
            "color": PALETTE[10], "border_width": 2,
            "border_color": "white", "border_style": "dashed",
            "z": Z_TEST_SHAPES,
        },
        # Shape with bend deformation
        {
            "ip": "test_bend", "vertices": 4,
            "size": [100, 60], "x": base_x, "y": base_y + 170,
            "color": PALETTE[11], "curve_mode": "bend_all",
            "bend_amount": 25, "z": Z_TEST_SHAPES,
        },
    ]
    
    _active_ips.extend([s["ip"] for s in shapes])
    Draw.shape(display=tag, shape=shapes)
    
    # Add vector lines via Draw.point
    try:
        Draw.point(
            tag=tag,
            graph=[1400, 900],
            points=[
                {
                    "path": f"{base_x},{base_y + 260} ; {base_x + 150},{base_y + 230} ; {base_x + 300},{base_y + 270} ; {base_x + 450},{base_y + 240}",
                    "colour": PALETTE[0],
                    "width": 2,
                    "edge": "curve",
                    "smooth": "40%",
                    "fill": False,
                },
                {
                    "path": f"{base_x},{base_y + 290} ; {base_x + 200},{base_y + 310} ; {base_x + 400},{base_y + 280}",
                    "colour": PALETTE[3],
                    "width": 1,
                    "edge": "straight",
                    "fill": False,
                },
            ]
        )
    except Exception:
        pass


def deactivate(tag=WIN_TAG):
    """Remove all test shapes."""
    for ip in _active_ips:
        try:
            Draw.shapes.remove(ip)
        except Exception:
            pass
    _active_ips.clear()
