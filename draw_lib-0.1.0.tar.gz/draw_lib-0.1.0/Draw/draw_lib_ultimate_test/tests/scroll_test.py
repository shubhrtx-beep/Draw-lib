"""
Draw-lib Ultimate Benchmark — Scroll Test
===========================================
Tests Draw.scroller for scrollable content areas.
"""
import sys
sys.path.insert(0, r'd:/pg/draw2')

import Draw
from draw_lib_ultimate_test.config import (
    WIN_TAG, PALETTE, CONTENT_X, CONTENT_Y,
    CONTENT_W, CONTENT_H, Z_TEST_SHAPES,
)

_active = False
_scroll_ips = []


def activate(tag=WIN_TAG):
    """Create a scrollable region with many items."""
    global _active
    if _active:
        return
    _active = True

    bx = CONTENT_X + 20
    by = CONTENT_Y + 20

    # Create a tall column of items that extends beyond visible area
    num_items = 20
    item_h = 40
    total_h = num_items * (item_h + 10)

    for i in range(num_items):
        ip = f"scroll_item_{i}"
        y_pos = by + i * (item_h + 10)
        color = PALETTE[i % len(PALETTE)]

        Draw.shape(display=tag, shape=[{
            "ip": ip, "vertices": 4,
            "size": [400, item_h], "x": bx, "y": y_pos,
            "color": color, "border_radius": 6,
            "opacity": 80, "z": Z_TEST_SHAPES,
        }])
        _scroll_ips.append(ip)

        Draw.text(tag=tag, text=f"Scroll Item #{i + 1}", customise={
            "x": bx + 15, "y": y_pos + 12, "font_size": 13,
            "color": "white", "bold": True, "z": Z_TEST_SHAPES - 1,
        })

    # Set up scroller if content exceeds view
    if total_h > CONTENT_H:
        try:
            Draw.scroller(
                ip="test_scroller",
                display=tag,
                scroll="vertical",
                max_y=total_h,
                speed=1.0,
            )
        except Exception as e:
            print(f"[Scroll Test] Scroller error: {e}")


def deactivate(tag=WIN_TAG):
    global _active
    for ip in _scroll_ips:
        try:
            Draw.shapes.remove(ip)
        except Exception:
            pass
    _scroll_ips.clear()

    try:
        Draw.scroller.remove("test_scroller")
    except Exception:
        pass
    _active = False
