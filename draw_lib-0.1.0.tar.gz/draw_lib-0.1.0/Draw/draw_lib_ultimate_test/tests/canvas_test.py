"""
Draw-lib Ultimate Benchmark — Canvas Test
==========================================
Tests Draw.point vector paths and Draw.screen display surfaces.
"""
import sys
sys.path.insert(0, r'd:/pg/draw2')

import Draw
from draw_lib_ultimate_test.config import (
    WIN_TAG, PALETTE, CONTENT_X, CONTENT_Y, Z_TEST_SHAPES,
)

_active = False


def activate(tag=WIN_TAG):
    """Create canvas/point path demonstrations."""
    global _active
    if _active:
        return
    _active = True
    
    bx = CONTENT_X + 20
    by = CONTENT_Y + 20
    
    # Curved path
    try:
        Draw.point(
            tag=tag,
            graph=[1400, 900],
            points=[
                {
                    "path": (
                        f"{bx},{by + 50} ; {bx + 80},{by} ; "
                        f"{bx + 160},{by + 80} ; {bx + 240},{by + 30} ; "
                        f"{bx + 320},{by + 70}"
                    ),
                    "colour": PALETTE[0],
                    "width": 3,
                    "edge": "curve",
                    "smooth": "50%",
                    "fill": False,
                },
                # Filled polygon path
                {
                    "path": (
                        f"{bx + 350},{by + 10} ; {bx + 420},{by + 60} ; "
                        f"{bx + 390},{by + 100} ; {bx + 330},{by + 80}"
                    ),
                    "colour": PALETTE[2],
                    "width": 2,
                    "edge": "straight",
                    "fill": True,
                    "fill_colour": PALETTE[2],
                    "opacity": 60,
                },
                # Straight grid lines
                {
                    "path": f"{bx},{by + 120} ; {bx + 450},{by + 120}",
                    "colour": "rgba(255,255,255,0.2)",
                    "width": 1,
                    "edge": "straight",
                },
                {
                    "path": f"{bx},{by + 150} ; {bx + 450},{by + 150}",
                    "colour": "rgba(255,255,255,0.2)",
                    "width": 1,
                    "edge": "straight",
                },
            ]
        )
    except Exception as e:
        print(f"[Canvas Test] Point path error: {e}")


def deactivate(tag=WIN_TAG):
    global _active
    _active = False
