"""
Draw-lib Ultimate Benchmark — Live/Reactive Test
==================================================
Tests Draw.live reactive variables, live text bindings,
and Draw.every scheduled updates.
"""
import sys
sys.path.insert(0, r'd:/pg/draw2')

import time
import random
import Draw
from draw_lib_ultimate_test.config import (
    WIN_TAG, PALETTE, CONTENT_X, CONTENT_Y, Z_TEST_SHAPES,
    UI_TEXT_PRIMARY, UI_TEXT_ACCENT,
)

_active = False
_timer_handle = None
_counter = 0
_live_shape_ips = []


def _counter_text():
    """Callable binding for live counter display."""
    return f"Live Counter: {_counter}"


def _time_text():
    """Callable binding for live time display."""
    t = time.time() % 1000
    return f"Time: {t:.2f}"


def _tick():
    """Periodic update for live test."""
    global _counter
    _counter += 1

    # Update live variable
    try:
        Draw.live.set("bench_counter", _counter)
        Draw.live.set("bench_random", random.randint(0, 100))
    except Exception:
        pass


def activate(tag=WIN_TAG):
    """Set up live/reactive demonstrations."""
    global _active, _timer_handle, _counter
    if _active:
        return
    _active = True
    _counter = 0

    bx = CONTENT_X + 20
    by = CONTENT_Y + 20

    # Title
    Draw.text(tag=tag, text="Live / Reactive System", customise={
        "x": bx, "y": by, "font_size": 18, "bold": True,
        "color": UI_TEXT_PRIMARY, "z": Z_TEST_SHAPES,
    })

    # Callable text — counter
    Draw.text(tag=tag, text=_counter_text, customise={
        "x": bx, "y": by + 35, "font_size": 15,
        "color": PALETTE[1], "z": Z_TEST_SHAPES,
    })

    # Callable text — time
    Draw.text(tag=tag, text=_time_text, customise={
        "x": bx, "y": by + 60, "font_size": 15,
        "color": PALETTE[0], "z": Z_TEST_SHAPES,
    })

    # Set initial live values
    Draw.live.set("bench_counter", 0)
    Draw.live.set("bench_random", 50)

    # Create shapes that will be updated by live system
    live_colors = [PALETTE[0], PALETTE[2], PALETTE[4], PALETTE[6], PALETTE[8]]
    for i, c in enumerate(live_colors):
        ip = f"live_shape_{i}"
        Draw.shape(display=tag, shape=[{
            "ip": ip, "vertices": 4,
            "size": [40, 40], "x": bx + i * 55, "y": by + 100,
            "color": c, "border_radius": 8,
            "opacity": 70, "z": Z_TEST_SHAPES,
        }])
        _live_shape_ips.append(ip)

    # Info text
    Draw.text(tag=tag, text="↑ Shapes updated via Draw.every()", customise={
        "x": bx, "y": by + 150, "font_size": 11,
        "color": "#9CA3AF", "z": Z_TEST_SHAPES,
    })

    # Start periodic updates
    _timer_handle = Draw.every(0.1, _tick)


def deactivate(tag=WIN_TAG):
    global _active, _timer_handle
    if _timer_handle:
        _timer_handle.stop()
        _timer_handle = None

    for ip in _live_shape_ips:
        try:
            Draw.shapes.remove(ip)
        except Exception:
            pass
    _live_shape_ips.clear()
    _active = False
