"""
Draw-lib Ultimate Benchmark — Keyboard Test
=============================================
Tests keyboard senses for key detection.
"""
import sys
sys.path.insert(0, r'd:/pg/draw2')

import Draw
from draw_lib_ultimate_test.config import (
    WIN_TAG, PALETTE, CONTENT_X, CONTENT_Y, Z_TEST_SHAPES,
    UI_TEXT_PRIMARY, UI_TEXT_ACCENT,
)

_active = False
_last_key = "none"


def _key_display():
    return f"Last key: {_last_key}"


def activate(tag=WIN_TAG):
    """Set up keyboard senses."""
    global _active
    if _active:
        return
    _active = True

    bx = CONTENT_X + 20
    by = CONTENT_Y + 20

    # Key display text
    Draw.text(tag=tag, text="Keyboard Test — Press any key", customise={
        "x": bx, "y": by, "font_size": 16, "bold": True,
        "color": UI_TEXT_PRIMARY, "z": Z_TEST_SHAPES,
    })

    Draw.text(tag=tag, text=_key_display, customise={
        "x": bx, "y": by + 30, "font_size": 14,
        "color": UI_TEXT_ACCENT, "z": Z_TEST_SHAPES,
    })

    # Keyboard shortcuts info
    shortcuts = [
        "Space → Toggle pause",
        "Escape → Clear all",
        "↑↓ → Adjust stress level",
    ]
    for i, s in enumerate(shortcuts):
        Draw.text(tag=tag, text=s, customise={
            "x": bx, "y": by + 65 + i * 22, "font_size": 12,
            "color": "#9CA3AF", "z": Z_TEST_SHAPES,
        })

    # Arrow key indicator shapes
    arrow_positions = {
        "key_up": (bx + 60, by + 150),
        "key_left": (bx + 20, by + 185),
        "key_down": (bx + 60, by + 185),
        "key_right": (bx + 100, by + 185),
    }
    arrows = {"key_up": "↑", "key_left": "←", "key_down": "↓", "key_right": "→"}

    for ip, (x, y) in arrow_positions.items():
        Draw.shape(display=tag, shape=[{
            "ip": ip, "vertices": 4,
            "size": [32, 28], "x": x, "y": y,
            "color": "#1F2937", "border_radius": 4,
            "border_width": 1, "border_color": "#4B5563",
            "z": Z_TEST_SHAPES,
        }])
        Draw.text(tag=tag, text=arrows[ip], customise={
            "x": x + 10, "y": y + 5, "font_size": 14,
            "color": "white", "z": Z_TEST_SHAPES - 1,
        })

    # Register key senses
    try:
        Draw.senses("key_press", id="sense_space", key=["space"])
        Draw.senses("key_press", id="sense_escape", key=["escape"])
        Draw.senses("key_press", id="sense_up", key=["up"])
        Draw.senses("key_press", id="sense_down", key=["down"])
    except Exception:
        pass


def deactivate(tag=WIN_TAG):
    global _active
    for ip in ["key_up", "key_left", "key_down", "key_right"]:
        try:
            Draw.shapes.remove(ip)
        except Exception:
            pass
    _active = False
