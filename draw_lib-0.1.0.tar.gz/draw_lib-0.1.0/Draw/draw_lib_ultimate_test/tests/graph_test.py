"""
Draw-lib Ultimate Benchmark — Graph Test
=========================================
Tests bar, line, pie, donut, and area charts.
"""
import sys
sys.path.insert(0, r'd:/pg/draw2')

import Draw
from draw_lib_ultimate_test.config import (
    WIN_TAG, PALETTE, CONTENT_X, CONTENT_Y, Z_TEST_SHAPES,
)

_active = False


def activate(tag=WIN_TAG):
    """Create multiple chart types."""
    global _active
    if _active:
        return
    _active = True
    
    bx = CONTENT_X + 20
    by = CONTENT_Y + 20
    
    # Bar chart
    Draw.graph(
        ip="test_bar_chart", type="bar", display=tag,
        graph=[
            {"label": "Q1", "value": 450, "color": PALETTE[0]},
            {"label": "Q2", "value": 720, "color": PALETTE[1]},
            {"label": "Q3", "value": 580, "color": PALETTE[2]},
            {"label": "Q4", "value": 910, "color": PALETTE[3]},
        ],
        x=bx, y=by, width=280, height=180,
        customise={"title": "Revenue", "show_values": True, "grid_lines": True},
    )
    
    # Line chart
    Draw.graph(
        ip="test_line_chart", type="line", display=tag,
        graph=[
            {"label": "Jan", "value": 30, "color": PALETTE[4]},
            {"label": "Feb", "value": 45, "color": PALETTE[4]},
            {"label": "Mar", "value": 38, "color": PALETTE[4]},
            {"label": "Apr", "value": 65, "color": PALETTE[4]},
            {"label": "May", "value": 52, "color": PALETTE[4]},
            {"label": "Jun", "value": 78, "color": PALETTE[4]},
        ],
        x=bx + 310, y=by, width=280, height=180,
        customise={"title": "Trend", "grid_lines": True},
    )
    
    # Pie chart
    Draw.graph(
        ip="test_pie_chart", type="pie", display=tag,
        graph=[
            {"label": "Desktop", "value": 55, "color": PALETTE[0]},
            {"label": "Mobile", "value": 30, "color": PALETTE[2]},
            {"label": "Tablet", "value": 15, "color": PALETTE[4]},
        ],
        x=bx, y=by + 210, width=180, height=180,
        customise={"title": "Platform"},
    )
    
    # Donut chart
    Draw.graph(
        ip="test_donut_chart", type="donut", display=tag,
        graph=[
            {"label": "Python", "value": 40, "color": PALETTE[1]},
            {"label": "JS", "value": 35, "color": PALETTE[3]},
            {"label": "Rust", "value": 25, "color": PALETTE[5]},
        ],
        x=bx + 200, y=by + 210, width=180, height=180,
        customise={"title": "Languages", "inner_radius": 50},
    )


def deactivate(tag=WIN_TAG):
    global _active
    chart_ips = ["test_bar_chart", "test_line_chart", "test_pie_chart", "test_donut_chart"]
    for ip in chart_ips:
        try:
            Draw.graph.clear(ip=ip)
        except Exception:
            pass
    _active = False
