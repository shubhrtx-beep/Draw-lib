"""
Draw-lib Ultimate Benchmark — Bar/Progress Test
================================================
Tests progressbar, slider widgets, and custom shape-based bars.
"""
import sys
sys.path.insert(0, r'd:/pg/draw2')

import Draw
from draw_lib_ultimate_test.config import (
    WIN_TAG, PALETTE, CONTENT_X, CONTENT_Y, Z_TEST_SHAPES,
    UI_TEXT_PRIMARY,
)

_active = False
_progress_val = 0
_timer_handle = None


def _tick_progress():
    """Animate the progress bar."""
    global _progress_val
    _progress_val = (_progress_val + 1) % 101
    try:
        Draw.widget.set_value("test_progress", _progress_val)
    except Exception:
        pass


def activate(tag=WIN_TAG):
    """Create progress bars and slider widgets."""
    global _active, _timer_handle
    if _active:
        return
    _active = True
    
    bx = CONTENT_X + 20
    by = CONTENT_Y + 20
    
    # Progress bar label
    Draw.text(tag=tag, text="Progress Bar:", customise={
        "x": bx, "y": by, "font_size": 13, "color": UI_TEXT_PRIMARY,
        "z": Z_TEST_SHAPES,
    })
    
    # Native progress bar
    Draw.widget(
        ip="test_progress", type="progressbar", display=tag,
        x=bx + 110, y=by - 2, width=250, height=22,
        value=0, min_val=0, max_val=100,
    )
    
    # Slider label
    Draw.text(tag=tag, text="Slider:", customise={
        "x": bx, "y": by + 40, "font_size": 13, "color": UI_TEXT_PRIMARY,
        "z": Z_TEST_SHAPES,
    })
    
    # Native slider
    Draw.widget(
        ip="test_slider", type="slider", display=tag,
        x=bx + 110, y=by + 38, width=250, height=22,
        value=50, min_val=0, max_val=100,
        on_change=lambda val: None,  # just tests the widget
    )
    
    # Custom shape-based progress bars (3 colored bars)
    bar_colors = [PALETTE[0], PALETTE[1], PALETTE[2]]
    bar_widths = [200, 150, 180]
    for i, (c, w) in enumerate(zip(bar_colors, bar_widths)):
        # Background track
        Draw.shape(display=tag, shape=[{
            "ip": f"bar_track_{i}", "vertices": 4,
            "size": [250, 14], "x": bx + 110, "y": by + 80 + i * 30,
            "color": "#1F2937", "border_radius": 7, "z": Z_TEST_SHAPES + 1,
        }])
        # Fill bar
        Draw.shape(display=tag, shape=[{
            "ip": f"bar_fill_{i}", "vertices": 4,
            "size": [w, 14], "x": bx + 110, "y": by + 80 + i * 30,
            "color": c, "border_radius": 7, "z": Z_TEST_SHAPES,
        }])
    
    # Start animated progress timer
    _timer_handle = Draw.every(0.05, _tick_progress)


def deactivate(tag=WIN_TAG):
    global _active, _timer_handle
    if _timer_handle:
        _timer_handle.stop()
        _timer_handle = None
    
    for ip in ["test_progress", "test_slider"]:
        try:
            Draw.widget.close(ip)
        except Exception:
            pass
    
    for i in range(3):
        for prefix in ["bar_track_", "bar_fill_"]:
            try:
                Draw.shapes.remove(f"{prefix}{i}")
            except Exception:
                pass
    _active = False
