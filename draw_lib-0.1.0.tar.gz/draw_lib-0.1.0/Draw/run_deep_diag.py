"""
Deep analysis script to verify correlations, percentiles, and exact causes.
"""
import sys, os, time, math, random, gc
import numpy as np

_DIR = os.path.dirname(os.path.abspath(__file__))
_PARENT = os.path.dirname(_DIR)
for p in (_DIR, _PARENT):
    if p not in sys.path:
        sys.path.insert(0, p)

import Draw
from PySide6.QtCore import Qt, QTimer, QPointF, QRectF
from PySide6.QtGui import QColor, QPainter, QPen, QMatrix4x4
from PySide6.QtWidgets import QApplication
from Draw._super import _DrawOpenGLCanvas
from Draw._shapes import (
    ShapeDef, _shape_preferred_geometry, _shape_hit_geometry,
    _apply_motion_geometry, _draw_one_shape, _get_unit_polygon, _parse_color
)
from Draw._text import _draw_one_text, LiveTextBinding, resolve_live_text
from Draw._layout import _draw_one_layout
from Draw._motion import motion as _motion_registry

def run_deep_diagnostics():
    random.seed(42)
    Draw.window(
        tag="deep_diag",
        title="Deep Diagnostic",
        width=1280,
        height=800,
        background_color="#0D1117",
    )

    # 1 header card
    Draw.shape(
        display="deep_diag",
        shape=[{
            "vertices": 4,
            "size": [1240, 120],
            "color": "#161B22",
            "border_color": "#30363D",
            "border_width": 1,
            "border_radius": 12,
            "x": 20, "y": 15, "ip": "header",
        }]
    )

    # 2 text items
    Draw.text(tag="deep_diag", text="Header Title", customise={"x": 40, "y": 28, "font_size": 20, "color": "#58A6FF"})
    Draw.text(tag="deep_diag", text="Telemetry String", customise={"x": 40, "y": 58, "font_size": 13, "color": "#39D353"})

    # 30 moving shapes
    shapes = []
    for i in range(30):
        ip = f"rect_{i}"
        shapes.append({
            "vertices": 4,
            "size": [40, 40],
            "color": "#00B0FF",
            "x": 100 + (i % 6) * 150,
            "y": 200 + (i // 6) * 100,
            "rotation": 0.0,
            "ip": ip,
            "opacity": 90,
        })
    Draw.shape(display="deep_diag", shape=shapes)

    for s in shapes:
        ip = s["ip"]
        x0, y0 = s["x"], s["y"]
        Draw.motion(
            ip=ip,
            motion=[
                {"type": "move", "from": [x0, y0], "to": [x0 + 200, y0 + 100], "time": {"start": 0.0, "end": 3.0}, "repeat": True, "pingpong": True},
                {"type": "rotate", "from": 0.0, "to": 360.0, "time": {"start": 0.0, "end": 2.0}, "repeat": True},
            ]
        )

    canvas = Draw.super(display="deep_diag", precompile=True, mode="max", vsync=False, batch_capacity=131072)
    win = canvas.parent()
    win.show()

    app = QApplication.instance()

    # Track detailed arrays
    t_motion_list = []
    t_geometry_list = []
    t_spatial_grid_list = []
    t_color_list = []
    t_cpu_batching_list = []
    t_numpy_copy_list = []
    t_vbo_upload_list = []
    t_qpainter_list = []
    t_total_render_list = []
    t_between_paints_list = []

    shapes_processed_list = []
    shapes_regenerated_list = []
    gpu_uploads_list = []
    bytes_uploaded_list = []
    draw_calls_list = []

    last_paint_timestamp = [None]
    gc_count_during = [0]

    def on_gc(phase, info):
        if phase == "stop":
            gc_count_during[0] += 1

    gc.callbacks.append(on_gc)

    def measured_paint_gl():
        t_entry = time.perf_counter()
        if last_paint_timestamp[0] is not None:
            t_between_paints_list.append((t_entry - last_paint_timestamp[0]) * 1000.0)
        last_paint_timestamp[0] = t_entry

        cw, ch = canvas.width(), canvas.height()
        if cw <= 0 or ch <= 0:
            return

        m_time = 0.0
        g_time = 0.0
        s_time = 0.0
        c_time = 0.0
        b_time = 0.0
        nc_time = 0.0
        vbo_time = 0.0
        qp_time = 0.0
        s_proc = 0
        s_regen = 0
        g_uploads = 0
        b_uploaded = 0
        d_calls = 0

        now = time.perf_counter()
        canvas._update_scroller_thumbs(from_paint=True)

        if canvas._z_order_dirty:
            t0 = time.perf_counter()
            canvas._sorted_shapes = sorted(canvas.shape_items, key=lambda s: -s.z)
            canvas._z_order_dirty = False
            b_time += (time.perf_counter() - t0) * 1000.0
        sorted_shapes = canvas._sorted_shapes

        t0 = time.perf_counter()
        canvas.batcher.reset()
        b_time += (time.perf_counter() - t0) * 1000.0

        unbatched_shapes = []
        batched_shape_set = set()

        if canvas._projection_matrix is None:
            proj = QMatrix4x4()
            proj.ortho(0.0, float(cw), float(ch), 0.0, -1.0, 1.0)
            canvas._projection_matrix = proj

        _window_tag = getattr(canvas, "_window_tag", None)
        _scroll_x = canvas._scroll_x
        _scroll_y = canvas._scroll_y
        _gl_ok = canvas._gl_initialized and not canvas._gpu_failed
        _batcher = canvas.batcher
        _has_active_timelines = bool(_motion_registry._active_timelines)
        _sgrid_items = canvas._spatial_grid_direct.item_boxes
        _sgrid = canvas._spatial_grid_direct
        _EMPTY_MOTION = {}

        for s in sorted_shapes:
            s_proc += 1
            sid = id(s)
            is_dragged = getattr(s, "_is_dragged", False)
            _shape_motions = getattr(s, "motion", None)
            has_motion = bool(_shape_motions) or (_has_active_timelines and s.ip is not None)
            is_scroller = s.ip and (s.ip.startswith("scroller_") or "_track" in s.ip or "_thumb" in s.ip)

            _gpu = getattr(s, "_gpu_cache", None)
            if (
                _gpu is not None
                and not s.dirty
                and not is_dragged
                and not has_motion
                and not is_scroller
                and _gpu["cw"] == cw
                and _gpu["ch"] == ch
                and _gpu["sx"] == _scroll_x
                and _gpu["sy"] == _scroll_y
            ):
                if _gpu["batched"] and _gl_ok:
                    t_b0 = time.perf_counter()
                    cached_verts = _gpu["n_verts"]
                    if _batcher.v_count + cached_verts <= _batcher.max_vertices:
                        cached_data = _gpu["vdata"]
                        v_off = _batcher.v_count * 6
                        _batcher.vertex_buffer[v_off:v_off + len(cached_data)] = cached_data
                        _batcher.v_count += cached_verts
                        _batcher.i_count = _batcher.v_count
                        batched_shape_set.add(sid)
                        b_time += (time.perf_counter() - t_b0) * 1000.0
                        continue
                elif not _gpu["batched"]:
                    unbatched_shapes.append((s, _gpu["pos"], _EMPTY_MOTION))
                    continue

            s_regen += 1

            t_g0 = time.perf_counter()
            try:
                (
                    origin_x, origin_y, area_w, area_h,
                    sw, sh, preferred_x, preferred_y
                ) = _shape_preferred_geometry(s, cw, ch, window_tag=_window_tag)
            except Exception:
                continue
            g_time += (time.perf_counter() - t_g0) * 1000.0

            final_x = getattr(s, "_placed_x", preferred_x)
            final_y = getattr(s, "_placed_y", preferred_y)
            sw = getattr(s, "_placed_w", sw)
            sh = getattr(s, "_placed_h", sh)

            if not is_scroller:
                final_x -= _scroll_x
                final_y -= _scroll_y

            if is_dragged and not is_scroller:
                final_x = getattr(s, "_drag_x", final_x)
                final_y = getattr(s, "_drag_y", final_y)
                anim_x, anim_y = float(final_x), float(final_y)
                anim_sw, anim_sh = float(sw), float(sh)
                shape_motion_state = _EMPTY_MOTION
            else:
                if has_motion:
                    t_m0 = time.perf_counter()
                    shape_motion_state = _motion_registry.compute_shape_state(
                        s, now, _parse_color, float(final_x), float(final_y), sw, sh, canvas
                    )
                    s._last_motion_state = shape_motion_state
                    anim_x, anim_y, anim_sw, anim_sh = _apply_motion_geometry(
                        shape_motion_state, float(final_x), float(final_y), sw, sh
                    )
                    m_time += (time.perf_counter() - t_m0) * 1000.0
                else:
                    shape_motion_state = _EMPTY_MOTION
                    s._last_motion_state = _EMPTY_MOTION
                    anim_x = float(final_x)
                    anim_y = float(final_y)
                    anim_sw = float(sw)
                    anim_sh = float(sh)

            s.last_position = (float(anim_x), float(anim_y))
            s.last_size = (int(anim_sw), int(anim_sh))

            t_g1 = time.perf_counter()
            hx, hy, hsw, hsh = _shape_hit_geometry(s)
            s.last_hit_position = (float(hx), float(hy))
            s.last_hit_size = (int(hsw), int(hsh))
            g_time += (time.perf_counter() - t_g1) * 1000.0

            # Spatial grid update
            t_s0 = time.perf_counter()
            new_bbox = (float(anim_x), float(anim_y), float(anim_sw), float(anim_sh))
            old_bbox = _sgrid_items.get(sid)
            if old_bbox != new_bbox:
                _sgrid._update_internal(sid, new_bbox)
            s_time += (time.perf_counter() - t_s0) * 1000.0

            is_simple_polygon = (
                s.curve_mode == "line" and
                not s.bend and
                not s.exclude and
                not s.symmetry and
                not s.warp and
                s.shape_type == "vector" and
                s.border_width == 0 and
                getattr(s, "gradient", None) is None and
                getattr(s, "custom_vertices", None) is None
            )

            batched = False
            vdata_slice = None
            n_verts = 0

            if is_simple_polygon and _gl_ok:
                t_g2 = time.perf_counter()
                n = s.vertices if s.vertices and s.vertices >= 3 else 4
                rot = shape_motion_state.get("rotation", getattr(s, "rotation", 0.0) or 0.0)
                cx = anim_x + anim_sw / 2.0
                cy = anim_y + anim_sh / 2.0
                rx = anim_sw / 2.0
                ry = anim_sh / 2.0
                unit_pts = _get_unit_polygon(n)
                g_time += (time.perf_counter() - t_g2) * 1000.0

                # Color processing
                t_c0 = time.perf_counter()
                raw_c = getattr(s, "color", None)
                _color_cache = getattr(s, "_cached_rgba", None)
                _color_key = getattr(s, "_cached_rgba_key", None)
                color_key = (id(raw_c) if isinstance(raw_c, QColor) else raw_c, s.opacity)
                if _color_cache is not None and _color_key == color_key:
                    color_rgba = _color_cache
                else:
                    from Draw._super import _parse_color_to_rgba
                    color_rgba = _parse_color_to_rgba(raw_c, s.opacity)
                    s._cached_rgba = color_rgba
                    s._cached_rgba_key = color_key
                c_time += (time.perf_counter() - t_c0) * 1000.0

                # CPU Batching
                t_b1 = time.perf_counter()
                v_start = _batcher.v_count
                batched = _batcher.add_transformed_polygon(cx, cy, rx, ry, unit_pts, rot, color_rgba)
                if batched:
                    batched_shape_set.add(sid)
                    v_end = _batcher.v_count
                    n_verts = v_end - v_start
                    t_nc0 = time.perf_counter()
                    vdata_slice = _batcher.vertex_buffer[v_start * 6:v_end * 6].copy()
                    nc_time += (time.perf_counter() - t_nc0) * 1000.0
                b_time += (time.perf_counter() - t_b1) * 1000.0

            if not batched:
                unbatched_shapes.append((s, (final_x, final_y), shape_motion_state))

            s._gpu_cache = {
                "cw": cw, "ch": ch, "sx": _scroll_x, "sy": _scroll_y,
                "batched": batched, "vdata": vdata_slice, "n_verts": n_verts, "pos": (final_x, final_y),
            }
            s.dirty = False

        # QPainter Pass
        t_qp0 = time.perf_counter()
        painter = QPainter(canvas)
        try:
            painter.setRenderHint(QPainter.RenderHint.Antialiasing)
            painter.setRenderHint(QPainter.RenderHint.TextAntialiasing)

            win_obj = canvas.parent() if canvas.parent() else None
            bg_col = getattr(win_obj, "_bg_color", None) if win_obj else None
            if bg_col is None:
                bg_col = QColor(8, 12, 20)
            painter.fillRect(canvas.rect(), bg_col)

            for layout in canvas.layout_items:
                _draw_one_layout(painter, layout, cw, ch)

            bg_unbatched = [(s, pos, ms) for s, pos, ms in unbatched_shapes if s.z >= 80]
            fg_unbatched = [(s, pos, ms) for s, pos, ms in unbatched_shapes if s.z < 80]

            for s, pos_override, m_state in bg_unbatched:
                _draw_one_shape(painter, s, cw, ch, position_override=pos_override, motion_state=m_state, canvas=canvas)
                d_calls += 1

            if canvas._gl_initialized and not canvas._gpu_failed and canvas.batcher.v_count > 0:
                try:
                    painter.beginNativePainting()
                    funcs = canvas.context().functions() if canvas.context() else None
                    if funcs and canvas.shader_program and canvas.vbo:
                        t_nc1 = time.perf_counter()
                        v_used_floats = canvas.batcher.v_count * 6
                        v_bytes = canvas.batcher.vertex_buffer[:v_used_floats].tobytes()
                        nc_time += (time.perf_counter() - t_nc1) * 1000.0
                        b_uploaded = len(v_bytes)

                        t_v0 = time.perf_counter()
                        canvas.vbo.bind()
                        canvas.vbo.write(0, v_bytes, len(v_bytes))
                        g_uploads += 1
                        vbo_time += (time.perf_counter() - t_v0) * 1000.0

                        canvas.shader_program.bind()
                        canvas.shader_program.setUniformValue("uProjection", canvas._projection_matrix)

                        if canvas.vao and canvas.vao.isCreated():
                            canvas.vao.bind()
                        else:
                            canvas.vbo.bind()
                            stride = 6 * 4
                            canvas.shader_program.enableAttributeArray(0)
                            canvas.shader_program.setAttributeBuffer(0, 0x1406, 0, 2, stride)
                            canvas.shader_program.enableAttributeArray(1)
                            canvas.shader_program.setAttributeBuffer(1, 0x1406, 2 * 4, 4, stride)

                        funcs.glDrawArrays(0x0004, 0, canvas.batcher.v_count)
                        d_calls += 1

                        if canvas.vao and canvas.vao.isCreated():
                            canvas.vao.release()
                        canvas.vbo.release()
                        canvas.shader_program.release()
                except Exception:
                    canvas._gpu_failed = True
                finally:
                    painter.endNativePainting()

            for s, pos_override, m_state in fg_unbatched:
                _draw_one_shape(painter, s, cw, ch, position_override=pos_override, motion_state=m_state, canvas=canvas)
                d_calls += 1

            for t in canvas.text_items:
                if getattr(t, "motion", None):
                    t_m1 = time.perf_counter()
                    ref_x, ref_y, ref_w, ref_h = t.last_rect if t.last_rect else (float(t.x or 0), float(t.y or 0), 0.0, 0.0)
                    t._last_motion_state = _motion_registry.compute_shape_state(t, now, _parse_color, ref_x, ref_y, ref_w, ref_h, canvas)
                    m_time += (time.perf_counter() - t_m1) * 1000.0
                else:
                    t._last_motion_state = None
                _draw_one_text(painter, t, cw, ch, canvas=canvas)
                d_calls += 1

            if canvas._focused_ip:
                _focus_rect = canvas._focus_rect_for_ip(canvas._focused_ip)
                if _focus_rect is not None:
                    _fx, _fy, _fw, _fh = _focus_rect
                    painter.save()
                    _focus_pen = QPen(QColor(66, 133, 244))
                    _focus_pen.setWidth(2)
                    _focus_pen.setStyle(Qt.PenStyle.DashLine)
                    painter.setPen(_focus_pen)
                    painter.setBrush(Qt.BrushStyle.NoBrush)
                    painter.drawRoundedRect(QRectF(_fx - 3, _fy - 3, _fw + 6, _fh + 6), 4, 4)
                    painter.restore()
        finally:
            if painter.isActive():
                painter.end()
            qp_time = ((time.perf_counter() - t_qp0) * 1000.0) - vbo_time

        t_exit = time.perf_counter()
        tot_render = (t_exit - t_entry) * 1000.0

        t_motion_list.append(m_time)
        t_geometry_list.append(g_time)
        t_spatial_grid_list.append(s_time)
        t_color_list.append(c_time)
        t_cpu_batching_list.append(b_time)
        t_numpy_copy_list.append(nc_time)
        t_vbo_upload_list.append(vbo_time)
        t_qpainter_list.append(qp_time)
        t_total_render_list.append(tot_render)

        shapes_processed_list.append(s_proc)
        shapes_regenerated_list.append(s_regen)
        gpu_uploads_list.append(g_uploads)
        bytes_uploaded_list.append(b_uploaded)
        draw_calls_list.append(d_calls)

    canvas._do_paint_gl = measured_paint_gl

    print("Warming up 100 frames...")
    while len(t_total_render_list) < 100:
        app.processEvents()
        time.sleep(0.001)

    print("Clearing arrays for 1000 consecutive frames...")
    t_motion_list.clear()
    t_geometry_list.clear()
    t_spatial_grid_list.clear()
    t_color_list.clear()
    t_cpu_batching_list.clear()
    t_numpy_copy_list.clear()
    t_vbo_upload_list.clear()
    t_qpainter_list.clear()
    t_total_render_list.clear()
    t_between_paints_list.clear()
    shapes_processed_list.clear()
    shapes_regenerated_list.clear()
    gpu_uploads_list.clear()
    bytes_uploaded_list.clear()
    draw_calls_list.clear()
    gc_count_during[0] = 0

    t_start = time.perf_counter()
    while len(t_total_render_list) < 1000:
        app.processEvents()
        time.sleep(0.0005)
    t_end = time.perf_counter()

    win.close()

    def calc_stats(arr):
        a = np.array(arr)
        return {
            "mean": float(np.mean(a)),
            "median": float(np.median(a)),
            "p95": float(np.percentile(a, 95)),
            "p99": float(np.percentile(a, 99)),
            "max": float(np.max(a)),
        }

    print("\n--- DETAILED VERIFIED METRICS (1000 FRAMES) ---")
    metrics_dict = {
        "1. motion calculation time": calc_stats(t_motion_list),
        "2. geometry generation time": calc_stats(t_geometry_list),
        "3. spatial-grid update time": calc_stats(t_spatial_grid_list),
        "4. color processing time": calc_stats(t_color_list),
        "5. CPU batching time": calc_stats(t_cpu_batching_list),
        "6. NumPy/memory-copy time": calc_stats(t_numpy_copy_list),
        "7. VBO/GPU upload time": calc_stats(t_vbo_upload_list),
        "8. QPainter time": calc_stats(t_qpainter_list),
        "9. total CPU render time": calc_stats(t_total_render_list),
        "10. time between paint events": calc_stats(t_between_paints_list),
    }

    import json
    with open("detailed_metrics.json", "w") as f:
        json.dump(metrics_dict, f, indent=2)

    for k, v in metrics_dict.items():
        print(f"{k:<32}: mean={v['mean']:.4f}, median={v['median']:.4f}, P95={v['p95']:.4f}, P99={v['p99']:.4f}, max={v['max']:.4f}")

    print(f"\nGC collections during 1000 frames: {gc_count_during[0]}")
    print(f"Shapes processed: mean={np.mean(shapes_processed_list):.1f}, max={max(shapes_processed_list)}")
    print(f"Shapes regenerated: mean={np.mean(shapes_regenerated_list):.1f}, max={max(shapes_regenerated_list)}")
    print(f"GPU uploads: mean={np.mean(gpu_uploads_list):.1f}, max={max(gpu_uploads_list)}")
    print(f"Bytes uploaded: mean={np.mean(bytes_uploaded_list):.1f}, max={max(bytes_uploaded_list)}")
    print(f"Draw calls: mean={np.mean(draw_calls_list):.1f}, max={max(draw_calls_list)}")

    # Analysis of the 50-500 FPS phenomenon
    inv_render_times = [1000.0 / t for t in t_total_render_list]
    print(f"\nInverse CPU Render Time (1000 / t_render):")
    print(f"  Min FPS: {min(inv_render_times):.1f}")
    print(f"  Max FPS: {max(inv_render_times):.1f}")
    print(f"  Median FPS: {np.median(inv_render_times):.1f}")
    print(f"  Mean FPS: {np.mean(inv_render_times):.1f}")

    inv_paint_intervals = [1000.0 / dt for dt in t_between_paints_list if dt > 0.001]
    print(f"\nInverse Paint Interval (1000 / dt_paint):")
    print(f"  Min FPS: {min(inv_paint_intervals):.1f}")
    print(f"  Max FPS: {max(inv_paint_intervals):.1f}")
    print(f"  Median FPS: {np.median(inv_paint_intervals):.1f}")
    print(f"  Mean FPS: {np.mean(inv_paint_intervals):.1f}")

if __name__ == "__main__":
    run_deep_diagnostics()
