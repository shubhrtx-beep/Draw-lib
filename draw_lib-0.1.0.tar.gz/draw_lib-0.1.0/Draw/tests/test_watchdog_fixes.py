"""
Regression tests for confirmed Draw.debug / watchdog bugs:

1. infinite_loop_stuck_seconds now actually governs detection timing.
2. CPU watchdog enable/disable flag is respected.
3. Memory watchdog enable/disable flag is respected.
4. safe_stop() marshals window shutdown onto the Qt GUI thread instead of
   running it directly on the watchdog thread.
5. The infinite-loop detector no longer excludes a user function purely
   because it happens to be named run().

These tests exercise Draw.debug's internals directly (rather than waiting
on real watchdog sleep cycles or spinning up an actual infinite loop) by
monkeypatching time.time / time.sleep / sys._current_frames /
threading.main_thread, matching the style already used in this file's
sibling test_debug.py.
"""

import os
import sys
import threading

SYS_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PARENT_ROOT = os.path.dirname(SYS_ROOT)
if PARENT_ROOT not in sys.path:
    sys.path.insert(0, PARENT_ROOT)
if SYS_ROOT not in sys.path:
    sys.path.insert(0, SYS_ROOT)

import importlib

import pytest

# pyrefly: ignore [missing-import]
from PySide6.QtWidgets import QApplication

import Draw
from Draw.debug import debug

# NOTE: Draw/__init__.py does `from Draw.debug import debug`, which rebinds
# the *attribute* `Draw.debug` to the DebugManager singleton instance
# (shadowing the submodule on the package namespace, even though the real
# module object is still registered in sys.modules). `import Draw.debug as
# debug_module` would therefore silently hand back the singleton instead of
# the module, so the real module is fetched explicitly instead -- this is
# what lets these tests monkeypatch debug.py's `time`/`sys`/`threading`
# globals.
debug_module = importlib.import_module("Draw.debug")


@pytest.fixture(autouse=True)
def ensure_app():
    app = QApplication.instance()
    if app is None:
        app = QApplication([])
    yield app
    Draw.window.close_all()


@pytest.fixture(autouse=True)
def reset_debug_state():
    """Isolate each test's watchdog/infinite-loop state."""
    settings = debug.settings()
    old_cpu_enabled = settings.cpu_watchdog_enabled
    old_mem_enabled = settings.memory_watchdog_enabled
    old_render_enabled = settings.render_timeout_enabled
    old_loop_enabled = settings.infinite_loop_detector_enabled
    old_seconds = settings.infinite_loop_stuck_seconds
    old_auto_stop = settings.auto_emergency_stop_enabled
    old_stop_flag = debug._stop_flag
    old_watchdog_running = debug._watchdog_running

    debug._last_main_frame_location = None
    debug._main_frame_stuck_count = 0
    debug._main_frame_stuck_since = None
    debug._render_counter = 0
    debug._last_checked_render_counter = -1

    yield

    settings.cpu_watchdog_enabled = old_cpu_enabled
    settings.memory_watchdog_enabled = old_mem_enabled
    settings.render_timeout_enabled = old_render_enabled
    settings.infinite_loop_detector_enabled = old_loop_enabled
    settings.infinite_loop_stuck_seconds = old_seconds
    settings.auto_emergency_stop_enabled = old_auto_stop
    debug._stop_flag = old_stop_flag
    debug._watchdog_running = old_watchdog_running
    debug._last_main_frame_location = None
    debug._main_frame_stuck_count = 0
    debug._main_frame_stuck_since = None


class _FakeCode:
    def __init__(self, filename, name):
        self.co_filename = filename
        self.co_name = name


class _FakeFrame:
    def __init__(self, filename, lineno, name):
        self.f_code = _FakeCode(filename, name)
        self.f_lineno = lineno


def _install_fake_main_frame(monkeypatch, ident, frame):
    fake_main = type("FakeThread", (), {"ident": ident})()
    monkeypatch.setattr(debug_module.threading, "main_thread", lambda: fake_main)
    monkeypatch.setattr(debug_module.sys, "_current_frames", lambda: {ident: frame})


# ─────────────────────────────────────────────────────────────────────────
# Bug 1: infinite_loop_stuck_seconds now governs detection timing
# ─────────────────────────────────────────────────────────────────────────

def test_infinite_loop_stuck_seconds_governs_timing(monkeypatch):
    debug.settings().auto_emergency_stop_enabled = False
    debug.settings().infinite_loop_stuck_seconds = 1.0

    # NOTE: filename deliberately avoids the substrings "_app.py" / "_window.py"
    # so it isn't mistaken for one of Draw's own framework files.
    frame = _FakeFrame("user_script.py", 10, "spin")
    _install_fake_main_frame(monkeypatch, 111, frame)

    clock = [1000.0]
    monkeypatch.setattr(debug_module.time, "time", lambda: clock[0])

    logged = []
    monkeypatch.setattr(
        debug._logger, "log",
        lambda level, msg, category="runtime": logged.append(msg),
    )

    # Tick 1: first time this location is observed -> establishes baseline,
    # not yet "stuck".
    debug._check_infinite_loop()
    assert debug._main_frame_stuck_since is None

    # Tick 2: same location again -> stuck streak begins now.
    clock[0] = 1000.1
    debug._check_infinite_loop()
    assert debug._main_frame_stuck_since == 1000.1

    # Elapsed time since the stuck streak began is still under the
    # configured 1.0s threshold -> must NOT trigger yet.
    clock[0] = 1000.1 + 0.5
    debug._check_infinite_loop()
    assert not any("Infinite Loop" in m for m in logged)

    # Elapsed time now exceeds the configured 1.0s threshold -> must trigger.
    clock[0] = 1000.1 + 1.2
    debug._check_infinite_loop()
    assert any("Infinite Loop" in m for m in logged)


def test_infinite_loop_stuck_seconds_value_changes_when_it_fires(monkeypatch):
    """Same stuck-frame pattern, only infinite_loop_stuck_seconds differs
    between runs -> the setting must be the thing controlling detection
    timing (previously it had no effect at all)."""

    def run_with_seconds(seconds, ident):
        debug.settings().auto_emergency_stop_enabled = False
        debug.settings().infinite_loop_stuck_seconds = seconds
        debug._last_main_frame_location = None
        debug._main_frame_stuck_count = 0
        debug._main_frame_stuck_since = None
        debug._render_counter = 0
        debug._last_checked_render_counter = -1

        frame = _FakeFrame("user_script.py", 20, "spin")
        _install_fake_main_frame(monkeypatch, ident, frame)

        clock = [2000.0]
        monkeypatch.setattr(debug_module.time, "time", lambda: clock[0])

        logged = []
        monkeypatch.setattr(
            debug._logger, "log",
            lambda level, msg, category="runtime": logged.append(msg),
        )

        debug._check_infinite_loop()          # establish baseline
        clock[0] += 0.1                        # stuck streak begins
        debug._check_infinite_loop()
        clock[0] += 0.8                        # 0.8s into the stuck streak
        debug._check_infinite_loop()
        return any("Infinite Loop" in m for m in logged)

    # With a short threshold, 0.8s of stuck time is enough to fire.
    assert run_with_seconds(0.5, ident=201) is True
    # With a longer threshold, the same 0.8s of stuck time must NOT fire.
    assert run_with_seconds(5.0, ident=202) is False


# ─────────────────────────────────────────────────────────────────────────
# Bug 2 & 3: CPU / memory watchdog enable flags are respected
# ─────────────────────────────────────────────────────────────────────────

def _run_one_watchdog_tick(monkeypatch):
    """Run exactly one iteration of _watchdog_loop by making time.sleep
    stop the loop after its first call."""
    debug._watchdog_running = True
    debug._stop_flag = False

    def fake_sleep(_seconds):
        debug._watchdog_running = False

    monkeypatch.setattr(debug_module.time, "sleep", fake_sleep)
    debug._watchdog_loop()


def test_cpu_watchdog_disabled_flag_is_respected(monkeypatch):
    debug.settings().cpu_watchdog_enabled = False
    debug.settings().memory_watchdog_enabled = False
    debug.settings().render_timeout_enabled = False
    debug.settings().infinite_loop_detector_enabled = False

    calls = {"n": 0}

    def fake_cpu_percent():
        calls["n"] += 1
        return 100.0  # would clearly be "overloaded" if ever sampled

    monkeypatch.setattr(debug, "_get_cpu_percent", fake_cpu_percent)

    _run_one_watchdog_tick(monkeypatch)

    assert calls["n"] == 0, "CPU watchdog sampled CPU despite being disabled"


def test_cpu_watchdog_enabled_flag_is_respected(monkeypatch):
    debug.settings().cpu_watchdog_enabled = True
    debug.settings().memory_watchdog_enabled = False
    debug.settings().render_timeout_enabled = False
    debug.settings().infinite_loop_detector_enabled = False

    calls = {"n": 0}

    def fake_cpu_percent():
        calls["n"] += 1
        return 10.0

    monkeypatch.setattr(debug, "_get_cpu_percent", fake_cpu_percent)

    _run_one_watchdog_tick(monkeypatch)

    assert calls["n"] == 1, "CPU watchdog did not sample CPU while enabled"


def test_memory_watchdog_disabled_flag_is_respected(monkeypatch):
    debug.settings().cpu_watchdog_enabled = False
    debug.settings().memory_watchdog_enabled = False
    debug.settings().render_timeout_enabled = False
    debug.settings().infinite_loop_detector_enabled = False

    calls = {"n": 0}

    def fake_memory_mb():
        calls["n"] += 1
        return 999_999.0  # would clearly exceed any sane memory_limit

    monkeypatch.setattr(debug, "_get_memory_mb", fake_memory_mb)

    _run_one_watchdog_tick(monkeypatch)

    assert calls["n"] == 0, "Memory watchdog sampled memory despite being disabled"


def test_memory_watchdog_enabled_flag_is_respected(monkeypatch):
    debug.settings().cpu_watchdog_enabled = False
    debug.settings().memory_watchdog_enabled = True
    debug.settings().render_timeout_enabled = False
    debug.settings().infinite_loop_detector_enabled = False

    calls = {"n": 0}

    def fake_memory_mb():
        calls["n"] += 1
        return 1.0

    monkeypatch.setattr(debug, "_get_memory_mb", fake_memory_mb)

    _run_one_watchdog_tick(monkeypatch)

    assert calls["n"] == 1, "Memory watchdog did not sample memory while enabled"


# ─────────────────────────────────────────────────────────────────────────
# Bug 4: safe_stop() marshals window shutdown to the Qt GUI thread
# ─────────────────────────────────────────────────────────────────────────

def test_safe_stop_marshals_shutdown_to_gui_thread():
    Draw.window(tag="watchdog_regression_win", width=200, height=200)
    assert "watchdog_regression_win" in Draw.window.list_tags()

    debug._stop_flag = False

    def worker():
        debug.safe_stop("regression test: off-thread safe_stop")

    t = threading.Thread(target=worker, name="RegressionWatchdogThread")
    t.start()
    t.join(timeout=5)
    assert not t.is_alive()

    # The stop flag itself is plain Python state and is safe to set
    # directly from any thread.
    assert debug.should_stop() is True

    # The window must NOT be closed yet -- closing it is a Qt GUI
    # operation and must have been queued onto the GUI thread rather than
    # executed directly on the background thread that called safe_stop().
    assert "watchdog_regression_win" in Draw.window.list_tags()

    # Pump the Qt event loop on the GUI (main) thread to deliver the
    # queued shutdown request.
    app = QApplication.instance()
    for _ in range(20):
        app.processEvents()
        if "watchdog_regression_win" not in Draw.window.list_tags():
            break

    assert "watchdog_regression_win" not in Draw.window.list_tags(), (
        "safe_stop() did not close the window after the GUI event loop "
        "processed the queued shutdown request"
    )


# ─────────────────────────────────────────────────────────────────────────
# Bug 5: a user function named run() is no longer exempt by name alone
# ─────────────────────────────────────────────────────────────────────────

def test_user_function_named_run_is_not_excluded_by_name(monkeypatch):
    debug.settings().auto_emergency_stop_enabled = False
    debug.settings().infinite_loop_stuck_seconds = 0.05

    # A user-defined function that happens to be named run(), living in the
    # user's own script -- NOT inside Draw's _window.py/_app.py or PySide6.
    frame = _FakeFrame("my_script.py", 77, "run")
    _install_fake_main_frame(monkeypatch, 301, frame)

    clock = [5000.0]
    monkeypatch.setattr(debug_module.time, "time", lambda: clock[0])

    logged = []
    monkeypatch.setattr(
        debug._logger, "log",
        lambda level, msg, category="runtime": logged.append(msg),
    )

    debug._check_infinite_loop()      # baseline
    clock[0] += 0.01
    debug._check_infinite_loop()      # stuck streak begins
    clock[0] += 0.2                   # comfortably past the 0.05s threshold
    debug._check_infinite_loop()

    assert any("Infinite Loop" in m for m in logged), (
        "A user function literally named run() was silently excluded from "
        "infinite-loop detection just because of its name."
    )


def test_qt_window_run_is_still_excluded(monkeypatch):
    """The framework's own Draw._window.window.run() (which blocks inside
    app.exec()) must still be treated as healthy Qt waiting, not flagged."""
    debug.settings().auto_emergency_stop_enabled = False
    debug.settings().infinite_loop_stuck_seconds = 0.05

    frame = _FakeFrame(r"C:\pg\draw2\Draw\_window.py", 500, "run")
    _install_fake_main_frame(monkeypatch, 302, frame)

    clock = [6000.0]
    monkeypatch.setattr(debug_module.time, "time", lambda: clock[0])

    logged = []
    monkeypatch.setattr(
        debug._logger, "log",
        lambda level, msg, category="runtime": logged.append(msg),
    )

    for _ in range(5):
        clock[0] += 1.0
        debug._check_infinite_loop()

    assert not any("Infinite Loop" in m for m in logged), (
        "Draw's own event-loop-blocking run() was incorrectly flagged as "
        "an infinite loop."
    )


if __name__ == "__main__":
    print("Running Draw.debug watchdog regression tests...")
    raise SystemExit(pytest.main([__file__, "-v"]))
