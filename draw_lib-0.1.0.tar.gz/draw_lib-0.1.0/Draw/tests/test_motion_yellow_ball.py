"""
tests/test_motion_yellow_ball.py
================================
Comprehensive unit and integration test suite for Draw._motion (Draw.motion).
Validates all 38+ motion types, analytical physics solvers, procedural kinematics,
AST expression solvers, timeline orchestration, custom motions, and interactive triggers
using a small yellow ball shape entity.
"""

import math
import os
import sys
import time
import pytest
from PySide6.QtGui import QColor

# Ensure workspace root is on sys.path
TEST_DIR = os.path.dirname(os.path.abspath(__file__))
WORKSPACE_ROOT = os.path.dirname(TEST_DIR)
PARENT_ROOT = os.path.dirname(WORKSPACE_ROOT)
if PARENT_ROOT not in sys.path:
    sys.path.insert(0, PARENT_ROOT)
if WORKSPACE_ROOT not in sys.path:
    sys.path.insert(0, WORKSPACE_ROOT)

import Draw
from Draw._motion import (
    MotionRecord,
    MotionRegistry,
    DrawExprSolver,
    Timeline,
    solve_spring,
    solve_gravity_bounce,
    solve_projectile_2d,
    solve_inertia,
    solve_pendulum,
    solve_attractor_2d,
    solve_stretch_squash,
    solve_cubic_bezier,
    solve_wiggle,
    solve_wave,
    solve_lissajous,
    solve_spiral,
    solve_polygon_orbit,
    sample_polyline_at,
    resolve_motion_path_vertices,
    resolve_morph_vertices,
)
from Draw._colour import _parse_color


class MockYellowBall:
    """Mock shape entity representing a small yellow ball with position, size, and motion."""

    def __init__(self, ip: str = "yellow_ball", x: float = 100.0, y: float = 100.0, size: float = 20.0):
        self.ip = ip
        self.x = x
        self.y = y
        self.size = [size, size]
        self.color = "yellow"
        self.border_radius_raw = "50%"
        self.vertices = 4
        self.motion: list[MotionRecord] = []
        self.motion_started_at = 0.0
        self._trigger_progresses = {}
        self._last_motion_state = None
        self._is_hovered = False
        self._is_pressed = False
        self._is_dragged = False
        self._is_visible = True
        self.last_position = (x, y)


# ══════════════════════════════════════════════════════════════════════════════
# 1. ANALYTICAL PHYSICS SOLVERS TESTS (O(1))
# ══════════════════════════════════════════════════════════════════════════════

def test_solver_spring_kinetics():
    """Verify 2nd-order damped harmonic spring solver across underdamped, critical, and overdamped regimes."""
    # Underdamped
    x0 = solve_spring(t=0.0, v_from=0.0, v_to=100.0, v0=0.0, stiffness=300.0, damping=15.0, mass=1.0)
    assert math.isclose(x0, 0.0, abs_tol=1e-5)

    x_settled = solve_spring(t=5.0, v_from=0.0, v_to=100.0, v0=0.0, stiffness=300.0, damping=25.0, mass=1.0)
    assert math.isclose(x_settled, 100.0, abs_tol=0.1)

    # Critically damped (zeta == 1.0) -> c = 2 * sqrt(k*m) = 2 * sqrt(100) = 20
    xc0 = solve_spring(t=0.0, v_from=50.0, v_to=200.0, v0=0.0, stiffness=100.0, damping=20.0, mass=1.0)
    assert math.isclose(xc0, 50.0, abs_tol=1e-5)
    xc_mid = solve_spring(t=0.5, v_from=50.0, v_to=200.0, v0=0.0, stiffness=100.0, damping=20.0, mass=1.0)
    assert 50.0 < xc_mid < 200.0

    # Overdamped (zeta > 1.0)
    xo_mid = solve_spring(t=0.5, v_from=0.0, v_to=100.0, v0=0.0, stiffness=100.0, damping=30.0, mass=1.0)
    assert 0.0 < xo_mid < 100.0


def test_solver_gravity_and_bounce():
    """Verify analytical vertical gravity and floor collision bounce physics."""
    # Ball dropped from y=50 towards floor at y=400 with restitution 0.75
    y0 = solve_gravity_bounce(t=0.0, v0=0.0, g=980.0, restitution=0.75, floor_y=400.0, start_y=50.0)
    assert math.isclose(y0, 50.0, abs_tol=1e-5)

    # At t=0.2s before impact, y(t) = start_y + 0.5 * g * t^2 = 50 + 0.5 * 980 * 0.04 = 69.6
    y_fall = solve_gravity_bounce(t=0.2, v0=0.0, g=980.0, restitution=0.75, floor_y=400.0, start_y=50.0)
    assert math.isclose(y_fall, 69.6, abs_tol=0.5)

    # Over long time, ball settles on the floor
    y_settle = solve_gravity_bounce(t=10.0, v0=0.0, g=980.0, restitution=0.75, floor_y=400.0, start_y=50.0)
    assert math.isclose(y_settle, 400.0, abs_tol=1.0)


def test_solver_projectile_2d():
    """Verify 2D parabolic ballistic trajectory with air drag, ground bounce, and wall reflection."""
    px0, py0 = solve_projectile_2d(
        t=0.0, vx0=250.0, vy0=-400.0, g=980.0, drag=0.02, restitution=0.75,
        floor_y=500.0, wall_x=600.0, start_x=50.0, start_y=450.0
    )
    assert math.isclose(px0, 50.0, abs_tol=1e-5)
    assert math.isclose(py0, 450.0, abs_tol=1e-5)

    # Trajectory advances rightwards and upwards initially (vy0 < 0)
    px1, py1 = solve_projectile_2d(
        t=0.1, vx0=250.0, vy0=-400.0, g=980.0, drag=0.02, restitution=0.75,
        floor_y=500.0, wall_x=600.0, start_x=50.0, start_y=450.0
    )
    assert px1 > 50.0
    assert py1 < 450.0  # launched upward


def test_solver_inertia_friction():
    """Verify kinetic inertia deceleration and wall clamping."""
    x0 = solve_inertia(t=0.0, v_from=100.0, v0=500.0, friction=0.92, bounds={"min": 0.0, "max": 1000.0})
    assert math.isclose(x0, 100.0, abs_tol=1e-5)

    # Over time, position smoothly increases and asymptotically settles
    x_late = solve_inertia(t=2.0, v_from=100.0, v0=500.0, friction=0.92, bounds={"min": 0.0, "max": 1000.0})
    assert x_late > 100.0
    assert x_late <= 1000.0


def test_solver_pendulum():
    """Verify harmonic pendulum angle decay oscillation."""
    rot0 = solve_pendulum(t=0.0, amplitude=45.0, frequency=1.5, damping=0.2)
    assert math.isclose(rot0, 45.0, abs_tol=1e-5)

    # Damped oscillation decreases in magnitude
    rot_late = solve_pendulum(t=5.0, amplitude=45.0, frequency=1.5, damping=0.5)
    assert abs(rot_late) < 45.0


def test_solver_attractor_2d():
    """Verify 2D point attraction toward target coordinate."""
    nx, ny = solve_attractor_2d(t=0.5, cur_x=100.0, cur_y=100.0, target_x=300.0, target_y=200.0, strength=5.0)
    assert 100.0 < nx <= 300.0
    assert 100.0 < ny <= 200.0


def test_solver_stretch_squash():
    """Verify area-preserving stretch & squash geometric multiplier."""
    # At t=0, delta=0 -> scale is 1.0, 1.0
    sx0, sy0 = solve_stretch_squash(t=0.0, amplitude=0.3, frequency=2.0, damping=1.0)
    assert math.isclose(sx0, 1.0, abs_tol=1e-5)
    assert math.isclose(sy0, 1.0, abs_tol=1e-5)

    # At quarter period t=0.125s (sin = 1.0)
    sx1, sy1 = solve_stretch_squash(t=0.125, amplitude=0.3, frequency=2.0, damping=0.5)
    assert sx1 > 1.0
    assert math.isclose(sy1, 1.0 / sx1, abs_tol=1e-4)


def test_solver_cubic_bezier():
    """Verify CSS cubic-bezier inversion solver."""
    # Linear curve (0, 0, 1, 1)
    assert math.isclose(solve_cubic_bezier(0.0, 0.0, 0.0, 1.0, 1.0), 0.0, abs_tol=1e-4)
    assert math.isclose(solve_cubic_bezier(0.5, 0.0, 0.0, 1.0, 1.0), 0.5, abs_tol=1e-3)
    assert math.isclose(solve_cubic_bezier(1.0, 0.0, 0.0, 1.0, 1.0), 1.0, abs_tol=1e-4)

    # Ease (0.25, 0.1, 0.25, 1.0)
    eased = solve_cubic_bezier(0.4, 0.25, 0.1, 0.25, 1.0)
    assert 0.0 <= eased <= 1.0


# ══════════════════════════════════════════════════════════════════════════════
# 2. PROCEDURAL KINEMATICS & ORBITAL CURVES TESTS
# ══════════════════════════════════════════════════════════════════════════════

def test_solver_wiggle_and_wave():
    """Verify 2D continuous Simplex noise wiggle and sinusoidal wave."""
    wx, wy = solve_wiggle(t=1.5, frequency=3.0, amplitude=20.0, octaves=2)
    assert isinstance(wx, float) and isinstance(wy, float)
    assert -20.0 <= wx <= 20.0
    assert -20.0 <= wy <= 20.0

    wv = solve_wave(t=0.25, frequency=1.0, amplitude=30.0, phase=0.0)
    # sin(2 * pi * 1.0 * 0.25) = sin(pi / 2) = 1.0 -> wave = 30.0
    assert math.isclose(wv, 30.0, abs_tol=1e-4)


def test_solver_lissajous_and_spiral():
    """Verify parametric Lissajous figures and spiral curves."""
    lx, ly = solve_lissajous(t=0.0, amplitude_x=100.0, amplitude_y=80.0, freq_x=2.0, freq_y=3.0, phase_x=0.0, phase_y=math.pi / 2)
    # x = 100 * sin(0) = 0, y = 80 * sin(pi/2) = 80
    assert math.isclose(lx, 0.0, abs_tol=1e-4)
    assert math.isclose(ly, 80.0, abs_tol=1e-4)

    # Archimedean spiral: r = a + b * theta
    sx, sy = solve_spiral(t=0.0, a=10.0, b=15.0, frequency=1.0, logarithmic=False)
    # at t=0, theta=0 -> r = 10 -> x = 10, y = 0
    assert math.isclose(sx, 10.0, abs_tol=1e-4)
    assert math.isclose(sy, 0.0, abs_tol=1e-4)


def test_solver_polygon_orbit():
    """Verify regular n-gon boundary orbits (triangle, square, hexagon)."""
    for sides in (3, 4, 6, 8):
        dx, dy = solve_polygon_orbit(t=0.5, radius=100.0, sides=sides, frequency=1.0)
        assert isinstance(dx, float) and isinstance(dy, float)
        assert math.hypot(dx, dy) <= 105.0  # within bounding radius


# ══════════════════════════════════════════════════════════════════════════════
# 3. AST EXPRESSION SOLVER (DrawExprSolver)
# ══════════════════════════════════════════════════════════════════════════════

def test_draw_expr_solver():
    """Verify sandboxed AST expression evaluation without eval/exec."""
    solver = DrawExprSolver("x = x + sin(time * 2) * 50\ny = y + cos(time * 2) * 50")
    ctx = {"time": 0.0, "x": 100.0, "y": 100.0}
    res = solver.evaluate(ctx)
    assert math.isclose(res["x"], 100.0, abs_tol=1e-4)
    assert math.isclose(res["y"], 150.0, abs_tol=1e-4)  # cos(0) * 50 = 50 -> y = 150


# ══════════════════════════════════════════════════════════════════════════════
# 4. COMPREHENSIVE MOTION TYPES ON YELLOW BALL
# ══════════════════════════════════════════════════════════════════════════════

@pytest.fixture
def motion_reg():
    return MotionRegistry()


def test_yellow_ball_motion_move_and_pos(motion_reg):
    """Test 'move', 'position', 'pos', 'x', 'y' on yellow ball."""
    ball = MockYellowBall(ip="ball_move", x=50.0, y=50.0)
    records = motion_reg.parse_motion_list([
        {"type": "move", "from": [50, 50], "to": [250, 150], "duration": 2.0, "graph": "linear"}
    ])
    ball.motion = records

    # t=0.0
    s0 = motion_reg.compute_shape_state(ball, now=0.0, parse_color=_parse_color, x=50, y=50, w=20, h=20)
    assert math.isclose(s0["x"], 50.0, abs_tol=1e-4)
    assert math.isclose(s0["y"], 50.0, abs_tol=1e-4)

    # t=1.0 (halfway)
    s1 = motion_reg.compute_shape_state(ball, now=1.0, parse_color=_parse_color, x=50, y=50, w=20, h=20)
    assert math.isclose(s1["x"], 150.0, abs_tol=1e-4)
    assert math.isclose(s1["y"], 100.0, abs_tol=1e-4)

    # t=2.0 (end)
    s2 = motion_reg.compute_shape_state(ball, now=2.0, parse_color=_parse_color, x=50, y=50, w=20, h=20)
    assert math.isclose(s2["x"], 250.0, abs_tol=1e-4)
    assert math.isclose(s2["y"], 150.0, abs_tol=1e-4)


def test_yellow_ball_motion_scale_and_expand(motion_reg):
    """Test 'scale', 'expand', 'size' on yellow ball."""
    ball = MockYellowBall(ip="ball_scale", size=20.0)
    ball.motion = motion_reg.parse_motion_list([
        {"type": "scale", "from": [1.0, 1.0], "to": [2.5, 2.5], "duration": 1.0, "graph": "linear"},
        {"type": "expand", "from": [20, 20], "to": [50, 50], "duration": 1.0, "graph": "linear"},
    ])

    s1 = motion_reg.compute_shape_state(ball, now=1.0, parse_color=_parse_color, x=100, y=100, w=20, h=20)
    assert math.isclose(s1["scale_x"], 2.5, abs_tol=1e-4)
    assert math.isclose(s1["scale_y"], 2.5, abs_tol=1e-4)
    assert s1["width"] == 50
    assert s1["height"] == 50


def test_yellow_ball_motion_rotate_and_skew(motion_reg):
    """Test 'rotate', 'skew', 'shear', and 3D transforms on yellow ball."""
    ball = MockYellowBall(ip="ball_rotate")
    ball.motion = motion_reg.parse_motion_list([
        {"type": "rotate", "from": 0, "to": 360, "duration": 2.0, "graph": "linear"},
        {"type": "skew", "from": [0, 0], "to": [15, -15], "duration": 2.0, "graph": "linear"},
    ])

    s1 = motion_reg.compute_shape_state(ball, now=1.0, parse_color=_parse_color, x=100, y=100, w=20, h=20)
    assert math.isclose(s1["rotation"], 180.0, abs_tol=1e-4)
    assert math.isclose(s1["skew_x"], 7.5, abs_tol=1e-4)
    assert math.isclose(s1["skew_y"], -7.5, abs_tol=1e-4)

    # Test rotate_3d on a separate ball entity
    ball_3d = MockYellowBall(ip="ball_3d")
    ball_3d.motion = motion_reg.parse_motion_list([
        {"type": "rotate_3d", "from": {"rotate_x": 0, "rotate_y": 0, "rotation": 0}, "to": {"rotate_x": 45, "rotate_y": 60, "rotation": 90}, "duration": 2.0, "graph": "linear"},
    ])
    s_3d = motion_reg.compute_shape_state(ball_3d, now=1.0, parse_color=_parse_color, x=100, y=100, w=20, h=20)
    assert math.isclose(s_3d["rotate_x"], 22.5, abs_tol=1e-4)
    assert math.isclose(s_3d["rotate_y"], 30.0, abs_tol=1e-4)


def test_yellow_ball_motion_visual_fx(motion_reg):
    """Test 'opacity', 'blur', 'color', 'glow', 'stroke_dash', 'trim_path' on yellow ball."""
    ball = MockYellowBall(ip="ball_fx")
    ball.motion = motion_reg.parse_motion_list([
        {"type": "opacity", "from": 100, "to": 30, "duration": 1.0, "graph": "linear"},
        {"type": "blur", "from": 0, "to": 12, "duration": 1.0, "graph": "linear"},
        {"type": "color", "from": "yellow", "to": "red", "duration": 1.0, "graph": "linear"},
        {"type": "glow", "from": {"radius": 0, "color": "yellow"}, "to": {"radius": 20, "color": "gold"}, "duration": 1.0, "graph": "linear"},
        {"type": "stroke_dash", "from": [0, 5], "to": [50, 5], "duration": 1.0, "graph": "linear"},
        {"type": "trim_path", "from": [0.0, 1.0], "to": [0.2, 0.8], "duration": 1.0, "graph": "linear"},
    ])

    s1 = motion_reg.compute_shape_state(ball, now=1.0, parse_color=_parse_color, x=100, y=100, w=20, h=20)
    assert s1["opacity"] == 30
    assert s1["blur"] == 12
    assert isinstance(s1["color"], QColor)
    assert s1["color"].red() == 255 and s1["color"].green() == 0 and s1["color"].blue() == 0  # Red
    assert s1["glow"] is True
    assert s1["glow_radius"] == 20
    assert s1["trim_start"] == 0.2
    assert s1["trim_end"] == 0.8


def test_yellow_ball_motion_path_follower(motion_reg):
    """Test SVG path following with auto-tangent orientation."""
    ball = MockYellowBall(ip="ball_path")
    ball.motion = motion_reg.parse_motion_list([
        {
            "type": "path",
            "path": "M 0 0 L 100 0 L 100 100",
            "orient": True,
            "duration": 2.0,
            "graph": "linear",
        }
    ])

    # t=0 -> (0, 0)
    s0 = motion_reg.compute_shape_state(ball, now=0.0, parse_color=_parse_color, x=0, y=0, w=20, h=20)
    assert math.isclose(s0["x"], 0.0, abs_tol=1.0)
    assert math.isclose(s0["y"], 0.0, abs_tol=1.0)

    # t=1.0 -> corner at (100, 0)
    s1 = motion_reg.compute_shape_state(ball, now=1.0, parse_color=_parse_color, x=0, y=0, w=20, h=20)
    assert math.isclose(s1["x"], 100.0, abs_tol=2.0)
    assert math.isclose(s1["y"], 0.0, abs_tol=2.0)

    # t=2.0 -> end at (100, 100)
    s2 = motion_reg.compute_shape_state(ball, now=2.0, parse_color=_parse_color, x=0, y=0, w=20, h=20)
    assert math.isclose(s2["x"], 100.0, abs_tol=2.0)
    assert math.isclose(s2["y"], 100.0, abs_tol=2.0)


def test_yellow_ball_motion_procedural_and_physics(motion_reg):
    """Test spring, gravity, projectile, inertia, pendulum, wiggle, wave, pulse, benzene, lissajous, spiral, attractor, stretch_squash."""
    procedural_types = [
        {"type": "spring", "from": [0, 0], "to": [100, 100], "stiffness": 300, "damping": 20},
        {"type": "gravity", "from": 0, "g": 980, "restitution": 0.7, "floor_y": 300},
        {"type": "projectile", "from": [0, 100], "vx0": 150, "vy0": -200, "g": 600, "floor_y": 250},
        {"type": "inertia", "from": 0.0, "velocity": 300, "friction": 0.9},
        {"type": "pendulum", "amplitude": 30, "frequency": 1.0, "damping": 0.1},
        {"type": "wiggle", "frequency": 4.0, "amplitude": 15.0},
        {"type": "wave", "frequency": 2.0, "amplitude": 25.0},
        {"type": "pulse", "frequency": 2.0, "amplitude": 30.0},
        {"type": "orbit", "radius": 60.0, "sides": 6, "frequency": 0.5},
        {"type": "benzene", "radius": 50.0, "frequency": 1.0},
        {"type": "lissajous", "amplitude_x": 40.0, "amplitude_y": 30.0, "freq_x": 2, "freq_y": 1},
        {"type": "spiral", "a": 5, "b": 10, "frequency": 1.0},
        {"type": "attractor", "target_x": 200, "target_y": 150, "strength": 5.0},
        {"type": "stretch_squash", "amplitude": 0.3, "frequency": 2.0, "damping": 0.5},
    ]

    for item in procedural_types:
        ball = MockYellowBall(ip=f"ball_{item['type']}")
        ball.motion = motion_reg.parse_motion_list([item])
        # Compute state at t=0.5
        state = motion_reg.compute_shape_state(ball, now=0.5, parse_color=_parse_color, x=100, y=100, w=20, h=20)
        assert isinstance(state, dict)
        assert len(state) > 0


def test_yellow_ball_motion_keyframes(motion_reg):
    """Test multi-keyframe trajectory with bezier interpolation."""
    ball = MockYellowBall(ip="ball_kf")
    ball.motion = motion_reg.parse_motion_list([
        {
            "attribute": "position",
            "keyframes": [
                {"time": 0.0, "value": [0, 0]},
                {"time": 1.0, "value": [100, 50]},
                {"time": 2.0, "value": [200, 0]},
            ]
        }
    ])

    s1 = motion_reg.compute_shape_state(ball, now=1.0, parse_color=_parse_color, x=0, y=0, w=20, h=20)
    assert math.isclose(s1["x"], 100.0, abs_tol=1e-3)
    assert math.isclose(s1["y"], 50.0, abs_tol=1e-3)


def test_yellow_ball_motion_morph(motion_reg):
    """Test vector polygon vertex morphing between circle and star."""
    ball = MockYellowBall(ip="ball_morph")
    ball.motion = motion_reg.parse_motion_list([
        {
            "type": "morph",
            "from": {"shape": "circle", "radius": 20, "cx": 100, "cy": 100},
            "to": {"shape": "star", "points": 5, "outer_radius": 25, "inner_radius": 12, "cx": 100, "cy": 100},
            "duration": 2.0,
            "resample": "distribute",
        }
    ])

    s0 = motion_reg.compute_shape_state(ball, now=0.0, parse_color=_parse_color, x=100, y=100, w=20, h=20)
    assert "vertices" in s0
    assert len(s0["vertices"]) > 0


def test_yellow_ball_custom_motion():
    """Test Draw.custom.motion programmatic callback registry."""
    Draw.motion.clear_custom(ip="custom_ball")
    Draw.custom.motion(
        ip="custom_ball",
        get_custom=lambda rec, t: {"custom_x": math.cos(t * math.tau) * 50, "custom_y": math.sin(t * math.tau) * 50},
        motion=[{"from": 0, "to": 1, "duration": 2.0, "repeat": True}],
    )

    rec = Draw.motion.get_custom("custom_ball")
    assert rec is not None
    assert rec.ip == "custom_ball"

    changed = Draw.motion.tick_custom(now=0.5)
    assert changed is True
    assert "custom_x" in rec.current_value
    assert "custom_y" in rec.current_value
    Draw.motion.clear_custom(ip="custom_ball")


def test_yellow_ball_timeline_orchestration():
    """Test Draw.timeline sequencing and staggering across multiple yellow balls."""
    tl = Draw.timeline(
        targets=["ball_1", "ball_2", "ball_3"],
        stagger=0.2,
        motion=[{"type": "move", "from": [0, 0], "to": [100, 100], "duration": 1.0, "graph": "linear"}],
        repeat=True,
    )
    assert len(tl.records) == 3
    # First target starts at 0.0, second at 0.2, third at 0.4
    assert tl.records[0][1].start == 0.0
    assert math.isclose(tl.records[1][1].start, 0.2, abs_tol=1e-5)
    assert math.isclose(tl.records[2][1].start, 0.4, abs_tol=1e-5)


def test_yellow_ball_interactive_triggers(motion_reg):
    """Test interactive trigger transitions (hover, press, drag)."""
    ball = MockYellowBall(ip="ball_trigger")
    records = motion_reg.parse_motion_list([
        {"type": "scale", "from": 1.0, "to": 1.5, "duration": 0.2}
    ])
    records[0].trigger = "hover"
    ball.motion = records

    # Hover active -> trigger progress increases
    ball._is_hovered = True
    motion_reg.tick_shape_triggers(ball, dt=0.1)
    assert ball._trigger_progresses.get("hover", 0.0) > 0.0

    motion_reg.tick_shape_triggers(ball, dt=0.2)
    assert math.isclose(ball._trigger_progresses.get("hover", 0.0), 1.0, abs_tol=1e-4)

    # Hover deactivated -> trigger progress smoothly falls back to 0.0
    ball._is_hovered = False
    motion_reg.tick_shape_triggers(ball, dt=0.3)
    assert math.isclose(ball._trigger_progresses.get("hover", 0.0), 0.0, abs_tol=1e-4)


# ══════════════════════════════════════════════════════════════════════════════
# 5. FULL WINDOW & CANVAS INTEGRATION TEST
# ══════════════════════════════════════════════════════════════════════════════

def test_window_motion_yellow_ball_integration():
    """Verify end-to-end integration: Window creation, Shape instantiation, Draw.motion attachment, and Canvas render evaluation."""
    win = Draw.window(tag="test_motion_yellow_win", width=500, height=400)

    # Add small yellow ball shape
    Draw.shape(
        display="test_motion_yellow_win",
        shape=[
            {
                "ip": "test_yellow_ball",
                "x": 100,
                "y": 100,
                "size": [20, 20],
                "color": "yellow",
                "border_radius": "50%",
            }
        ]
    )

    # Attach multi-attribute motion
    Draw.motion(
        ip="test_yellow_ball",
        motion=[
            {"type": "move", "from": [100, 100], "to": [300, 200], "duration": 2.0, "graph": "linear"},
            {"type": "pulse", "frequency": 3.0, "amplitude": 20.0},
        ]
    )

    canvas = win._draw_canvas
    assert len(canvas.shape_items) == 1
    shape_item = canvas.shape_items[0]
    assert shape_item.ip == "test_yellow_ball"
    assert len(shape_item.motion) == 2

    # Verify that compute_shape_state accurately transforms the shape geometry
    shape_item.motion_started_at = 0.0
    state = Draw.motion.compute_shape_state(shape_item, now=1.0, parse_color=_parse_color, x=100, y=100, w=20, h=20, canvas=canvas)
    assert "x" in state
    assert "y" in state
    assert math.isclose(state["x"], 200.0, abs_tol=1.0)
    assert math.isclose(state["y"], 150.0, abs_tol=1.0)

    Draw.window.close("test_motion_yellow_win")
