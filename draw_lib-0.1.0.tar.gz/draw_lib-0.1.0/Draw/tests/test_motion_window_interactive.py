"""
Draw/tests/test_motion_window_interactive.py
============================================
Automated unit & integration test suite for the Motion Studio Interactive Window.
Verifies all 38+ motion specifications, dynamic parameter sliders, categories,
and physics evaluations with the small yellow ball.
"""

import math
import os
import sys
import pytest
from PySide6.QtCore import QPointF, Qt
from PySide6.QtGui import QColor

# Ensure workspace root is on sys.path
TEST_DIR = os.path.dirname(os.path.abspath(__file__))
WORKSPACE_ROOT = os.path.dirname(TEST_DIR)
PARENT_ROOT = os.path.dirname(WORKSPACE_ROOT)
for path in (PARENT_ROOT, WORKSPACE_ROOT):
    if path not in sys.path:
        sys.path.insert(0, path)

import Draw
from Draw.examples.test_motion_window import (
    CATEGORIES,
    EASING_FUNCTIONS,
    MOTION_SPECS,
    ControlPanelWidget,
    MotionScreenWidget,
    MotionStudioWindow,
)


@pytest.fixture(scope="module")
def qapp():
    """Ensure QApplication instance is initialized."""
    return Draw._app.get_app()


def test_motion_catalog_coverage():
    """Verify that all 38+ motion types and categories are registered in the catalog."""
    assert len(MOTION_SPECS) >= 24
    categories = {s["category"] for s in MOTION_SPECS}
    assert "physics" in categories
    assert "procedural" in categories
    assert "kinematics" in categories
    assert "paths" in categories
    assert "transforms" in categories
    assert "styling" in categories
    assert "timeline" in categories

    for spec in MOTION_SPECS:
        assert "id" in spec
        assert "name" in spec
        assert "params" in spec
        assert isinstance(spec["params"], list)
        for p in spec["params"]:
            assert "id" in p
            assert "label" in p


def test_motion_studio_window_init(qapp):
    """Verify MotionStudioWindow creates both Screen and Control Panel widgets properly."""
    win = MotionStudioWindow()
    assert win.screen_widget is not None
    assert win.control_panel is not None
    assert win.is_playing is True
    assert win.speed_multiplier == 1.0
    assert win.ball_diameter == 22.0
    win.close()


def test_control_panel_category_filtering(qapp):
    """Verify filtering motions by category correctly updates the dropdown menu."""
    win = MotionStudioWindow()
    cp = win.control_panel

    for cat_id, cat_name in CATEGORIES:
        cp._select_category(cat_id)
        assert cp.active_category == cat_id
        count = cp.combo_motion.count()
        assert count > 0

    win.close()


def test_all_motion_specs_evaluation(qapp):
    """Verify that every motion specification evaluates without mathematical or runtime errors."""
    win = MotionStudioWindow()
    cx, cy, sw, sh = 400.0, 350.0, 800.0, 700.0

    for spec in MOTION_SPECS:
        win.control_panel._select_motion_by_id(spec["id"])
        assert win.active_spec["id"] == spec["id"]

        # Evaluate across several time samples (t=0.0, t=0.5, t=1.0, t=2.5)
        for t_sample in (0.0, 0.5, 1.0, 2.5):
            pos, vel, cycle_t, visuals = win._evaluate_motion(t_sample, cx, cy, sw, sh)
            assert isinstance(pos, tuple) and len(pos) == 2
            assert not math.isnan(pos[0]) and not math.isnan(pos[1])
            assert not math.isinf(pos[0]) and not math.isinf(pos[1])
            assert isinstance(vel, tuple) and len(vel) == 2
            assert 0.0 <= cycle_t <= 1.01
            assert isinstance(visuals, dict)
            assert "scale_x" in visuals
            assert "color" in visuals

    win.close()


def test_slider_parameter_mutations(qapp):
    """Verify changing slider parameter values triggers live motion update on screen."""
    win = MotionStudioWindow()
    cp = win.control_panel

    # Test spring stiffness adjustment
    cp._select_motion_by_id("spring")
    assert "stiffness" in cp.param_sliders
    slider, lbl, p_def = cp.param_sliders["stiffness"]
    slider.setValue(600)
    assert win.active_params["stiffness"] == 600

    # Test gravity acceleration adjustment
    cp._select_motion_by_id("gravity")
    assert "g" in cp.param_sliders
    slider_g, _, _ = cp.param_sliders["g"]
    slider_g.setValue(1500)
    assert win.active_params["g"] == 1500

    win.close()


def test_playback_actions(qapp):
    """Verify play, pause, reset, reverse, trail, guides, and speed actions."""
    win = MotionStudioWindow()

    # Pause / Play toggle
    assert win.is_playing is True
    win.on_action_triggered("toggle_play")
    assert win.is_playing is False
    win.on_action_triggered("toggle_play")
    assert win.is_playing is True

    # Reverse toggle
    assert win.is_reversed is False
    win.on_action_triggered("reverse")
    assert win.is_reversed is True

    # Trail toggle
    assert win.screen_widget.show_trail is True
    win.on_action_triggered("toggle_trail", False)
    assert win.screen_widget.show_trail is False

    # Speed multiplier
    win.on_action_triggered("speed", 2.5)
    assert math.isclose(win.speed_multiplier, 2.5)

    # Ball size
    win.on_action_triggered("ball_size", 36)
    assert win.ball_diameter == 36
    assert win.screen_widget.ball_base_size == 36

    win.close()


def test_screen_rendering_pipeline(qapp):
    """Verify that screen widget paintEvent and update_frame execute cleanly."""
    win = MotionStudioWindow()
    screen = win.screen_widget
    screen.resize(800, 600)

    # Push a frame update
    screen.update_frame(
        pos=(350.0, 280.0),
        vel=(120.0, -80.0),
        cycle_t=0.45,
        elapsed=1.2,
        fps=60.0,
        visuals={
            "scale_x": 1.2,
            "scale_y": 0.9,
            "rotation": 45.0,
            "opacity": 0.85,
            "color": QColor("#facc15"),
            "glow_radius": 15.0,
        }
    )
    assert screen.ball_pos == QPointF(350.0, 280.0)
    assert screen.speed > 0
    assert len(screen.trail_points) >= 1

    win.close()
