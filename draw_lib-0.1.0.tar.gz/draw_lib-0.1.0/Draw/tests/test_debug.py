import os
import sys
import shutil
import time

SYS_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PARENT_ROOT = os.path.dirname(SYS_ROOT)
if PARENT_ROOT not in sys.path:
    sys.path.insert(0, PARENT_ROOT)
if SYS_ROOT not in sys.path:
    sys.path.insert(0, SYS_ROOT)

try:
    import pytest
except ImportError:
    pytest = None

import Draw
from Draw.debug import (
    debug,
    DebugSettings,
    LoggingSystem,
    LogLevel,
    FrameHistory,
    PerformanceProfiler,
    RenderValidator,
    LeakDetector,
    ThreadMonitor,
)


def test_debug_settings_defaults():
    settings = debug.settings()
    assert isinstance(settings, DebugSettings)
    assert settings.fps_limit == 60
    assert settings.memory_limit == 4096.0
    assert settings.cpu_limit == 90.0
    assert settings.gpu_limit == 95.0
    assert settings.render_timeout == 5.0
    assert settings.force_thread_interrupt is False
    assert settings.infinite_loop_stuck_threshold == 6
    assert settings.infinite_loop_stuck_seconds == 3.0
    assert settings.infinite_render_count_threshold == 500_000
    assert settings.cpu_overload_duration == 5.0


def test_safeplay_enables_defaults():
    debug.safeplay()
    settings = debug.settings()
    assert settings.safeplay_active is True
    assert settings.fps_limiter_enabled is True
    assert settings.memory_watchdog_enabled is True
    assert settings.cpu_watchdog_enabled is True
    assert settings.gpu_watchdog_enabled is True


def test_custom_settings_modification():
    settings = debug.settings()
    settings.fps_limit = 120
    settings.memory_limit = 2048.0
    settings.cpu_limit = 80.0
    settings.gpu_limit = 85.0
    settings.render_timeout = 10.0
    settings.show_console = True
    settings.force_thread_interrupt = True
    settings.infinite_loop_stuck_seconds = 2.0
    settings.infinite_render_count_threshold = 100_000

    assert settings.fps_limit == 120
    assert settings.memory_limit == 2048.0
    assert settings.cpu_limit == 80.0
    assert settings.gpu_limit == 85.0
    assert settings.render_timeout == 10.0
    assert settings.show_console is True
    assert settings.force_thread_interrupt is True
    assert settings.infinite_loop_stuck_seconds == 2.0
    assert settings.infinite_render_count_threshold == 100_000


def test_logging_system(tmp_path):
    log_dir = str(tmp_path / "test_logs")
    logger = LoggingSystem(log_dir=log_dir)

    logger.log(LogLevel.INFO, "Test Info Message", category="runtime")
    logger.log(LogLevel.WARNING, "Test Warning Message", category="runtime")
    logger.log(LogLevel.EMERGENCY, "Test Crash Message", category="crashes")

    runtime_log = os.path.join(log_dir, "runtime.log")
    warnings_log = os.path.join(log_dir, "warnings.log")
    crashes_log = os.path.join(log_dir, "crashes.log")

    assert os.path.exists(runtime_log)
    assert os.path.exists(warnings_log)
    assert os.path.exists(crashes_log)

    with open(runtime_log, "r", encoding="utf-8") as f:
        content = f.read()
        assert "Test Info Message" in content

    with open(warnings_log, "r", encoding="utf-8") as f:
        content = f.read()
        assert "Test Warning Message" in content

    with open(crashes_log, "r", encoding="utf-8") as f:
        content = f.read()
        assert "Test Crash Message" in content


def test_frame_history():
    history = FrameHistory(capacity=50)
    for i in range(1, 11):
        history.add_frame(frame_time_ms=16.6)

    stats = history.get_stats()
    assert stats["total_frames"] == 10
    assert stats["avg_fps"] > 50.0
    assert stats["worst_frame_ms"] == 16.6

    graph = history.render_ascii_graph(width=10)
    assert len(graph) == 10


def test_performance_profiler():
    profiler = PerformanceProfiler()
    profiler.record("Layout", 2.1)
    profiler.record("Animation", 1.7)
    profiler.record("Render", 4.3)
    profiler.record("GPU Upload", 2.8)
    profiler.end_frame()

    bd = profiler.get_breakdown()
    assert bd["Layout"] == 2.1
    assert bd["Animation"] == 1.7
    assert bd["Render"] == 4.3
    assert bd["GPU Upload"] == 2.8

    output = profiler.format_output()
    assert "Layout" in output
    assert "2.1ms" in output


def test_render_validator():
    validator = RenderValidator()

    # Valid shape
    valid_shape = {"color": "blue", "size": [100, 100], "z": 0}
    errors = validator.validate_shape_dict(valid_shape, "valid_ip")
    assert len(errors) == 0

    # Invalid shape with NaN and negative size
    invalid_shape = {
        "color": 12345,  # Invalid color type
        "size": [-50, 100],  # Negative width
        "rotation": float("nan"),  # NaN
        "z": "invalid_z",  # Bad z
    }
    errors = validator.validate_shape_dict(invalid_shape, "bad_ip")
    assert len(errors) >= 3
    assert any("NaN" in e for e in errors)
    assert any("negative size" in e for e in errors)
    assert any("invalid color type" in e for e in errors)


def test_leak_detector_and_thread_monitor():
    detector = LeakDetector()
    leaks = detector.check_leaks()
    assert "window_leaks" in leaks
    assert "total_python_objects" in leaks

    summary = ThreadMonitor.get_thread_summary()
    assert summary["total_threads"] >= 1
    assert isinstance(summary["running_threads"], list)


def test_process_monitor_output():
    debug.record_frame(frame_time_ms=16.4, draw_calls=32, vertices=22045, triangles=10563)
    output = debug.process_monitor()

    assert "Renderer" in output
    assert "Draw Calls: 32" in output
    assert "Vertices: 22045" in output
    assert "Triangles: 10563" in output
    assert "Subsystems Status" in output


def test_safe_stop_workflow():
    assert debug.should_stop() is False
    debug.safe_stop("Unit Test Emergency Trigger")
    assert debug.should_stop() is True


if __name__ == "__main__":
    print("Running Draw.debug unit tests...")
    test_debug_settings_defaults()
    print("[OK] test_debug_settings_defaults passed")
    test_safeplay_enables_defaults()
    print("[OK] test_safeplay_enables_defaults passed")
    test_custom_settings_modification()
    print("[OK] test_custom_settings_modification passed")
    import tempfile, pathlib
    with tempfile.TemporaryDirectory() as tmpdir:
        test_logging_system(pathlib.Path(tmpdir))
    print("[OK] test_logging_system passed")
    test_frame_history()
    print("[OK] test_frame_history passed")
    test_performance_profiler()
    print("[OK] test_performance_profiler passed")
    test_render_validator()
    print("[OK] test_render_validator passed")
    test_leak_detector_and_thread_monitor()
    print("[OK] test_leak_detector_and_thread_monitor passed")
    test_process_monitor_output()
    print("[OK] test_process_monitor_output passed")

    # Reset stop flag for safe_stop test
    debug._stop_flag = False
    test_safe_stop_workflow()
    print("[OK] test_safe_stop_workflow passed")

    print("\nALL DEBUG TESTS PASSED SUCCESSFULLY!")

