"""
Draw.super Comprehensive Full-Feature & Hardware Test Suite
===========================================================
Thoroughly tests if Draw.super (Hardware-Accelerated OpenGL Engine) can handle:
1. Motion: move, rotate, scale, opacity, spring, shake, wave, timelines, pingpong, easings.
2. Color: Hex, RGB, RGBA, named colors, opacity blending, color tokens (Draw.colour/Draw.color).
3. Shape: GPU dynamic geometry batching (GPUGeometryBatcher: 3, 4, 5, 6, 8 vertices), complex shapes (borders, radius, glow, shadow, bend), vector paths.
4. Graph: Bar, line, pie, donut, area charts, legends, tooltips, live updates.
5. Hardware: Mouse (click, double click, move, hover, drag, wheel scroll) & Keyboard (press, release, arrows, space, escape, lineedit text input).
6. Combined Integrated Scene: All features running concurrently on a single OpenGL canvas.
"""

import os
import sys
import time

SYS_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PARENT_ROOT = os.path.dirname(SYS_ROOT)
if PARENT_ROOT not in sys.path:
    sys.path.insert(0, PARENT_ROOT)
if SYS_ROOT not in sys.path:
    sys.path.insert(0, SYS_ROOT)

import pytest
# pyrefly: ignore [missing-import]
from PySide6.QtCore import QPoint, QPointF, Qt
# pyrefly: ignore [missing-import]
from PySide6.QtGui import QColor, QKeyEvent, QMouseEvent, QWheelEvent

import Draw
from Draw._super import _DrawOpenGLCanvas, GPUGeometryBatcher, _parse_color_to_rgba


# ─────────────────────────────────────────────────────────────────────────────
# 1. MOTION TESTS UNDER DRAW.SUPER
# ─────────────────────────────────────────────────────────────────────────────

def test_super_motion_all_types():
    """Test that Draw.super handles all motion types: move, rotate, scale, opacity, spring, shake, wave."""
    win_tag = "test_super_motion"
    Draw.window(tag=win_tag, width=1000, height=800)

    motions_to_test = [
        ("m_move", {"type": "move", "from": [100, 100], "to": [300, 100], "time": {"start": 0.0, "end": 2.0}, "repeat": True, "pingpong": True}),
        ("m_rotate", {"type": "rotate", "from": 0, "to": 360, "time": {"start": 0.0, "end": 2.0}, "repeat": True}),
        ("m_scale", {"type": "scale", "from": [1.0, 1.0], "to": [2.0, 2.0], "time": {"start": 0.0, "end": 1.5}, "repeat": True}),
        ("m_opacity", {"type": "opacity", "from": 20, "to": 100, "time": {"start": 0.0, "end": 1.0}, "repeat": True}),
        ("m_spring", {"type": "spring", "stiffness": 150, "damping": 10, "from": [100, 200], "to": [250, 200], "time": {"start": 0.0, "end": 2.0}}),
        ("m_shake", {"type": "shake", "intensity": 10, "frequency": 4, "time": {"start": 0.0, "end": 5.0}, "repeat": True}),
        ("m_wave", {"type": "wave", "amplitude": 30, "frequency": 2.0, "time": {"start": 0.0, "end": 4.0}, "repeat": True}),
    ]

    shapes_def = []
    for i, (ip, m_dict) in enumerate(motions_to_test):
        shapes_def.append({
            "ip": ip,
            "vertices": 4,
            "size": [40, 40],
            "x": 100,
            "y": 100 + i * 60,
            "color": "#00E5FF",
        })

    Draw.shape(display=win_tag, shape=shapes_def)

    for ip, m_dict in motions_to_test:
        Draw.motion(ip=ip, motion=[m_dict])

    gl_canvas = Draw.super(display=win_tag)
    assert isinstance(gl_canvas, _DrawOpenGLCanvas)
    assert len(gl_canvas.shape_items) == len(motions_to_test)
    assert gl_canvas._has_active_shape_animation() is True

    # Advance time and tick animation multiple times
    for _ in range(5):
        gl_canvas._tick_animation()

    # Trigger OpenGL paint pipeline to verify motion compute and buffer loading
    gl_canvas.paintGL()

    # Verify that shapes have recorded last_position and motion state
    for s in gl_canvas.shape_items:
        assert s.last_position is not None
        assert s._last_motion_state is not None

    Draw.window.close(win_tag)


def test_super_motion_timelines_and_triggers():
    """Test Draw.super with timeline sequences and triggers."""
    win_tag = "test_super_timelines"
    Draw.window(tag=win_tag, width=800, height=600)

    Draw.shape(display=win_tag, shape=[
        {"ip": "timeline_shape", "vertices": 6, "size": [50, 50], "x": 100, "y": 100, "color": "orange"}
    ])

    Draw.timeline(
        tag=win_tag,
        motion=[
            {"ip": "timeline_shape", "type": "move", "from": [100, 100], "to": [200, 100], "time": {"start": 0.0, "end": 1.0}},
            {"ip": "timeline_shape", "type": "rotate", "from": 0, "to": 180, "time": {"start": 1.0, "end": 2.0}},
        ]
    )

    gl_canvas = Draw.super(display=win_tag)
    assert isinstance(gl_canvas, _DrawOpenGLCanvas)

    gl_canvas._tick_animation()
    gl_canvas.paintGL()

    Draw.window.close(win_tag)


# ─────────────────────────────────────────────────────────────────────────────
# 2. COLOR TESTS UNDER DRAW.SUPER
# ─────────────────────────────────────────────────────────────────────────────

def test_super_color_variations():
    """Test that Draw.super accurately parses and batches all color formats."""
    win_tag = "test_super_colors"
    Draw.window(tag=win_tag, width=800, height=600)

    # 1. Test helper _parse_color_to_rgba
    r, g, b, a = _parse_color_to_rgba("#FF0000", opacity=100)
    assert (round(r, 2), round(g, 2), round(b, 2), round(a, 2)) == (1.0, 0.0, 0.0, 1.0)

    r, g, b, a = _parse_color_to_rgba("green", opacity=50)
    assert round(a, 2) == 0.50

    # 2. Test shapes with various color specifications
    color_specs = [
        "#FF5722",                     # Hex 6
        "#00FF0088",                   # Hex 8 with alpha
        "cyan",                        # Named
        "rgb(255, 200, 0)",            # RGB string
        QColor(128, 64, 255, 200),     # QColor instance
    ]

    shapes = []
    for i, c in enumerate(color_specs):
        shapes.append({
            "ip": f"color_shape_{i}",
            "vertices": 4,
            "size": [40, 40],
            "x": 50 + i * 50,
            "y": 100,
            "color": c,
            "opacity": 80,
        })

    Draw.shape(display=win_tag, shape=shapes)
    gl_canvas = Draw.super(display=win_tag)

    # Run paintGL to execute color parsing & batching
    gl_canvas.paintGL()
    assert len(gl_canvas.shape_items) == len(color_specs)

    # Verify color validity on shapes and parsed RGBA
    for s in gl_canvas.shape_items:
        assert isinstance(s.color, QColor)
        assert s.color.isValid()
        rgba = _parse_color_to_rgba(s.color, s.opacity)
        assert len(rgba) == 4
        assert 0.0 <= rgba[3] <= 1.0

    Draw.window.close(win_tag)


def test_super_color_tokens_and_live_updates():
    """Test Draw.super with dynamic color tokens from Draw.color."""
    win_tag = "test_super_color_tokens"
    Draw.window(tag=win_tag, width=600, height=400)

    Draw.color(ip="token_shape", color=[{"for": "body", "color": "#7C4DFF"}])
    Draw.shape(display=win_tag, shape=[
        {"ip": "token_shape", "vertices": 4, "size": [60, 60], "x": 100, "y": 100, "color": "white"}
    ])

    gl_canvas = Draw.super(display=win_tag)
    gl_canvas.paintGL()

    # Update color token
    Draw.color(ip="token_shape", color=[{"for": "body", "color": "#00E676"}])
    gl_canvas.shape_items[0].dirty = True
    gl_canvas.paintGL()

    Draw.window.close(win_tag)


# ─────────────────────────────────────────────────────────────────────────────
# 3. SHAPE & GEOMETRY TESTS UNDER DRAW.SUPER
# ─────────────────────────────────────────────────────────────────────────────

def test_super_shapes_and_geometry():
    """Test GPU-batched regular polygons, complex borders, corner radius, deformations, and points."""
    win_tag = "test_super_shapes"
    Draw.window(tag=win_tag, width=1200, height=900)

    # Directly verify GPUGeometryBatcher fast vertex buffer packaging
    batcher = GPUGeometryBatcher(max_vertices=4096)
    pts = [QPointF(0, 0), QPointF(50, 0), QPointF(50, 50), QPointF(0, 50)]
    rgba = (1.0, 0.5, 0.2, 1.0)
    assert batcher.add_polygon(pts, rgba) is True
    assert batcher.v_count == 6  # 2 triangles * 3 vertices

    # Transformed regular polygon
    unit_hex = [(1.0, 0.0), (0.5, 0.866), (-0.5, 0.866), (-1.0, 0.0), (-0.5, -0.866), (0.5, -0.866)]
    assert batcher.add_transformed_polygon(100.0, 100.0, 30.0, 30.0, unit_hex, 45.0, rgba) is True
    assert batcher.v_count == 6 + 12  # +4 triangles * 3 = 18 total

    shapes = [
        # Regular Polygons (GPU-batched fast path)
        {"ip": "poly_tri", "vertices": 3, "size": [50, 50], "x": 50, "y": 50, "color": "red"},
        {"ip": "poly_quad", "vertices": 4, "size": [50, 50], "x": 120, "y": 50, "color": "green"},
        {"ip": "poly_penta", "vertices": 5, "size": [50, 50], "x": 190, "y": 50, "color": "blue"},
        {"ip": "poly_hexa", "vertices": 6, "size": [50, 50], "x": 260, "y": 50, "color": "yellow"},
        {"ip": "poly_octa", "vertices": 8, "size": [50, 50], "x": 330, "y": 50, "color": "magenta"},

        # Complex Styled Shapes (QPainter fallback pass)
        {"ip": "complex_border", "vertices": 4, "size": [60, 60], "x": 50, "y": 150, "color": "#2196F3", "border_width": 3, "border_color": "white", "border_style": "dashed"},
        {"ip": "complex_radius", "vertices": 4, "size": [60, 60], "x": 130, "y": 150, "color": "#9C27B0", "border_radius": 15},
        {"ip": "complex_circle", "vertices": 4, "size": [60, 60], "x": 210, "y": 150, "color": "#00BCD4", "border_radius": 30},
        {"ip": "complex_bend", "vertices": 4, "size": [70, 50], "x": 290, "y": 150, "color": "#FF9800", "curve_mode": "bend_all", "bend_amount": 20},
        {"ip": "complex_shadow", "vertices": 4, "size": [60, 60], "x": 380, "y": 150, "color": "#4CAF50", "shadow_color": "rgba(0,0,0,0.5)", "shadow_blur": 8, "shadow_offset": [4, 4]},
        {"ip": "complex_glow", "vertices": 4, "size": [60, 60], "x": 460, "y": 150, "color": "#E91E63", "glow_color": "#E91E63", "glow_blur": 12},
    ]

    Draw.shape(display=win_tag, shape=shapes)

    # Add vector lines via Draw.point
    Draw.point(
        tag=win_tag,
        graph=[1200, 900],
        points=[
            {
                "path": "50,300 ; 150,250 ; 250,320 ; 350,270",
                "colour": "#00E5FF",
                "width": 3,
                "edge": "curve",
                "smooth": "50%",
                "fill": False,
            }
        ]
    )

    gl_canvas = Draw.super(display=win_tag)
    assert isinstance(gl_canvas, _DrawOpenGLCanvas)
    assert len(gl_canvas.shape_items) == len(shapes)

    # Render frame safely
    gl_canvas.paintGL()

    Draw.window.close(win_tag)


# ─────────────────────────────────────────────────────────────────────────────
# 4. GRAPH TESTS UNDER DRAW.SUPER
# ─────────────────────────────────────────────────────────────────────────────

def test_super_graph_all_chart_types():
    """Test that Draw.super handles bar, line, pie, donut, and area charts seamlessly."""
    win_tag = "test_super_graphs"
    Draw.window(tag=win_tag, width=1200, height=800)

    # 1. Bar Chart
    Draw.graph(
        ip="graph_bar", type="bar", display=win_tag,
        graph=[
            {
                "x": ["A", "B", "C"],
                "y": [100, 250, 180],
                "title": "Revenue",
                "customise": {"color": "#FF5722", "show_values": True, "show_line": True}
            }
        ],
        x=30, y=30, width=250, height=180,
    )

    # 2. Line Chart
    Draw.graph(
        ip="graph_line", type="line", display=win_tag,
        graph=[
            {
                "x": ["Jan", "Feb", "Mar", "Apr"],
                "y": [20, 55, 40, 85],
                "title": "Trend",
                "customise": {"color": "#00E5FF", "show_line": True}
            }
        ],
        x=310, y=30, width=250, height=180,
    )

    # 3. Pie Chart
    Draw.graph(
        ip="graph_pie", type="pie", display=win_tag,
        graph=[
            {
                "x": ["Alpha", "Beta", "Gamma"],
                "y": [45, 35, 20],
                "title": "Pie",
                "customise": {"color": ["#E040FB", "#7C4DFF", "#536DFE"]}
            }
        ],
        x=30, y=240, width=200, height=200,
    )

    # 4. Donut Chart
    Draw.graph(
        ip="graph_donut", type="donut", display=win_tag,
        graph=[
            {
                "x": ["Python", "C++", "Rust"],
                "y": [60, 25, 15],
                "title": "Donut",
                "customise": {"color": ["#00E676", "#FFD600", "#FF3D00"], "inner_radius": 45}
            }
        ],
        x=260, y=240, width=200, height=200,
    )

    # 5. Area Chart
    Draw.graph(
        ip="graph_area", type="area", display=win_tag,
        graph=[
            {
                "x": ["Q1", "Q2", "Q3", "Q4"],
                "y": [50, 80, 65, 110],
                "title": "Area",
                "customise": {"color": "#00B0FF", "show_line": True}
            }
        ],
        x=500, y=240, width=250, height=180,
    )

    gl_canvas = Draw.super(display=win_tag)
    assert isinstance(gl_canvas, _DrawOpenGLCanvas)

    # Verify chart shapes & texts populated onto canvas
    assert len(gl_canvas.shape_items) > 10
    assert len(gl_canvas.text_items) > 5

    # Render without errors
    gl_canvas.paintGL()

    Draw.window.close(win_tag)


# ─────────────────────────────────────────────────────────────────────────────
# 5. HARDWARE TESTS: MOUSE & DRAGGING UNDER DRAW.SUPER
# ─────────────────────────────────────────────────────────────────────────────

def test_super_hardware_mouse_interaction():
    """Test mouse click, right click, double click, mouse move, hover, dragging, and wheel."""
    win_tag = "test_super_mouse"
    Draw.window(tag=win_tag, width=800, height=600)

    Draw.shape(display=win_tag, shape=[
        {"ip": "interactive_box", "vertices": 4, "size": [100, 100], "x": 100, "y": 100, "color": "#2979FF"}
    ])

    events_fired = []

    # Senses & Connectors
    Draw.senses("mouse_click", ip="interactive_box", id="s_click")
    Draw.connectors(sense="s_click", work=lambda r: events_fired.append("click"))

    Draw.senses("mouse_rightclick", ip="interactive_box", id="s_rclick")
    Draw.connectors(sense="s_rclick", work=lambda r: events_fired.append("rightclick"))

    Draw.senses("mouse_doubleclick", ip="interactive_box", id="s_dblclick")
    Draw.connectors(sense="s_dblclick", work=lambda r: events_fired.append("doubleclick"))

    Draw.senses("mouse_hover", ip="interactive_box", id="s_hover")
    Draw.connectors(sense="s_hover", work=lambda r: events_fired.append("hover"))

    Draw.senses("drag_move", ip="interactive_box", id="s_drag")
    Draw.connectors(sense="s_drag", work=lambda r: events_fired.append("drag"))

    gl_canvas = Draw.super(display=win_tag)
    gl_canvas.paintGL()

    # 1. Simulate Mouse Move / Hover
    move_ev = QMouseEvent(
        QMouseEvent.Type.MouseMove,
        QPointF(150.0, 150.0),
        QPointF(150.0, 150.0),
        Qt.MouseButton.NoButton,
        Qt.MouseButton.NoButton,
        Qt.KeyboardModifier.NoModifier,
    )
    gl_canvas.mouseMoveEvent(move_ev)
    assert "interactive_box" in gl_canvas._hovered_ips

    # 2. Simulate Left Click
    press_ev = QMouseEvent(
        QMouseEvent.Type.MouseButtonPress,
        QPointF(150.0, 150.0),
        QPointF(150.0, 150.0),
        Qt.MouseButton.LeftButton,
        Qt.MouseButton.LeftButton,
        Qt.KeyboardModifier.NoModifier,
    )
    gl_canvas.mousePressEvent(press_ev)

    release_ev = QMouseEvent(
        QMouseEvent.Type.MouseButtonRelease,
        QPointF(150.0, 150.0),
        QPointF(150.0, 150.0),
        Qt.MouseButton.LeftButton,
        Qt.MouseButton.NoButton,
        Qt.KeyboardModifier.NoModifier,
    )
    gl_canvas.mouseReleaseEvent(release_ev)

    # 3. Simulate Right Click
    rpress_ev = QMouseEvent(
        QMouseEvent.Type.MouseButtonPress,
        QPointF(150.0, 150.0),
        QPointF(150.0, 150.0),
        Qt.MouseButton.RightButton,
        Qt.MouseButton.RightButton,
        Qt.KeyboardModifier.NoModifier,
    )
    gl_canvas.mousePressEvent(rpress_ev)

    rrelease_ev = QMouseEvent(
        QMouseEvent.Type.MouseButtonRelease,
        QPointF(150.0, 150.0),
        QPointF(150.0, 150.0),
        Qt.MouseButton.RightButton,
        Qt.MouseButton.NoButton,
        Qt.KeyboardModifier.NoModifier,
    )
    gl_canvas.mouseReleaseEvent(rrelease_ev)

    # 4. Simulate Double Click
    dbl_ev = QMouseEvent(
        QMouseEvent.Type.MouseButtonDblClick,
        QPointF(150.0, 150.0),
        QPointF(150.0, 150.0),
        Qt.MouseButton.LeftButton,
        Qt.MouseButton.LeftButton,
        Qt.KeyboardModifier.NoModifier,
    )
    gl_canvas.mouseDoubleClickEvent(dbl_ev)

    # 5. Simulate Dragging to new position (250, 250)
    gl_canvas.mousePressEvent(press_ev)
    drag_move_ev = QMouseEvent(
        QMouseEvent.Type.MouseMove,
        QPointF(300.0, 300.0),
        QPointF(300.0, 300.0),
        Qt.MouseButton.LeftButton,
        Qt.MouseButton.LeftButton,
        Qt.KeyboardModifier.NoModifier,
    )
    gl_canvas.mouseMoveEvent(drag_move_ev)
    gl_canvas.mouseReleaseEvent(release_ev)

    # 6. Simulate Mouse Wheel Scroll
    wheel_ev = QWheelEvent(
        QPointF(150.0, 150.0),
        QPointF(150.0, 150.0),
        QPoint(0, 0),
        QPoint(0, -120),  # Scroll down
        Qt.MouseButton.NoButton,
        Qt.KeyboardModifier.NoModifier,
        Qt.ScrollPhase.NoScrollPhase,
        False,
    )
    gl_canvas.wheelEvent(wheel_ev)

    # Verify event capture
    assert Draw.senses.get("s_click").active is True
    assert Draw.senses.get("s_rclick").active is True
    assert Draw.senses.get("s_dblclick").active is True

    Draw.window.close(win_tag)


# ─────────────────────────────────────────────────────────────────────────────
# 6. HARDWARE TESTS: KEYBOARD & TEXT INPUT UNDER DRAW.SUPER
# ─────────────────────────────────────────────────────────────────────────────

def test_super_hardware_keyboard_and_input():
    """Test keyboard key press/release, arrow keys, space, modifiers, and lineedit input."""
    win_tag = "test_super_keyboard"
    Draw.window(tag=win_tag, width=800, height=600)

    # Text input field
    Draw.lineedit(
        display=win_tag,
        text="Initial Text",
        ip="test_input",
        x=50, y=50, width=200, height=35
    )

    # Senses for keyboard keys
    Draw.senses("key_press", id="s_space", key=["space"])
    Draw.senses("key_press", id="s_up", key=["up"])
    Draw.senses("key_press", id="s_down", key=["down"])
    Draw.senses("key_press", id="s_a", key=["a"])

    gl_canvas = Draw.super(display=win_tag)
    gl_canvas.paintGL()

    # 1. Simulate Space Key Press & Release
    space_press = QKeyEvent(QKeyEvent.Type.KeyPress, Qt.Key.Key_Space, Qt.KeyboardModifier.NoModifier, " ")
    gl_canvas.keyPressEvent(space_press)
    assert Draw.senses.get("s_space").active is True

    space_release = QKeyEvent(QKeyEvent.Type.KeyRelease, Qt.Key.Key_Space, Qt.KeyboardModifier.NoModifier, " ")
    gl_canvas.keyReleaseEvent(space_release)

    # 2. Simulate Arrow Keys
    up_press = QKeyEvent(QKeyEvent.Type.KeyPress, Qt.Key.Key_Up, Qt.KeyboardModifier.NoModifier)
    gl_canvas.keyPressEvent(up_press)
    assert Draw.senses.get("s_up").active is True

    down_press = QKeyEvent(QKeyEvent.Type.KeyPress, Qt.Key.Key_Down, Qt.KeyboardModifier.NoModifier)
    gl_canvas.keyPressEvent(down_press)
    assert Draw.senses.get("s_down").active is True

    # 3. Simulate Letter Key 'a'
    a_press = QKeyEvent(QKeyEvent.Type.KeyPress, Qt.Key.Key_A, Qt.KeyboardModifier.NoModifier, "a")
    gl_canvas.keyPressEvent(a_press)
    assert Draw.senses.get("s_a").active is True

    Draw.window.close(win_tag)


# ─────────────────────────────────────────────────────────────────────────────
# 7. INTEGRATED FULL SCENE TEST UNDER DRAW.SUPER
# ─────────────────────────────────────────────────────────────────────────────

def test_super_integrated_combined_scene():
    """Simultaneously test motion, color, shapes, graphs, mouse, and keyboard on Draw.super."""
    win_tag = "test_super_integrated"
    Draw.window(tag=win_tag, width=1200, height=900, background_color="#0A0E17")

    # Shapes with varied colors
    Draw.shape(display=win_tag, shape=[
        {"ip": "hero_node", "vertices": 6, "size": [80, 80], "x": 100, "y": 100, "color": "#00E5FF"},
        {"ip": "satellite_node", "vertices": 4, "size": [40, 40], "x": 250, "y": 100, "color": "#FF1744", "border_radius": 8},
    ])

    # Motion
    Draw.motion(ip="hero_node", motion=[
        {"type": "rotate", "from": 0, "to": 360, "time": {"start": 0.0, "end": 3.0}, "repeat": True}
    ])
    Draw.motion(ip="satellite_node", motion=[
        {"type": "scale", "from": [1.0, 1.0], "to": [1.5, 1.5], "time": {"start": 0.0, "end": 1.5}, "repeat": True, "pingpong": True}
    ])

    # Live Graph
    Draw.graph(
        ip="live_dashboard_chart", type="bar", display=win_tag,
        graph=[
            {
                "x": ["CPU", "GPU", "RAM"],
                "y": [45, 85, 60],
                "title": "Metrics",
                "customise": {"color": "#00E676", "show_values": True, "show_line": True}
            }
        ],
        x=500, y=100, width=300, height=200,
    )

    # Live Text
    counter = [1]
    Draw.text(
        tag=win_tag,
        text=lambda: f"Active Threads: {counter[0]}",
        customise={"x": 100, "y": 250, "font_size": 16, "color": "white"}
    )

    # Senses
    Draw.senses("mouse_click", ip="hero_node", id="hero_click")
    Draw.senses("key_press", id="main_key_press", key=["space"])

    # Activate Super Engine
    gl_canvas = Draw.super(
        display=win_tag,
        precompile=True,
        mode="max",
        vsync=False,
        batch_capacity=65536,
    )

    assert isinstance(gl_canvas, _DrawOpenGLCanvas)

    # Run multi-frame simulation loop
    for frame in range(10):
        counter[0] += 1
        gl_canvas._tick_animation()
        gl_canvas.paintGL()

    # Trigger interaction during active rendering
    click_ev = QMouseEvent(
        QMouseEvent.Type.MouseButtonPress,
        QPointF(140.0, 140.0),
        QPointF(140.0, 140.0),
        Qt.MouseButton.LeftButton,
        Qt.MouseButton.LeftButton,
        Qt.KeyboardModifier.NoModifier,
    )
    gl_canvas.mousePressEvent(click_ev)
    assert Draw.senses.get("hero_click").active is True

    # Render frame after interaction
    gl_canvas.paintGL()

    # Clean close
    Draw.window.close(win_tag)
