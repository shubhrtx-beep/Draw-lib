"""
Tests for Draw.super OpenGL Hardware Acceleration Engine.
Covers Tests A through K as required by the specification.
"""

import os
import sys
import time

SYS_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PARENT_ROOT = os.path.dirname(SYS_ROOT)
if PARENT_ROOT not in sys.path:
    sys.path.insert(0, PARENT_ROOT)
if SYS_ROOT not in sys.path:
    sys.path.insert(0, SYS_ROOT)

import pytest
from PySide6.QtCore import QPointF, Qt, QSize
from PySide6.QtGui import QColor, QMouseEvent, QResizeEvent

import Draw
from Draw._super import _DrawOpenGLCanvas, GPUGeometryBatcher, super_engine


def test_a_single_rectangle():
    """Test A: One single rectangle rendered via Draw.super."""
    win = Draw.window(tag="test_single_rect", width=600, height=400)
    Draw.shape(
        display="test_single_rect",
        shape=[{"vertices": 4, "size": [100, 80], "color": "#FF5722", "x": 50, "y": 50, "ip": "rect_a"}]
    )
    gl_canvas = Draw.super(display="test_single_rect")
    assert isinstance(gl_canvas, _DrawOpenGLCanvas)
    assert len(gl_canvas.shape_items) == 1
    Draw.window.close("test_single_rect")


def test_b_hundred_polygons():
    """Test B: 100+ simple polygons batched."""
    win = Draw.window(tag="test_hundred_poly", width=800, height=600)
    shapes = [
        {"vertices": 6, "size": [30, 30], "color": "cyan", "x": (i % 10) * 40, "y": (i // 10) * 40, "ip": f"hex_{i}"}
        for i in range(120)
    ]
    Draw.shape(display="test_hundred_poly", shape=shapes)
    gl_canvas = Draw.super(display="test_hundred_poly")
    assert len(gl_canvas.shape_items) == 120
    Draw.window.close("test_hundred_poly")


def test_c_thousands_shapes():
    """Test C: Thousands of simple shapes."""
    win = Draw.window(tag="test_thousands", width=1000, height=800)
    shapes = [
        {"vertices": 4, "size": [10, 10], "color": "green", "x": (i % 50) * 15, "y": (i // 50) * 15, "ip": f"sq_{i}"}
        for i in range(1000)
    ]
    Draw.shape(display="test_thousands", shape=shapes)
    gl_canvas = Draw.super(display="test_thousands", batch_capacity=65536)
    assert len(gl_canvas.shape_items) == 1000
    Draw.window.close("test_thousands")


def test_d_animated_shapes():
    """Test D: Animated shapes."""
    win = Draw.window(tag="test_anim_shapes", width=600, height=400)
    Draw.shape(
        display="test_anim_shapes",
        shape=[{
            "vertices": 5,
            "size": [60, 60],
            "color": "yellow",
            "x": 100,
            "y": 100,
            "ip": "star_anim",
        }]
    )
    # Dynamic timeline animation
    Draw.timeline(
        tag="test_anim_shapes",
        motion=[
            {"ip": "star_anim", "type": "rotate", "to": 360, "time": {"start": 0.0, "end": 2.0}, "repeat": True}
        ]
    )
    gl_canvas = Draw.super(display="test_anim_shapes")
    assert gl_canvas._has_active_shape_animation() or len(Draw._motion.motion._active_timelines) > 0
    Draw.window.close("test_anim_shapes")


def test_e_live_text():
    """Test E: Live text integration."""
    win = Draw.window(tag="test_live_text_win", width=600, height=400)
    counter = [0]
    Draw.text(
        tag="test_live_text_win",
        text=lambda: f"Count: {counter[0]}",
        customise={"x": 50, "y": 50, "font_size": 16}
    )
    gl_canvas = Draw.super(display="test_live_text_win")
    assert len(gl_canvas.text_items) == 1
    # Tick animation to refresh live text
    gl_canvas._tick_animation()
    counter[0] += 1
    gl_canvas._refresh_live_text_bindings()
    Draw.window.close("test_live_text_win")


def test_f_mouse_and_dragging():
    """Test F: Mouse interaction and dragging."""
    win = Draw.window(tag="test_mouse_drag", width=600, height=400)
    Draw.shape(
        display="test_mouse_drag",
        shape=[{"vertices": 4, "size": [80, 80], "color": "blue", "x": 100, "y": 100, "ip": "drag_box"}]
    )
    gl_canvas = Draw.super(display="test_mouse_drag")

    clicked = []
    Draw.senses("mouse_click", ip="drag_box", id="box_click")
    Draw.connectors(from_ip="drag_box", to_ip="drag_box", sense="box_click", work=lambda r: clicked.append(True))

    press_ev = QMouseEvent(
        QMouseEvent.Type.MouseButtonPress,
        QPointF(120.0, 120.0),
        Qt.MouseButton.LeftButton,
        Qt.MouseButton.LeftButton,
        Qt.KeyboardModifier.NoModifier,
    )
    gl_canvas.mousePressEvent(press_ev)

    release_ev = QMouseEvent(
        QMouseEvent.Type.MouseButtonRelease,
        QPointF(120.0, 120.0),
        Qt.MouseButton.LeftButton,
        Qt.MouseButton.NoButton,
        Qt.KeyboardModifier.NoModifier,
    )
    gl_canvas.mouseReleaseEvent(release_ev)

    sense_rec = Draw.senses.get("box_click")
    assert sense_rec is not None and sense_rec.active is True
    Draw.window.close("test_mouse_drag")


def test_g_scrolling():
    """Test G: Scrolling."""
    win = Draw.window(tag="test_scrolling", width=600, height=400)
    Draw.shape(
        display="test_scrolling",
        shape=[{"vertices": 4, "size": [200, 200], "color": "purple", "x": 100, "y": 800, "ip": "bottom_shape"}]
    )
    gl_canvas = Draw.super(display="test_scrolling")
    gl_canvas._scroll_y = 100.0
    gl_canvas._update_scroller_thumbs(from_paint=False)
    assert gl_canvas._scroll_y >= 0.0
    Draw.window.close("test_scrolling")


def test_h_complex_qpainter_shapes():
    """Test H: Complex QPainter-only shapes (borders, gradients, cutouts)."""
    win = Draw.window(tag="test_complex_shapes", width=600, height=400)
    Draw.shape(
        display="test_complex_shapes",
        shape=[
            {
                "vertices": 4,
                "size": [100, 100],
                "color": "red",
                "x": 50,
                "y": 50,
                "border_width": 4,
                "border_color": "white",
                "ip": "bordered_rect",
            }
        ]
    )
    gl_canvas = Draw.super(display="test_complex_shapes")
    assert len(gl_canvas.shape_items) == 1
    Draw.window.close("test_complex_shapes")


def test_i_draw_super_idempotent():
    """Test I: Repeated Draw.super() calls are idempotent (1 canvas, 1 timer)."""
    win = Draw.window(tag="test_idempotent", width=600, height=400)
    c1 = Draw.super(display="test_idempotent")
    c2 = Draw.super(display="test_idempotent")
    c3 = Draw.super(display="test_idempotent")

    assert c1 is c2
    assert c2 is c3
    assert hasattr(c1, "_animation_timer")
    assert c1._animation_timer.isActive()
    Draw.window.close("test_idempotent")


def test_j_window_resize_repeatedly():
    """Test J: Window resize repeatedly without render recursion."""
    win = Draw.window(tag="test_resize_rep", width=600, height=400)
    gl_canvas = Draw.super(display="test_resize_rep")

    # Simulate multiple resize events
    for (w, h) in [(800, 600), (1024, 768), (500, 400), (1200, 900)]:
        gl_canvas.resizeGL(w, h)
        assert gl_canvas._projection_matrix is not None
        assert gl_canvas._painting is False

    Draw.window.close("test_resize_rep")


def test_k_close_and_reopen_window():
    """Test K: Close and reopen window without stale resources or crashes."""
    win1 = Draw.window(tag="test_reopen_win", width=500, height=300)
    c1 = Draw.super(display="test_reopen_win")
    assert c1._cleaned_up is False
    c1._cleanup_resources()
    assert c1._cleaned_up is True
    Draw.window.close("test_reopen_win")

    # Reopen window with same tag
    win2 = Draw.window(tag="test_reopen_win", width=600, height=400)
    c2 = Draw.super(display="test_reopen_win")
    assert isinstance(c2, _DrawOpenGLCanvas)
    assert c2._cleaned_up is False
    Draw.window.close("test_reopen_win")
