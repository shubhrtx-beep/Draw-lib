"""
Security Remediation & Hardening Test Suite for Draw library.
Validates all 5 security fixes:
1. AST Calculator expression sandbox & exponent starvation bounds
2. Checkpoint JSON persistence & deserialization isolation
3. Text rendering HTML tag injection protection & opt-in behavior
4. Pixmap caching & I/O protection
5. Watchdog thread-safe emergency stop & cleanup
6. Schedule timer purge
"""

import json
import os
import tempfile
import pytest
from PySide6.QtGui import QColor, QPixmap
from PySide6.QtCore import QCoreApplication

import Draw
from Draw._calculator import calculator, eval_expression
from Draw._checkpoint import (
    CheckpointState,
    _state_to_dict,
    _state_from_dict,
    _serialize_shape,
    _deserialize_shape,
    _serialize_text,
    _deserialize_text,
)
from Draw._shapes import _parse_shape, _get_cached_pixmap, _PIXMAP_CACHE
from Draw._text import text, measure_text
from Draw._schedule import after, every, clear_all, _active_timers
from Draw.debug import debug


# ── 1. AST Calculator Security Tests ─────────────────────────────────────────

def test_ast_calculator_rejects_code_execution():
    """Verify that dangerous constructs and builtins are strictly blocked."""
    malicious_expressions = [
        "__import__('os').system('dir')",
        "eval('1 + 1')",
        "exec('import sys')",
        "open('test.txt', 'w')",
        "globals()",
        "locals()",
        "[x for x in range(10)]",
        "lambda: 42",
        "system('echo 1')",
    ]
    for expr in malicious_expressions:
        with pytest.raises(ValueError):
            eval_expression(expr)


def test_ast_calculator_exponent_bounds():
    """Verify that astronomical exponents are clamped to prevent CPU starvation."""
    starvation_expressions = [
        "999999 ** 999999",
        "2 ** 1000000",
        "10 ** 5000",
        "(-2) ** 0.5",  # complex result
    ]
    for expr in starvation_expressions:
        with pytest.raises(ValueError):
            eval_expression(expr)


def test_ast_calculator_valid_math():
    """Verify legitimate mathematical expressions evaluate correctly."""
    assert eval_expression("2 + 3 * 4") == 14.0
    assert eval_expression("sin(0)") == 0.0
    assert eval_expression("sqrt(16)") == 4.0
    assert eval_expression("abs(-42)") == 42.0
    assert eval_expression("2 ** 8") == 256.0
    assert calculator("2 + 3 * 4") == "14"


# ── 2. Checkpoint JSON Persistence Tests ─────────────────────────────────────

def test_checkpoint_json_serialization_roundtrip():
    """Verify state serialization to pure JSON and accurate deserialization."""
    shape_def = _parse_shape({
        "vertices": 4,
        "size": [100, 200],
        "border_radius": 10,
        "x": 50,
        "y": 75,
        "align": "center",
        "rotation": 45.0,
        "color": "red",
        "border_color": "green",
        "border_width": 2,
        "border_style": "dashed",
        "opacity": 90,
        "ip": "test_shape",
    })

    text_def = text._parse("Hello Secure World", {
        "ip": "test_text",
        "font_family": "Roboto",
        "font_size": 18,
        "bold": True,
        "color": "blue",
        "html": False,
    })

    state = CheckpointState(
        ip="slot1",
        display="main",
        properties={"scene": "intro", "level": 1},
        shape_items=[shape_def],
        text_items=[text_def],
        saved_at="2026-08-18T12:00:00Z",
    )

    data = _state_to_dict(state)

    # Must be serializable via standard json.dumps with no pickle
    json_str = json.dumps(data)
    loaded_data = json.loads(json_str)

    restored_state = _state_from_dict(loaded_data)

    assert restored_state.ip == "slot1"
    assert restored_state.display == "main"
    assert restored_state.properties["scene"] == "intro"
    assert len(restored_state.shape_items) == 1
    assert restored_state.shape_items[0].ip == "test_shape"
    assert restored_state.shape_items[0].vertices == 4
    assert restored_state.shape_items[0].rotation == 45.0
    assert restored_state.shape_items[0].color.name() == "#ff0000"

    assert len(restored_state.text_items) == 1
    assert restored_state.text_items[0].ip == "test_text"
    assert restored_state.text_items[0].text == "Hello Secure World"
    assert restored_state.text_items[0].font_size == 18
    assert restored_state.text_items[0].bold is True
    assert restored_state.text_items[0].html is False


def test_checkpoint_file_save_and_load(tmp_path):
    """Verify that save and load from file writes valid JSON to disk."""
    save_file = str(tmp_path / "checkpoint_test.json")

    shape_def = _parse_shape({"vertices": 3, "size": [80, 80], "color": "#ff5500", "ip": "triangle_1"})
    text_def = text._parse("Level Complete", {"ip": "score_label"})

    state = CheckpointState(
        ip="level_state",
        display="main",
        properties={"score": 9500},
        shape_items=[shape_def],
        text_items=[text_def],
    )

    Draw.checkpoint._save_to_file(state, save_file)
    assert os.path.exists(save_file)

    # Check file content is valid JSON text
    with open(save_file, "r", encoding="utf-8") as f:
        loaded_json = json.load(f)
        assert loaded_json["format"] == "Draw.checkpoint.json"
        assert loaded_json["ip"] == "level_state"

    # Reload through checkpoint registry
    restored = Draw.checkpoint._load_from_file("level_state", save_file)
    assert restored is not None
    assert restored.ip == "level_state"
    assert len(restored.shape_items) == 1
    assert restored.shape_items[0].ip == "triangle_1"


# ── 3. Text Rendering HTML Opt-in Tests ──────────────────────────────────────

def test_text_html_opt_in():
    """Verify HTML parsing is strictly opt-in and does not auto-activate on angle brackets."""
    plain_text_def = text._parse("User input: <script>alert(1)</script> and <test>", {})
    assert plain_text_def.html is False

    rich_text_def = text._parse("<b>Bold Heading</b>", {"html": True})
    assert rich_text_def.html is True

    rich_text_def_alias = text._parse("<i>Italic Heading</i>", {"rich": True})
    assert rich_text_def_alias.html is True


def test_measure_text_html_opt_in():
    """Verify measure_text respects the html flag."""
    sample = "<b>Long formatted title with tags</b>"
    w1, h1 = measure_text(sample, max_width=200, html=False)
    w2, h2 = measure_text(sample, max_width=200, html=True)
    assert w1 > 0 and h1 > 0
    assert w2 > 0 and h2 > 0


# ── 4. Pixmap In-memory Caching Tests ────────────────────────────────────────

def test_pixmap_caching(tmp_path):
    """Verify that pixmaps are cached in memory and reloaded if file mtime changes."""
    img_path = str(tmp_path / "test_icon.png")

    # Create a small valid test pixmap
    pm = QPixmap(64, 64)
    pm.fill(QColor("blue"))
    pm.save(img_path, "PNG")

    # Clear cache before test
    _PIXMAP_CACHE.clear()

    # First load
    cached_pm_1 = _get_cached_pixmap(img_path)
    assert cached_pm_1 is not None
    assert not cached_pm_1.isNull()
    assert img_path in _PIXMAP_CACHE

    # Second load (should hit cache)
    cached_pm_2 = _get_cached_pixmap(img_path)
    assert cached_pm_2 is cached_pm_1

    # Non-existent file
    assert _get_cached_pixmap(str(tmp_path / "does_not_exist.png")) is None


# ── 5. Watchdog Safe Emergency Stop Tests ────────────────────────────────────

def test_watchdog_safe_stop():
    """Verify safe_stop sets stop flag and requests shutdown cleanly."""
    debug._stop_flag = False
    debug.safe_stop("Unit test emergency stop")
    assert debug.should_stop() is True
    debug._stop_flag = False


# ── 6. Schedule Timers Cleanup Tests ─────────────────────────────────────────

def test_schedule_clear_all():
    """Verify Draw._schedule.clear_all purges all active timers."""
    h1 = after(10.0, lambda: None)
    h2 = every(5.0, lambda: None)
    assert len(_active_timers) >= 2

    stopped = clear_all()
    assert stopped >= 2
    assert len(_active_timers) == 0
