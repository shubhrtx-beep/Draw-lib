"""
tests/test_dodge_game.py
========================
Headless unit tests for dodge_game logic:
- Player boundary clamping
- Obstacle avoidance scoring
- Collision detection with player
- Progressive speed scaling
- Life decrement and Game Over transition
"""
import os
import sys
import pytest

# Ensure repository parent is on sys.path
TEST_DIR = os.path.dirname(os.path.abspath(__file__))
WORKSPACE_ROOT = os.path.dirname(TEST_DIR)
PARENT_ROOT = os.path.dirname(WORKSPACE_ROOT)
if PARENT_ROOT not in sys.path:
    sys.path.insert(0, PARENT_ROOT)
if WORKSPACE_ROOT not in sys.path:
    sys.path.insert(0, WORKSPACE_ROOT)

import dodge_game


def test_dodge_game_constants():
    assert dodge_game.WIN_WIDTH == 460
    assert dodge_game.WIN_HEIGHT == 680
    assert dodge_game.PLAYER_SIZE == 34
    assert dodge_game.BASE_FALL_SPEED == 210.0
    assert dodge_game.MAX_FALL_SPEED == 680.0


def test_player_clamping():
    # Test left boundary
    px = -50.0
    min_x = 10.0
    max_x = float(dodge_game.WIN_WIDTH - dodge_game.PLAYER_SIZE - 10)
    clamped_left = max(min_x, min(max_x, px))
    assert clamped_left == 10.0

    # Test right boundary
    px = 999.0
    clamped_right = max(min_x, min(max_x, px))
    assert clamped_right == max_x
    assert clamped_right == float(460 - 34 - 10)


def test_collision_detection_logic():
    # Player bounding box at bottom center
    px = 200.0
    py = float(dodge_game.PLAYER_Y)
    pw = float(dodge_game.PLAYER_SIZE)
    ph = float(dodge_game.PLAYER_SIZE)

    # 1. Obstacle overlapping player
    ox = 210.0
    oy = py + 5.0
    ow = 30.0
    oh = 30.0

    is_colliding = (
        ox < px + pw and ox + ow > px and
        oy < py + ph and oy + oh > py
    )
    assert is_colliding is True

    # 2. Obstacle far away
    ox = 50.0
    oy = 100.0
    is_colliding_far = (
        ox < px + pw and ox + ow > px and
        oy < py + ph and oy + oh > py
    )
    assert is_colliding_far is False


def test_avoidance_score_and_speed_scaling():
    score = 0
    # Simulate avoiding 10 obstacles
    for _ in range(10):
        score += 1

    assert score == 10
    speed = min(dodge_game.MAX_FALL_SPEED, dodge_game.BASE_FALL_SPEED + (score * dodge_game.SPEED_INCREMENT))
    assert speed == 210.0 + (10 * 5.5)
    assert speed == 265.0


def test_lives_and_game_over_logic():
    lives = 3
    # Hit 1
    lives -= 1
    assert lives == 2
    # Hit 2
    lives -= 1
    assert lives == 1
    # Hit 3 -> Game Over
    lives -= 1
    assert lives == 0
    is_game_over = (lives <= 0)
    assert is_game_over is True
