"""
tests/test_point_physics_animation.py
======================================
Interactive Physics Engine Integration Test for Draw.point (_point.py).

Verifies:
1. Dynamic real-time physics coordinate updates on Draw.point registered PathDef instances.
2. Multi-node spring-mass-damper chain simulation following mouse position.
3. 4 Physics Flower Entities with distinct mass, stiffness, and orbital spring mechanics.
4. Smooth Catmull-Rom vector path recalculation and geometry cache invalidation.
"""

import os
import sys
import math
import pytest

# Ensure repository root is on sys.path
REPO_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)

import Draw
from PySide6.QtCore import QTimer


class PointPhysicsEngine:
    """Multi-body spring-mass-damper physics engine for Draw.point paths."""

    def __init__(self, num_nodes: int = 15):
        self.num_nodes = num_nodes
        # Ribbon chain nodes (x, y, vx, vy)
        self.nodes = [[400.0, 300.0, 0.0, 0.0] for _ in range(num_nodes)]

        # 4 Flower Entities physics state: (x, y, vx, vy, mass, stiffness, damping, orbit_phase)
        self.flowers = {
            "flower_rose": {
                "x": 300.0, "y": 200.0, "vx": 0.0, "vy": 0.0,
                "stiffness": 0.08, "damping": 0.85, "orbit_radius": 120.0, "orbit_speed": 1.5
            },
            "flower_sunflower": {
                "x": 500.0, "y": 200.0, "vx": 0.0, "vy": 0.0,
                "stiffness": 0.15, "damping": 0.75, "orbit_radius": 160.0, "orbit_speed": -2.0
            },
            "flower_orchid": {
                "x": 300.0, "y": 400.0, "vx": 0.0, "vy": 0.0,
                "stiffness": 0.05, "damping": 0.90, "orbit_radius": 100.0, "orbit_speed": 1.0
            },
            "flower_lotus": {
                "x": 500.0, "y": 400.0, "vx": 0.0, "vy": 0.0,
                "stiffness": 0.12, "damping": 0.80, "orbit_radius": 140.0, "orbit_speed": -1.2
            },
        }

        self.target_x = 400.0
        self.target_y = 300.0
        self.time_accum = 0.0

    def update_target(self, tx: float, ty: float):
        self.target_x = tx
        self.target_y = ty

    def step(self, dt: float = 1.0 / 60.0):
        self.time_accum += dt

        # 1. Update Ribbon Head with Spring Attraction to Mouse
        head = self.nodes[0]
        ax = 0.25 * (self.target_x - head[0])
        ay = 0.25 * (self.target_y - head[1])
        head[2] = (head[2] + ax) * 0.80
        head[3] = (head[3] + ay) * 0.80
        head[0] += head[2]
        head[1] += head[3]

        # 2. Update Follower Nodes (Elastic Chain + Sine Wave Wiggle)
        for i in range(1, self.num_nodes):
            prev = self.nodes[i - 1]
            curr = self.nodes[i]

            dx = prev[0] - curr[0]
            dy = prev[1] - curr[1]
            dist = math.hypot(dx, dy)
            target_dist = 18.0

            if dist > 0.001:
                # Wave oscillation
                wave_offset = math.sin(self.time_accum * 6.0 + i * 0.4) * 3.0
                nx, ny = -dy / dist, dx / dist

                force = (dist - target_dist) * 0.35
                curr[2] = (curr[2] + (dx / dist) * force + nx * wave_offset) * 0.82
                curr[3] = (curr[3] + (dy / dist) * force + ny * wave_offset) * 0.82

            curr[0] += curr[2]
            curr[1] += curr[3]

        # 3. Update 4 Flower Entities (Orbital Spring Physics)
        for idx, (ip, fl) in enumerate(self.flowers.items()):
            angle = self.time_accum * fl["orbit_speed"] + idx * (math.pi / 2.0)
            desired_x = self.target_x + math.cos(angle) * fl["orbit_radius"]
            desired_y = self.target_y + math.sin(angle) * fl["orbit_radius"]

            fax = fl["stiffness"] * (desired_x - fl["x"])
            fay = fl["stiffness"] * (desired_y - fl["y"])

            fl["vx"] = (fl["vx"] + fax) * fl["damping"]
            fl["vy"] = (fl["vy"] + fay) * fl["damping"]

            fl["x"] += fl["vx"]
            fl["y"] += fl["vy"]

    def apply_impulse(self, force: float = 80.0):
        """Apply radial explosion force from target."""
        for fl in self.flowers.values():
            dx = fl["x"] - self.target_x
            dy = fl["y"] - self.target_y
            dist = max(1.0, math.hypot(dx, dy))
            fl["vx"] += (dx / dist) * force
            fl["vy"] += (dy / dist) * force


def test_physics_engine_simulation():
    """Test core physics step calculations and stability."""
    sim = PointPhysicsEngine(num_nodes=15)
    sim.update_target(600.0, 400.0)

    initial_head_x = sim.nodes[0][0]
    initial_rose_x = sim.flowers["flower_rose"]["x"]

    # Step simulation 30 frames
    for _ in range(30):
        sim.step(1.0 / 60.0)

    # Verify head moved towards target (600, 400)
    assert sim.nodes[0][0] > initial_head_x
    # Verify rose flower moved due to spring physics
    assert sim.flowers["flower_rose"]["x"] != initial_rose_x


def test_point_path_dynamic_physics_updates():
    """Test updating live Draw.point PathDef coordinates via physics engine."""
    app = Draw.get_app()
    win_tag = "test_physics_draw"
    win_w, win_h = 1000, 800

    Draw.window(tag=win_tag, width=win_w, height=win_h, background_color="#0F172A")

    # Create ribbon path and flower paths
    ribbon_path_str = " ; ".join(f"{100 + i * 20},{300}" for i in range(15))
    flower_path_str = "100,100 ; 120,50 ; 100,20 ; 80,50 ; 100,100 ; 150,80 ; 180,100 ; 150,120 ; 100,100"

    Draw.point(
        tag=win_tag,
        graph=[win_w, win_h],
        points=[
            {
                "path": ribbon_path_str,
                "colour": "#38BDF8",
                "width": 5,
                "edge": "curve",
                "smooth": "50%",
                "ip": "physics_ribbon",
            },
            {
                "path": flower_path_str,
                "colour": "#E11D48",
                "fill": True,
                "fill_colour": "#FB7185",
                "edge": "curve",
                "smooth": "50%",
                "width": 3,
                "ip": "flower_rose",
            },
        ],
    )

    ribbon_def = Draw.point.get_by_ip(win_tag, "physics_ribbon")
    rose_def = Draw.point.get_by_ip(win_tag, "flower_rose")

    assert ribbon_def is not None
    assert rose_def is not None

    b0_ribbon = Draw.point.get_pixel_bounds(win_tag, "physics_ribbon")
    b0_rose = Draw.point.get_pixel_bounds(win_tag, "flower_rose")

    # Execute physics step
    sim = PointPhysicsEngine(num_nodes=15)
    sim.update_target(700.0, 500.0)

    for _ in range(20):
        sim.step(1.0 / 60.0)

    # Push physics positions to PathDef objects
    ribbon_def.coords = [(n[0], n[1]) for n in sim.nodes]
    ribbon_def._cache_key = None

    # Move flower_rose using move_by_ip
    new_rose_x = sim.flowers["flower_rose"]["x"]
    new_rose_y = sim.flowers["flower_rose"]["y"]
    Draw.point.move_by_ip(win_tag, "flower_rose", new_rose_x, new_rose_y)

    b1_ribbon = Draw.point.get_pixel_bounds(win_tag, "physics_ribbon")
    b1_rose = Draw.point.get_pixel_bounds(win_tag, "flower_rose")

    # Bounds should update smoothly
    assert b1_ribbon != b0_ribbon
    assert b1_rose != b0_rose


def test_physics_impulse_explosion():
    """Test radial explosion impulse force on physics entities."""
    sim = PointPhysicsEngine()
    sim.update_target(400.0, 300.0)
    sim.step(1.0 / 60.0)

    vx_before = sim.flowers["flower_rose"]["vx"]
    sim.apply_impulse(100.0)
    vx_after = sim.flowers["flower_rose"]["vx"]

    # Velocity should significantly increase after explosion impulse
    assert abs(vx_after) > abs(vx_before)
