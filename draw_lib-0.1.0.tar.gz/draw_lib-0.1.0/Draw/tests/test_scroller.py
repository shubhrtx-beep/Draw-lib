import os
import sys

SYS_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PARENT_ROOT = os.path.dirname(SYS_ROOT)
if PARENT_ROOT not in sys.path:
    sys.path.insert(0, PARENT_ROOT)
if SYS_ROOT not in sys.path:
    sys.path.insert(0, SYS_ROOT)

import Draw
from Draw._align import AlignCalc, calc
from Draw._scroller import scroller, ScrollerConfig


def test_align_calc_primitives():
    """Test core math primitives in AlignCalc."""
    # clamp
    assert calc.clamp(5, 0, 10) == 5.0
    assert calc.clamp(-5, 0, 10) == 0.0
    assert calc.clamp(15, 0, 10) == 10.0

    # lerp & inverse_lerp
    assert calc.lerp(0, 100, 0.5) == 50.0
    assert calc.lerp(10, 20, 0) == 10.0
    assert calc.lerp(10, 20, 1) == 20.0
    assert calc.inverse_lerp(0, 100, 50) == 0.5
    assert calc.inverse_lerp(100, 100, 50) == 0.0  # degenerate case

    # remap
    assert calc.remap(50, 0, 100, 0, 1) == 0.5
    assert calc.remap(150, 0, 100, 0, 1, clamped=True) == 1.0
    assert calc.remap(150, 0, 100, 0, 1, clamped=False) == 1.5

    # smoothstep
    assert calc.smoothstep(0, 10, -1) == 0.0
    assert calc.smoothstep(0, 10, 11) == 1.0
    assert calc.smoothstep(0, 10, 5) == 0.5


def test_align_calc_scroll_and_geometry():
    """Test scroll geometry and spatial functions in AlignCalc."""
    # normalize & denormalize
    assert calc.normalize(50, 0, 200) == 0.25
    assert calc.normalize(-10, 0, 200) == 0.0
    assert calc.normalize(250, 0, 200) == 1.0
    assert calc.denormalize(0.25, 0, 200) == 50.0

    # thumb position & fraction
    assert calc.thumb_position(0.5, 10, 200, 40) == 90.0
    assert calc.thumb_fraction(90, 10, 200, 40) == 0.5

    # distance & midpoint
    assert calc.distance(0, 0, 3, 4) == 5.0
    assert calc.midpoint(0, 0, 10, 20) == (5.0, 10.0)

    # rect_contains & rects_overlap
    assert calc.rect_contains(10, 10, 50, 50, 20, 20) is True
    assert calc.rect_contains(10, 10, 50, 50, 0, 0) is False
    assert calc.rects_overlap(0, 0, 20, 20, 10, 10, 20, 20) is True
    assert calc.rects_overlap(0, 0, 10, 10, 20, 20, 10, 10) is False

    # snap_to_grid
    assert calc.snap_to_grid(47, 10) == 50.0
    assert calc.snap_to_grid(42, 10) == 40.0
    assert calc.snap_to_grid(47, 0) == 47.0


def test_align_calc_alignment_wrappers():
    """Test align_pos, align_rect, and inset wrappers."""
    pos = calc.align_pos("center", sw=100, sh=50, cw=400, ch=200)
    assert pos == (150.0, 75.0)

    rect = calc.align_rect("top-left", sw=100, sh=50, cw=400, ch=200, pad=10)
    assert rect == (10.0, 10.0, 100, 50)

    inset = calc.inset(400, 300, pad_left=10, pad_top=20, pad_right=30, pad_bottom=40)
    assert inset == (10.0, 20.0, 360.0, 240.0)


def test_scroller_registry_management():
    """Test registering, querying, and removing scrollers in mock/windowless environment."""
    scroller.remove(None)
    assert len(scroller.list()) == 0

    cfg = scroller(display="dummy_win", scroll="vertical", keyboard=True)
    assert isinstance(cfg, ScrollerConfig)
    assert cfg.display == "dummy_win"
    assert cfg.direction == "vertical"
    assert cfg.scroll == "vertical"
    assert len(cfg.sense_ids) > 0
    assert len(cfg.connector_ids) > 0

    # Querying
    found = scroller.get(cfg.id)
    assert found is cfg
    assert len(scroller.list()) == 1

    # Add second scroller with custom IP and both scroll direction
    cfg2 = scroller(
        ip="main_scroll",
        room="page",
        scroll="both",
        max_x=1500,
        max_y=2500,
        speed=2.5,
        align="right",
        thumb="thumb_shape",
        motion="scroll_motion",
        senses="scroll_sense",
        connectors="scroll_connector",
        display="dummy_win",
    )
    assert cfg2.id == "main_scroll"
    assert cfg2.ip == "main_scroll"
    assert cfg2.room == "page"
    assert cfg2.scroll == "both"
    assert cfg2.direction == "both"
    assert cfg2.max_x == 1500.0
    assert cfg2.max_y == 2500.0
    assert cfg2.speed == 2.5
    assert cfg2.align == "right"
    assert cfg2.thumb == "thumb_shape"
    assert cfg2.motion == "scroll_motion"
    assert cfg2.senses == "scroll_sense"
    assert cfg2.connectors == "scroll_connector"
    assert cfg2.show_thumb is True
    assert len(scroller.list()) == 2

    # Removal by ID
    scroller.remove("main_scroll")
    assert scroller.get("main_scroll") is None
    assert len(scroller.list()) == 1

    # Clear all
    scroller.remove(None)
    assert len(scroller.list()) == 0


def test_scroller_lock_and_enable():
    """Test enable, disable, lock, unlock API."""
    scroller.remove(None)
    cfg = scroller(ip="test_lock", display="dummy_win")
    assert cfg.enabled is True
    assert cfg.locked is False

    scroller.lock("test_lock")
    assert cfg.locked is True

    scroller.unlock("test_lock")
    assert cfg.locked is False

    scroller.disable("test_lock")
    assert cfg.enabled is False

    scroller.enable("test_lock")
    assert cfg.enabled is True

    scroller.remove(None)


def test_scroller_programmatic_scroll_mock():
    """Test scroll_to, scroll_by, set_scroll, get_scroll, scroll_to_ip, center_ip."""
    scroller.remove(None)
    offsets = scroller.get_scroll(display="non_existent_win")
    assert offsets == {"x": 0.0, "y": 0.0}

    # Should not raise exception even when canvas is absent
    scroller.scroll_to(100, display="non_existent_win")
    scroller.scroll_by(50, display="non_existent_win")
    scroller.set_scroll(200, display="non_existent_win")
    scroller.scroll_to_ip("some_shape", display="non_existent_win")
    scroller.center_ip("some_shape", display="non_existent_win")


def test_text_auto_align_in_ip():
    """Test auto_align_in_ip property parsing and TextDef registration."""
    from Draw._text import _TextRegistry
    tdef = _TextRegistry._parse(
        "Test content string",
        {"auto_align_in_ip": True, "hitbox": "card_1", "min_font_size": 12},
        ip="test_text",
    )
    assert tdef.auto_align_in_ip is True
    assert tdef.hitbox_ip == "card_1"
    assert tdef.min_font_size == 12

    # Default is False
    tdef_def = _TextRegistry._parse("Plain text", {}, ip="plain")
    assert tdef_def.auto_align_in_ip is False


if __name__ == "__main__":
    print("Running Draw._align (AlignCalc) and Draw._scroller unit tests...")
    test_align_calc_primitives()
    print("[OK] test_align_calc_primitives passed")
    test_align_calc_scroll_and_geometry()
    print("[OK] test_align_calc_scroll_and_geometry passed")
    test_align_calc_alignment_wrappers()
    print("[OK] test_align_calc_alignment_wrappers passed")
    test_scroller_registry_management()
    print("[OK] test_scroller_registry_management passed")
    test_scroller_lock_and_enable()
    print("[OK] test_scroller_lock_and_enable passed")
    test_scroller_programmatic_scroll_mock()
    print("[OK] test_scroller_programmatic_scroll_mock passed")
    test_text_auto_align_in_ip()
    print("[OK] test_text_auto_align_in_ip passed")

    print("\nALL SCROLLER AND ALIGN TESTS PASSED SUCCESSFULLY!\n")
