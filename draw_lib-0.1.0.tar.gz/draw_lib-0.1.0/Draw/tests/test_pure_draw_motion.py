"""
Draw/tests/test_pure_draw_motion.py
===================================
Unit & integration tests for Draw library native helpers (Draw.slider, Draw.button,
Draw.combobox, Draw.checkbox, Draw.motion.studio) and the pure Draw studio application.
"""

import os
import sys
import pytest

# Ensure workspace root is on sys.path
TEST_DIR = os.path.dirname(os.path.abspath(__file__))
WORKSPACE_ROOT = os.path.dirname(TEST_DIR)
PARENT_ROOT = os.path.dirname(WORKSPACE_ROOT)
for path in (PARENT_ROOT, WORKSPACE_ROOT):
    if path not in sys.path:
        sys.path.insert(0, path)

import Draw
from Draw.examples.test_motion_window_pure_draw import (
    setup_pure_draw_studio,
    apply_active_motion,
    on_motion_changed,
    on_slider_changed,
    app_state,
    PURE_MOTIONS,
    WIN_TAG,
)


@pytest.fixture(scope="module")
def qapp():
    return Draw._app.get_app()


def test_draw_native_helpers_exist():
    """Verify that Draw exports slider, button, combobox, checkbox directly."""
    assert hasattr(Draw, "slider")
    assert callable(Draw.slider)
    assert hasattr(Draw, "button")
    assert callable(Draw.button)
    assert hasattr(Draw, "combobox")
    assert callable(Draw.combobox)
    assert hasattr(Draw, "checkbox")
    assert callable(Draw.checkbox)
    assert hasattr(Draw.motion, "studio")
    assert callable(Draw.motion.studio)


def test_draw_native_helpers_instantiation(qapp):
    """Verify creating native widgets via Draw.slider, Draw.button, etc."""
    win_tag = "test_native_win"
    Draw.window(tag=win_tag, title="Native Test", width=600, height=400)

    # Test slider
    sl = Draw.slider(ip="test_slider_1", display=win_tag, min=10, max=500, value=150)
    assert sl is not None
    assert Draw.widget.get_value("test_slider_1") == 150
    Draw.widget.set_value("test_slider_1", 300)
    assert Draw.widget.get_value("test_slider_1") == 300

    # Test button
    clicked = []
    btn = Draw.button(ip="test_btn_1", display=win_tag, text="Click Me", on_click=lambda: clicked.append(True))
    assert btn is not None

    # Test combobox
    combo = Draw.combobox(ip="test_combo_1", display=win_tag, items=["Option A", "Option B"])
    assert combo is not None
    assert Draw.widget.get_value("test_combo_1") == "Option A"
    Draw.widget.set_value("test_combo_1", "Option B")
    assert Draw.widget.get_value("test_combo_1") == "Option B"

    # Test checkbox
    toggled = []
    chk = Draw.checkbox(ip="test_chk_1", display=win_tag, text="Check", checked=True, on_toggle=lambda v: toggled.append(v))
    assert chk is not None
    assert Draw.widget.get_value("test_chk_1") is True

    Draw.window.close(win_tag)


def test_draw_motion_studio_launcher(qapp):
    """Verify that Draw.motion.studio() creates the studio window."""
    win = Draw.motion.studio()
    assert win is not None
    assert hasattr(win, "screen_widget")
    assert hasattr(win, "control_panel")
    win.close()


def test_pure_draw_studio_app(qapp):
    """Verify building and driving the pure Draw motion studio application."""
    setup_pure_draw_studio()

    # Iterate through all motions and apply them
    for m in PURE_MOTIONS:
        on_motion_changed(m["id"])
        assert app_state["active_idx"] >= 0

    # Test slider changes
    on_slider_changed("stiffness", 450)
    assert app_state["param_values"]["stiffness"] == 450

    Draw.window.close(WIN_TAG)
