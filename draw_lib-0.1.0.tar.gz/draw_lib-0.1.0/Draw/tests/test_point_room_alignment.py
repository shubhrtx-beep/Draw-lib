"""
tests/test_point_room_alignment.py
===================================
Alignment and Layout Integration Test for Draw.point (_point.py) and Draw.room (_room.py).

This module tests:
1. Creating 4 distinct flower vector paths using Draw.point (Style 1 with Catmull-Rom splines).
2. Aligning all 4 flowers using scene-relative anchors (top-left, top-right, bottom-left, bottom-right).
3. Aligning all 4 flowers using object-relative placements (center, right, bottom).
4. Aligning 4 flowers inside a scoped container box (container="...").
5. Resizing flower point paths dynamically using Draw.room(sizes=...).
"""

import os
import sys
import pytest

# Ensure repository root is on sys.path for direct script execution
REPO_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)

import Draw

# ── 4 Flower Path Definitions (Catmull-Rom smooth vector paths) ──────────────

FLOWER_ROSE_PATH = (
    "100,100 ; 120,50 ; 100,20 ; 80,50 ; 100,100 ; "
    "150,80 ; 180,100 ; 150,120 ; 100,100 ; "
    "120,150 ; 100,180 ; 80,150 ; 100,100 ; "
    "50,120 ; 20,100 ; 50,80 ; 100,100"
)

FLOWER_SUNFLOWER_PATH = (
    "100,100 ; 100,30 ; 115,70 ; 150,50 ; 130,85 ; "
    "170,100 ; 130,115 ; 150,150 ; 115,130 ; 100,170 ; "
    "85,130 ; 50,150 ; 70,115 ; 30,100 ; 70,85 ; 50,50 ; 85,70 ; 100,100"
)

FLOWER_ORCHID_PATH = (
    "100,100 ; 140,40 ; 160,100 ; 140,160 ; 100,100 ; "
    "60,160 ; 40,100 ; 60,40 ; 100,100"
)

FLOWER_LOTUS_PATH = (
    "100,100 ; 120,30 ; 150,60 ; 120,100 ; 100,100 ; "
    "80,100 ; 50,60 ; 80,30 ; 100,100 ; "
    "100,120 ; 140,150 ; 100,180 ; 60,150 ; 100,120"
)


def _create_4_flowers(window_tag: str, width: int = 1000, height: int = 800):
    """Helper to initialize window and 4 flower point paths."""
    Draw.window(tag=window_tag, width=width, height=height, background_color="#0F172A")
    Draw.point(
        tag=window_tag,
        graph=[width, height],
        points=[
            {
                "path": FLOWER_ROSE_PATH,
                "colour": "#E11D48",
                "fill": True,
                "fill_colour": "#FB7185",
                "edge": "curve",
                "smooth": "50%",
                "width": 3,
                "ip": "flower_rose",
            },
            {
                "path": FLOWER_SUNFLOWER_PATH,
                "colour": "#D97706",
                "fill": True,
                "fill_colour": "#FBBF24",
                "edge": "curve",
                "smooth": "40%",
                "width": 3,
                "ip": "flower_sunflower",
            },
            {
                "path": FLOWER_ORCHID_PATH,
                "colour": "#7C3AED",
                "fill": True,
                "fill_colour": "#C084FC",
                "edge": "curve",
                "smooth": "50%",
                "width": 3,
                "ip": "flower_orchid",
            },
            {
                "path": FLOWER_LOTUS_PATH,
                "colour": "#0284C7",
                "fill": True,
                "fill_colour": "#38BDF8",
                "edge": "curve",
                "smooth": "50%",
                "width": 3,
                "ip": "flower_lotus",
            },
        ],
    )


def test_point_room_scene_alignment():
    """Test aligning 4 flowers to 4 scene corners using Draw.room()."""
    app = Draw.get_app()
    win_tag = "test_scene_corner"
    win_w, win_h = 1000, 800
    pad = 40

    _create_4_flowers(win_tag, win_w, win_h)

    # Perform Draw.room alignment to 4 corners
    Draw.room(
        display=win_tag,
        general={"padding": pad},
        scene={
            "flower_rose": "top-left",
            "flower_sunflower": "top-right",
            "flower_orchid": "bottom-left",
            "flower_lotus": "bottom-right",
        },
    )

    # Post-alignment bounds
    rose_b = Draw.point.get_pixel_bounds(win_tag, "flower_rose")
    sun_b = Draw.point.get_pixel_bounds(win_tag, "flower_sunflower")
    orc_b = Draw.point.get_pixel_bounds(win_tag, "flower_orchid")
    lot_b = Draw.point.get_pixel_bounds(win_tag, "flower_lotus")

    # 1. Top-Left: x = pad, y = pad
    assert abs(rose_b[0] - pad) < 1e-3
    assert abs(rose_b[1] - pad) < 1e-3

    # 2. Top-Right: x = win_w - w - pad, y = pad
    assert abs(sun_b[0] - (win_w - sun_b[2] - pad)) < 1e-3
    assert abs(sun_b[1] - pad) < 1e-3

    # 3. Bottom-Left: x = pad, y = win_h - h - pad
    assert abs(orc_b[0] - pad) < 1e-3
    assert abs(orc_b[1] - (win_h - orc_b[3] - pad)) < 1e-3

    # 4. Bottom-Right: x = win_w - w - pad, y = win_h - h - pad
    assert abs(lot_b[0] - (win_w - lot_b[2] - pad)) < 1e-3
    assert abs(lot_b[1] - (win_h - lot_b[3] - pad)) < 1e-3


def test_point_room_relative_alignment():
    """Test object-relative chained alignment of 4 flowers using Draw.room()."""
    app = Draw.get_app()
    win_tag = "test_object_relative"
    win_w, win_h = 1000, 800
    gap = 25

    _create_4_flowers(win_tag, win_w, win_h)

    Draw.room(
        display=win_tag,
        general={"padding": gap},
        scene={
            "flower_rose": "center",
            "flower_sunflower": ["flower_rose", "right"],
            "flower_orchid": ["flower_rose", "bottom"],
            "flower_lotus": ["flower_orchid", "right"],
        },
    )

    rose_b = Draw.point.get_pixel_bounds(win_tag, "flower_rose")
    sun_b = Draw.point.get_pixel_bounds(win_tag, "flower_sunflower")
    orc_b = Draw.point.get_pixel_bounds(win_tag, "flower_orchid")
    lot_b = Draw.point.get_pixel_bounds(win_tag, "flower_lotus")

    # Center check for flower_rose
    expected_rose_x = (win_w - rose_b[2]) / 2.0
    expected_rose_y = (win_h - rose_b[3]) / 2.0
    assert abs(rose_b[0] - expected_rose_x) < 1e-3
    assert abs(rose_b[1] - expected_rose_y) < 1e-3

    # flower_sunflower to the right of flower_rose: x = rose_x + rose_w + gap
    assert abs(sun_b[0] - (rose_b[0] + rose_b[2] + gap)) < 1e-3

    # flower_orchid below flower_rose: y = rose_y + rose_h + gap
    assert abs(orc_b[1] - (rose_b[1] + rose_b[3] + gap)) < 1e-3

    # flower_lotus to the right of flower_orchid: x = orc_x + orc_w + gap
    assert abs(lot_b[0] - (orc_b[0] + orc_b[2] + gap)) < 1e-3


def test_point_room_container_alignment():
    """Test scoped container alignment of 4 flowers inside a card shape."""
    app = Draw.get_app()
    win_tag = "test_container_alignment"
    win_w, win_h = 1000, 800

    _create_4_flowers(win_tag, win_w, win_h)

    # Create parent container shape (card panel)
    card_x, card_y, card_w, card_h = 200.0, 150.0, 600.0, 500.0
    Draw.shapes(
        display=win_tag,
        shape=[
            {
                "ip": "garden_card",
                "vertices": 4,
                "x": int(card_x),
                "y": int(card_y),
                "size": [int(card_w), int(card_h)],
                "color": "#1E293B",
            }
        ],
    )

    pad = 30
    Draw.room(
        display=win_tag,
        container="garden_card",
        general={"padding": pad},
        scene={
            "flower_rose": "top-left",
            "flower_sunflower": "top-right",
            "flower_orchid": "bottom-left",
            "flower_lotus": "bottom-right",
        },
    )

    rose_b = Draw.point.get_pixel_bounds(win_tag, "flower_rose")
    sun_b = Draw.point.get_pixel_bounds(win_tag, "flower_sunflower")
    orc_b = Draw.point.get_pixel_bounds(win_tag, "flower_orchid")
    lot_b = Draw.point.get_pixel_bounds(win_tag, "flower_lotus")

    # Positions should be inside garden_card bounds
    assert abs(rose_b[0] - (card_x + pad)) < 1e-3
    assert abs(rose_b[1] - (card_y + pad)) < 1e-3

    assert abs(sun_b[0] - (card_x + card_w - sun_b[2] - pad)) < 1e-3
    assert abs(sun_b[1] - (card_y + pad)) < 1e-3

    assert abs(orc_b[0] - (card_x + pad)) < 1e-3
    assert abs(orc_b[1] - (card_y + card_h - orc_b[3] - pad)) < 1e-3

    assert abs(lot_b[0] - (card_x + card_w - lot_b[2] - pad)) < 1e-3
    assert abs(lot_b[1] - (card_y + card_h - lot_b[3] - pad)) < 1e-3


def test_point_room_resize_alignment():
    """Test dynamic resizing of point paths using Draw.room(sizes=...)."""
    app = Draw.get_app()
    win_tag = "test_resize_alignment"
    win_w, win_h = 1000, 800

    _create_4_flowers(win_tag, win_w, win_h)

    target_w, target_h = 200.0, 200.0
    Draw.room(
        display=win_tag,
        general={"padding": 20},
        sizes={
            "flower_rose": {"width": target_w, "height": target_h},
        },
        scene={
            "flower_rose": "center",
        },
    )

    rose_b = Draw.point.get_pixel_bounds(win_tag, "flower_rose")
    assert abs(rose_b[2] - target_w) < 2.0
    assert abs(rose_b[3] - target_h) < 2.0
