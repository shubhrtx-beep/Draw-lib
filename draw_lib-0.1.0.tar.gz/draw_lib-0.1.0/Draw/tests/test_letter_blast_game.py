"""
test_letter_blast_game.py
=========================
Verification test suite for letter_blast_game.py mechanics.
"""

import os
import sys
import time

WORKSPACE_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PARENT_ROOT = os.path.dirname(WORKSPACE_ROOT)
if PARENT_ROOT not in sys.path:
    sys.path.insert(0, PARENT_ROOT)
if WORKSPACE_ROOT not in sys.path:
    sys.path.insert(0, WORKSPACE_ROOT)

import Draw
import letter_blast_game as game


def test_letter_blast_game_flow():
    print("[TEST] Step 1: Initializing game scene...")
    game.init_game_scene()

    assert game.WIN_TAG in Draw.window.list_tags(), "Window tag should be registered"
    win = Draw.window.get(game.WIN_TAG)
    assert win is not None, "Window instance must exist"

    print("[TEST] Step 2: Testing Loader -> Gameplay transition...")
    assert game.state["status"] == "LOADING"
    # Fast forward loader
    game.finish_loading()
    assert game.state["status"] == "PLAYING"
    assert game.state["score"] == 0
    assert game.state["danger"] == 0.0
    assert game.state["lives"] == game.MAX_LIVES

    print("[TEST] Step 3: Testing Letter Spawning & Motion...")
    game.spawn_letter()
    active_letters = [l for l in game.letter_pool if l["active"]]
    assert len(active_letters) == 1, "Should have 1 active letter spawned"
    target_let = active_letters[0]
    initial_y = target_let["y"]
    target_char = target_let["char"]
    print(f"[TEST] Spawned letter: '{target_char}' at y={initial_y}")

    # Test paintGL directly to ensure no QPen / OpenGL errors
    canvas = Draw.window.get_canvas(game.WIN_TAG)
    if hasattr(canvas, "paintGL"):
        canvas.paintGL()
    elif hasattr(canvas, "paintEvent"):
        canvas.update()

    # Simulate game tick for motion
    game.state["last_time"] = time.perf_counter() - 0.05
    game.game_tick()
    assert target_let["y"] > initial_y, "Letter should have moved downward"

    print(f"[TEST] Step 4: Testing Key Sensor detection & Shatter on '{target_char}'...")
    # Trigger sense for target letter
    lower_char = target_char.lower()
    sense = game.letter_senses.get(lower_char)
    assert sense is not None, f"Sense for '{lower_char}' must exist"
    
    # Simulate letter in active danger zone
    target_let["y"] = game.HEADER_H + 50.0
    
    # Set danger to 40% to verify healing / danger reduction
    game.state["danger"] = 40.0
    
    # Direct shatter test
    game.shatter_letter(target_let)
    assert not target_let["active"], "Target letter should be deactivated after shatter"
    assert game.state["score"] == 100, f"Score should be 100, got {game.state['score']}"
    assert game.state["streak"] == 1, "Streak should increment"
    assert game.state["danger"] < 40.0, "Danger should decrease (heal) upon shatter"
    print(f"[TEST] Score: {game.state['score']}, Danger: {game.state['danger']}%, Streak: {game.state['streak']}")

    print("[TEST] Step 5: Testing Miss Penalty & 100% Danger Game Over...")
    # Spawn and let a letter fall past the bottom
    game.spawn_letter()
    escaped_let = next(l for l in game.letter_pool if l["active"])
    escaped_let["y"] = game.WIN_HEIGHT + 10.0
    game.state["danger"] = 90.0
    
    game.state["last_time"] = time.perf_counter() - 0.05
    game.game_tick()
    
    assert game.state["danger"] >= 100.0, "Danger should reach 100% after escape"
    assert game.state["status"] == "GAMEOVER", "Game state should transition to GAMEOVER"
    print("[TEST] Game Over correctly triggered at 100% danger!")

    print("[TEST] Step 6: Testing Restart...")
    game.reset_game()
    assert game.state["status"] == "PLAYING", "State should return to PLAYING"
    assert game.state["danger"] == 0.0, "Danger should reset to 0%"
    assert game.state["score"] == 0, "Score should reset to 0"
    assert game.state["lives"] == game.MAX_LIVES, "Lives should reset to MAX_LIVES"
    print("[TEST] Restart successfully restored game state!")

    Draw.window.close(game.WIN_TAG)
    print("\n[SUCCESS] ALL TESTS PASSED SUCCESSFULLY!")


if __name__ == "__main__":
    test_letter_blast_game_flow()
