﻿"""
Unit Tests for Draw.veo (Visibility Optimization Engine / Dust Remover)
"""

import pytest
import Draw
from Draw._veo import (
    AABB,
    ViewportCuller,
    SpatialGridHierarchy,
    StaticDynamicTracker,
    CompactRenderQueue,
    OcclusionCuller,
    VisibilityOptimizer,
    veo,
    voe,
    dust_remover,
)


def test_aabb_primitives():
    box1 = AABB(10.0, 10.0, 100.0, 50.0)
    assert box1.right == 110.0
    assert box1.bottom == 60.0

    # Intersects
    box2 = AABB(50.0, 30.0, 100.0, 50.0)
    assert box1.intersects(box2)
    assert box2.intersects(box1)

    # Disjoint
    box3 = AABB(200.0, 200.0, 50.0, 50.0)
    assert not box1.intersects(box3)

    # Contains
    inner = AABB(20.0, 20.0, 30.0, 20.0)
    assert box1.contains(inner)
    assert not inner.contains(box1)


def test_viewport_culler():
    viewport = AABB(0.0, 0.0, 800.0, 600.0)
    
    # Inside viewport
    visible_box = AABB(100.0, 100.0, 50.0, 50.0)
    assert ViewportCuller.is_visible(visible_box, viewport, margin=0.0)

    # Outside viewport (far right)
    outside_box = AABB(1000.0, 100.0, 50.0, 50.0)
    assert not ViewportCuller.is_visible(outside_box, viewport, margin=0.0)

    # Outside without margin, but visible with margin=300
    assert ViewportCuller.is_visible(outside_box, viewport, margin=300.0)


def test_spatial_grid_hierarchy():
    grid = SpatialGridHierarchy(fine_cell_size=100.0, coarse_cell_size=500.0)
    grid.clear()

    box1 = AABB(50.0, 50.0, 50.0, 50.0)
    box2 = AABB(1200.0, 1200.0, 100.0, 100.0)

    grid.insert(1, box1)
    grid.insert(2, box2)

    # Query small viewport at origin
    viewport = AABB(0.0, 0.0, 400.0, 400.0)
    hits = grid.query_viewport(viewport, margin=32.0)
    assert 1 in hits
    assert 2 not in hits

    # Query large viewport covering both
    viewport_large = AABB(0.0, 0.0, 2000.0, 2000.0)
    hits_large = grid.query_viewport(viewport_large, margin=32.0)
    assert 1 in hits_large
    assert 2 in hits_large

    grid.clear()
    assert len(grid.query_viewport(viewport_large)) == 0


def test_static_dynamic_tracker():
    tracker = StaticDynamicTracker()
    tracker.clear()

    class DummyShape:
        def __init__(self, is_drag=False, motion=None):
            self._is_dragged = is_drag
            self.motion = motion

    s_static = DummyShape()
    s_drag = DummyShape(is_drag=True)
    s_motion = DummyShape(motion="wave")

    assert not tracker.is_dynamic(s_static)
    assert tracker.is_dynamic(s_drag)
    assert tracker.is_dynamic(s_motion)

    tracker.classify_and_index([s_static, s_drag, s_motion], get_bbox_fn=lambda s: AABB(0, 0, 50, 50))
    assert len(tracker.static_items) == 1
    assert len(tracker.dynamic_items) == 2


def test_compact_render_queue():
    queue = CompactRenderQueue(initial_capacity=4)
    assert queue.size == 0
    
    for i in range(10):
        queue.add(f"item_{i}")

    assert queue.size == 10
    assert queue.capacity >= 10
    res = queue.to_list()
    assert len(res) == 10
    assert res[0] == "item_0"
    assert res[9] == "item_9"

    queue.clear()
    assert queue.size == 0
    assert len(queue.to_list()) == 0


def test_occlusion_culler():
    class SolidShape:
        def __init__(self, opacity=100, rot=0, radius=0):
            self.opacity = opacity
            self.rotation = rot
            self.border_radius_raw = radius

    solid = SolidShape()
    assert OcclusionCuller.is_opaque(solid)

    semi = SolidShape(opacity=50)
    assert not OcclusionCuller.is_opaque(semi)

    # Front-to-back occlusion
    foreground_box = AABB(0.0, 0.0, 500.0, 500.0)
    hidden_behind_box = AABB(100.0, 100.0, 100.0, 100.0)
    uncovered_box = AABB(600.0, 600.0, 100.0, 100.0)

    # Lower Z is drawn in front (topmost) in candidate tuples: (item, kind, z, bbox)
    items = [
        (SolidShape(), "shape", 0, foreground_box),      # Front
        (SolidShape(), "shape", 10, hidden_behind_box),  # Behind and fully covered
        (SolidShape(), "shape", 10, uncovered_box),      # Behind but outside foreground
    ]

    visible = OcclusionCuller.cull_occluded(items)
    # The hidden one should be culled
    assert len(visible) == 2
    assert visible[0][3] == foreground_box
    assert visible[1][3] == uncovered_box


def test_visibility_optimizer_pipeline():
    opt = VisibilityOptimizer()
    opt.set_enabled(True)
    opt.set_occlusion_enabled(True)

    class MockShape:
        def __init__(self, x, y, w, h, z=0):
            self.x = x
            self.y = y
            self.width = w
            self.height = h
            self.z = z
            self.opacity = 100
            self.border_radius_raw = 0
            self.rotation = 0

    class MockText:
        def __init__(self, x, y, z=0):
            self.x = x
            self.y = y
            self.z = z

    shapes = [
        MockShape(50, 50, 100, 100, z=0),      # In view
        MockShape(5000, 5000, 100, 100, z=0),  # Far outside
    ]
    texts = [
        MockText(60, 60, z=0),                 # In view
        MockText(6000, 6000, z=0),             # Far outside
    ]

    queue = opt.cull_scene(shapes, texts, viewport_w=800, viewport_h=600, scroll_x=0, scroll_y=0)
    assert len(queue) == 2
    stats = opt.get_stats()
    assert stats["total_items"] == 4
    assert stats["visible_items"] == 2
    assert stats["culled_frustum"] == 2


def test_draw_public_api_alias():
    assert Draw.veo is not None
    assert Draw.voe is not None
    assert Draw.dust_remover is not None
    assert hasattr(Draw.veo, "cull_scene")
    assert hasattr(Draw.veo, "get_stats")
