import pytest
import os
# pyrefly: ignore [missing-import]
from PySide6.QtCore import QPointF, Qt, QEvent
# pyrefly: ignore [missing-import]
from PySide6.QtGui import QImage, QMouseEvent, QWheelEvent, QColor, QKeyEvent
# pyrefly: ignore [missing-import]
from PySide6.QtWidgets import QApplication

import Draw
from Draw._screen import screen, ScreenSurface, _to_qimage


@pytest.fixture(autouse=True)
def ensure_app():
    app = QApplication.instance()
    if app is None:
        app = QApplication([])
    yield app
    # Clean up test windows and screens
    Draw.window.close_all()


def test_screen_initialization():
    """Verify Draw.screen() API defaults and properties."""
    Draw.window(tag="test_win", width=800, height=600)

    s = Draw.screen(
        ip="live_display",
        size=[640, 480],
        align="center",
        source=None,
        senses=None,
        display="test_win",
    )

    assert isinstance(s, ScreenSurface)
    assert s.ip == "live_display"
    assert s.width == 640
    assert s.height == 480
    assert s.size == [640, 480]
    assert s.is_drawing_mode is False
    assert Draw.screen.get("live_display") is s
    assert Draw.screen["live_display"] is s
    assert "live_display" in Draw.screen.list()


def test_screen_frame_updates_and_conversion():
    """Test updating the screen with various pixel formats (QImage, numpy array, bytes, etc.)."""
    Draw.window(tag="test_win", width=800, height=600)
    s = Draw.screen(ip="cam", size=[320, 240], display="test_win")

    # 1. Update with QImage
    img = QImage(320, 240, QImage.Format.Format_RGB888)
    img.fill(QColor(255, 0, 0))
    s.update(img)
    captured = s.capture()
    assert captured is not None
    assert captured.width() == 320
    assert captured.height() == 240

    # 2. Update with numpy array (if numpy is installed)
    try:
        import numpy as np
        # 3D RGB array
        arr_rgb = np.zeros((240, 320, 3), dtype=np.uint8)
        arr_rgb[:, :, 0] = 255  # Red
        s.update(arr_rgb)
        captured2 = s.capture()
        assert captured2 is not None
        assert captured2.width() == 320

        # 2D Grayscale array
        arr_gray = np.full((240, 320), 128, dtype=np.uint8)
        s.update(arr_gray)
        captured_gray = s.capture()
        assert captured_gray is not None
    except ImportError:
        pass

    # 3. Update via module-level registry function
    img_blue = QImage(320, 240, QImage.Format.Format_RGB888)
    img_blue.fill(QColor(0, 0, 255))
    Draw.screen.update("cam", img_blue)

    # 4. Clear display
    s.clear()
    assert s._current_frame is None


def test_screen_resize():
    """Test screen.resize() and coordinate resizing."""
    Draw.window(tag="test_win", width=800, height=600)
    s = Draw.screen(ip="view", size=[320, 240], display="test_win")

    resize_events = []
    s.on_resize = lambda w, h: resize_events.append((w, h))

    # Resize via tuple
    s.resize([640, 480])
    assert s.width == 640
    assert s.height == 480
    assert s.size == [640, 480]
    assert (640, 480) in resize_events

    # Resize via explicit width / height
    s.resize(width=800, height=600)
    assert s.width == 800
    assert s.height == 600

    # Resize via registry
    Draw.screen.resize("view", [400, 300])
    assert s.width == 400
    assert s.height == 300


def test_coordinate_output_and_mouse_events():
    """Test relative coordinate reporting and event callbacks."""
    Draw.window(tag="test_win", width=800, height=600)

    received_moves = []
    received_downs = []
    received_ups = []
    received_clicks = []
    received_drags = []

    s = Draw.screen(
        ip="stream",
        size=[400, 300],
        display="test_win",
        on_mouse_move=lambda x, y, evt: received_moves.append((x, y)),
        on_mouse_down=lambda x, y, btn, evt: received_downs.append((x, y, btn)),
        on_mouse_up=lambda x, y, btn, evt: received_ups.append((x, y, btn)),
        on_click=lambda x, y, btn: received_clicks.append((x, y, btn)),
        on_drag=lambda x, y, dx, dy, btn: received_drags.append((x, y, dx, dy, btn)),
    )

    # Simulate mouse press at (150, 100)
    event_press = QMouseEvent(
        QEvent.Type.MouseButtonPress,
        QPointF(150.0, 100.0),
        QPointF(150.0, 100.0),
        Qt.MouseButton.LeftButton,
        Qt.MouseButton.LeftButton,
        Qt.KeyboardModifier.NoModifier,
    )
    s.mousePressEvent(event_press)

    assert s.mouse_x == 150.0
    assert s.mouse_y == 100.0
    assert s.last_x == 150.0
    assert s.last_y == 100.0
    assert (150.0, 100.0, "left") in received_downs

    # Simulate mouse move / drag to (170, 120)
    event_move = QMouseEvent(
        QEvent.Type.MouseMove,
        QPointF(170.0, 120.0),
        QPointF(170.0, 120.0),
        Qt.MouseButton.LeftButton,
        Qt.MouseButton.LeftButton,
        Qt.KeyboardModifier.NoModifier,
    )
    s.mouseMoveEvent(event_move)

    assert s.mouse_x == 170.0
    assert s.mouse_y == 120.0
    assert (170.0, 120.0) in received_moves
    assert len(received_drags) > 0
    assert received_drags[0][0] == 170.0
    assert received_drags[0][1] == 120.0
    assert received_drags[0][2] == 20.0  # dx
    assert received_drags[0][3] == 20.0  # dy

    # Simulate mouse release at (170, 120)
    event_release = QMouseEvent(
        QEvent.Type.MouseButtonRelease,
        QPointF(170.0, 120.0),
        QPointF(170.0, 120.0),
        Qt.MouseButton.LeftButton,
        Qt.MouseButton.NoButton,
        Qt.KeyboardModifier.NoModifier,
    )
    s.mouseReleaseEvent(event_release)

    assert (170.0, 120.0, "left") in received_ups
    assert (170.0, 120.0, "left") in received_clicks


def test_drawing_mode():
    """Verify drawing mode reports mouse_down, mouse_move, mouse_up without creating lines or shapes."""
    Draw.window(tag="test_win", width=800, height=600)

    host_points = []

    def host_mouse_down(x, y, btn="left"):
        host_points.append(("down", x, y))

    def host_mouse_move(x, y, btn="left"):
        host_points.append(("move", x, y))

    def host_mouse_up(x, y, btn="left"):
        host_points.append(("up", x, y))

    s = Draw.screen(
        ip="paint_surface",
        size=[500, 400],
        display="test_win",
        drawing_mode=True,
        mouse_down=host_mouse_down,
        mouse_move=host_mouse_move,
        mouse_up=host_mouse_up,
    )

    assert s.is_drawing_mode is True

    # Simulate draw stroke
    p1 = QMouseEvent(QEvent.Type.MouseButtonPress, QPointF(50.0, 50.0), Qt.MouseButton.LeftButton, Qt.MouseButton.LeftButton, Qt.KeyboardModifier.NoModifier)
    p2 = QMouseEvent(QEvent.Type.MouseMove, QPointF(60.0, 70.0), Qt.MouseButton.LeftButton, Qt.MouseButton.LeftButton, Qt.KeyboardModifier.NoModifier)
    p3 = QMouseEvent(QEvent.Type.MouseButtonRelease, QPointF(60.0, 70.0), Qt.MouseButton.LeftButton, Qt.MouseButton.NoButton, Qt.KeyboardModifier.NoModifier)

    s.mousePressEvent(p1)
    s.mouseMoveEvent(p2)
    s.mouseReleaseEvent(p3)

    assert ("down", 50.0, 50.0) in host_points
    assert ("move", 60.0, 70.0) in host_points
    assert ("up", 60.0, 70.0) in host_points

    # Verify philosophy: Draw.screen never creates shapes or lines itself
    assert not hasattr(s, "shape_items") or len(getattr(s, "shape_items", [])) == 0


def test_event_decorators_and_wheel():
    """Test @screen.on(...) decorator syntax and wheel event forwarding."""
    Draw.window(tag="test_win", width=800, height=600)
    s = Draw.screen(ip="interactive", size=[300, 300], display="test_win")

    wheel_logs = []

    @s.on("wheel")
    def handle_wheel(delta_x, delta_y, x, y, evt):
        wheel_logs.append((delta_x, delta_y, x, y))

    wheel_evt = QWheelEvent(
        QPointF(100.0, 100.0),
        QPointF(100.0, 100.0),
        QPointF(0, 0).toPoint(),
        QPointF(0, 120).toPoint(),
        Qt.MouseButton.NoButton,
        Qt.KeyboardModifier.NoModifier,
        Qt.ScrollPhase.NoScrollPhase,
        False,
    )
    s.wheelEvent(wheel_evt)

    assert len(wheel_logs) == 1
    assert wheel_logs[0][1] == 120
    assert wheel_logs[0][2] == 100.0
    assert wheel_logs[0][3] == 100.0


def test_touch_and_stylus_and_keyboard():
    """Test touch, tablet/stylus, and keyboard reporting."""
    Draw.window(tag="test_win", width=800, height=600)

    stylus_events = []
    key_events = []
    enter_leave_events = []

    s = Draw.screen(
        ip="devices",
        size=[400, 400],
        display="test_win",
        on_stylus=lambda pressure, x, y, tx, ty, evt: stylus_events.append((pressure, x, y)),
        on_key=lambda text, code, evt: key_events.append((text, code)),
        on_enter=lambda evt: enter_leave_events.append("enter"),
        on_leave=lambda evt: enter_leave_events.append("leave"),
    )

    # Key press
    key_evt = QKeyEvent(QEvent.Type.KeyPress, Qt.Key.Key_Space, Qt.KeyboardModifier.NoModifier, " ")
    s.keyPressEvent(key_evt)
    assert (" ", Qt.Key.Key_Space) in key_events

    # Enter & Leave
    s.enterEvent(QEvent(QEvent.Type.Enter))
    s.leaveEvent(QEvent(QEvent.Type.Leave))
    assert "enter" in enter_leave_events
    assert "leave" in enter_leave_events


def test_screen_registry_lifecycle():
    """Test registry list, capture, clear, remove."""
    Draw.window(tag="test_win", width=800, height=600)
    s1 = Draw.screen(ip="s1", size=[200, 200], display="test_win")
    s2 = Draw.screen(ip="s2", size=[300, 300], display="test_win")

    assert "s1" in Draw.screen.list()
    assert "s2" in Draw.screen.list()

    assert Draw.screen.get("s1") is s1
    assert Draw.screen.get("s2") is s2

    captured = Draw.screen.capture("s1")
    assert captured is not None

    assert Draw.screen.remove("s1") is True
    assert "s1" not in Draw.screen.list()
    assert Draw.screen.get("s1") is None
