"""
Automated validation of Draw.super Tabbed Test Suite.
Verifies that switching between all tabs ('Color', 'Motion', 'Shapes', 'Graph', 'Live', 'Mouse', 'Keyboard')
renders cleanly without exceptions on _DrawOpenGLCanvas using pure Draw shapes & senses.
"""

import os
import sys

SYS_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PARENT_ROOT = os.path.dirname(SYS_ROOT)
if PARENT_ROOT not in sys.path:
    sys.path.insert(0, PARENT_ROOT)
if SYS_ROOT not in sys.path:
    sys.path.insert(0, SYS_ROOT)

import pytest
# pyrefly: ignore [missing-import]
from PySide6.QtCore import QPointF, Qt
# pyrefly: ignore [missing-import]
from PySide6.QtGui import QMouseEvent

import Draw
from Draw.examples.test_super_tabbed_suite import (
    WIN_TAG, TABS, set_tab, init_top_navigation, _state
)
from Draw._super import _DrawOpenGLCanvas


def test_super_tabbed_suite_all_tabs_switching():
    """Verify that every tab mounts, ticks, and renders under Draw.super without errors."""
    Draw.window(
        tag=WIN_TAG,
        title="Test Tabbed Suite",
        width=1200,
        height=800,
        background_color="#070B14",
    )

    init_top_navigation()
    gl_canvas = Draw.super(display=WIN_TAG)
    assert isinstance(gl_canvas, _DrawOpenGLCanvas)

    for tab_name in TABS:
        # Switch tab
        set_tab(tab_name)

        # Tick animation & live text
        gl_canvas._tick_animation()

        # Render frame through OpenGL paint routine
        gl_canvas.paintGL()

        # Verify shapes / items are populated
        assert len(gl_canvas.shape_items) > 0 or len(gl_canvas.text_items) > 0

    # Verify live FPS property on OpenGL canvas
    assert hasattr(gl_canvas, "fps")
    assert gl_canvas.fps >= 0.0

    # Clean close
    Draw.window.close(WIN_TAG)
