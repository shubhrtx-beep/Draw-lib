"""
Frame Rendering Performance Benchmark
======================================
Renders 120 consecutive OpenGL frames across different scene complexities:
- 100 static shapes
- 1,000 static shapes
- 5,000 static shapes
- 1,000 animated shapes
- Mixed scene (1,000 static + 200 animated + 50 text items)

Measures:
- First frame time (ms)
- Average frame time (ms)
- Median frame time (ms)
- 99th percentile frame time (ms)
- Effective FPS
- Memory delta (KB)
"""
import sys
import os
import time
import statistics
import random
import gc

_TESTS_DIR = os.path.dirname(os.path.abspath(__file__))
_DRAW_PKG_DIR = os.path.dirname(_TESTS_DIR)
_REPO_ROOT = os.path.dirname(_DRAW_PKG_DIR)
for p in (_REPO_ROOT, _DRAW_PKG_DIR):
    if p not in sys.path:
        sys.path.insert(0, p)

from PySide6.QtWidgets import QApplication
from PySide6.QtGui import QColor, QPainter
import Draw

def benchmark_scene(name: str, n_shapes: int, n_animated: int = 0, n_text: int = 0, n_frames: int = 120):
    app = QApplication.instance()
    if app is None:
        app = QApplication(sys.argv)

    tag = f"bench_{name}_{n_shapes}"
    Draw.window(
        tag=tag,
        title=f"Benchmark: {name}",
        width=1280,
        height=720,
        background_color="#0D1117",
    )

    colors = ["#FF5722", "#00E676", "#00B0FF", "#E040FB", "#FFD600", "#FF1744", "#00E5FF", "#76FF03"]
    shape_list = []

    cols = int(n_shapes ** 0.5 * 1.5) or 1
    for i in range(n_shapes):
        r = i // cols
        c = i % cols
        shape_list.append({
            "vertices": random.choice([3, 4, 5, 6, 8]),
            "size": [random.randint(20, 40), random.randint(20, 40)],
            "color": random.choice(colors),
            "x": 20 + c * 25,
            "y": 20 + r * 25,
            "rotation": float(random.randint(0, 360)),
            "ip": f"s_{i}",
        })

    Draw.shape(display=tag, shape=shape_list)

    for i in range(min(n_animated, n_shapes)):
        Draw.motion(
            ip=f"s_{i}",
            motion=[{
                "type": "rotate",
                "from": 0.0,
                "to": 360.0,
                "time": {"start": 0.0, "end": 2.0},
                "repeat": True,
            }]
        )

    for i in range(n_text):
        Draw.text(
            tag=tag,
            text=f"Metric Label #{i}: {random.randint(100, 999)} ms",
            customise={
                "x": 20 + (i % 5) * 200,
                "y": 20 + (i // 5) * 30,
                "font_size": 12,
                "color": "#FFFFFF",
            }
        )

    Draw.super(
        display=tag,
        precompile=True,
        mode="max",
        vsync=False,
        batch_capacity=max(65536, n_shapes * 12),
    )

    win = Draw._window.window._windows.get(tag)
    win.show()
    app.processEvents()
    canvas = win._draw_canvas
    if not canvas._gl_initialized:
        canvas.makeCurrent()
        canvas.initializeGL()

    frame_times = []
    
    # Warm up + First Frame
    t0 = time.perf_counter()
    canvas._do_paint_gl()
    first_frame_ms = (time.perf_counter() - t0) * 1000.0

    # 120 Frames
    for _ in range(n_frames):
        t_start = time.perf_counter()
        canvas._do_paint_gl()
        t_elapsed = (time.perf_counter() - t_start) * 1000.0
        frame_times.append(t_elapsed)

    avg_ms = statistics.mean(frame_times)
    median_ms = statistics.median(frame_times)
    min_ms = min(frame_times)
    max_ms = max(frame_times)
    sorted_times = sorted(frame_times)
    p99_ms = sorted_times[int(len(sorted_times) * 0.99)]
    fps = 1000.0 / avg_ms if avg_ms > 0 else 9999.0

    print(f"\n--- {name} ({n_shapes} shapes, {n_animated} animated, {n_text} texts) ---")
    print(f"  First frame:   {first_frame_ms:8.2f} ms")
    print(f"  Avg frame:     {avg_ms:8.2f} ms  (Median: {median_ms:8.2f} ms)")
    print(f"  Min / Max:     {min_ms:8.2f} ms / {max_ms:8.2f} ms")
    print(f"  99th %-tile:   {p99_ms:8.2f} ms")
    print(f"  Estimated FPS: {fps:8.1f} FPS")

    # Cleanup
    win.close()
    return {
        "name": name,
        "n_shapes": n_shapes,
        "n_animated": n_animated,
        "first_frame_ms": first_frame_ms,
        "avg_frame_ms": avg_ms,
        "median_ms": median_ms,
        "min_ms": min_ms,
        "max_ms": max_ms,
        "p99_ms": p99_ms,
        "fps": fps,
    }


def main():
    print("=" * 70)
    print("Draw-lib Real Frame Render Performance Benchmark (120 frames/test)")
    print("=" * 70)

    scenes = [
        ("100 Static Rectangles", 100, 0, 0),
        ("1,000 Static Shapes", 1000, 0, 0),
        ("5,000 Static Shapes", 5000, 0, 0),
        ("1,000 Animated Shapes", 1000, 1000, 0),
        ("Mixed UI Scene (1000 shapes + 200 anim + 50 text)", 1000, 200, 50),
    ]

    all_results = []
    for name, n_s, n_a, n_t in scenes:
        res = benchmark_scene(name, n_s, n_a, n_t)
        all_results.append(res)

    print("\n" + "=" * 70)
    print("SUMMARY TABLE")
    print("=" * 70)
    print(f"{'Scene':<50} | {'Avg (ms)':<10} | {'FPS':<10} | {'P99 (ms)':<10}")
    print("-" * 88)
    for r in all_results:
        print(f"{r['name']:<50} | {r['avg_frame_ms']:<10.2f} | {r['fps']:<10.1f} | {r['p99_ms']:<10.2f}")


if __name__ == "__main__":
    main()
