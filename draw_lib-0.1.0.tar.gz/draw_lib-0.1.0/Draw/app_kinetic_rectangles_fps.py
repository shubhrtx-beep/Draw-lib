"""
Draw-lib Kinetic Rectangles & Real Live FPS Showcase
====================================================
Features:
- Input bar (Draw.lineedit) to enter a custom count of rectangles to spawn.
- "Spawn Rectangles" action button (Draw.button) to instantiate animated shapes.
- Quick preset buttons (+10, +50, +100, and Clear All).
- All spawned rectangles move continuously across the canvas (kinetic bounce/drift + rotation).
- Real Live FPS measurement system: True rolling-window wall-clock presentation framerate (no aliasing).
- Explicit Z-axis depth layering:
    * Background Canvas / Grid: z = 100
    * Header & Control Panel Card: z = 85 (or top-tier native widget)
    * Kinetic Moving Shapes: z in [10, 60] (multi-layer 3D depth ordering)
    * Foreground UI Controls, Input Bar, Button & HUD Text: z <= 0 (always on top)
- High-Performance Hardware-Accelerated OpenGL Engine (Draw.super).
"""

import sys
import os
import random
import time
import collections
from typing import List, Optional

# Ensure workspace root is on sys.path
_CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
_WORKSPACE_ROOT = os.path.dirname(_CURRENT_DIR)
for p in (_WORKSPACE_ROOT, _CURRENT_DIR):
    if p not in sys.path:
        sys.path.insert(0, p)

import Draw

WIN_TAG = "kinetic_rect_ui"
WIN_W = 1280
WIN_H = 820

# Vibrant color palette for rectangles
PALETTE = [
    "#38BDF8",  # Sky Blue
    "#34D399",  # Emerald Green
    "#F472B6",  # Pink
    "#FBBF24",  # Amber
    "#A78BFA",  # Violet
    "#FB7185",  # Rose
    "#2DD4BF",  # Teal
    "#F97316",  # Orange
    "#818CF8",  # Indigo
    "#4ADE80",  # Light Green
    "#C084FC",  # Purple
    "#38BDF8",  # Cyan
]

# Rolling window FPS tracker
class RealFPSTracker:
    """
    Computes both:
    1. Display Framerate: Actual screen paint refresh rate (~60 FPS via Qt Timer/VSync).
    2. Engine Throughput: Pure CPU/GPU render execution speed (~250-450 FPS headroom).
    """
    def __init__(self, window_size: int = 30):
        self.window_size = window_size
        self.frame_deltas = collections.deque(maxlen=window_size)
        self.render_times = collections.deque(maxlen=window_size)
        self.last_paint_time = time.perf_counter()
        self.last_render_cpu_ms = 2.5
        self.total_frames = 0
        self.display_fps = 60.0
        self.engine_fps = 350.0
        self.current_frame_ms = 16.6

    def record_frame(self, cpu_render_ms: float = 0.0):
        now = time.perf_counter()
        dt = now - self.last_paint_time
        self.last_paint_time = now
        self.total_frames += 1
        self.last_render_cpu_ms = cpu_render_ms

        if cpu_render_ms > 0.001:
            self.render_times.append(cpu_render_ms)
            avg_render_ms = sum(self.render_times) / len(self.render_times)
            self.engine_fps = 1000.0 / max(avg_render_ms, 0.001)

        if 0.0005 < dt < 1.0:
            self.frame_deltas.append(dt)
            if len(self.frame_deltas) >= 5:
                avg_dt = sum(self.frame_deltas) / len(self.frame_deltas)
                self.display_fps = 1.0 / avg_dt
                self.current_frame_ms = avg_dt * 1000.0

    def get_telemetry_string(self, shape_count: int) -> str:
        disp_fps = self.display_fps
        eng_fps = self.engine_fps
        cpu_ms = self.last_render_cpu_ms
        ft_ms = self.current_frame_ms

        return (
            f"Display: {disp_fps:4.1f} FPS ({ft_ms:4.1f}ms) | "
            f"Engine Speed: {eng_fps:5.1f} FPS (Render: {cpu_ms:3.1f}ms) | "
            f"Active: {shape_count:,} Shapes"
        )


fps_tracker = RealFPSTracker(window_size=30)

# Application state
app_state = {
    "rect_count": 0,
    "rect_ips": [],
    "total_spawned_ever": 0,
}


def get_fps_display() -> str:
    """Callable text binding for live telemetry HUD."""
    return fps_tracker.get_telemetry_string(app_state["rect_count"])


def spawn_rectangles(count: Optional[int] = None):
    """Spawns N animated rectangles with distinct Z-indices and kinetic motion."""
    if count is None:
        raw_val = Draw.lineedit.get_text("num_input").strip()
        try:
            count = int(raw_val)
            if count <= 0:
                count = 10
        except ValueError:
            count = 20

    if count > 2000:
        count = 2000  # Safe upper bound for comfortable UI responsiveness

    new_shapes = []
    start_idx = app_state["total_spawned_ever"]

    # Play area boundaries
    min_x, max_x = 30, WIN_W - 90
    min_y, max_y = 160, WIN_H - 90

    for i in range(count):
        idx = start_idx + i
        ip = f"rect_{idx}"
        
        # Dimensions & appearance
        w = random.randint(32, 64)
        h = random.randint(32, 64)
        x0 = random.randint(min_x, max_x)
        y0 = random.randint(min_y, max_y)
        color = random.choice(PALETTE)
        rot0 = float(random.randint(0, 360))
        
        # Explicit Z-axis depth: Higher z = further back.
        # Moving shapes are distributed between z = 15 (near front) and z = 65 (near back).
        # This creates realistic depth layering where closer shapes pass in front of farther ones.
        z_layer = random.randint(15, 65)
        opacity = random.randint(80, 95)
        radius = random.choice([4, 6, 8, 12])

        new_shapes.append({
            "vertices": 4,
            "size": [w, h],
            "color": color,
            "x": x0,
            "y": y0,
            "rotation": rot0,
            "border_radius": radius,
            "border_width": 1,
            "border_color": "rgba(255, 255, 255, 0.25)",
            "ip": ip,
            "opacity": opacity,
            "z": z_layer,
        })
        app_state["rect_ips"].append(ip)

    app_state["rect_count"] += count
    app_state["total_spawned_ever"] += count

    # Add shapes to canvas
    Draw.shape(
        display=WIN_TAG,
        shape=new_shapes,
    )

    # Attach continuous kinetic motion to each newly spawned rectangle
    for s in new_shapes:
        ip = s["ip"]
        x0, y0 = s["x"], s["y"]
        
        # Target destination for 2D kinetic drift
        x1 = random.randint(min_x, max_x)
        y1 = random.randint(min_y, max_y)
        move_duration = random.uniform(3.0, 8.0)
        rot_duration = random.uniform(2.0, 6.0)
        ease_mode = random.choice(["ease_in_out", "ease_out", "linear"])

        Draw.motion(
            ip=ip,
            motion=[
                {
                    "type": "move",
                    "from": [x0, y0],
                    "to": [x1, y1],
                    "time": {"start": 0.0, "end": move_duration},
                    "repeat": True,
                    "pingpong": True,
                    "ease": ease_mode,
                },
                {
                    "type": "rotate",
                    "from": 0.0,
                    "to": 360.0 if random.random() > 0.5 else -360.0,
                    "time": {"start": 0.0, "end": rot_duration},
                    "repeat": True,
                },
            ]
        )


def clear_all_rectangles():
    """Clears all moving rectangles while preserving the header and UI controls."""
    for ip in app_state["rect_ips"]:
        try:
            Draw.shapes.remove(ip)
        except Exception:
            pass
    app_state["rect_ips"].clear()
    app_state["rect_count"] = 0


def add_preset(n: int):
    """Callback for quick preset buttons."""
    Draw.lineedit.set_text("num_input", str(n))
    spawn_rectangles(n)


def build_ui():
    """Builds the complete UI with input bar, button, kinetic shapes, and live FPS telemetry."""
    print("Initializing Window...")
    Draw.window(
        tag=WIN_TAG,
        title="Draw-lib — Kinetic Rectangle Motion & Real Live FPS Engine",
        width=WIN_W,
        height=WIN_H,
        background_color="#0A0E17",
    )

    # ── 1. Top Header & Control Card (Z = 85: Behind UI text & buttons, above canvas) ──
    Draw.shape(
        display=WIN_TAG,
        shape=[
            {
                "vertices": 4,
                "size": [WIN_W - 40, 125],
                "color": "#111827",
                "border_color": "#1F2937",
                "border_width": 1,
                "border_radius": 14,
                "x": 20,
                "y": 12,
                "ip": "header_panel",
                "z": 85,
            }
        ]
    )

    # ── 2. Header Title & Description (Z = 0: Foreground) ──
    Draw.text(
        tag=WIN_TAG,
        text="⚡ Kinetic Rectangle Spawner & Real FPS Telemetry",
        customise={
            "x": 40,
            "y": 24,
            "font_size": 19,
            "bold": True,
            "color": "#60A5FA",
            "z": 0,
        }
    )

    # ── 3. Real Live FPS Telemetry (Dynamic Callable Binding) ──
    Draw.text(
        tag=WIN_TAG,
        text=get_fps_display,
        customise={
            "x": 40,
            "y": 54,
            "font_size": 13,
            "bold": True,
            "color": "#10B981",
            "z": 0,
        }
    )

    Draw.text(
        tag=WIN_TAG,
        text="Enter quantity → Click 'Spawn' → Rectangles glide, bounce & rotate across multi-depth Z-layers:",
        customise={
            "x": 40,
            "y": 88,
            "font_size": 11,
            "color": "#9CA3AF",
            "z": 0,
        }
    )

    # ── 4. Input Bar (Draw.lineedit) ──
    Draw.lineedit(
        ip="num_input",
        display=WIN_TAG,
        x=570,
        y=78,
        width=100,
        height=36,
        placeholder="e.g. 30",
        text="30",
        style={
            "background_color": "#0B132B",
            "color": "#60A5FA",
            "border_color": "#3B82F6",
            "border_width": 2,
            "border_radius": 6,
            "font_size": 13,
            "padding": 4,
        }
    )

    # ── 5. Primary Spawn Button (Draw.button) ──
    Draw.button(
        ip="btn_spawn",
        display=WIN_TAG,
        x=680,
        y=78,
        width=135,
        height=36,
        text="⚡ Spawn Rects",
        style={
            "background_color": "#059669",
            "hover_background_color": "#10B981",
            "color": "#FFFFFF",
            "font_size": 12,
            "bold": True,
            "border_radius": 6,
        },
        on_click=lambda: spawn_rectangles(),
    )

    # ── 6. Preset Quick-Action Buttons (+10, +50, +100, Clear) ──
    Draw.button(
        ip="btn_p10",
        display=WIN_TAG,
        x=825,
        y=78,
        width=65,
        height=36,
        text="+10",
        style={
            "background_color": "#1F2937",
            "hover_background_color": "#374151",
            "color": "#E5E7EB",
            "font_size": 12,
            "border_radius": 6,
        },
        on_click=lambda: add_preset(10),
    )

    Draw.button(
        ip="btn_p50",
        display=WIN_TAG,
        x=898,
        y=78,
        width=65,
        height=36,
        text="+50",
        style={
            "background_color": "#1F2937",
            "hover_background_color": "#374151",
            "color": "#E5E7EB",
            "font_size": 12,
            "border_radius": 6,
        },
        on_click=lambda: add_preset(50),
    )

    Draw.button(
        ip="btn_p100",
        display=WIN_TAG,
        x=971,
        y=78,
        width=75,
        height=36,
        text="+100",
        style={
            "background_color": "#2563EB",
            "hover_background_color": "#3B82F6",
            "color": "#FFFFFF",
            "font_size": 12,
            "bold": True,
            "border_radius": 6,
        },
        on_click=lambda: add_preset(100),
    )

    Draw.button(
        ip="btn_clear",
        display=WIN_TAG,
        x=1054,
        y=78,
        width=95,
        height=36,
        text="🗑️ Clear All",
        style={
            "background_color": "#DC2626",
            "hover_background_color": "#EF4444",
            "color": "#FFFFFF",
            "font_size": 12,
            "bold": True,
            "border_radius": 6,
        },
        on_click=clear_all_rectangles,
    )

    # ── 7. Spawn Initial 30 Rectangles ──
    print("Spawning initial batch of 30 kinetic rectangles...")
    spawn_rectangles(30)

    # ── 8. Activate Hardware-Accelerated OpenGL Engine ──
    print("Activating Draw.super GPU Engine...")
    canvas = Draw.super(
        display=WIN_TAG,
        precompile=True,
        mode="max",
        vsync=False,
        batch_capacity=131072,
    )

    # Attach our high-precision paintGL frame hook to record accurate frame telemetry
    orig_do_paint_gl = canvas._do_paint_gl
    def hooked_paint_gl():
        t0 = time.perf_counter()
        orig_do_paint_gl()
        render_cpu_ms = (time.perf_counter() - t0) * 1000.0
        fps_tracker.record_frame(render_cpu_ms)

    canvas._do_paint_gl = hooked_paint_gl
    return canvas


def main():
    build_ui()
    print("\n[OK] UI is running. Starting window loop...")
    Draw.window.run(WIN_TAG)


if __name__ == "__main__":
    main()
