"""
Draw._graph
===========
Declarative charting engine for the Draw framework.
Connects with 11 internal modules:
- _align, _bridge, _calculator, _shapes, _colour (color), _motion (motion),
  _room (room), _room_size, _list, _layout, _text.

Uses PySide6 and Matplotlib for layout, tick calculations, and color mapping.
Calculates the tightest fitable bounding box for hitbox registration with _shapes.hitbox.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple, Union

# ── 1. Import 11 connected internal Draw modules ─────────────────────────────
import Draw._align as _align
from Draw._align import calculate_alignment_pos, calculate_chart_region

import Draw._bridge as _bridge

import Draw._calculator as _calculator
from Draw._calculator import calculator

import Draw._shapes as _shapes
from Draw._shapes import shape, shapes, hitbox

import Draw._colour as _colour
from Draw._colour import color, colour, _parse_color

import Draw._motion as _motion
from Draw._motion import motion

import Draw._room as _room
from Draw._room import room

import Draw._room_size as _room_size

import Draw._list as _list

import Draw._layout as _layout

import Draw._text as _text
from Draw._text import text

# System & live dependencies
from Draw._window import window as _window_registry
from Draw._live import live as _live_registry, LiveRef
from Draw._tools import is_number

# ── 2. Import Third-Party Libraries (PySide6 & Matplotlib) ────────────────────
from PySide6.QtCore import QRectF, QPointF
import matplotlib
import matplotlib.ticker as ticker
import matplotlib.cm as cm


# ── 3. Data Structures & Constants ───────────────────────────────────────────

_GRAPH_TYPES = {
    "bar", "stacked_bar", "line", "area", "stacked_area",
    "dot", "scatter", "pie", "donut", "radar", "spider"
}

KNOWN_GRAPH_CUSTOMISE_KEYS: frozenset = frozenset({
    "x", "y", "width", "height", "margin", "show_line", "title", "x_title", "y_title",
    "title_font_size", "title_color", "axis_title_size", "axis_title_color",
    "grid_lines", "grid_color", "grid_width", "axis_color",
    "y_tick_color", "max_x", "min_y", "max_y",
    "color", "border_width", "border_color", "border_style",
    "bar_width", "line_width", "line_color", "area_opacity",
    "point_size", "point_vertices",
    "label_color", "label_font_size",
    "show_values", "value_color", "value_font_size", "value_decimals",
    "group_width_ratio", "flow", "z",
    "live", "live_key", "draggable", "hold_and_move",
    "animate", "animation_type", "duration", "stiffness", "damping",
    "hover", "tooltip", "tooltip_color", "tooltip_bg", "tooltip_font_size",
    "inner_radius", "hole_radius", "hole_color", "center_text", "center_subtext",
    "spider_grid", "spider_levels",
    "smooth", "curve",
    "show_legend", "legend_position", "legend_color", "legend_font_size",
})


@dataclass
class GraphDef:
    """Stores metadata and bounds for a registered graph."""
    ip: str
    window_tag: str
    bounds: Tuple[float, float, float, float]  # (x, y, w, h)
    series_data: List[Dict[str, Any]] = field(default_factory=list)
    customise: Dict[str, Any] = field(default_factory=dict)
    type: str = "bar"
    z: int = 0
    offset_x: float = 0.0
    offset_y: float = 0.0

    @property
    def series(self) -> List[Dict[str, Any]]:
        return self.series_data

    @series.setter
    def series(self, val: List[Dict[str, Any]]) -> None:
        self.series_data = val


# ── 4. Helper Functions ───────────────────────────────────────────────────────

def _normalize_graph_type(t: Any, field_name: Optional[str] = None) -> str:
    """Normalize graph type string (e.g. 'scatter' -> 'dot')."""
    if not isinstance(t, str):
        return "bar"
    norm = t.strip().lower()
    if norm == "scatter":
        return "dot"
    if norm == "spider":
        return "radar"
    if norm not in _GRAPH_TYPES:
        raise ValueError(f"Invalid graph type: '{t}'")
    return norm


def _as_bool(val: Any, field: Optional[str] = None, default: bool = False) -> bool:
    if val is None:
        return default
    if isinstance(val, bool):
        return val
    if isinstance(val, (int, float)):
        return bool(val)
    if isinstance(val, str):
        return val.strip().lower() in ("true", "1", "yes", "y", "on")
    return default


def _as_float(val: Any, field: Optional[str] = None, default: Optional[float] = None) -> float:
    if val is None and default is not None:
        return default
    try:
        return float(val)
    except (ValueError, TypeError):
        if default is not None:
            return default
        raise TypeError(f"Invalid float value for '{field}': {val}")


def _as_int(val: Any, field: Optional[str] = None, default: Optional[int] = None) -> int:
    if val is None and default is not None:
        return default
    try:
        return int(val)
    except (ValueError, TypeError):
        if default is not None:
            return default
        raise TypeError(f"Invalid int value for '{field}': {val}")


def _make_value_label(val: float, decimals: int = 0) -> str:
    if decimals <= 0:
        return f"{int(round(val))}"
    return f"{val:.{decimals}f}"


def _build_legend(
    series_list: List[Dict[str, Any]],
    get_color_fn: Any,
    left: float,
    top: float,
    chart_w: float,
    chart_h: float,
    legend_position: str = "top-right",
    legend_color: str = "#D0DCF0",
    legend_font_size: int = 11,
    value_decimals: int = 0,
    **kwargs: Any
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    """Helper legend builder."""
    if not series_list:
        return ([], [])
    bg_shape = {"color": "#1E293B", "x": left, "y": top, "size": [120, 30 * len(series_list)]}
    shape_list = [bg_shape]
    text_list = []
    for i, s in enumerate(series_list):
        c = get_color_fn(i) if callable(get_color_fn) else "#3B82F6"
        t_str = s.get("title") or s.get("name") or f"Series {i+1}"
        swatch = {"color": c, "x": left + 10, "y": top + 10 + i * 20, "size": [12, 12]}
        shape_list.append(swatch)
        t_dict = {"text": t_str, "x": left + 30, "y": top + 10 + i * 20, "color": legend_color, "font_size": legend_font_size}
        text_list.append(t_dict)
    return (shape_list, text_list)


def resolve_live_data(val: Any) -> Any:
    """Unwrap reactive LiveRef objects or callables."""
    if isinstance(val, LiveRef):
        return _live_registry.get(val.key)
    if callable(val) and not isinstance(val, type):
        try:
            return val()
        except Exception:
            return val
    return val


def resolve_text_spec(window_tag: str, val: Any) -> Tuple[str, Dict[str, Any]]:
    """
    Resolves text input specification.
    If val is a text IP registered in Draw.text on the canvas,
    returns its text content and styling properties and suppresses duplicate rendering.
    Otherwise returns (str(val), {}).
    """
    val = resolve_live_data(val)
    if not isinstance(val, str):
        return (str(val) if val is not None else "", {})

    # Check if window exists and text item is registered with this IP
    if _window_exists(window_tag):
        win = _window_registry._windows.get(window_tag)
        if win and hasattr(win, "_draw_canvas") and hasattr(win._draw_canvas, "text_items"):
            for t_item in list(win._draw_canvas.text_items):
                if getattr(t_item, "ip", None) == val:
                    style = {
                        "font_family": getattr(t_item, "font_family", None),
                        "font_size": getattr(t_item, "font_size", None),
                        "bold": getattr(t_item, "bold", None),
                        "italic": getattr(t_item, "italic", None),
                        "rotation": getattr(t_item, "rotation", 0.0),
                    }
                    if hasattr(t_item, "color") and t_item.color:
                        style["color"] = t_item.color.name()
                    # Remove the template placeholder text registered at (0,0) so it doesn't double-render
                    if getattr(t_item, "x", None) == 0 and getattr(t_item, "y", None) == 0:
                        try:
                            win._draw_canvas.text_items.remove(t_item)
                        except Exception:
                            pass
                    return (t_item.text, {k: v for k, v in style.items() if v is not None})

    return (val, {})


def _extract_color(cust: Dict[str, Any], key: str, default: Any = "#3B82F6") -> Any:
    """Extract and resolve color specifications from customise dict, color IP, or color system."""
    val = cust.get(key, default)
    val = resolve_live_data(val)
    if isinstance(val, str):
        resolved = color.resolve_for_shape(val)
        if resolved and "body_color" in resolved:
            r, g, b, a = resolved["body_color"]
            return f"#{r:02x}{g:02x}{b:02x}"
        if val.startswith("#") or val.lower() in ("red", "green", "blue", "cyan", "magenta", "yellow", "orange", "purple", "pink", "white", "black", "gray", "grey"):
            return val
    return val if val is not None else default


def _window_exists(window_tag: str) -> bool:
    """Checks if a window tag exists in the window registry."""
    if hasattr(_window_registry, "_windows") and isinstance(_window_registry._windows, dict):
        return window_tag in _window_registry._windows
    return False


# ── 5. Main Graph Engine Registry ─────────────────────────────────────────────

class _GraphRegistry:
    """
    Central graph management registry.
    Exposed publicly as `Draw.graph`.
    """

    def __init__(self) -> None:
        self._graphs: Dict[Tuple[str, str], GraphDef] = {}
        self._registry = self._graphs
        self._raw_params: Dict[Tuple[str, str], Dict[str, Any]] = {}

    def __call__(
        self,
        ip: str = "graph_default",
        type: str = "bar",
        graph: Optional[List[Dict[str, Any]]] = None,
        tag: str = "main",
        display: Optional[str] = None,
        align: str = "center",
        get_ip: Optional[str] = None,
        columns: int = 0,
        z: int = 0,
        animate: bool = False,
        hover: bool = True,
        tooltip: bool = True,
        draggable: bool = False,
        hold_and_move: bool = False,
        customise: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> GraphDef:
        """
        Primary entry point for rendering graphs.
        Usage: Draw.graph(ip="sales", type="bar", graph=[{...}], z=0, ...)
        """
        window_tag = display or tag or "main"
        graph_series = graph or []
        norm_type = _normalize_graph_type(type)
        z_layer = kwargs.get("z", z)
        extra_cust = customise or kwargs.get("customise") or {}

        # Store raw invocation params for live updating
        self._raw_params[(window_tag, ip)] = {
            "ip": ip,
            "type": type,
            "graph": graph_series,
            "tag": tag,
            "display": display,
            "align": align,
            "get_ip": get_ip,
            "columns": columns,
            "z": z_layer,
            "animate": animate or extra_cust.get("animate", False),
            "hover": hover,
            "tooltip": tooltip,
            "draggable": draggable,
            "hold_and_move": hold_and_move,
            "customise": extra_cust,
            "kwargs": kwargs,
        }

        # Clear existing shapes/texts for this graph IP if window exists
        if _window_exists(window_tag):
            try:
                shapes.remove_by_ip(window_tag, ip)
            except Exception:
                pass

        # Dispatch rendering based on chart type
        if norm_type == "bar":
            bounds = self._render_bar_graph(
                ip=ip,
                window_tag=window_tag,
                series_list=graph_series,
                align_spec=align,
                get_ip=get_ip,
                columns=columns,
                z_layer=z_layer,
                draggable=draggable or hold_and_move,
                extra_cust=extra_cust,
            )
        else:
            bounds = self._render_placeholder_graph(
                ip=ip,
                type_name=norm_type,
                window_tag=window_tag,
                align_spec=align,
                z_layer=z_layer,
            )

        gdef = GraphDef(
            ip=ip,
            window_tag=window_tag,
            bounds=bounds,
            series_data=graph_series,
            customise=extra_cust,
            type=norm_type,
            z=z_layer,
        )

        self._graphs[(window_tag, ip)] = gdef
        return gdef

    # ── Bar Graph Renderer ────────────────────────────────────────────────────

    def _render_bar_graph(
        self,
        ip: str,
        window_tag: str,
        series_list: List[Dict[str, Any]],
        align_spec: str,
        get_ip: Optional[str],
        columns: int,
        z_layer: int,
        draggable: bool,
        extra_cust: Dict[str, Any],
    ) -> Tuple[float, float, float, float]:
        """
        Renders a Bar Graph using _shapes for bars/lines and _text for labels.
        Supports text IP resolution, color IP resolution, motion integration, and z-index layer ordering.
        Calculates and registers the tightest fitable bounding box.
        """
        has_win = _window_exists(window_tag)
        win_w, win_h = 800, 600

        if has_win:
            win = _window_registry._windows.get(window_tag)
            if win:
                if hasattr(win, "width") and callable(win.width):
                    win_w = win.width()
                elif hasattr(win, "width"):
                    win_w = getattr(win, "width", 800)

                if hasattr(win, "height") and callable(win.height):
                    win_h = win.height()
                elif hasattr(win, "height"):
                    win_h = getattr(win, "height", 600)

        # Container positioning & sizing (supports x, y, width, height overrides in customise)
        margin = extra_cust.get("margin", 50)
        user_w = extra_cust.get("width", None)
        user_h = extra_cust.get("height", None)
        user_x = extra_cust.get("x", None)
        user_y = extra_cust.get("y", None)

        base_w = (user_w + 2 * margin - 40) if user_w is not None else 600
        base_h = (user_h + 2 * margin - 52) if user_h is not None else 400

        if user_x is not None:
            base_x = user_x - margin + 40
        else:
            base_x = 100

        if user_y is not None:
            base_y = user_y - margin + 20
        else:
            base_y = 100

        # Calculate alignment using _align module if align_spec provided and no explicit x,y in customise
        if align_spec and user_x is None and user_y is None:
            aligned_pos = calculate_alignment_pos(align_spec, base_w, base_h, win_w, win_h)
            if aligned_pos:
                base_x, base_y = aligned_pos

        plot_x = base_x + margin
        plot_y = base_y + margin
        plot_w = base_w - 2 * margin
        plot_h = base_h - 2 * margin

        # Extract series categories and numerical values
        all_categories: List[str] = []
        parsed_series: List[Dict[str, Any]] = []
        all_y_values: List[float] = [0.0]  # include baseline 0

        for s_idx, s_item in enumerate(series_list):
            raw_x = resolve_live_data(s_item.get("x", []))
            raw_y = resolve_live_data(s_item.get("y", []))
            s_title_spec = s_item.get("title", f"Series {s_idx + 1}")
            s_title_str, s_title_style = resolve_text_spec(window_tag, s_title_spec)
            cust = s_item.get("customise", {})

            # Resolve category labels via resolve_text_spec (text IP & rotation support)
            cat_specs = raw_x if isinstance(raw_x, (list, tuple)) else [raw_x]
            cat_labels = [resolve_text_spec(window_tag, c_spec)[0] for c_spec in cat_specs]
            y_vals = [float(val) for val in (raw_y if isinstance(raw_y, (list, tuple)) else [raw_y]) if is_number(val)]

            if not all_categories and cat_labels:
                all_categories = cat_labels

            all_y_values.extend(y_vals)

            color_spec = s_item.get("color", cust.get("color", "#3B82F6"))
            color_val = _extract_color({"color": color_spec}, "color", "#3B82F6")
            parsed_series.append({
                "title": s_title_str,
                "title_style": s_title_style,
                "y": y_vals,
                "color": color_val,
                "customise": cust,
            })

        if not all_categories:
            all_categories = ["A", "B", "C", "D"]

        # Calculate auto-scaled Y ticks using Matplotlib ticker.MaxNLocator
        max_y_val = max(all_y_values) if all_y_values else 100.0
        min_y_val = min(min(all_y_values), 0.0)

        locator = ticker.MaxNLocator(nbins=5, integer=True)
        tick_locations = locator.tick_values(min_y_val, max_y_val if max_y_val > 0 else 10.0)
        y_min = float(tick_locations[0])
        y_max = float(tick_locations[-1])
        if y_max <= y_min:
            y_max = y_min + 10.0

        # Track min/max coordinates for tightest bounding box fit
        min_fit_x = plot_x
        max_fit_x = plot_x + plot_w
        min_fit_y = plot_y
        max_fit_y = plot_y + plot_h

        # 1. Render Background Grid & Y Ticks
        show_line = extra_cust.get("show_line", True)
        grid_color = _extract_color(extra_cust, "grid_color", "#D6DDE6")
        y_tick_color = _extract_color(extra_cust, "y_tick_color", "#475569")

        for t_val in tick_locations:
            if y_min <= t_val <= y_max:
                norm_y = (t_val - y_min) / (y_max - y_min)
                tick_pixel_y = plot_y + plot_h - norm_y * plot_h

                if has_win:
                    if show_line:
                        # Grid horizontal line via _shapes.shape
                        shape(
                            display=window_tag,
                            x=plot_x,
                            y=tick_pixel_y,
                            size=[plot_w, 1],
                            color=grid_color,
                            z=z_layer,
                        )

                    # Y tick text label via _text.text
                    tick_str = f"{t_val:g}"
                    text(
                        display=window_tag,
                        text=tick_str,
                        x=plot_x - 12,
                        y=tick_pixel_y - 6,
                        color=y_tick_color,
                        font_size=10,
                        align="right",
                    )
                min_fit_x = min(min_fit_x, plot_x - 40)

        # Baseline Y = 0 coordinate
        zero_norm_y = (0.0 - y_min) / (y_max - y_min)
        zero_pixel_y = plot_y + plot_h - zero_norm_y * plot_h

        # Axis Baseline line
        if has_win:
            axis_color = _extract_color(extra_cust, "axis_color", "#8DA0B8")
            shape(
                display=window_tag,
                x=plot_x,
                y=zero_pixel_y,
                size=[plot_w, 2],
                color=axis_color,
                z=z_layer,
            )

        # 2. Render Bars and X Category Labels
        num_cats = len(all_categories)
        num_series = len(parsed_series)
        group_width_ratio = extra_cust.get("group_width_ratio", 0.8)

        slot_width = plot_w / max(num_cats, 1)

        for cat_idx, cat_name in enumerate(all_categories):
            slot_center_x = plot_x + (cat_idx + 0.5) * slot_width

            # X Category Label via _text.text (with text IP & rotation support)
            label_color = _extract_color(extra_cust, "label_color", "#334155")
            label_size = extra_cust.get("label_font_size", 11)
            label_rotation = extra_cust.get("label_rotation", 0.0)
            label_y = plot_y + plot_h + 12

            if has_win:
                text(
                    display=window_tag,
                    text=cat_name,
                    x=slot_center_x,
                    y=label_y,
                    color=label_color,
                    font_size=label_size,
                    rotation=label_rotation,
                    align="center",
                )
            max_fit_y = max(max_fit_y, label_y + 20)

            # Draw bars for each series inside this category slot
            group_avail_w = slot_width * group_width_ratio
            bar_w = group_avail_w / max(num_series, 1)
            group_start_x = slot_center_x - group_avail_w / 2.0

            for s_idx, s_data in enumerate(parsed_series):
                y_list = s_data["y"]
                val = y_list[cat_idx] if cat_idx < len(y_list) else 0.0

                val_norm = (val - y_min) / (y_max - y_min)
                val_pixel_y = plot_y + plot_h - val_norm * plot_h

                bar_x = group_start_x + s_idx * bar_w
                bar_top = min(val_pixel_y, zero_pixel_y)
                bar_h = abs(zero_pixel_y - val_pixel_y)

                if bar_h < 1.0:
                    bar_h = 1.0

                # Render Bar rectangle via _shapes.shape with z-layer & shape bending support
                bar_ip = f"{ip}:bar:{s_idx}:{cat_idx}"
                if has_win:
                    shape(
                        display=window_tag,
                        ip=bar_ip,
                        x=bar_x,
                        y=bar_top,
                        size=[bar_w, bar_h],
                        color=s_data["color"],
                        border_radius=4,
                        bend=extra_cust.get("bar_bend", None),
                        bend_amount=extra_cust.get("bar_bend_amount", 40.0),
                        z=z_layer,
                    )

                    # Show numerical value callout text above bar if requested
                    if extra_cust.get("show_values", False) or s_data["customise"].get("show_values", False):
                        val_color = _extract_color(extra_cust, "value_color", "#1E293B")
                        val_str = _make_value_label(val, extra_cust.get("value_decimals", 0))
                        text(
                            display=window_tag,
                            text=val_str,
                            x=bar_x + bar_w / 2.0,
                            y=bar_top - 14,
                            color=val_color,
                            font_size=10,
                            align="center",
                        )
                min_fit_y = min(min_fit_y, bar_top - 20)

        # 3. Render Chart Title (Supports Text IP & Rotation)
        raw_title = extra_cust.get("title", "")
        if raw_title:
            title_str, title_style = resolve_text_spec(window_tag, raw_title)
            title_color = title_style.get("color") or _extract_color(extra_cust, "title_color", "#0F172A")
            title_size = title_style.get("font_size") or extra_cust.get("title_font_size", 16)
            title_rotation = title_style.get("rotation", 0.0) or extra_cust.get("title_rotation", 0.0)
            title_y = plot_y - 25

            if has_win:
                text(
                    display=window_tag,
                    text=title_str,
                    x=plot_x + plot_w / 2.0,
                    y=title_y,
                    color=title_color,
                    font_size=title_size,
                    bold=title_style.get("bold", False),
                    italic=title_style.get("italic", False),
                    rotation=title_rotation,
                    align="center",
                )
            min_fit_y = min(min_fit_y, title_y - 15)

        # 4. Calculate tightest fitable bounding box
        tight_x = float(min_fit_x)
        tight_y = float(min_fit_y)
        tight_w = float(max_fit_x - min_fit_x)
        tight_h = float(max_fit_y - min_fit_y)

        # Register container shape with ip so Draw.room and Draw.motion can locate it
        if has_win:
            shape(
                display=window_tag,
                ip=ip,
                x=tight_x,
                y=tight_y,
                size=[tight_w, tight_h],
                color="transparent",
                opacity=0,
                z=z_layer,
            )

        # Register tightest fitable box with _shapes.hitbox
        hitbox(
            tag=ip,
            mode="resetgeometry",
            box={
                "x": tight_x,
                "y": tight_y,
                "width": tight_w,
                "height": tight_h,
            },
        )

        return (tight_x, tight_y, tight_w, tight_h)

    # ── Extension Stub Renderer for Future Chart Types ────────────────────────

    def _render_placeholder_graph(
        self,
        ip: str,
        type_name: str,
        window_tag: str,
        align_spec: str,
        z_layer: int = 0,
    ) -> Tuple[float, float, float, float]:
        """Placeholder handler for future chart types (line, pie, radar, etc.)."""
        x, y, w, h = 100.0, 100.0, 400.0, 300.0
        if _window_exists(window_tag):
            shape(
                display=window_tag,
                ip=ip,
                x=x,
                y=y,
                size=[w, h],
                color="transparent",
                opacity=0,
                z=z_layer,
            )
            text(
                display=window_tag,
                text=f"Chart type '{type_name}' connected (ready for expansion)",
                x=x + w / 2.0,
                y=y + h / 2.0,
                color="#64748B",
                font_size=14,
                align="center",
            )
        hitbox(tag=ip, mode="resetgeometry", box={"x": x, "y": y, "width": w, "height": h})
        return (x, y, w, h)

    # ── Public Interop Methods ────────────────────────────────────────────────

    def update_live(self, window_tag: Optional[str] = None) -> None:
        """Re-evaluates reactive live variables and refreshes graph rendering."""
        for (w_tag, ip_key), params in list(self._raw_params.items()):
            if window_tag is None or w_tag == window_tag:
                self.__call__(**params)

    def get_by_ip(self, window_tag: str, ip: str) -> Optional[GraphDef]:
        """Returns the registered GraphDef record."""
        return self._graphs.get((window_tag, ip))

    def get_pixel_bounds(self, window_tag: str, ip: str) -> Optional[Tuple[float, float, float, float]]:
        """Returns pixel bounding box (x, y, w, h)."""
        gdef = self.get_by_ip(window_tag, ip)
        return gdef.bounds if gdef else None

    def get_intrinsic_size(self, window_tag: str, ip: str) -> Optional[Tuple[float, float]]:
        """Returns (width, height) for layout interop."""
        bounds = self.get_pixel_bounds(window_tag, ip)
        return (bounds[2], bounds[3]) if bounds else None

    def move_by_ip(self, window_tag: str, ip: str, x: float, y: float) -> bool:
        """Shifts graph container top-left position to (x, y) and re-renders all elements."""
        gdef = self.get_by_ip(window_tag, ip)
        if not gdef:
            return False

        params = self._raw_params.get((window_tag, ip))
        if params:
            cust = dict(params.get("customise", {}))
            cust["x"] = float(x)
            cust["y"] = float(y)
            params["customise"] = cust
            if "kwargs" in params and isinstance(params["kwargs"], dict):
                kw_cust = dict(params["kwargs"].get("customise", {}))
                kw_cust["x"] = float(x)
                kw_cust["y"] = float(y)
                params["kwargs"]["customise"] = kw_cust
            self.__call__(**params)

        gdef.bounds = (float(x), float(y), gdef.bounds[2], gdef.bounds[3])
        return True

    def resize_by_ip(self, window_tag: str, ip: str, width: float, height: float) -> bool:
        """Resizes graph container bounds (width, height) and re-renders all elements."""
        if width <= 0 or height <= 0:
            return False
        gdef = self.get_by_ip(window_tag, ip)
        if not gdef:
            return False

        params = self._raw_params.get((window_tag, ip))
        if params:
            cust = dict(params.get("customise", {}))
            cust["width"] = float(width)
            cust["height"] = float(height)
            params["customise"] = cust
            if "kwargs" in params and isinstance(params["kwargs"], dict):
                kw_cust = dict(params["kwargs"].get("customise", {}))
                kw_cust["width"] = float(width)
                kw_cust["height"] = float(height)
                params["kwargs"]["customise"] = kw_cust
            self.__call__(**params)

        gdef.bounds = (gdef.bounds[0], gdef.bounds[1], float(width), float(height))
        return True

    def clear(self, window_tag: Optional[str] = None) -> int:
        """Clears registered graph records for a window tag."""
        if window_tag is None:
            count = len(self._graphs)
            self._graphs.clear()
            self._raw_params.clear()
            return count
        keys_to_del = [k for k in self._graphs if k[0] == window_tag]
        for k in keys_to_del:
            self._graphs.pop(k, None)
            self._raw_params.pop(k, None)
        return len(keys_to_del)


# ── 6. Public Singleton Export ────────────────────────────────────────────────

graph = _GraphRegistry()
