
import os
import sys
import random
import time

# Ensure Draw package parent is in sys.path
SYS_ROOT = os.path.dirname(os.path.abspath(__file__))
PARENT_ROOT = os.path.dirname(SYS_ROOT)
if PARENT_ROOT not in sys.path:
    sys.path.insert(0, PARENT_ROOT)
if SYS_ROOT not in sys.path:
    sys.path.insert(0, SYS_ROOT)

import Draw


def create_nexus_app():
    # ══════════════════════════════════════════════════════════════════════
    # 1. CREATE MAIN WINDOW with Dark CSS Theme
    # ══════════════════════════════════════════════════════════════════════
    Draw.window(
        tag="main",
        title="Nexus Studio — Executive Analytics & Operations Center",
        width=1160,
        height=750,
        resizable=True,
        style="""
            QMainWindow {
                background-color: #0F172A;
                color: #F8FAFC;
                font-family: 'Segoe UI', system-ui, sans-serif;
            }
            QMenuBar {
                background-color: #1E293B;
                color: #E2E8F0;
                font-size: 13px;
                padding: 4px;
                border-bottom: 1px solid #334155;
            }
            QMenuBar::item:selected {
                background-color: #3B82F6;
                color: #FFFFFF;
                border-radius: 4px;
            }
            QMenu {
                background-color: #1E293B;
                color: #F8FAFC;
                border: 1px solid #334155;
                padding: 5px;
            }
            QMenu::item:selected {
                background-color: #2563EB;
            }
            QStatusBar {
                background-color: #1E293B;
                color: #94A3B8;
                font-size: 12px;
                border-top: 1px solid #334155;
            }
        """,
        on_close=lambda: print("Nexus Application Closing...") or True
    )

    # ══════════════════════════════════════════════════════════════════════
    # 2. DECLARATIVE NATIVE MENU BAR
    # ══════════════════════════════════════════════════════════════════════
    def action_new():
        Draw.window.set_status("main", "New Analytics Workspace Initialized", 4000)

    def action_export():
        rev = Draw.live.get("revenue_vals")
        prof = Draw.live.get("profit_vals")
        data_summary = f"Nexus Analytics Export Summary\nTime: {time.strftime('%Y-%m-%d %H:%M:%S')}\n"
        data_summary += f"Revenue: {rev}\nProfit: {prof}\n"
        Draw.clipboard.copy(data_summary)
        Draw.window.set_status("main", "📋 Summary copied to OS Clipboard!", 5000)

    def action_save_file():
        path = Draw.filedialog.save_file(caption="Export Report", filter="JSON Files (*.json);;Text Files (*.txt)")
        if path:
            Draw.window.set_status("main", f"💾 Report saved to {path}", 5000)

    def action_open_file():
        path = Draw.filedialog.open_file(caption="Open Dataset", filter="All Files (*.*)")
        if path:
            Draw.window.set_status("main", f"📂 Opened: {os.path.basename(path)}", 5000)

    def open_pie_studio_window():
        Draw.window(
            tag="pie_studio",
            title="Pie & Universal Color Studio",
            width=680,
            height=520,
            resizable=True,
            style="""
                QMainWindow {
                    background-color: #0F172A;
                    color: #F8FAFC;
                    font-family: 'Segoe UI', system-ui, sans-serif;
                }
            """
        )

        Draw.shapes(
            display="pie_studio",
            shape=[{
                "ip": "pie_studio_bg",
                "vertices": 4,
                "align": "center",
                "size": ["100%", "100%"],
                "color": "#0F172A",
                "z": 1000,
                "overlap": True,
            }]
        )

        # Register dynamic color binding via Draw.color (color.py)
        Draw.color(
            ip="pie_studio_chart:wedge:0:0",
            color=[{"for": "body", "h": "time * 45", "s": 90, "v": 100}]
        )

        Draw.graph(
            ip="pie_studio_chart",
            type="pie",
            tag="pie_studio",
            align="center",
            draggable=True,
            graph=[{
                "x": ["Dynamic Hue", "Direct", "Search", "Referral"],
                "y": Draw.live.ref("pie_studio_vals"),
                "title": "Live Color & Pie Studio",
                "customise": {
                    "margin": 25,
                    "color": ["#6366F1", "#10B981", "#EC4899", "#F59E0B"]
                }
            }]
        )

        Draw.window.show("pie_studio")
        Draw.window.set_status("main", "Opened Pie & Universal Color Studio Window", 4000)

    Draw.window.set_menu("main", [
        {
            "File": [
                ("New Workspace", action_new),
                ("Open Dataset...", action_open_file),
                ("Save Report...", action_save_file),
                "---",
                ("Copy Summary to Clipboard", action_export),
                "---",
                ("Exit", Draw.quit)
            ]
        },
        {
            "View": [
                ("Maximize Main Window", lambda: Draw.window.maximize("main")),
                ("Restore Main Window", lambda: Draw.window.restore("main")),
                "---",
                ("Open Pie & Color Studio Window", open_pie_studio_window),
            ]
        },
        {
            "Tools": [
                ("Refresh Live Data", lambda: stream_tick()),
                ("Open Pie & Color Studio", open_pie_studio_window),
            ]
        }
    ])

    Draw.window.set_status("main", "System Ready — Real-Time Streaming Active", 6000)

    # ══════════════════════════════════════════════════════════════════════
    # 3. BACKGROUND & HEADER SHAPES
    # ══════════════════════════════════════════════════════════════════════
    Draw.shapes(
        display="main",
        shape=[
            {
                "ip": "main_bg",
                "vertices": 4,
                "align": "center",
                "size": ["100%", "100%"],
                "color": "#0F172A",
                "z": 1000,
                "overlap": True,
                "locked": True
            },
            {
                "ip": "header_card",
                "vertices": 4,
                "size": ["97%", 55],
                "color": "#1E293B",
                "border_color": "#334155",
                "border_width": 1,
                "border_radius": 8,
                "z": 500,
                "overlap": True,
                "locked": True
            }
        ]
    )

    # ══════════════════════════════════════════════════════════════════════
    # 4. HEADER TITLE & MATH SOLVER
    # ══════════════════════════════════════════════════════════════════════
    Draw.text(
        tag="main",
        text="⚡ NEXUS EXECUTIVE DASHBOARD",
        ip="app_title",
        x=35, y=28,
        customise={
            "font_size": 16,
            "font_family": "Segoe UI",
            "color": "#38BDF8",
            "bold": True
        }
    )

    def on_calc_submit(text_val):
        if not text_val or not text_val.strip():
            return
        result = Draw.calculator(text_val, precision=4, error_value="Math Error")
        Draw.live.set("calc_result", f"= {result}")
        Draw.window.set_status("main", f"Evaluated: {text_val} => {result}", 5000)

    Draw.text(
        tag="main",
        text="Math Solver:",
        ip="calc_label",
        x=520, y=30,
        customise={"font_size": 11, "color": "#94A3B8", "bold": True}
    )

    Draw.lineedit(
        ip="calc_input",
        display="main",
        x=610, y=22, width=200, height=28,
        placeholder="e.g. sin(3.14) * 100",
        style={
            "background_color": "#0F172A",
            "text_color": "#F8FAFC",
            "border_color": "#475569",
            "border_radius": 6
        },
        on_submit=on_calc_submit
    )

    Draw.live.set("calc_result", "= Ready")
    Draw.text(
        tag="main",
        text=Draw.live.text(Draw.live.ref("calc_result")),
        ip="calc_result_text",
        x=820, y=30,
        customise={"font_size": 11, "color": "#4ADE80", "bold": True}
    )

    # ══════════════════════════════════════════════════════════════════════
    # 5. GRID LAYOUT FOR CHARTS (2x2 grid)
    # ══════════════════════════════════════════════════════════════════════
    Draw.table(
        ip="dash_grid",
        dimension={
            "type": "table",
            "rows": 2,
            "columns": 2,
            "origin": "top-left",
            "margin": {
                "top": 75,
                "left": 15,
                "right": 15,
                "bottom": 10,
                "cell_margin": 8,
            },
        }
    )

    # ══════════════════════════════════════════════════════════════════════
    # 6. INITIALIZE REACTIVE LIVE DATA FOR CHARTS
    # ══════════════════════════════════════════════════════════════════════
    Draw.live.set("quarters", ["Q1", "Q2", "Q3", "Q4", "Q5"])
    Draw.live.set("revenue_vals", [140, 260, 210, 340, 310])
    Draw.live.set("profit_vals", [55, 110, 85, 155, 135])
    Draw.live.set("pie_studio_vals", [45, 25, 20, 10])

    # ══════════════════════════════════════════════════════════════════════
    # 7. SALES & PROFIT BAR+LINE CHART (Top-Left Cell: column 0, row 0)
    # ══════════════════════════════════════════════════════════════════════
    Draw.graph(
        ip="sales_chart",
        type="bar",
        tag="main",
        get_ip="dash_grid",
        columns=(0, 0),
        draggable=True,
        animate=True,
        hover=True,
        graph=[
            {
                "x": Draw.live.ref("quarters"),
                "y": Draw.live.ref("revenue_vals"),
                "title": "Revenue ($K)",
                "customise": {
                    "color": "#3B82F6",
                    "show_values": True,
                    "value_decimals": 0,
                    "title": "Quarterly Financial Performance",
                    "x_title": "Fiscal Quarters",
                    "y_title": "Revenue & Profit ($K)",
                    "show_line": True,
                    "show_legend": True,
                    "legend_position": "top-right",
                    "margin": 35,
                }
            },
            {
                "x": Draw.live.ref("quarters"),
                "y": Draw.live.ref("profit_vals"),
                "type": "line",
                "title": "Net Profit ($K)",
                "customise": {
                    "line_color": "#10B981",
                    "line_width": 4,
                    "smooth": True,
                    "point_size": 8,
                }
            }
        ]
    )

    # ══════════════════════════════════════════════════════════════════════
    # 8. TRAFFIC DONUT CHART (Top-Right Cell: column 1, row 0)
    # ══════════════════════════════════════════════════════════════════════
    Draw.graph(
        ip="traffic_donut",
        type="donut",
        tag="main",
        get_ip="dash_grid",
        columns=(1, 0),
        draggable=True,
        animate=True,
        graph=[
            {
                "x": ["Direct", "Search", "Social", "Referral"],
                "y": [42, 32, 16, 10],
                "title": "Acquisition Breakdown",
                "customise": {
                    "color": ["#6366F1", "#10B981", "#EC4899", "#F59E0B"],
                    "center_text": "100%",
                    "hole_color": "#0F172A",
                    "margin": 30,
                }
            }
        ]
    )

    # ══════════════════════════════════════════════════════════════════════
    # 9. SYSTEM AUDIT RADAR CHART (Bottom-Left Cell: column 0, row 1)
    # ══════════════════════════════════════════════════════════════════════
    Draw.graph(
        ip="audit_radar",
        type="radar",
        tag="main",
        get_ip="dash_grid",
        columns=(0, 1),
        draggable=True,
        graph=[
            {
                "x": ["Latency", "Security", "Uptime", "Scalability", "UX Quality"],
                "y": [92, 98, 99, 88, 95],
                "title": "System Audit Score",
                "customise": {
                    "margin": 35,
                }
            }
        ]
    )

    # ══════════════════════════════════════════════════════════════════════
    # 10. FLOATING STUDIO CONTROL PANEL (Bottom-Right area)
    # ══════════════════════════════════════════════════════════════════════
    Draw.panel(
        ip="controls_panel",
        display="main",
        title="🎛️ Live Stream & Studio Controls",
        width=510,
        height=285,
        background_color="#1E293B",
        title_background="#0F172A",
        title_color="#38BDF8",
        border_color="#334155",
        border_radius=10,
        draggable=True,
        closable=False,
        shadow=True,
        shadow_blur=15
    )

    # Panel button shapes
    Draw.shapes(
        display="controls_panel",
        shape=[
            {
                "ip": "btn_refresh",
                "vertices": 4,
                "size": [200, 38],
                "x": 20, "y": 15,
                "color": "#2563EB",
                "border_radius": 6,
                "z": 10
            },
            {
                "ip": "btn_toggle_stream",
                "vertices": 4,
                "size": [200, 38],
                "x": 240, "y": 15,
                "color": "#0D9488",
                "border_radius": 6,
                "z": 10
            },
            {
                "ip": "btn_copy_clip",
                "vertices": 4,
                "size": [200, 38],
                "x": 20, "y": 68,
                "color": "#7C3AED",
                "border_radius": 6,
                "z": 10
            },
            {
                "ip": "btn_save_report",
                "vertices": 4,
                "size": [200, 38],
                "x": 240, "y": 68,
                "color": "#D97706",
                "border_radius": 6,
                "z": 10
            }
        ]
    )

    # Button labels
    Draw.text(
        tag="controls_panel",
        text="Refresh Ticks",
        ip="txt_refresh",
        x=20, y=24,
        customise={"font_size": 12, "color": "#FFFFFF", "bold": True, "align_text": "center", "max_width": 200}
    )

    Draw.live.set("stream_status_text", "Pause Stream")
    Draw.text(
        tag="controls_panel",
        text=Draw.live.text(Draw.live.ref("stream_status_text")),
        ip="txt_toggle_stream",
        x=240, y=24,
        customise={"font_size": 12, "color": "#FFFFFF", "bold": True, "align_text": "center", "max_width": 200}
    )

    Draw.text(
        tag="controls_panel",
        text="Copy Metrics",
        ip="txt_copy_clip",
        x=20, y=77,
        customise={"font_size": 12, "color": "#FFFFFF", "bold": True, "align_text": "center", "max_width": 200}
    )

    Draw.text(
        tag="controls_panel",
        text="Export Report",
        ip="txt_save_report",
        x=240, y=77,
        customise={"font_size": 12, "color": "#FFFFFF", "bold": True, "align_text": "center", "max_width": 200}
    )

    # ── Status Metrics ───────────────────────────────────────────────────
    Draw.live.set("live_rev_display", "Revenue: $310K")
    Draw.live.set("live_prof_display", "Profit: $135K")

    Draw.text(
        tag="controls_panel",
        text=Draw.live.text(Draw.live.ref("live_rev_display")),
        ip="txt_live_rev",
        x=30, y=125,
        customise={"font_size": 14, "color": "#38BDF8", "bold": True}
    )

    Draw.text(
        tag="controls_panel",
        text=Draw.live.text(Draw.live.ref("live_prof_display")),
        ip="txt_live_prof",
        x=250, y=125,
        customise={"font_size": 14, "color": "#4ADE80", "bold": True}
    )

    # Spinner loader indicator inside panel
    Draw.loader(
        display="controls_panel",
        ip="panel_spinner",
        shape="circle",
        color="#38BDF8",
        motion="spin",
        x=200, y=160,
        size=[30, 30]
    )

    Draw.text(
        tag="controls_panel",
        text="Live Engine Active (~60 FPS)",
        ip="txt_spinner_lbl",
        x=130, y=200,
        customise={"font_size": 11, "color": "#64748B"}
    )

    # ══════════════════════════════════════════════════════════════════════
    # 11. LAYOUT: Position header_card via Draw.room (must be after all
    #     referenced objects are created). Graphs use align= directly.
    # ══════════════════════════════════════════════════════════════════════
    Draw.room(
        display="main",
        general={"padding": 12},
        scene={
            "header_card": "top",
        }
    )

    # ══════════════════════════════════════════════════════════════════════
    # 11. LIVE STREAMING LOGIC (Draw.live + Draw.every + Draw.graph.update_live)
    # ══════════════════════════════════════════════════════════════════════
    stream_active = [True]

    def stream_tick():
        if not stream_active[0]:
            return
        revenue = Draw.live.get("revenue_vals")
        if not revenue:
            return
        new_rev = [max(60, min(450, v + random.randint(-20, 25))) for v in revenue]
        new_prof = [max(25, min(220, int(v * 0.48))) for v in new_rev]
        Draw.live.set("revenue_vals", new_rev)
        Draw.live.set("profit_vals", new_prof)
        Draw.live.set("pie_studio_vals", [random.randint(25, 65), random.randint(15, 45), random.randint(10, 35), random.randint(5, 25)])

        # Update live metric displays in the panel
        Draw.live.set("live_rev_display", f"Revenue: ${new_rev[-1]}K")
        Draw.live.set("live_prof_display", f"Profit: ${new_prof[-1]}K")

        try:
            Draw.graph.update_live("main")
            Draw.graph.update_live("pie_studio")
        except (KeyError, RuntimeError):
            pass

    def toggle_stream():
        stream_active[0] = not stream_active[0]
        status_str = "Pause Stream" if stream_active[0] else "Resume Stream"
        Draw.live.set("stream_status_text", status_str)
        msg = "Live streaming resumed" if stream_active[0] else "Live streaming paused"
        Draw.window.set_status("main", msg, 3000)

    # ══════════════════════════════════════════════════════════════════════
    # 12. WIRE BUTTON CLICKS via Draw.senses + Draw.connectors
    # ══════════════════════════════════════════════════════════════════════
    sense_refresh = Draw.senses("press", ip="btn_refresh", mouse_type="pointer")
    sense_toggle = Draw.senses("press", ip="btn_toggle_stream", mouse_type="pointer")
    sense_copy = Draw.senses("press", ip="btn_copy_clip", mouse_type="pointer")
    sense_save = Draw.senses("press", ip="btn_save_report", mouse_type="pointer")

    Draw.connectors(sense=sense_refresh, work=lambda rec: stream_tick())
    Draw.connectors(sense=sense_toggle, work=lambda rec: toggle_stream())
    Draw.connectors(sense=sense_copy, work=lambda rec: action_export())
    Draw.connectors(sense=sense_save, work=lambda rec: action_save_file())

    # ══════════════════════════════════════════════════════════════════════
    # 13. START BACKGROUND TIMER FOR LIVE STREAM TICKS
    # ══════════════════════════════════════════════════════════════════════
    Draw.every(1.5, stream_tick)

    # ══════════════════════════════════════════════════════════════════════
    # 14. RUN MAIN APPLICATION EVENT LOOP
    # ══════════════════════════════════════════════════════════════════════
    print("Launching Nexus Application...")
    Draw.window.run("main")


if __name__ == "__main__":
    create_nexus_app()
