"""
DRAW.NEXUS Step Debugging & System Diagnostics Suite
===================================================
Comprehensive step-by-step validation tool to verify Python environment,
PySide6 GUI capabilities, Draw engine subsystems, OpenGL hardware acceleration,
and multi-window rendering.
"""

from __future__ import annotations

import os
import sys
import time
import traceback

# Console output safety
try:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

# Ensure paths
_CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
_PARENT_DIR = os.path.dirname(_CURRENT_DIR)
for p in [_PARENT_DIR, _CURRENT_DIR]:
    if p not in sys.path:
        sys.path.insert(0, p)

LOG_FILE = os.path.join(_CURRENT_DIR, "step_debug.log")


class StepDebugger:
    """Manages sequential step debugging and reports detailed status."""

    def __init__(self):
        self.step_num = 0
        self.total_steps = 8
        self.logs = []
        self.has_errors = False
        with open(LOG_FILE, "w", encoding="utf-8") as f:
            f.write(f"=== DRAW.NEXUS STEP DEBUG SESSION [{time.ctime()}] ===\n\n")

    def log(self, msg: str, level: str = "INFO"):
        prefix = f"[{level}]"
        line = f"{prefix:<8} {msg}"
        print(line, flush=True)
        self.logs.append(line)
        try:
            with open(LOG_FILE, "a", encoding="utf-8") as f:
                f.write(line + "\n")
        except Exception:
            pass

    def start_step(self, title: str) -> bool:
        self.step_num += 1
        print("\n" + "=" * 65, flush=True)
        print(f"  STEP {self.step_num}/{self.total_steps}: {title.upper()}", flush=True)
        print("=" * 65, flush=True)
        self.log(f"Entering Step {self.step_num}: {title}")
        return True

    def pass_step(self, summary: str = "OK"):
        print(f"  --> [PASSED] {summary}\n", flush=True)
        self.log(f"Step {self.step_num} PASSED: {summary}")

    def fail_step(self, error: Exception | str, details: str = ""):
        self.has_errors = True
        print(f"  --> [FAILED] {error}", flush=True)
        if details:
            print(f"      Details: {details}", flush=True)
        self.log(f"Step {self.step_num} FAILED: {error} | {details}", level="ERROR")
        try:
            with open(LOG_FILE, "a", encoding="utf-8") as f:
                f.write(traceback.format_exc() + "\n")
        except Exception:
            pass

    def run_all(self, pause_between_steps: bool = False) -> bool:
        """Executes all 8 diagnostic steps sequentially."""
        print("\n" + "#" * 65)
        print("   DRAW.NEXUS STEP-BY-STEP DIAGNOSTIC SYSTEM")
        print("#" * 65)

        # -------------------------------------------------------------
        # STEP 1: Python Environment & Interpreter
        # -------------------------------------------------------------
        self.start_step("Python Environment & Interpreter Check")
        try:
            py_ver = sys.version.replace('\n', ' ')
            is_64bit = sys.maxsize > 2**32
            self.log(f"Executable: {sys.executable}")
            self.log(f"Version:    {py_ver}")
            self.log(f"64-Bit OS:  {is_64bit}")
            self.log(f"sys.path:   {sys.path[:3]}")
            if sys.version_info < (3, 8):
                raise RuntimeError(f"Python 3.8+ required. Current version: {sys.version}")
            self.pass_step(f"Python {sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro} ({'64-bit' if is_64bit else '32-bit'})")
        except Exception as e:
            self.fail_step(e, traceback.format_exc())
            return False

        if pause_between_steps:
            input("Press ENTER to continue to Step 2...")

        # -------------------------------------------------------------
        # STEP 2: Core Dependencies Verification
        # -------------------------------------------------------------
        self.start_step("Core Dependencies Check (PySide6, OpenGL, NumPy)")
        try:
            import PySide6
            self.log(f"PySide6 version: {PySide6.__version__}")
            from PySide6 import QtCore, QtGui, QtWidgets
            self.log("PySide6 QtCore, QtGui, QtWidgets loaded successfully.")
            from PySide6 import QtOpenGLWidgets
            self.log("PySide6 QtOpenGLWidgets loaded successfully.")
            import numpy
            self.log(f"NumPy version: {numpy.__version__}")
            self.pass_step("PySide6 & NumPy libraries fully operational")
        except Exception as e:
            self.fail_step(e, "Install missing packages: py -3.13 -m pip install PySide6 numpy")
            return False

        if pause_between_steps:
            input("Press ENTER to continue to Step 3...")

        # -------------------------------------------------------------
        # STEP 3: Basic Native Qt Window Test
        # -------------------------------------------------------------
        self.start_step("Native OS Display & QApplication Window Test")
        try:
            app = QtWidgets.QApplication.instance()
            if app is None:
                app = QtWidgets.QApplication([])
            self.log("QApplication instance ready.")
            test_win = QtWidgets.QMainWindow()
            test_win.setWindowTitle("DRAW.NEXUS Diagnostic Smoke Test")
            test_win.resize(400, 200)
            self.log("Test QMainWindow created successfully.")
            self.pass_step("OS Desktop Windowing Subsystem OK")
        except Exception as e:
            self.fail_step(e, traceback.format_exc())
            return False

        if pause_between_steps:
            input("Press ENTER to continue to Step 4...")

        # -------------------------------------------------------------
        # STEP 4: Draw Framework Core Package Loading
        # -------------------------------------------------------------
        self.start_step("Draw Framework Core Package Loading")
        try:
            import Draw
            self.log(f"Draw Framework Version: {Draw.__version__}")
            self.log(f"Registered Windows: {Draw.window.list_tags()}")
            from Draw.debug import debug
            self.log(f"Debug Subsystems Monitored: {len(debug._query_subsystems_status())} subsystems")
            self.pass_step(f"Draw v{Draw.__version__} loaded cleanly")
        except Exception as e:
            self.fail_step(e, traceback.format_exc())
            return False

        if pause_between_steps:
            input("Press ENTER to continue to Step 5...")

        # -------------------------------------------------------------
        # STEP 5: DRAW.NEXUS Subsystem Component Verification
        # -------------------------------------------------------------
        self.start_step("DRAW.NEXUS Subsystem Module Instantiation")
        try:
            import draw_nexus
            from draw_nexus.particles import ParticleUniverse
            from draw_nexus.motion_lab import MotionLab
            from draw_nexus.inspector import InspectorHUD
            from draw_nexus.graph_hud import PerformanceGraph
            from draw_nexus.drag_experiment import DragExperiment
            from draw_nexus.timeline import MotionTimeline
            from draw_nexus.wow_sequence import WowDirector
            from draw_nexus.benchmark import BenchmarkSuite
            from draw_nexus.chaos import ChaosController

            # 1. Particles
            u = ParticleUniverse(count=100)
            u.update(0.016)
            self.log(f"Particle Universe: {len(u.particles)} nodes simulated OK.")

            # 2. Motion Lab
            m = MotionLab()
            self.log(f"Motion Lab: Active mode '{m.active_mode}' OK.")

            # 3. Inspector
            insp = InspectorHUD()
            self.log("Object Inspector HUD: Initialized OK.")

            # 4. Graph HUD
            g = PerformanceGraph()
            g.record_sample(60.0, 16.6, 100)
            self.log("Performance Graph: Sampler OK.")

            # 5. Drag Physics
            d = DragExperiment()
            self.log(f"Drag Experiment: {len(d.nodes)} nodes OK.")

            # 6. Timeline
            t = MotionTimeline()
            t.update(0.016)
            self.log("Timeline Controller: OK.")

            self.pass_step("All 10 DRAW.NEXUS Subsystems verified cleanly")
        except Exception as e:
            self.fail_step(e, traceback.format_exc())
            return False

        if pause_between_steps:
            input("Press ENTER to continue to Step 6...")

        # -------------------------------------------------------------
        # STEP 6: Multi-Window App Instantiation & Layout Assembly
        # -------------------------------------------------------------
        self.start_step("Multi-Window App Instantiation & Layout Assembly")
        try:
            from draw_nexus.app import DrawNexusApp
            app_inst = DrawNexusApp(tag="debug_nexus_main")
            app_inst.setup_window(open_satellite=True)
            self.log(f"Primary Window Tag: {app_inst.tag}")
            self.log(f"Satellite Window Tag: {app_inst.satellite.tag}")
            self.log(f"Registered Windows: {Draw.window.list_tags()}")
            self.pass_step("Dual-Window Workstation + Satellite link active")
        except Exception as e:
            self.fail_step(e, traceback.format_exc())
            return False

        if pause_between_steps:
            input("Press ENTER to continue to Step 7...")

        # -------------------------------------------------------------
        # STEP 7: OpenGL Draw.super Acceleration Warm-up
        # -------------------------------------------------------------
        self.start_step("OpenGL Draw.super Hardware Acceleration Warm-up")
        try:
            import Draw
            gl_canvas = Draw.super(display="debug_nexus_main", mode="max", vsync=False)
            self.log(f"OpenGL Canvas Widget: {type(gl_canvas).__name__}")
            cap = getattr(gl_canvas.batcher, "max_vertices", 65536)
            self.log(f"Geometry Batcher Capacity: {cap:,} vertices")
            self.pass_step("Hardware-Accelerated OpenGL Engine Ready")
        except Exception as e:
            self.fail_step(e, traceback.format_exc())
            return False

        # -------------------------------------------------------------
        # STEP 8: Final Summary & Launch Preparation
        # -------------------------------------------------------------
        self.start_step("Launch Readiness Summary")
        print("  [✓] All 8 Subsystems & Engine Checks PASSED!")
        print(f"  [✓] Full debug log recorded at: {LOG_FILE}\n")
        self.pass_step("System 100% Ready for Interactive Execution")
        return True


def interactive_launcher():
    """Interactive CLI menu allowing users to step-debug or launch."""
    debugger = StepDebugger()
    
    print("\n" + "=" * 60)
    print("      DRAW.NEXUS STEP DEBUGGER & LAUNCH MENU")
    print("=" * 60)
    print("  [1] Run Full Step-by-Step Diagnostics (Automated)")
    print("  [2] Run Step-by-Step Diagnostics (Interactive Pause)")
    print("  [3] Launch DRAW.NEXUS Live Application (Dual Window)")
    print("  [4] Launch in Safe Fallback Mode (No OpenGL)")
    print("  [5] Exit")
    print("=" * 60)
    
    choice = input("Enter choice [1-5] (default: 1): ").strip() or "1"
    
    if choice == "1":
        ok = debugger.run_all(pause_between_steps=False)
        if ok:
            print("\nDiagnostics passed! Launching DRAW.NEXUS now...")
            time.sleep(1)
            from draw_nexus.app import run_draw_nexus
            run_draw_nexus()
        else:
            print(f"\n[!] Diagnostics failed. Check {LOG_FILE} for details.")
            input("Press ENTER to exit...")
            
    elif choice == "2":
        ok = debugger.run_all(pause_between_steps=True)
        if ok:
            ans = input("\nDiagnostics passed! Would you like to launch the app now? (Y/n): ").strip().lower()
            if ans in ("", "y", "yes"):
                from draw_nexus.app import run_draw_nexus
                run_draw_nexus()
        else:
            print(f"\n[!] Diagnostics failed. Check {LOG_FILE} for details.")
            input("Press ENTER to exit...")
            
    elif choice == "3":
        print("\nStarting DRAW.NEXUS in Hardware-Accelerated Mode...")
        from draw_nexus.app import run_draw_nexus
        run_draw_nexus()
        
    elif choice == "4":
        print("\nStarting DRAW.NEXUS in Safe Fallback Mode...")
        from draw_nexus.app import DrawNexusApp
        import Draw
        app = DrawNexusApp(tag="nexus_main")
        app.setup_window(open_satellite=True)
        Draw.window.run()
        
    elif choice == "5":
        print("Exiting.")
        sys.exit(0)


if __name__ == "__main__":
    interactive_launcher()
