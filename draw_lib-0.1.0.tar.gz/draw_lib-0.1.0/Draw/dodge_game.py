"""
dodge_game.py
=============
A fast-paced 2D arcade dodge game built entirely with the Draw library.

Features:
- Animated startup loader with real-time progress bar (Draw.loader + Draw.room).
- Automatic transition from loader to active gameplay in 1.5s (or press any key to skip).
- Declarative HUD & Modal scene layouts powered by Draw.room.
- Player (🟦) controlled at the bottom with ← / → arrow keys or A / D.
- Falling obstacles (■) rain down at dynamically increasing speeds.
- Evading obstacles past the bottom awards +1 score.
- 3 Lives (❤️ 3) with impact particles, invulnerability frames, and game over.
- Pure Draw API: Draw.window, Draw.loader, Draw.room, Draw.shapes, Draw.text, Draw.senses, Draw.every.
"""

import os
import sys
import random
import time

# Ensure Draw package parent is in sys.path
WORKSPACE_ROOT = os.path.dirname(os.path.abspath(__file__))
PARENT_ROOT = os.path.dirname(WORKSPACE_ROOT)
if PARENT_ROOT not in sys.path:
    sys.path.insert(0, PARENT_ROOT)
if WORKSPACE_ROOT not in sys.path:
    sys.path.insert(0, WORKSPACE_ROOT)

import Draw

# ══════════════════════════════════════════════════════════════════════════════
#  Game Configuration & Constants
# ══════════════════════════════════════════════════════════════════════════════
WIN_TAG        = "main"
WIN_WIDTH      = 460
WIN_HEIGHT     = 680
HEADER_H       = 58

PLAYER_SIZE    = 34
PLAYER_Y       = 600
PLAYER_SPEED   = 380.0  # px/s

NUM_OBSTACLES  = 16
NUM_STARS      = 22
NUM_SPARKS     = 14

BASE_FALL_SPEED    = 210.0
SPEED_INCREMENT    = 5.5
MAX_FALL_SPEED     = 680.0

BASE_SPAWN_INTERVAL = 0.78
MIN_SPAWN_INTERVAL  = 0.20

LOADER_DURATION     = 1.5  # seconds for startup loader

# ══════════════════════════════════════════════════════════════════════════════
#  Game State & Pools
# ══════════════════════════════════════════════════════════════════════════════
state = {
    "status": "LOADING",         # "LOADING" | "PLAYING" | "PAUSED" | "GAMEOVER"
    "loader_elapsed": 0.0,
    "score": 0,
    "high_score": 0,
    "lives": 3,
    "player_x": float(WIN_WIDTH // 2 - PLAYER_SIZE // 2),
    "player_vx": 0.0,
    "invulnerable_timer": 0.0,
    "spawn_timer": 0.0,
    "last_time": time.perf_counter(),
    "flash_state": False,
    "key_left": False,
    "key_right": False,
}

# Obstacle pool records
obstacles = []
for i in range(NUM_OBSTACLES):
    obstacles.append({
        "ip": f"obs_{i}",
        "active": False,
        "x": -100.0,
        "y": -100.0,
        "w": 30.0,
        "h": 30.0,
        "speed": BASE_FALL_SPEED,
        "color": "#EF4444",
        "border_color": "#FCA5A5",
    })

# Starfield parallax records
stars = []
for i in range(NUM_STARS):
    stars.append({
        "ip": f"star_{i}",
        "x": float(random.randint(10, WIN_WIDTH - 10)),
        "y": float(random.randint(HEADER_H + 10, WIN_HEIGHT - 10)),
        "speed": float(random.uniform(40.0, 120.0)),
        "size": random.choice([2, 3, 4]),
    })

# Particle sparks pool
sparks = []
for i in range(NUM_SPARKS):
    sparks.append({
        "ip": f"spark_{i}",
        "active": False,
        "x": -100.0,
        "y": -100.0,
        "vx": 0.0,
        "vy": 0.0,
        "life": 0.0,
        "max_life": 0.4,
    })


# ══════════════════════════════════════════════════════════════════════════════
#  Scene Initialization with Draw.room & Draw.loader
# ══════════════════════════════════════════════════════════════════════════════
def init_game_scene():
    # 1. Initialize Main Window
    Draw.window(
        tag=WIN_TAG,
        title="🟦 Square Dodge — Draw Arcade",
        width=WIN_WIDTH,
        height=WIN_HEIGHT,
        resizable=False,
        background_color="#090D16",
    )

    # 2. Starfield Background Shapes (z=500 -> deep background)
    star_shapes = []
    for star in stars:
        star_shapes.append({
            "ip": star["ip"],
            "vertices": 4,
            "size": [star["size"], star["size"]],
            "x": int(star["x"]),
            "y": int(star["y"]),
            "color": "#334155",
            "z": 500,
            "locked": True,
            "overlap": True,
        })
    Draw.shapes(display=WIN_TAG, shape=star_shapes)

    # 3. Particle Sparks (z=30)
    spark_shapes = []
    for spark in sparks:
        spark_shapes.append({
            "ip": spark["ip"],
            "vertices": 4,
            "size": [5, 5],
            "x": -100,
            "y": -100,
            "color": "#FBBF24",
            "z": 30,
            "locked": True,
            "overlap": True,
        })
    Draw.shapes(display=WIN_TAG, shape=spark_shapes)

    # 4. Obstacles Pool (z=20)
    obs_shapes = []
    for obs in obstacles:
        obs_shapes.append({
            "ip": obs["ip"],
            "vertices": 4,
            "size": [int(obs["w"]), int(obs["h"])],
            "x": -100,
            "y": -100,
            "color": obs["color"],
            "border_width": 2,
            "border_color": obs["border_color"],
            "z": 20,
            "locked": True,
            "overlap": True,
        })
    Draw.shapes(display=WIN_TAG, shape=obs_shapes)

    # 5. Player (🟦) and Thruster Glow (z=10)
    Draw.shapes(
        display=WIN_TAG,
        shape=[
            {
                "ip": "player",
                "vertices": 4,
                "size": [PLAYER_SIZE, PLAYER_SIZE],
                "x": int(state["player_x"]),
                "y": PLAYER_Y,
                "color": "#38BDF8",
                "border_width": 3,
                "border_color": "#E0F2FE",
                "z": 10,
                "locked": True,
                "overlap": True,
            },
            {
                "ip": "player_glow",
                "vertices": 4,
                "size": [20, 6],
                "x": int(state["player_x"] + 7),
                "y": PLAYER_Y + PLAYER_SIZE + 1,
                "color": "#0284C7",
                "z": 11,
                "locked": True,
                "overlap": True,
            },
        ]
    )

    # 6. Header Top Bar (z=5 -> Overlay HUD)
    Draw.shapes(
        display=WIN_TAG,
        shape=[
            {
                "ip": "header_bar",
                "vertices": 4,
                "size": [WIN_WIDTH, HEADER_H],
                "x": 0,
                "y": 0,
                "color": "#0F172A",
                "border_width": 0,
                "z": 5,
                "locked": True,
                "overlap": True,
            },
            {
                "ip": "header_divider",
                "vertices": 4,
                "size": [WIN_WIDTH, 2],
                "x": 0,
                "y": HEADER_H - 2,
                "color": "#1E293B",
                "z": 4,
                "locked": True,
                "overlap": True,
            },
        ]
    )

    # 7. HUD Text Elements (z=3)
    Draw.text(
        tag=WIN_TAG,
        text="SCORE: 0",
        ip="hud_score",
        x=20,
        y=16,
        customise={
            "font_size": 17,
            "font_family": "Segoe UI",
            "bold": True,
            "color": "#F8FAFC",
            "z": 3,
        }
    )

    Draw.text(
        tag=WIN_TAG,
        text="BEST: 0",
        ip="hud_best",
        x=190,
        y=18,
        customise={
            "font_size": 13,
            "font_family": "Segoe UI",
            "bold": True,
            "color": "#94A3B8",
            "z": 3,
        }
    )

    Draw.text(
        tag=WIN_TAG,
        text="❤️ ❤️ ❤️",
        ip="hud_lives",
        x=335,
        y=16,
        customise={
            "font_size": 16,
            "font_family": "Segoe UI",
            "bold": True,
            "color": "#EF4444",
            "z": 3,
        }
    )

    # Declarative layout via Draw.room for HUD
    try:
        Draw.room(
            display=WIN_TAG,
            general={"padding": 12, "z": 5, "z_step": 2},
            scene={
                "header_bar": "top",
                "hud_score": ["header_bar", "left", "inside"],
                "hud_best": ["header_bar", "center", "inside"],
                "hud_lives": ["header_bar", "right", "inside"],
                "header_divider": ["header_bar", "bottom", 0],
            }
        )
    except Exception as e:
        print("Draw.room layout info:", e)

    # 8. Start / Game Over Modal Dialog Card (z=2 -> frontmost modal)
    Draw.shapes(
        display=WIN_TAG,
        shape=[
            {
                "ip": "modal_bg",
                "vertices": 4,
                "size": [380, 270],
                "x": 40,
                "y": -999,
                "color": "#0F172A",
                "border_width": 2,
                "border_color": "#38BDF8",
                "z": 2,
                "locked": True,
                "overlap": True,
            }
        ]
    )

    Draw.text(
        tag=WIN_TAG,
        text="🟦 SQUARE DODGE",
        ip="modal_title",
        x=230,
        y=-999,
        customise={
            "font_size": 22,
            "font_family": "Segoe UI",
            "bold": True,
            "align_text": "center",
            "color": "#38BDF8",
            "z": 1,
        }
    )

    Draw.text(
        tag=WIN_TAG,
        text="Avoid the falling blocks (■)\nEach avoided block awards +1 point",
        ip="modal_subtitle",
        x=230,
        y=-999,
        customise={
            "font_size": 13,
            "font_family": "Segoe UI",
            "align_text": "center",
            "color": "#94A3B8",
            "z": 1,
        }
    )

    Draw.text(
        tag=WIN_TAG,
        text="Press SPACE or ENTER to Play",
        ip="modal_action",
        x=230,
        y=-999,
        customise={
            "font_size": 16,
            "font_family": "Segoe UI",
            "bold": True,
            "align_text": "center",
            "color": "#F59E0B",
            "z": 1,
        }
    )

    Draw.text(
        tag=WIN_TAG,
        text="Move:  ←  →  or  A  /  D    |    Pause:  P",
        ip="modal_controls",
        x=230,
        y=-999,
        customise={
            "font_size": 12,
            "font_family": "Segoe UI",
            "align_text": "center",
            "color": "#64748B",
            "z": 1,
        }
    )

    # 9. Startup Loader using Draw.loader & Draw.room
    Draw.loader(
        display=WIN_TAG,
        ip="start_loader",
        shape="circle",
        color="#38BDF8",
        motion="spin",
        size=[48, 48],
        x=int(WIN_WIDTH // 2 - 24),
        y=int(WIN_HEIGHT // 2 - 50),
        z=1,
    )

    # Loader progress bar track and fill
    Draw.shapes(
        display=WIN_TAG,
        shape=[
            {
                "ip": "loader_bar_bg",
                "vertices": 4,
                "size": [180, 8],
                "x": int(WIN_WIDTH // 2 - 90),
                "y": int(WIN_HEIGHT // 2 + 55),
                "color": "#1E293B",
                "border_width": 1,
                "border_color": "#334155",
                "border_radius": 4,
                "z": 1,
                "locked": True,
                "overlap": True,
            },
            {
                "ip": "loader_bar",
                "vertices": 4,
                "size": [10, 8],
                "x": int(WIN_WIDTH // 2 - 90),
                "y": int(WIN_HEIGHT // 2 + 55),
                "color": "#38BDF8",
                "border_radius": 4,
                "z": 1,
                "locked": True,
                "overlap": True,
            },
        ]
    )

    Draw.text(
        tag=WIN_TAG,
        text="INITIALIZING ARENA... 0%",
        ip="loader_title",
        x=int(WIN_WIDTH // 2 - 90),
        y=int(WIN_HEIGHT // 2 + 15),
        customise={
            "font_size": 15,
            "font_family": "Segoe UI",
            "bold": True,
            "align_text": "center",
            "color": "#38BDF8",
            "z": 1,
        }
    )

    Draw.text(
        tag=WIN_TAG,
        text="Move with ← → or A / D (Press any key to start)",
        ip="loader_sub",
        x=int(WIN_WIDTH // 2 - 130),
        y=int(WIN_HEIGHT // 2 + 75),
        customise={
            "font_size": 12,
            "font_family": "Segoe UI",
            "align_text": "center",
            "color": "#94A3B8",
            "z": 1,
        }
    )

    # Use Draw.room to arrange loader elements relative to center
    try:
        Draw.room(
            display=WIN_TAG,
            general={"padding": 12},
            scene={
                "start_loader": "center",
                "loader_title": ["start_loader", "bottom", 16],
                "loader_bar_bg": ["loader_title", "bottom", 14],
                "loader_bar": ["loader_bar_bg", "left", "inside"],
                "loader_sub": ["loader_bar_bg", "bottom", 12],
            }
        )
    except Exception as e:
        print("Draw.room loader layout info:", e)

    # 10. Register Input Senses with Draw
    global sense_left_down, sense_left_up
    global sense_right_down, sense_right_up
    global sense_start, sense_pause

    sense_left_down  = Draw.senses("key_press",   id="sense_left_down",  key=["left", "a"])
    sense_left_up    = Draw.senses("key_release", id="sense_left_up",    key=["left", "a"])
    sense_right_down = Draw.senses("key_press",   id="sense_right_down", key=["right", "d"])
    sense_right_up   = Draw.senses("key_release", id="sense_right_up",   key=["right", "d"])
    sense_start      = Draw.senses("key_press",   id="sense_start",      key=["space", "return", "enter", "r"])
    sense_pause      = Draw.senses("key_press",   id="sense_pause",      key=["p", "escape"])


# ══════════════════════════════════════════════════════════════════════════════
#  Game Logic & State Helpers
# ══════════════════════════════════════════════════════════════════════════════
def finish_loading():
    """Concludes startup loading and transitions immediately into active gameplay."""
    if state["status"] != "LOADING":
        return

    # Hide all loader shapes
    for lid in ("start_loader", "loader_bar", "loader_bar_bg"):
        s = Draw.shapes.get_by_ip(WIN_TAG, lid)
        if s:
            s.x = -999
            s.y = -999
            s.dirty = True

    canvas = Draw.window.get_canvas(WIN_TAG)
    if canvas:
        for t in canvas.text_items:
            if t.ip in ("loader_title", "loader_sub"):
                t.y = -999

    # Start live gameplay immediately!
    state["status"] = "PLAYING"
    state["score"] = 0
    state["lives"] = 3
    state["spawn_timer"] = 0.0
    state["last_time"] = time.perf_counter()
    update_hud_display()
    print("🎮 Loader complete! Arena active — Dodge the blocks!")


def reset_game():
    state["score"] = 0
    state["lives"] = 3
    state["player_x"] = float(WIN_WIDTH // 2 - PLAYER_SIZE // 2)
    state["player_vx"] = 0.0
    state["invulnerable_timer"] = 0.0
    state["spawn_timer"] = 0.0
    state["status"] = "PLAYING"
    state["last_time"] = time.perf_counter()

    # Reset all obstacles to off-screen
    for obs in obstacles:
        obs["active"] = False
        obs["x"] = -100.0
        obs["y"] = -100.0
        s = Draw.shapes.get_by_ip(WIN_TAG, obs["ip"])
        if s:
            s.x = -100
            s.y = -100
            s.dirty = True

    # Hide modal overlay
    set_modal_visible(False)
    update_hud_display()


def trigger_game_over():
    state["status"] = "GAMEOVER"
    if state["score"] > state["high_score"]:
        state["high_score"] = state["score"]

    set_modal_visible(
        True,
        title="💥 GAME OVER",
        subtitle=f"Final Score: {state['score']}\nPersonal Best: {state['high_score']}",
        action="Press SPACE or R to Try Again",
        title_color="#EF4444"
    )
    update_hud_display()


def emit_sparks(cx: float, cy: float):
    for spark in sparks:
        if not spark["active"]:
            spark["active"] = True
            spark["x"] = cx
            spark["y"] = cy
            angle = random.uniform(0, 6.283)
            spd = random.uniform(80.0, 260.0)
            import math
            spark["vx"] = math.cos(angle) * spd
            spark["vy"] = math.sin(angle) * spd
            spark["life"] = 0.0
            spark["max_life"] = random.uniform(0.25, 0.45)


def set_modal_visible(visible: bool, title="", subtitle="", action="", title_color="#38BDF8"):
    canvas = Draw.window.get_canvas(WIN_TAG)
    modal_card = Draw.shapes.get_by_ip(WIN_TAG, "modal_bg")

    card_y = 180 if visible else -999
    if modal_card:
        modal_card.y = card_y
        modal_card.dirty = True

    if canvas:
        for t in canvas.text_items:
            if t.ip == "modal_title":
                t.y = 205 if visible else -999
                if title:
                    t.text = title
            elif t.ip == "modal_subtitle":
                t.y = 245 if visible else -999
                if subtitle:
                    t.text = subtitle
            elif t.ip == "modal_action":
                t.y = 320 if visible else -999
                if action:
                    t.text = action
            elif t.ip == "modal_controls":
                t.y = 395 if visible else -999

    if visible:
        try:
            Draw.room(
                display=WIN_TAG,
                general={"padding": 16},
                scene={
                    "modal_bg": "center",
                    "modal_title": ["modal_bg", "top", "inside"],
                    "modal_subtitle": ["modal_title", "bottom", 12],
                    "modal_action": ["modal_subtitle", "bottom", 20],
                    "modal_controls": ["modal_action", "bottom", 16],
                }
            )
        except Exception:
            pass


def update_hud_display():
    canvas = Draw.window.get_canvas(WIN_TAG)
    if not canvas:
        return

    hearts = "❤️ " * max(0, state["lives"])
    if state["lives"] <= 0:
        hearts = "💀 0"

    for t in canvas.text_items:
        if t.ip == "hud_score":
            t.text = f"SCORE: {state['score']}"
        elif t.ip == "hud_best":
            t.text = f"BEST: {state['high_score']}"
        elif t.ip == "hud_lives":
            t.text = hearts.strip()


def spawn_obstacle():
    # Find an inactive obstacle
    for obs in obstacles:
        if not obs["active"]:
            obs["active"] = True
            variant = random.choice(["normal", "normal", "small", "wide"])
            if variant == "small":
                obs["w"], obs["h"] = 22.0, 22.0
            elif variant == "wide":
                obs["w"], obs["h"] = 44.0, 26.0
            else:
                obs["w"], obs["h"] = 30.0, 30.0

            obs["x"] = float(random.randint(15, int(WIN_WIDTH - obs["w"] - 15)))
            obs["y"] = float(HEADER_H - obs["h"] - 5)

            # Progressive speed scaling
            cur_speed = min(MAX_FALL_SPEED, BASE_FALL_SPEED + (state["score"] * SPEED_INCREMENT))
            obs["speed"] = cur_speed * random.uniform(0.92, 1.15)

            s = Draw.shapes.get_by_ip(WIN_TAG, obs["ip"])
            if s:
                s.x = int(obs["x"])
                s.y = int(obs["y"])
                s.size_raw = [int(obs["w"]), int(obs["h"])]
                s.dirty = True
            break


# ══════════════════════════════════════════════════════════════════════════════
#  60 FPS Main Game Tick Loop
# ══════════════════════════════════════════════════════════════════════════════
def game_tick():
    if WIN_TAG not in Draw.window.list_tags():
        return

    now = time.perf_counter()
    dt = min(0.05, now - state["last_time"])
    state["last_time"] = now

    # 1. Process Input Senses
    left_pressed = sense_left_down.consume()
    if left_pressed:
        state["key_left"] = True
    if sense_left_up.consume():
        state["key_left"] = False

    right_pressed = sense_right_down.consume()
    if right_pressed:
        state["key_right"] = True
    if sense_right_up.consume():
        state["key_right"] = False

    start_pressed = sense_start.consume()

    # If in LOADING state, update progress or allow instant skip
    if state["status"] == "LOADING":
        state["loader_elapsed"] += dt
        progress = min(1.0, state["loader_elapsed"] / LOADER_DURATION)

        # Update loader progress bar and text
        l_bar = Draw.shapes.get_by_ip(WIN_TAG, "loader_bar")
        if l_bar:
            l_bar.size_raw = [max(4, int(180 * progress)), 8]
            l_bar.dirty = True

        canvas = Draw.window.get_canvas(WIN_TAG)
        if canvas:
            for t in canvas.text_items:
                if t.ip == "loader_title":
                    t.text = f"INITIALIZING ARENA... {int(progress * 100)}%"

        # When progress reaches 100% OR any key is pressed -> start gameplay!
        if progress >= 1.0 or start_pressed or left_pressed or right_pressed:
            finish_loading()

        # Update starfield even during loading for dynamic background
        for star in stars:
            star["y"] += star["speed"] * dt
            if star["y"] > WIN_HEIGHT:
                star["y"] = float(HEADER_H + 2)
                star["x"] = float(random.randint(10, WIN_WIDTH - 10))
            s = Draw.shapes.get_by_ip(WIN_TAG, star["ip"])
            if s:
                s.y = int(star["y"])
                s.x = int(star["x"])
                s.dirty = True

        if canvas:
            canvas.update()
        return

    # Handle Restart / Pause
    if start_pressed:
        if state["status"] == "GAMEOVER":
            reset_game()
        elif state["status"] == "PAUSED":
            state["status"] = "PLAYING"
            set_modal_visible(False)

    if sense_pause.consume():
        if state["status"] == "PLAYING":
            state["status"] = "PAUSED"
            set_modal_visible(
                True,
                title="⏸️ PAUSED",
                subtitle=f"Current Score: {state['score']}",
                action="Press SPACE or P to Resume",
                title_color="#38BDF8"
            )
        elif state["status"] == "PAUSED":
            state["status"] = "PLAYING"
            set_modal_visible(False)

    # 2. Update Starfield Parallax
    for star in stars:
        star["y"] += star["speed"] * dt
        if star["y"] > WIN_HEIGHT:
            star["y"] = float(HEADER_H + 2)
            star["x"] = float(random.randint(10, WIN_WIDTH - 10))
        s = Draw.shapes.get_by_ip(WIN_TAG, star["ip"])
        if s:
            s.y = int(star["y"])
            s.x = int(star["x"])
            s.dirty = True

    # 3. Update Sparks
    for spark in sparks:
        if spark["active"]:
            spark["life"] += dt
            if spark["life"] >= spark["max_life"]:
                spark["active"] = False
                spark["x"] = -100.0
                spark["y"] = -100.0
            else:
                spark["x"] += spark["vx"] * dt
                spark["y"] += spark["vy"] * dt

            s = Draw.shapes.get_by_ip(WIN_TAG, spark["ip"])
            if s:
                s.x = int(spark["x"])
                s.y = int(spark["y"])
                s.dirty = True

    # 4. If paused or game over, keep rendering canvas and return
    if state["status"] != "PLAYING":
        canvas = Draw.window.get_canvas(WIN_TAG)
        if canvas:
            canvas.update()
        return

    # 5. Update Player Movement
    move_dir = 0.0
    if state["key_left"]:
        move_dir -= 1.0
    if state["key_right"]:
        move_dir += 1.0

    state["player_x"] += move_dir * PLAYER_SPEED * dt
    # Clamp player inside arena bounds
    min_x = 10.0
    max_x = float(WIN_WIDTH - PLAYER_SIZE - 10)
    state["player_x"] = max(min_x, min(max_x, state["player_x"]))

    # 6. Update Invulnerability Timer & Player Blinking
    if state["invulnerable_timer"] > 0:
        state["invulnerable_timer"] -= dt
        state["flash_state"] = int(state["invulnerable_timer"] * 10) % 2 == 0
    else:
        state["flash_state"] = False

    player_shape = Draw.shapes.get_by_ip(WIN_TAG, "player")
    glow_shape = Draw.shapes.get_by_ip(WIN_TAG, "player_glow")

    if player_shape:
        player_shape.x = int(state["player_x"])
        player_shape.dirty = True

    if glow_shape:
        glow_shape.x = int(state["player_x"] + 7)
        glow_shape.dirty = True

    # 7. Spawn Obstacles
    cur_spawn_interval = max(MIN_SPAWN_INTERVAL, BASE_SPAWN_INTERVAL - (state["score"] * 0.012))
    state["spawn_timer"] += dt
    if state["spawn_timer"] >= cur_spawn_interval:
        state["spawn_timer"] = 0.0
        spawn_obstacle()

    # 8. Update Obstacles, Collision, and Avoidance Scoring
    px = state["player_x"]
    py = float(PLAYER_Y)
    pw = float(PLAYER_SIZE)
    ph = float(PLAYER_SIZE)

    for obs in obstacles:
        if not obs["active"]:
            continue

        obs["y"] += obs["speed"] * dt
        s = Draw.shapes.get_by_ip(WIN_TAG, obs["ip"])
        if s:
            s.y = int(obs["y"])
            s.dirty = True

        ox = obs["x"]
        oy = obs["y"]
        ow = obs["w"]
        oh = obs["h"]

        # AABB Collision Test with Player
        if (state["invulnerable_timer"] <= 0 and
            ox < px + pw and ox + ow > px and
            oy < py + ph and oy + oh > py):
            
            # Hit detected!
            emit_sparks(ox + ow / 2, oy + oh / 2)
            obs["active"] = False
            obs["y"] = -100.0
            if s:
                s.y = -100
                s.dirty = True

            state["lives"] -= 1
            state["invulnerable_timer"] = 1.2
            update_hud_display()

            if state["lives"] <= 0:
                trigger_game_over()
                break

        # Check if obstacle successfully avoided past bottom
        elif oy > WIN_HEIGHT:
            obs["active"] = False
            obs["y"] = -100.0
            if s:
                s.y = -100
                s.dirty = True

            # +1 point for successful avoid
            state["score"] += 1
            update_hud_display()

    # Trigger canvas repaint
    canvas = Draw.window.get_canvas(WIN_TAG)
    if canvas:
        canvas.update()


# ══════════════════════════════════════════════════════════════════════════════
#  Main Entrypoint
# ══════════════════════════════════════════════════════════════════════════════
def main():
    print("🚀 Initializing Square Dodge with Draw...")
    init_game_scene()

    # Register 60 FPS Game Loop
    Draw.every(0.016, game_tick)

    # Launch Application
    print("🎮 Game starting with Draw.loader! Press ← → / A D to move.")
    Draw.window.run(WIN_TAG)


if __name__ == "__main__":
    main()
