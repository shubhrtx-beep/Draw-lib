"""
FPS Jitter Diagnostic & Rendering Loop Instrumentation
======================================================
Instruments 1000 consecutive frames of the real Draw rendering loop with 30 moving shapes.
Measures:
1. motion calculation time
2. geometry generation time
3. spatial-grid update time
4. color processing time
5. CPU batching time
6. NumPy/memory-copy time
7. VBO/GPU upload time
8. QPainter time
9. total CPU render time
10. time between paint events
"""

import sys
import os
import time
import math
import random
import gc
from typing import List, Dict, Any, Tuple
import numpy as np

# Ensure Draw package is on path
_DIR = os.path.dirname(os.path.abspath(__file__))
_PARENT = os.path.dirname(_DIR)
for p in (_DIR, _PARENT):
    if p not in sys.path:
        sys.path.insert(0, p)

import Draw
from PySide6.QtCore import Qt, QTimer, QPointF, QRectF
from PySide6.QtGui import QColor, QPainter, QPen, QMatrix4x4
from PySide6.QtOpenGLWidgets import QOpenGLWidget
from Draw._super import _DrawOpenGLCanvas, GPUGeometryBatcher
from Draw._shapes import (
    ShapeDef, _shape_preferred_geometry, _shape_hit_geometry,
    _apply_motion_geometry, _draw_one_shape, _get_unit_polygon, _parse_color
)
from Draw._text import _draw_one_text, _resolve_text_value, resolve_live_text, LiveTextBinding
from Draw._layout import _draw_one_layout
from Draw._motion import motion as _motion_registry

WIN_TAG = "jitter_diag_win"
WIN_W = 1280
WIN_H = 800

# Color palette
PALETTE = [
    "#FF5722", "#00E676", "#00B0FF", "#E040FB",
    "#FFD600", "#FF1744", "#00E5FF", "#76FF03",
    "#FF9100", "#D500F9", "#00E5FF", "#1DE9B6",
]

# Telemetry state
state = {
    "rect_count": 0,
    "rectangles": [],
    "fps": 60.0,
    "frame_time_ms": 16.0,
    "last_time": time.perf_counter(),
    "fps_accum": 0.0,
    "fps_frames": 0,
    "displayed_fps_history": [],
}

def get_live_fps_text() -> str:
    """The exact FPS function from rect_motion_fps_app.py."""
    now = time.perf_counter()
    dt = now - state["last_time"]
    state["last_time"] = now
    
    if dt > 0.0001:
        instant_fps = 1.0 / dt
        state["fps_accum"] += instant_fps
        state["fps_frames"] += 1
        if state["fps_frames"] >= 15:
            state["fps"] = state["fps_accum"] / state["fps_frames"]
            state["frame_time_ms"] = (dt * 1000.0)
            state["fps_accum"] = 0.0
            state["fps_frames"] = 0
            state["displayed_fps_history"].append((now, state["fps"]))

    fps_val = state["fps"]
    ft_ms = state["frame_time_ms"]
    count = state["rect_count"]
    return f"Live FPS: {fps_val:5.1f} | Frame: {ft_ms:4.1f} ms | Active: {count:,}"


class FrameMetrics:
    def __init__(self):
        self.t_motion: List[float] = []          # 1. motion calculation time (ms)
        self.t_geometry: List[float] = []        # 2. geometry generation time (ms)
        self.t_spatial_grid: List[float] = []    # 3. spatial-grid update time (ms)
        self.t_color: List[float] = []           # 4. color processing time (ms)
        self.t_cpu_batching: List[float] = []    # 5. CPU batching time (ms)
        self.t_numpy_copy: List[float] = []      # 6. NumPy/memory-copy time (ms)
        self.t_vbo_upload: List[float] = []      # 7. VBO/GPU upload time (ms)
        self.t_qpainter: List[float] = []        # 8. QPainter time (ms)
        self.t_total_render: List[float] = []    # 9. total CPU render time (ms)
        self.t_between_paints: List[float] = []  # 10. time between paint events (ms)

        # Counters per frame
        self.shapes_processed: List[int] = []
        self.shapes_regenerated: List[int] = []
        self.gpu_uploads: List[int] = []
        self.bytes_uploaded: List[int] = []
        self.draw_calls: List[int] = []

        # GC tracking
        self.gc_collections_count = 0
        self.gc_events: List[Tuple[float, int, float]] = [] # (time, gen, duration)

        # Extra timer / scheduler tracking
        self.t_tick_animation: List[float] = []
        self.t_between_ticks: List[float] = []
        self.t_live_text_refresh: List[float] = []
        self.paint_timestamps: List[float] = []
        self.tick_timestamps: List[float] = []
        self.displayed_fps_values: List[float] = []


metrics = FrameMetrics()
_last_paint_time = None
_last_tick_time = None

def gc_callback(phase, info):
    if phase == "stop":
        metrics.gc_collections_count += 1
        metrics.gc_events.append((time.perf_counter(), info.get("generation", -1), info.get("collected", 0)))

gc.callbacks.append(gc_callback)


def instrumented_paint_gl(canvas: _DrawOpenGLCanvas):
    """
    Carefully instrumented version of _do_paint_gl measuring each required metric.
    """
    global _last_paint_time

    t_entry = time.perf_counter()
    if _last_paint_time is not None:
        dt_paint_ms = (t_entry - _last_paint_time) * 1000.0
    else:
        dt_paint_ms = 0.0
    _last_paint_time = t_entry
    metrics.paint_timestamps.append(t_entry)

    cw, ch = canvas.width(), canvas.height()
    if cw <= 0 or ch <= 0:
        return

    # Track metrics for this frame
    f_motion = 0.0
    f_geometry = 0.0
    f_spatial = 0.0
    f_color = 0.0
    f_batching = 0.0
    f_numpy_copy = 0.0
    f_vbo_upload = 0.0
    f_qpainter = 0.0
    f_shapes_proc = 0
    f_shapes_regen = 0
    f_gpu_uploads = 0
    f_bytes_uploaded = 0
    f_draw_calls = 0

    now = time.perf_counter()

    canvas._update_scroller_thumbs(from_paint=True)

    if canvas._z_order_dirty:
        t0 = time.perf_counter()
        canvas._sorted_shapes = sorted(canvas.shape_items, key=lambda s: -s.z)
        canvas._z_order_dirty = False
        f_batching += (time.perf_counter() - t0) * 1000.0
    sorted_shapes = canvas._sorted_shapes

    # Reset batcher
    t0 = time.perf_counter()
    canvas.batcher.reset()
    f_batching += (time.perf_counter() - t0) * 1000.0

    unbatched_shapes = []
    batched_shape_set = set()

    if canvas._projection_matrix is None:
        proj = QMatrix4x4()
        proj.ortho(0.0, float(cw), float(ch), 0.0, -1.0, 1.0)
        canvas._projection_matrix = proj

    _window_tag = getattr(canvas, "_window_tag", None)
    _scroll_x = canvas._scroll_x
    _scroll_y = canvas._scroll_y
    _gl_ok = canvas._gl_initialized and not canvas._gpu_failed
    _batcher = canvas.batcher
    _has_active_timelines = bool(_motion_registry._active_timelines)
    _sgrid_items = canvas._spatial_grid_direct.item_boxes
    _sgrid = canvas._spatial_grid_direct
    _EMPTY_MOTION = {}

    for s in sorted_shapes:
        f_shapes_proc += 1
        sid = id(s)
        is_dragged = getattr(s, "_is_dragged", False)
        _shape_motions = getattr(s, "motion", None)
        has_motion = bool(_shape_motions) or (_has_active_timelines and s.ip is not None)
        is_scroller = s.ip and (s.ip.startswith("scroller_") or "_track" in s.ip or "_thumb" in s.ip)

        _gpu = getattr(s, "_gpu_cache", None)
        if (
            _gpu is not None
            and not s.dirty
            and not is_dragged
            and not has_motion
            and not is_scroller
            and _gpu["cw"] == cw
            and _gpu["ch"] == ch
            and _gpu["sx"] == _scroll_x
            and _gpu["sy"] == _scroll_y
        ):
            if _gpu["batched"] and _gl_ok:
                t_b0 = time.perf_counter()
                cached_verts = _gpu["n_verts"]
                if _batcher.v_count + cached_verts <= _batcher.max_vertices:
                    cached_data = _gpu["vdata"]
                    v_off = _batcher.v_count * 6
                    _batcher.vertex_buffer[v_off:v_off + len(cached_data)] = cached_data
                    _batcher.v_count += cached_verts
                    _batcher.i_count = _batcher.v_count
                    batched_shape_set.add(sid)
                    f_batching += (time.perf_counter() - t_b0) * 1000.0
                    continue
            elif not _gpu["batched"]:
                unbatched_shapes.append((s, _gpu["pos"], _EMPTY_MOTION))
                continue

        # Dynamic / dirty path
        f_shapes_regen += 1

        t_g0 = time.perf_counter()
        try:
            (
                origin_x, origin_y, area_w, area_h,
                sw, sh, preferred_x, preferred_y
            ) = _shape_preferred_geometry(s, cw, ch, window_tag=_window_tag)
        except Exception:
            continue
        f_geometry += (time.perf_counter() - t_g0) * 1000.0

        final_x = getattr(s, "_placed_x", preferred_x)
        final_y = getattr(s, "_placed_y", preferred_y)
        sw = getattr(s, "_placed_w", sw)
        sh = getattr(s, "_placed_h", sh)

        if not is_scroller:
            final_x -= _scroll_x
            final_y -= _scroll_y

        if is_dragged and not is_scroller:
            final_x = getattr(s, "_drag_x", final_x)
            final_y = getattr(s, "_drag_y", final_y)
            anim_x, anim_y = float(final_x), float(final_y)
            anim_sw, anim_sh = float(sw), float(sh)
            shape_motion_state = _EMPTY_MOTION
        else:
            if has_motion:
                t_m0 = time.perf_counter()
                shape_motion_state = _motion_registry.compute_shape_state(
                    s, now, _parse_color, float(final_x), float(final_y), sw, sh, canvas
                )
                s._last_motion_state = shape_motion_state
                anim_x, anim_y, anim_sw, anim_sh = _apply_motion_geometry(
                    shape_motion_state, float(final_x), float(final_y), sw, sh
                )
                f_motion += (time.perf_counter() - t_m0) * 1000.0
            else:
                shape_motion_state = _EMPTY_MOTION
                s._last_motion_state = _EMPTY_MOTION
                anim_x = float(final_x)
                anim_y = float(final_y)
                anim_sw = float(sw)
                anim_sh = float(sh)

        s.last_position = (float(anim_x), float(anim_y))
        s.last_size = (int(anim_sw), int(anim_sh))

        t_g1 = time.perf_counter()
        hx, hy, hsw, hsh = _shape_hit_geometry(s)
        s.last_hit_position = (float(hx), float(hy))
        s.last_hit_size = (int(hsw), int(hsh))
        f_geometry += (time.perf_counter() - t_g1) * 1000.0

        # Spatial grid
        t_s0 = time.perf_counter()
        new_bbox = (float(anim_x), float(anim_y), float(anim_sw), float(anim_sh))
        old_bbox = _sgrid_items.get(sid)
        if old_bbox != new_bbox:
            _sgrid._update_internal(sid, new_bbox)
        f_spatial += (time.perf_counter() - t_s0) * 1000.0

        is_simple_polygon = (
            s.curve_mode == "line" and
            not s.bend and
            not s.exclude and
            not s.symmetry and
            not s.warp and
            s.shape_type == "vector" and
            s.border_width == 0 and
            getattr(s, "gradient", None) is None and
            getattr(s, "custom_vertices", None) is None
        )

        batched = False
        vdata_slice = None
        n_verts = 0

        if is_simple_polygon and _gl_ok:
            t_g2 = time.perf_counter()
            n = s.vertices if s.vertices and s.vertices >= 3 else 4
            rot = shape_motion_state.get("rotation", getattr(s, "rotation", 0.0) or 0.0)
            cx = anim_x + anim_sw / 2.0
            cy = anim_y + anim_sh / 2.0
            rx = anim_sw / 2.0
            ry = anim_sh / 2.0
            unit_pts = _get_unit_polygon(n)
            f_geometry += (time.perf_counter() - t_g2) * 1000.0

            # Color processing
            t_c0 = time.perf_counter()
            raw_c = getattr(s, "color", None)
            _color_cache = getattr(s, "_cached_rgba", None)
            _color_key = getattr(s, "_cached_rgba_key", None)
            color_key = (id(raw_c) if isinstance(raw_c, QColor) else raw_c, s.opacity)
            if _color_cache is not None and _color_key == color_key:
                color_rgba = _color_cache
            else:
                from Draw._super import _parse_color_to_rgba
                color_rgba = _parse_color_to_rgba(raw_c, s.opacity)
                s._cached_rgba = color_rgba
                s._cached_rgba_key = color_key
            f_color += (time.perf_counter() - t_c0) * 1000.0

            # CPU Batching
            t_b1 = time.perf_counter()
            v_start = _batcher.v_count
            batched = _batcher.add_transformed_polygon(cx, cy, rx, ry, unit_pts, rot, color_rgba)
            if batched:
                batched_shape_set.add(sid)
                v_end = _batcher.v_count
                n_verts = v_end - v_start
                t_nc0 = time.perf_counter()
                vdata_slice = _batcher.vertex_buffer[v_start * 6:v_end * 6].copy()
                f_numpy_copy += (time.perf_counter() - t_nc0) * 1000.0
            f_batching += (time.perf_counter() - t_b1) * 1000.0

        if not batched:
            unbatched_shapes.append((s, (final_x, final_y), shape_motion_state))

        s._gpu_cache = {
            "cw": cw,
            "ch": ch,
            "sx": _scroll_x,
            "sy": _scroll_y,
            "batched": batched,
            "vdata": vdata_slice,
            "n_verts": n_verts,
            "pos": (final_x, final_y),
        }
        s.dirty = False

    # ── 2. Layered Z-Ordered Rendering ──
    t_qp0 = time.perf_counter()
    painter = QPainter(canvas)
    try:
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setRenderHint(QPainter.RenderHint.TextAntialiasing)

        win_obj = canvas.parent() if canvas.parent() else None
        bg_col = getattr(win_obj, "_bg_color", None) if win_obj else None
        if bg_col is None:
            bg_col = QColor(8, 12, 20)
        painter.fillRect(canvas.rect(), bg_col)

        for layout in canvas.layout_items:
            _draw_one_layout(painter, layout, cw, ch)

        bg_unbatched = [(s, pos, ms) for s, pos, ms in unbatched_shapes if s.z >= 80]
        fg_unbatched = [(s, pos, ms) for s, pos, ms in unbatched_shapes if s.z < 80]

        for s, pos_override, m_state in bg_unbatched:
            _draw_one_shape(
                painter, s, cw, ch,
                position_override=pos_override,
                motion_state=m_state,
                canvas=canvas,
            )
            f_draw_calls += 1

        # GPU Dynamic Batch Draw
        if canvas._gl_initialized and not canvas._gpu_failed and canvas.batcher.v_count > 0:
            try:
                painter.beginNativePainting()
                funcs = canvas.context().functions() if canvas.context() else None
                if funcs and canvas.shader_program and canvas.vbo:
                    t_nc1 = time.perf_counter()
                    v_used_floats = canvas.batcher.v_count * 6
                    v_bytes = canvas.batcher.vertex_buffer[:v_used_floats].tobytes()
                    f_numpy_copy += (time.perf_counter() - t_nc1) * 1000.0
                    f_bytes_uploaded = len(v_bytes)

                    t_v0 = time.perf_counter()
                    canvas.vbo.bind()
                    canvas.vbo.write(0, v_bytes, len(v_bytes))
                    f_gpu_uploads += 1
                    f_vbo_upload += (time.perf_counter() - t_v0) * 1000.0

                    canvas.shader_program.bind()
                    canvas.shader_program.setUniformValue("uProjection", canvas._projection_matrix)

                    if canvas.vao and canvas.vao.isCreated():
                        canvas.vao.bind()
                    else:
                        canvas.vbo.bind()
                        stride = 6 * 4
                        canvas.shader_program.enableAttributeArray(0)
                        canvas.shader_program.setAttributeBuffer(0, 0x1406, 0, 2, stride)
                        canvas.shader_program.enableAttributeArray(1)
                        canvas.shader_program.setAttributeBuffer(1, 0x1406, 2 * 4, 4, stride)

                    funcs.glDrawArrays(0x0004, 0, canvas.batcher.v_count)
                    f_draw_calls += 1

                    if canvas.vao and canvas.vao.isCreated():
                        canvas.vao.release()
                    canvas.vbo.release()
                    canvas.shader_program.release()
            except Exception as exc:
                canvas._gpu_failed = True
            finally:
                painter.endNativePainting()

        for s, pos_override, m_state in fg_unbatched:
            _draw_one_shape(
                painter, s, cw, ch,
                position_override=pos_override,
                motion_state=m_state,
                canvas=canvas,
            )
            f_draw_calls += 1

        for t in canvas.text_items:
            if getattr(t, "motion", None):
                t_m1 = time.perf_counter()
                ref_x, ref_y, ref_w, ref_h = t.last_rect if t.last_rect else (
                    float(t.x or 0), float(t.y or 0), 0.0, 0.0
                )
                t._last_motion_state = _motion_registry.compute_shape_state(
                    t, now, _parse_color, ref_x, ref_y, ref_w, ref_h, canvas
                )
                f_motion += (time.perf_counter() - t_m1) * 1000.0
            else:
                t._last_motion_state = None
            _draw_one_text(painter, t, cw, ch, canvas=canvas)
            f_draw_calls += 1

        if canvas._focused_ip:
            _focus_rect = canvas._focus_rect_for_ip(canvas._focused_ip)
            if _focus_rect is not None:
                _fx, _fy, _fw, _fh = _focus_rect
                painter.save()
                _focus_pen = QPen(QColor(66, 133, 244))
                _focus_pen.setWidth(2)
                _focus_pen.setStyle(Qt.PenStyle.DashLine)
                painter.setPen(_focus_pen)
                painter.setBrush(Qt.BrushStyle.NoBrush)
                painter.drawRoundedRect(QRectF(_fx - 3, _fy - 3, _fw + 6, _fh + 6), 4, 4)
                painter.restore()
    finally:
        if painter.isActive():
            painter.end()
        # QPainter time is total QPainter pass time minus the GPU upload and native painting VBO time
        f_qpainter = ((time.perf_counter() - t_qp0) * 1000.0) - f_vbo_upload

    t_exit = time.perf_counter()
    f_total_render = (t_exit - t_entry) * 1000.0

    # Record metrics
    metrics.t_motion.append(f_motion)
    metrics.t_geometry.append(f_geometry)
    metrics.t_spatial_grid.append(f_spatial)
    metrics.t_color.append(f_color)
    metrics.t_cpu_batching.append(f_batching)
    metrics.t_numpy_copy.append(f_numpy_copy)
    metrics.t_vbo_upload.append(f_vbo_upload)
    metrics.t_qpainter.append(f_qpainter)
    metrics.t_total_render.append(f_total_render)
    metrics.t_between_paints.append(dt_paint_ms)

    metrics.shapes_processed.append(f_shapes_proc)
    metrics.shapes_regenerated.append(f_shapes_regen)
    metrics.gpu_uploads.append(f_gpu_uploads)
    metrics.bytes_uploaded.append(f_bytes_uploaded)
    metrics.draw_calls.append(f_draw_calls)


def build_test_ui():
    """Builds the exact UI with 30 moving shapes."""
    Draw.window(
        tag=WIN_TAG,
        title="FPS Jitter Diagnostic",
        width=WIN_W,
        height=WIN_H,
        background_color="#0D1117",
    )

    # Top header
    Draw.shape(
        display=WIN_TAG,
        shape=[
            {
                "vertices": 4,
                "size": [WIN_W - 40, 120],
                "color": "#161B22",
                "border_color": "#30363D",
                "border_width": 1,
                "border_radius": 12,
                "x": 20,
                "y": 15,
                "ip": "header_card",
            }
        ]
    )

    Draw.text(
        tag=WIN_TAG,
        text="⚡ Draw-lib Kinetic Rectangle Engine",
        customise={
            "x": 40,
            "y": 28,
            "font_size": 20,
            "bold": True,
            "color": "#58A6FF",
        }
    )

    Draw.text(
        tag=WIN_TAG,
        text=get_live_fps_text,
        customise={
            "x": 40,
            "y": 58,
            "font_size": 13,
            "bold": True,
            "color": "#39D353",
        }
    )

    # Spawn 30 rectangles with kinetic movement & continuous rotation
    new_shapes = []
    for i in range(30):
        ip = f"rect_{i}"
        w = random.randint(28, 55)
        h = random.randint(28, 55)
        x = random.randint(30, WIN_W - 80)
        y = random.randint(160, WIN_H - 80)
        color = random.choice(PALETTE)
        rot = float(random.randint(0, 360))

        new_shapes.append({
            "vertices": 4,
            "size": [w, h],
            "color": color,
            "x": x,
            "y": y,
            "rotation": rot,
            "ip": ip,
            "opacity": 90,
        })
        state["rectangles"].append(ip)

    state["rect_count"] = 30
    Draw.shape(display=WIN_TAG, shape=new_shapes)

    for s in new_shapes:
        ip = s["ip"]
        x0, y0 = s["x"], s["y"]
        dx = random.randint(30, WIN_W - 80)
        dy = random.randint(160, WIN_H - 80)
        move_dur = random.uniform(2.5, 7.0)
        rot_dur = random.uniform(1.5, 5.0)

        Draw.motion(
            ip=ip,
            motion=[
                {
                    "type": "move",
                    "from": [x0, y0],
                    "to": [dx, dy],
                    "time": {"start": 0.0, "end": move_dur},
                    "repeat": True,
                    "pingpong": True,
                    "ease": "ease_in_out",
                },
                {
                    "type": "rotate",
                    "from": 0.0,
                    "to": 360.0 if random.random() > 0.5 else -360.0,
                    "time": {"start": 0.0, "end": rot_dur},
                    "repeat": True,
                },
            ]
        )

    # Enable Draw.super
    canvas = Draw.super(
        display=WIN_TAG,
        precompile=True,
        mode="max",
        vsync=False,
        batch_capacity=131072,
    )
    return canvas


def run_benchmark():
    random.seed(42)
    canvas = build_test_ui()
    
    # Hook our instrumented paint_gl
    orig_do_paint_gl = canvas._do_paint_gl
    canvas._do_paint_gl = lambda: instrumented_paint_gl(canvas)

    # Also instrument _tick_animation
    orig_tick_anim = canvas._tick_animation
    def instrumented_tick():
        global _last_tick_time
        t0 = time.perf_counter()
        if _last_tick_time is not None:
            metrics.t_between_ticks.append((t0 - _last_tick_time) * 1000.0)
        _last_tick_time = t0
        metrics.tick_timestamps.append(t0)

        t_lr0 = time.perf_counter()
        # Track live text refresh time
        if canvas._has_live_text_source():
            canvas._refresh_live_text_bindings()
        metrics.t_live_text_refresh.append((time.perf_counter() - t_lr0) * 1000.0)

        orig_tick_anim()
        metrics.t_tick_animation.append((time.perf_counter() - t0) * 1000.0)

    canvas._tick_animation = instrumented_tick
    canvas._animation_timer.timeout.disconnect()
    canvas._animation_timer.timeout.connect(instrumented_tick)

    win = canvas.parent()
    win.show()

    from PySide6.QtWidgets import QApplication
    app = QApplication.instance()

    print("Warming up for 100 frames...")
    # Warmup
    while len(metrics.t_total_render) < 100:
        app.processEvents()
        time.sleep(0.001)

    # Reset metrics for clean 1000 frames
    print("Collecting 1000 consecutive frames...")
    for attr in [
        't_motion', 't_geometry', 't_spatial_grid', 't_color', 't_cpu_batching',
        't_numpy_copy', 't_vbo_upload', 't_qpainter', 't_total_render', 't_between_paints',
        'shapes_processed', 'shapes_regenerated', 'gpu_uploads', 'bytes_uploaded',
        'draw_calls', 't_tick_animation', 't_between_ticks', 't_live_text_refresh',
        'paint_timestamps', 'tick_timestamps'
    ]:
        getattr(metrics, attr).clear()
    metrics.gc_collections_count = 0
    metrics.gc_events.clear()

    # Collect 1000 frames
    TARGET_FRAMES = 1000
    start_bench_time = time.perf_counter()
    while len(metrics.t_total_render) < TARGET_FRAMES:
        app.processEvents()
        time.sleep(0.0005)

    end_bench_time = time.perf_counter()
    total_bench_duration = end_bench_time - start_bench_time

    win.close()
    return total_bench_duration


def stats(data: List[float]) -> Dict[str, float]:
    arr = np.array(data)
    if len(arr) == 0:
        return {"mean": 0.0, "median": 0.0, "p95": 0.0, "p99": 0.0, "max": 0.0}
    return {
        "mean": float(np.mean(arr)),
        "median": float(np.median(arr)),
        "p95": float(np.percentile(arr, 95)),
        "p99": float(np.percentile(arr, 99)),
        "max": float(np.max(arr)),
    }


def print_report(bench_duration: float):
    print("\n" + "="*80)
    print("           REAL RENDERING LOOP INSTRUMENTATION REPORT (1000 FRAMES)           ")
    print("="*80)
    print(f"Total benchmark wall-clock time: {bench_duration:.3f} s")
    print(f"Total frames captured: {len(metrics.t_total_render)}")
    print(f"Total paint events: {len(metrics.paint_timestamps)}")
    print(f"Total timer tick events: {len(metrics.tick_timestamps)}")

    print("\n" + "-"*80)
    print("FRAME-TIME BREAKDOWN (All times in milliseconds / ms):")
    print(f"{'Metric':<32} | {'Mean':>8} | {'Median':>8} | {'P95':>8} | {'P99':>8} | {'Max':>8}")
    print("-"*80)

    rows = [
        ("1. Motion calculation time", stats(metrics.t_motion)),
        ("2. Geometry generation time", stats(metrics.t_geometry)),
        ("3. Spatial-grid update time", stats(metrics.t_spatial_grid)),
        ("4. Color processing time", stats(metrics.t_color)),
        ("5. CPU batching time", stats(metrics.t_cpu_batching)),
        ("6. NumPy/memory-copy time", stats(metrics.t_numpy_copy)),
        ("7. VBO/GPU upload time", stats(metrics.t_vbo_upload)),
        ("8. QPainter time", stats(metrics.t_qpainter)),
        ("9. Total CPU render time", stats(metrics.t_total_render)),
        ("10. Time between paint events", stats(metrics.t_between_paints[1:])), # omit 1st transition
    ]

    for name, s in rows:
        print(f"{name:<32} | {s['mean']:8.4f} | {s['median']:8.4f} | {s['p95']:8.4f} | {s['p99']:8.4f} | {s['max']:8.4f}")

    print("\n" + "-"*80)
    print("EXTRA TIMING METRICS (Timer & Live Text):")
    print(f"{'Metric':<32} | {'Mean':>8} | {'Median':>8} | {'P95':>8} | {'P99':>8} | {'Max':>8}")
    print("-"*80)
    extra_rows = [
        ("Timer tick callback time", stats(metrics.t_tick_animation)),
        ("Time between timer ticks", stats(metrics.t_between_ticks[1:])),
        ("Live text refresh time", stats(metrics.t_live_text_refresh)),
    ]
    for name, s in extra_rows:
        print(f"{name:<32} | {s['mean']:8.4f} | {s['median']:8.4f} | {s['p95']:8.4f} | {s['p99']:8.4f} | {s['max']:8.4f}")

    print("\n" + "-"*80)
    print("FRAME WORKLOAD & RESOURCE COUNTERS:")
    print(f"• Garbage collections count (during 1000 frames) : {metrics.gc_collections_count}")
    print(f"• Number of shapes processed per frame           : Mean={np.mean(metrics.shapes_processed):.1f}, Max={max(metrics.shapes_processed)}")
    print(f"• Number of shapes geometry regenerated / frame  : Mean={np.mean(metrics.shapes_regenerated):.1f}, Max={max(metrics.shapes_regenerated)}")
    print(f"• Number of GPU buffer uploads per frame         : Mean={np.mean(metrics.gpu_uploads):.1f}, Max={max(metrics.gpu_uploads)}")
    print(f"• Bytes uploaded per frame                       : Mean={np.mean(metrics.bytes_uploaded):.1f} bytes, Max={max(metrics.bytes_uploaded)} bytes")
    print(f"• Number of draw calls per frame                 : Mean={np.mean(metrics.draw_calls):.1f}, Max={max(metrics.draw_calls)}")

    # Analysis of FPS calculations
    print("\n" + "-"*80)
    print("FPS ANALYSIS & JITTER SOURCE INVESTIGATION:")
    
    # 1. Theoretical FPS from CPU render time (1000 / render_time)
    render_fps = [1000.0 / max(t, 0.0001) for t in metrics.t_total_render]
    r_stats = stats(render_fps)
    print(f"• Pure CPU Render Throughput FPS (1000 / t_render)  : Mean={r_stats['mean']:.1f}, Median={r_stats['median']:.1f}, Min={min(render_fps):.1f}, Max={r_stats['max']:.1f}")

    # 2. Wall-clock interval FPS (1000 / dt_paint)
    dt_paint_filtered = [dt for dt in metrics.t_between_paints[1:] if dt > 0.001]
    interval_fps = [1000.0 / dt for dt in dt_paint_filtered]
    i_stats = stats(interval_fps)
    print(f"• Wall-Clock Event Interval FPS (1000 / dt_paint)   : Mean={i_stats['mean']:.1f}, Median={i_stats['median']:.1f}, Min={min(interval_fps):.1f}, Max={i_stats['max']:.1f}")

    # 3. Timer interval FPS (1000 / dt_tick)
    dt_tick_filtered = [dt for dt in metrics.t_between_ticks[1:] if dt > 0.001]
    tick_fps = [1000.0 / dt for dt in dt_tick_filtered]
    t_stats = stats(tick_fps)
    print(f"• Timer Tick Interval FPS (1000 / dt_tick)          : Mean={t_stats['mean']:.1f}, Median={t_stats['median']:.1f}, Min={min(tick_fps):.1f}, Max={t_stats['max']:.1f}")

    # 4. Displayed FPS in state["fps"]
    if state["displayed_fps_history"]:
        disp_vals = [f[1] for f in state["displayed_fps_history"]]
        d_stats = stats(disp_vals)
        print(f"• UI-Displayed FPS History                          : Mean={d_stats['mean']:.1f}, Median={d_stats['median']:.1f}, Min={min(disp_vals):.1f}, Max={d_stats['max']:.1f}")

    print("="*80 + "\n")


if __name__ == "__main__":
    duration = run_benchmark()
    print_report(duration)
