"""
letter_blast_game.py
====================
A fast-paced Neon Letter Shatter arcade game built entirely with the Draw library.

Core Features:
1. Early smooth startup loader with real-time percentage progress bar (Draw.loader + Draw.room).
2. Hardware-accelerated rendering path via Draw.super (OpenGL dynamic geometry batching).
3. Joined Shape + Text tokens: Flying letter blocks composed of neon polygon badges and centered bold typography.
4. Procedural flight & wave motion kinematics (Draw.motion + sine oscillation).
5. Multi-channel keyboard sensing (Draw.senses + Draw.connectors) for A-Z, Space, Enter, R, and Pause.
6. Letter Shatter & Explosive FX: Letter blocks break into flying polygon shards and expanding shockwaves.
7. Top HUD Bar (Draw.room layout): Real-time Overload/Danger Meter (0% - 100%), Score, Streak, Best Score, and Lives.
8. Healing / Live Point rewards on successful shatter (reduces Overload Danger meter).
9. Overload 100% Game Over condition with full Restart mechanics.
"""

from __future__ import annotations

import os
import sys
import math
import random
import string
import time
from typing import Dict, List, Optional, Any

# Ensure Draw package parent is in sys.path
WORKSPACE_ROOT = os.path.dirname(os.path.abspath(__file__))
PARENT_ROOT = os.path.dirname(WORKSPACE_ROOT)
if PARENT_ROOT not in sys.path:
    sys.path.insert(0, PARENT_ROOT)
if WORKSPACE_ROOT not in sys.path:
    sys.path.insert(0, WORKSPACE_ROOT)

import Draw
from Draw._window import _parse_color

# ══════════════════════════════════════════════════════════════════════════════
#  Game Configuration & Theme Constants
# ══════════════════════════════════════════════════════════════════════════════
WIN_TAG        = "main"
WIN_WIDTH      = 520
WIN_HEIGHT     = 740
HEADER_H       = 68

MAX_LIVES      = 5
NUM_LETTERS    = 16
NUM_SHARDS     = 48
NUM_STARS      = 28
NUM_POPUPS     = 6

LETTER_SIZE    = 48
BASE_SPEED     = 140.0   # px/s
MAX_SPEED      = 420.0
SPEED_STEP     = 4.0

SPAWN_INTERVAL_BASE = 1.10
SPAWN_INTERVAL_MIN  = 0.35

LOADER_DURATION     = 1.5  # Startup loader duration in seconds

# Neon Palette for Letter Blocks
PALETTE = [
    {"bg": "#06B6D4", "border": "#67E8F9", "glow": "#0891B2"},  # Cyan
    {"bg": "#8B5CF6", "border": "#C4B5FD", "glow": "#7C3AED"},  # Purple
    {"bg": "#EC4899", "border": "#F472B6", "glow": "#DB2777"},  # Pink
    {"bg": "#10B981", "border": "#6EE7B7", "glow": "#059669"},  # Emerald
    {"bg": "#F59E0B", "border": "#FCD34D", "glow": "#D97706"},  # Amber
    {"bg": "#3B82F6", "border": "#93C5FD", "glow": "#2563EB"},  # Blue
]

# ══════════════════════════════════════════════════════════════════════════════
#  Game State & Entity Pools
# ══════════════════════════════════════════════════════════════════════════════
state: Dict[str, Any] = {
    "status": "LOADING",        # "LOADING" | "PLAYING" | "PAUSED" | "GAMEOVER"
    "loader_elapsed": 0.0,
    "score": 0,
    "high_score": 0,
    "streak": 0,
    "max_streak": 0,
    "letters_smashed": 0,
    "danger": 0.0,              # 0.0 to 100.0 percent
    "lives": MAX_LIVES,
    "spawn_timer": 0.0,
    "last_time": time.perf_counter(),
    "border_flash": 0.0,
    "heal_flash": 0.0,
}

# Flying letter block pool
letter_pool: List[Dict[str, Any]] = []
for i in range(NUM_LETTERS):
    letter_pool.append({
        "id": i,
        "box_ip": f"let_box_{i}",
        "glow_ip": f"let_glow_{i}",
        "txt_ip": f"let_txt_{i}",
        "active": False,
        "char": "A",
        "x": -200.0,
        "y": -200.0,
        "base_x": 0.0,
        "speed": BASE_SPEED,
        "wave_phase": 0.0,
        "wave_freq": 1.5,
        "wave_amp": 25.0,
        "color_idx": 0,
        "scale": 1.0,
    })

# Shard particles for letter shatter physics
shards: List[Dict[str, Any]] = []
for i in range(NUM_SHARDS):
    shards.append({
        "ip": f"shard_{i}",
        "active": False,
        "x": -200.0,
        "y": -200.0,
        "vx": 0.0,
        "vy": 0.0,
        "life": 0.0,
        "max_life": 0.5,
        "size": 6,
        "color": "#38BDF8",
    })

# Floating text popups (+100, +HEAL, STREAK)
popups: List[Dict[str, Any]] = []
for i in range(NUM_POPUPS):
    popups.append({
        "ip": f"popup_{i}",
        "active": False,
        "text": "+100",
        "x": -200.0,
        "y": -200.0,
        "vy": -60.0,
        "life": 0.0,
        "max_life": 0.7,
        "color": "#38BDF8",
    })

# Starfield background particles
stars: List[Dict[str, Any]] = []
for i in range(NUM_STARS):
    stars.append({
        "ip": f"star_{i}",
        "x": float(random.randint(10, WIN_WIDTH - 10)),
        "y": float(random.randint(HEADER_H + 10, WIN_HEIGHT - 10)),
        "speed": float(random.uniform(30.0, 110.0)),
        "size": random.choice([2, 3, 4]),
    })


# ══════════════════════════════════════════════════════════════════════════════
#  Scene Initialization with Draw
# ══════════════════════════════════════════════════════════════════════════════
def init_game_scene():
    """Build the complete visual scene using Draw API."""
    # 1. Main Window
    Draw.window(
        tag=WIN_TAG,
        title="⚡ NEON LETTER SHATTER — Draw Arcade",
        width=WIN_WIDTH,
        height=WIN_HEIGHT,
        resizable=False,
        background_color="#070A12",
    )

    # 2. Starfield Deep Background (z=500)
    star_shapes = []
    for star in stars:
        star_shapes.append({
            "ip": star["ip"],
            "vertices": 4,
            "size": [star["size"], star["size"]],
            "x": int(star["x"]),
            "y": int(star["y"]),
            "color": "#1E293B",
            "z": 500,
            "locked": True,
            "overlap": True,
        })
    Draw.shapes(display=WIN_TAG, shape=star_shapes)

    # 3. Shard Particles (z=30)
    shard_shapes = []
    for shard in shards:
        shard_shapes.append({
            "ip": shard["ip"],
            "vertices": random.choice([3, 4]),
            "size": [shard["size"], shard["size"]],
            "x": -200,
            "y": -200,
            "color": shard["color"],
            "z": 30,
            "locked": True,
            "overlap": True,
        })
    Draw.shapes(display=WIN_TAG, shape=shard_shapes)

    # 4. Flying Letter Shapes & Text (Joined together)
    # Shape Badges (z=20)
    letter_shapes = []
    for let in letter_pool:
        # Glow border ring
        letter_shapes.append({
            "ip": let["glow_ip"],
            "vertices": 4,
            "border_radius": 10,
            "size": [LETTER_SIZE + 6, LETTER_SIZE + 6],
            "x": -200,
            "y": -200,
            "color": "transparent",
            "border_width": 2,
            "border_color": PALETTE[0]["border"],
            "z": 21,
            "locked": True,
            "overlap": True,
        })
        # Main Badge Box
        letter_shapes.append({
            "ip": let["box_ip"],
            "vertices": 4,
            "border_radius": 8,
            "size": [LETTER_SIZE, LETTER_SIZE],
            "x": -200,
            "y": -200,
            "color": PALETTE[0]["bg"],
            "border_width": 1,
            "border_color": PALETTE[0]["border"],
            "z": 20,
            "locked": True,
            "overlap": True,
        })
    Draw.shapes(display=WIN_TAG, shape=letter_shapes)

    # Letter Text in center of badge (z=15)
    for let in letter_pool:
        Draw.text(
            tag=WIN_TAG,
            text=let["char"],
            ip=let["txt_ip"],
            x=-200,
            y=-200,
            customise={
                "font_size": 20,
                "font_family": "Segoe UI",
                "bold": True,
                "align_text": "center",
                "color": "#FFFFFF",
                "z": 15,
            }
        )

    # Connect Letter Shapes with their Text via Draw.connectors sync link
    for let in letter_pool:
        try:
            Draw.connectors(
                from_ip=let["box_ip"],
                to_ip=let["glow_ip"],
                link="sync",
                properties=["position"],
                offset_x=-3,
                offset_y=-3,
            )
        except Exception:
            pass

    # 5. Floating Text Popups (z=12)
    for pop in popups:
        Draw.text(
            tag=WIN_TAG,
            text=pop["text"],
            ip=pop["ip"],
            x=-200,
            y=-200,
            customise={
                "font_size": 14,
                "font_family": "Segoe UI",
                "bold": True,
                "align_text": "center",
                "color": pop["color"],
                "z": 12,
            }
        )

    # 6. Top Header HUD Bar (z=6)
    Draw.shapes(
        display=WIN_TAG,
        shape=[
            {
                "ip": "hud_header_bg",
                "vertices": 4,
                "size": [WIN_WIDTH, HEADER_H],
                "x": 0,
                "y": 0,
                "color": "#0B1120",
                "border_width": 0,
                "z": 6,
                "locked": True,
                "overlap": True,
            },
            {
                "ip": "hud_divider",
                "vertices": 4,
                "size": [WIN_WIDTH, 2],
                "x": 0,
                "y": HEADER_H - 2,
                "color": "#1E293B",
                "z": 5,
                "locked": True,
                "overlap": True,
            },
            # Danger Bar Track (z=4)
            {
                "ip": "danger_track",
                "vertices": 4,
                "border_radius": 5,
                "size": [180, 10],
                "x": int(WIN_WIDTH // 2 - 90),
                "y": 42,
                "color": "#1E293B",
                "border_width": 1,
                "border_color": "#334155",
                "z": 4,
                "locked": True,
                "overlap": True,
            },
            # Danger Bar Fill (z=3)
            {
                "ip": "danger_fill",
                "vertices": 4,
                "border_radius": 5,
                "size": [6, 10],
                "x": int(WIN_WIDTH // 2 - 90),
                "y": 42,
                "color": "#10B981",
                "z": 3,
                "locked": True,
                "overlap": True,
            },
        ]
    )

    # 7. HUD Text Elements (z=3)
    Draw.text(
        tag=WIN_TAG,
        text="SCORE: 0",
        ip="hud_score",
        x=16,
        y=14,
        customise={
            "font_size": 15,
            "font_family": "Segoe UI",
            "bold": True,
            "color": "#38BDF8",
            "z": 3,
        }
    )

    Draw.text(
        tag=WIN_TAG,
        text="BEST: 0",
        ip="hud_best",
        x=16,
        y=38,
        customise={
            "font_size": 11,
            "font_family": "Segoe UI",
            "bold": True,
            "color": "#94A3B8",
            "z": 3,
        }
    )

    Draw.text(
        tag=WIN_TAG,
        text="OVERLOAD: 0%",
        ip="hud_danger_title",
        x=int(WIN_WIDTH // 2 - 60),
        y=14,
        customise={
            "font_size": 12,
            "font_family": "Segoe UI",
            "bold": True,
            "align_text": "center",
            "color": "#10B981",
            "z": 3,
        }
    )

    Draw.text(
        tag=WIN_TAG,
        text="STREAK x0",
        ip="hud_streak",
        x=WIN_WIDTH - 120,
        y=14,
        customise={
            "font_size": 13,
            "font_family": "Segoe UI",
            "bold": True,
            "align_text": "right",
            "color": "#F59E0B",
            "z": 3,
        }
    )

    Draw.text(
        tag=WIN_TAG,
        text="💚 💚 💚 💚 💚",
        ip="hud_lives",
        x=WIN_WIDTH - 120,
        y=38,
        customise={
            "font_size": 12,
            "font_family": "Segoe UI",
            "align_text": "right",
            "color": "#10B981",
            "z": 3,
        }
    )

    # Declarative Top Bar layout via Draw.room
    try:
        Draw.room(
            display=WIN_TAG,
            general={"padding": 10},
            scene={
                "hud_header_bg": "top",
                "hud_divider": ["hud_header_bg", "bottom", 0],
                "hud_score": ["hud_header_bg", "left", "inside"],
                "hud_danger_title": ["hud_header_bg", "center", "inside"],
            }
        )
    except Exception as e:
        print("Draw.room HUD setup:", e)

    # 8. Start / Game Over Modal Dialog Card (z=2 -> frontmost modal)
    Draw.shapes(
        display=WIN_TAG,
        shape=[
            {
                "ip": "modal_bg",
                "vertices": 4,
                "border_radius": 12,
                "size": [400, 290],
                "x": 60,
                "y": -999,
                "color": "#0B1120",
                "border_width": 2,
                "border_color": "#38BDF8",
                "z": 2,
                "locked": True,
                "overlap": True,
            }
        ]
    )

    Draw.text(
        tag=WIN_TAG,
        text="⚡ LETTER SHATTER",
        ip="modal_title",
        x=260,
        y=-999,
        customise={
            "font_size": 22,
            "font_family": "Segoe UI",
            "bold": True,
            "align_text": "center",
            "color": "#38BDF8",
            "z": 1,
        }
    )

    Draw.text(
        tag=WIN_TAG,
        text="Type flying letters on your keyboard to shatter them!\nEach smash recovers danger & awards combo points.",
        ip="modal_subtitle",
        x=260,
        y=-999,
        customise={
            "font_size": 13,
            "font_family": "Segoe UI",
            "align_text": "center",
            "color": "#94A3B8",
            "z": 1,
        }
    )

    Draw.text(
        tag=WIN_TAG,
        text="Press SPACE or ENTER to Play",
        ip="modal_action",
        x=260,
        y=-999,
        customise={
            "font_size": 16,
            "font_family": "Segoe UI",
            "bold": True,
            "align_text": "center",
            "color": "#F59E0B",
            "z": 1,
        }
    )

    Draw.text(
        tag=WIN_TAG,
        text="Key Controls: A-Z (Shatter) | P (Pause) | R (Restart)",
        ip="modal_controls",
        x=260,
        y=-999,
        customise={
            "font_size": 12,
            "font_family": "Segoe UI",
            "align_text": "center",
            "color": "#64748B",
            "z": 1,
        }
    )

    # 9. Startup Loader using Draw.loader & Draw.room
    Draw.loader(
        display=WIN_TAG,
        ip="start_loader",
        shape="circle",
        color="#38BDF8",
        motion="spin",
        size=[52, 52],
        x=int(WIN_WIDTH // 2 - 26),
        y=int(WIN_HEIGHT // 2 - 60),
        z=1,
    )

    Draw.shapes(
        display=WIN_TAG,
        shape=[
            {
                "ip": "loader_bar_bg",
                "vertices": 4,
                "border_radius": 4,
                "size": [200, 8],
                "x": int(WIN_WIDTH // 2 - 100),
                "y": int(WIN_HEIGHT // 2 + 55),
                "color": "#1E293B",
                "border_width": 1,
                "border_color": "#334155",
                "z": 1,
                "locked": True,
                "overlap": True,
            },
            {
                "ip": "loader_bar",
                "vertices": 4,
                "border_radius": 4,
                "size": [10, 8],
                "x": int(WIN_WIDTH // 2 - 100),
                "y": int(WIN_HEIGHT // 2 + 55),
                "color": "#38BDF8",
                "z": 1,
                "locked": True,
                "overlap": True,
            },
        ]
    )

    Draw.text(
        tag=WIN_TAG,
        text="INITIALIZING ENGINE... 0%",
        ip="loader_title",
        x=int(WIN_WIDTH // 2),
        y=int(WIN_HEIGHT // 2 + 20),
        customise={
            "font_size": 15,
            "font_family": "Segoe UI",
            "bold": True,
            "align_text": "center",
            "color": "#38BDF8",
            "z": 1,
        }
    )

    Draw.text(
        tag=WIN_TAG,
        text="Press any key or Space to skip",
        ip="loader_sub",
        x=int(WIN_WIDTH // 2),
        y=int(WIN_HEIGHT // 2 + 80),
        customise={
            "font_size": 12,
            "font_family": "Segoe UI",
            "align_text": "center",
            "color": "#64748B",
            "z": 1,
        }
    )

    # Use Draw.room to align loader items
    try:
        Draw.room(
            display=WIN_TAG,
            general={"padding": 12},
            scene={
                "start_loader": "center",
                "loader_title": ["start_loader", "bottom", 18],
                "loader_bar_bg": ["loader_title", "bottom", 14],
                "loader_bar": ["loader_bar_bg", "left", "inside"],
                "loader_sub": ["loader_bar_bg", "bottom", 12],
            }
        )
    except Exception as e:
        print("Draw.room loader setup:", e)

    # 10. Register Keyboard Senses with Draw.senses
    register_senses()

    # 11. Hardware-Accelerated OpenGL Super Mode
    try:
        print("[OPENGL] Activating Draw.super Hardware-Accelerated OpenGL Engine...")
        Draw.super(display=WIN_TAG, precompile=True, mode="max", vsync=False)
    except Exception as exc:
        print("Draw.super note:", exc)


# ══════════════════════════════════════════════════════════════════════════════
#  Keyboard Senses & Connector Bindings
# ══════════════════════════════════════════════════════════════════════════════
letter_senses: Dict[str, Any] = {}
sense_start = None
sense_pause = None
sense_restart = None

def register_senses():
    global sense_start, sense_pause, sense_restart
    # Register alphabet sensors A-Z
    for ch in string.ascii_lowercase:
        s = Draw.senses("key_press", id=f"sense_key_{ch}", key=[ch, ch.upper()])
        letter_senses[ch] = s

    sense_start   = Draw.senses("key_press", id="sense_start",   key=["space", "return", "enter"])
    sense_restart = Draw.senses("key_press", id="sense_restart", key=["r", "R"])
    sense_pause   = Draw.senses("key_press", id="sense_pause",   key=["p", "P", "escape"])


# ══════════════════════════════════════════════════════════════════════════════
#  Game Logic & Shatter Particle FX
# ══════════════════════════════════════════════════════════════════════════════
def finish_loading():
    """Transition from startup loader to active gameplay."""
    if state["status"] != "LOADING":
        return

    # Hide all loader shapes
    for lid in ("start_loader", "loader_bar", "loader_bar_bg"):
        s = Draw.shapes.get_by_ip(WIN_TAG, lid)
        if s:
            s.x = -999
            s.y = -999
            s.dirty = True

    canvas = Draw.window.get_canvas(WIN_TAG)
    if canvas:
        for t in canvas.text_items:
            if t.ip in ("loader_title", "loader_sub"):
                t.y = -999

    # Start live gameplay!
    reset_game()
    print("[GAME] Loader complete! Arena active - Shatter the letters!")


def reset_game():
    """Reset all game variables, pools, and Overload Danger meter."""
    state["score"] = 0
    state["streak"] = 0
    state["danger"] = 0.0
    state["lives"] = MAX_LIVES
    state["letters_smashed"] = 0
    state["spawn_timer"] = 0.0
    state["status"] = "PLAYING"
    state["last_time"] = time.perf_counter()

    # Reset flying letter pool
    for let in letter_pool:
        let["active"] = False
        let["x"] = -200.0
        let["y"] = -200.0
        s_box = Draw.shapes.get_by_ip(WIN_TAG, let["box_ip"])
        s_glow = Draw.shapes.get_by_ip(WIN_TAG, let["glow_ip"])
        if s_box:
            s_box.x = -200
            s_box.y = -200
            s_box.dirty = True
        if s_glow:
            s_glow.x = -200
            s_glow.y = -200
            s_glow.dirty = True

    canvas = Draw.window.get_canvas(WIN_TAG)
    if canvas:
        for t in canvas.text_items:
            if t.ip.startswith("let_txt_"):
                t.x = -200
                t.y = -200

    set_modal_visible(False)
    update_hud_display()


def trigger_game_over():
    """Trigger 100% Danger Overload Game Over modal."""
    state["status"] = "GAMEOVER"
    if state["score"] > state["high_score"]:
        state["high_score"] = state["score"]
    if state["streak"] > state["max_streak"]:
        state["max_streak"] = state["streak"]

    set_modal_visible(
        True,
        title="💥 OVERLOAD: 100%!",
        subtitle=f"Score: {state['score']}  |  Smashed: {state['letters_smashed']}\nMax Streak: x{state['max_streak']}  |  Best: {state['high_score']}",
        action="Press SPACE or R to Restart",
        title_color="#EF4444",
    )
    update_hud_display()


def set_modal_visible(visible: bool, title="", subtitle="", action="", title_color="#38BDF8"):
    """Show or hide modal dialog card."""
    canvas = Draw.window.get_canvas(WIN_TAG)
    modal_card = Draw.shapes.get_by_ip(WIN_TAG, "modal_bg")

    card_y = 210 if visible else -999
    if modal_card:
        modal_card.y = card_y
        modal_card.border_color = title_color
        modal_card.dirty = True

    if canvas:
        for t in canvas.text_items:
            if t.ip == "modal_title":
                t.y = 235 if visible else -999
                t.color = _parse_color(title_color)
                if title:
                    t.text = title
            elif t.ip == "modal_subtitle":
                t.y = 280 if visible else -999
                if subtitle:
                    t.text = subtitle
            elif t.ip == "modal_action":
                t.y = 370 if visible else -999
                if action:
                    t.text = action
            elif t.ip == "modal_controls":
                t.y = 445 if visible else -999

    if visible:
        try:
            Draw.room(
                display=WIN_TAG,
                general={"padding": 16},
                scene={
                    "modal_bg": "center",
                    "modal_title": ["modal_bg", "top", "inside"],
                    "modal_subtitle": ["modal_title", "bottom", 14],
                    "modal_action": ["modal_subtitle", "bottom", 24],
                    "modal_controls": ["modal_action", "bottom", 16],
                }
            )
        except Exception:
            pass


def emit_shatter_shards(cx: float, cy: float, color: str):
    """Explode broken letter block into flying polygon debris shards."""
    count = 0
    for shard in shards:
        if not shard["active"]:
            shard["active"] = True
            shard["x"] = cx + random.uniform(-10, 10)
            shard["y"] = cy + random.uniform(-10, 10)
            angle = random.uniform(0, 2 * math.pi)
            speed = random.uniform(90.0, 320.0)
            shard["vx"] = math.cos(angle) * speed
            shard["vy"] = math.sin(angle) * speed - random.uniform(30.0, 90.0)  # upward pop
            shard["life"] = 0.0
            shard["max_life"] = random.uniform(0.35, 0.65)
            shard["color"] = color
            s = Draw.shapes.get_by_ip(WIN_TAG, shard["ip"])
            if s:
                s.color = color
                s.dirty = True

            count += 1
            if count >= 10:
                break


def spawn_popup(text: str, cx: float, cy: float, color="#38BDF8"):
    """Trigger a floating feedback text popup."""
    for pop in popups:
        if not pop["active"]:
            pop["active"] = True
            pop["text"] = text
            pop["x"] = cx - 30
            pop["y"] = cy - 20
            pop["life"] = 0.0
            pop["color"] = color
            canvas = Draw.window.get_canvas(WIN_TAG)
            if canvas:
                for t in canvas.text_items:
                    if t.ip == pop["ip"]:
                        t.text = text
                        t.x = int(pop["x"])
                        t.y = int(pop["y"])
                        t.color = _parse_color(color)
            break


def shatter_letter(target_let: Dict[str, Any]):
    """Process destruction of target letter, award points & reduce danger."""
    cx = target_let["x"] + LETTER_SIZE / 2.0
    cy = target_let["y"] + LETTER_SIZE / 2.0
    pal = PALETTE[target_let["color_idx"]]

    # 1. Explode Shards
    emit_shatter_shards(cx, cy, pal["border"])

    # 2. Deactivate flying letter
    target_let["active"] = False
    target_let["x"] = -200.0
    target_let["y"] = -200.0
    s_box = Draw.shapes.get_by_ip(WIN_TAG, target_let["box_ip"])
    s_glow = Draw.shapes.get_by_ip(WIN_TAG, target_let["glow_ip"])
    if s_box:
        s_box.x = -200
        s_box.y = -200
        s_box.dirty = True
    if s_glow:
        s_glow.x = -200
        s_glow.y = -200
        s_glow.dirty = True

    canvas = Draw.window.get_canvas(WIN_TAG)
    if canvas:
        for t in canvas.text_items:
            if t.ip == target_let["txt_ip"]:
                t.x = -200
                t.y = -200

    # 3. Scoring & Streak
    state["streak"] += 1
    if state["streak"] > state["max_streak"]:
        state["max_streak"] = state["streak"]
    state["letters_smashed"] += 1

    multiplier = min(5, 1 + (state["streak"] // 4))
    points = 100 * multiplier
    state["score"] += points

    # 4. Live Point / Danger Recovery (Reduce danger bar!)
    danger_recovered = 8.0 + (multiplier * 2.0)
    state["danger"] = max(0.0, state["danger"] - danger_recovered)
    if state["lives"] < MAX_LIVES and state["streak"] % 8 == 0:
        state["lives"] += 1

    # Feedback popups
    if multiplier > 1:
        spawn_popup(f"+{points} (x{multiplier})", cx, cy, "#F59E0B")
    else:
        spawn_popup(f"+{points} HEAL!", cx, cy, "#10B981")

    update_hud_display()


def spawn_letter():
    """Spawn a new random letter block with wave motion kinematics."""
    for let in letter_pool:
        if not let["active"]:
            let["active"] = True
            # Random uppercase letter
            let["char"] = random.choice(string.ascii_uppercase)
            let["color_idx"] = random.randint(0, len(PALETTE) - 1)
            pal = PALETTE[let["color_idx"]]

            # Horizontal placement in arena lanes
            margin = 35
            let["base_x"] = float(random.randint(margin, WIN_WIDTH - LETTER_SIZE - margin))
            let["x"] = let["base_x"]
            let["y"] = float(HEADER_H - LETTER_SIZE - 5)

            # Speed scaling based on score
            cur_speed = min(MAX_SPEED, BASE_SPEED + (state["score"] // 150) * SPEED_STEP)
            let["speed"] = cur_speed * random.uniform(0.90, 1.15)

            # Wave kinematics
            let["wave_phase"] = random.uniform(0, 2 * math.pi)
            let["wave_freq"] = random.uniform(1.2, 2.5)
            let["wave_amp"] = random.uniform(15.0, 35.0)

            # Update shape & text visual properties
            s_box = Draw.shapes.get_by_ip(WIN_TAG, let["box_ip"])
            s_glow = Draw.shapes.get_by_ip(WIN_TAG, let["glow_ip"])
            if s_box:
                s_box.color = pal["bg"]
                s_box.border_color = pal["border"]
                s_box.x = int(let["x"])
                s_box.y = int(let["y"])
                s_box.dirty = True
            if s_glow:
                s_glow.border_color = pal["glow"]
                s_glow.x = int(let["x"] - 3)
                s_glow.y = int(let["y"] - 3)
                s_glow.dirty = True

            canvas = Draw.window.get_canvas(WIN_TAG)
            if canvas:
                for t in canvas.text_items:
                    if t.ip == let["txt_ip"]:
                        t.text = let["char"]
                        t.x = int(let["x"] + LETTER_SIZE // 2 - 7)
                        t.y = int(let["y"] + LETTER_SIZE // 2 - 12)

            break


def update_hud_display():
    """Refresh HUD Overload Danger bar, Score, Best, Streak, and Lives."""
    canvas = Draw.window.get_canvas(WIN_TAG)
    if not canvas:
        return

    # 1. Update Danger Bar Fill width (0 - 180 px)
    danger_pct = min(100.0, max(0.0, state["danger"]))
    fill_w = max(4, int(180 * (danger_pct / 100.0)))
    d_fill = Draw.shapes.get_by_ip(WIN_TAG, "danger_fill")
    if d_fill:
        d_fill.size_raw = [fill_w, 10]
        # Dynamic color gradient
        if danger_pct < 40:
            d_fill.color = "#10B981"  # Emerald Green
        elif danger_pct < 75:
            d_fill.color = "#F59E0B"  # Amber Gold
        else:
            d_fill.color = "#EF4444"  # Crimson Red
        d_fill.dirty = True

    # 2. Update HUD Text Items
    hearts = ("💚 " * state["lives"]).strip() if state["lives"] > 0 else "💀 0"

    for t in canvas.text_items:
        if t.ip == "hud_score":
            t.text = f"SCORE: {state['score']}"
        elif t.ip == "hud_best":
            t.text = f"BEST: {state['high_score']}"
        elif t.ip == "hud_danger_title":
            t.text = f"OVERLOAD: {int(danger_pct)}%"
            if danger_pct < 40:
                t.color = _parse_color("#10B981")
            elif danger_pct < 75:
                t.color = _parse_color("#F59E0B")
            else:
                t.color = _parse_color("#EF4444")
        elif t.ip == "hud_streak":
            mult = min(5, 1 + (state["streak"] // 4))
            t.text = f"STREAK x{state['streak']} ({mult}x)"
        elif t.ip == "hud_lives":
            t.text = hearts


# ══════════════════════════════════════════════════════════════════════════════
#  60 FPS Main Game Tick Loop
# ══════════════════════════════════════════════════════════════════════════════
def game_tick():
    """60 FPS Game Update and Render Cycle."""
    if WIN_TAG not in Draw.window.list_tags():
        return

    now = time.perf_counter()
    dt = min(0.05, now - state["last_time"])
    state["last_time"] = now

    # Check Control Senses
    start_pressed   = sense_start.consume() if sense_start else False
    restart_pressed = sense_restart.consume() if sense_restart else False
    pause_pressed   = sense_pause.consume() if sense_pause else False

    # ── State 1: LOADING ──────────────────────────────────────────────────────
    if state["status"] == "LOADING":
        state["loader_elapsed"] += dt
        progress = min(1.0, state["loader_elapsed"] / LOADER_DURATION)

        # Update loader bar & text
        l_bar = Draw.shapes.get_by_ip(WIN_TAG, "loader_bar")
        if l_bar:
            l_bar.size_raw = [max(4, int(200 * progress)), 8]
            l_bar.dirty = True

        canvas = Draw.window.get_canvas(WIN_TAG)
        if canvas:
            for t in canvas.text_items:
                if t.ip == "loader_title":
                    t.text = f"INITIALIZING ENGINE... {int(progress * 100)}%"

        # Check for any keyboard press to skip loader
        any_key_pressed = start_pressed or restart_pressed or pause_pressed
        if not any_key_pressed:
            for s in letter_senses.values():
                if s.consume():
                    any_key_pressed = True
                    break

        if progress >= 1.0 or any_key_pressed:
            finish_loading()

        # Update starfield even during loading
        for star in stars:
            star["y"] += star["speed"] * dt
            if star["y"] > WIN_HEIGHT:
                star["y"] = float(HEADER_H + 2)
                star["x"] = float(random.randint(10, WIN_WIDTH - 10))
            s = Draw.shapes.get_by_ip(WIN_TAG, star["ip"])
            if s:
                s.y = int(star["y"])
                s.x = int(star["x"])
                s.dirty = True

        if canvas:
            canvas.update()
        return

    # ── Handle Global Pause & Restart ─────────────────────────────────────────
    if restart_pressed:
        reset_game()
        return

    if start_pressed:
        if state["status"] == "GAMEOVER":
            reset_game()
            return
        elif state["status"] == "PAUSED":
            state["status"] = "PLAYING"
            set_modal_visible(False)

    if pause_pressed:
        if state["status"] == "PLAYING":
            state["status"] = "PAUSED"
            set_modal_visible(
                True,
                title="⏸️ PAUSED",
                subtitle=f"Current Score: {state['score']}\nOverload: {int(state['danger'])}%",
                action="Press SPACE or P to Resume",
                title_color="#38BDF8",
            )
        elif state["status"] == "PAUSED":
            state["status"] = "PLAYING"
            set_modal_visible(False)

    # ── Background Stars & Shard Particles Update ─────────────────────────────
    for star in stars:
        star["y"] += star["speed"] * dt
        if star["y"] > WIN_HEIGHT:
            star["y"] = float(HEADER_H + 2)
            star["x"] = float(random.randint(10, WIN_WIDTH - 10))
        s = Draw.shapes.get_by_ip(WIN_TAG, star["ip"])
        if s:
            s.y = int(star["y"])
            s.x = int(star["x"])
            s.dirty = True

    for shard in shards:
        if shard["active"]:
            shard["life"] += dt
            if shard["life"] >= shard["max_life"]:
                shard["active"] = False
                shard["x"] = -200.0
                shard["y"] = -200.0
            else:
                shard["vy"] += 280.0 * dt  # Gravity
                shard["x"] += shard["vx"] * dt
                shard["y"] += shard["vy"] * dt

            s = Draw.shapes.get_by_ip(WIN_TAG, shard["ip"])
            if s:
                s.x = int(shard["x"])
                s.y = int(shard["y"])
                s.dirty = True

    # ── Popups Update ─────────────────────────────────────────────────────────
    canvas = Draw.window.get_canvas(WIN_TAG)
    for pop in popups:
        if pop["active"]:
            pop["life"] += dt
            if pop["life"] >= pop["max_life"]:
                pop["active"] = False
                pop["x"] = -200.0
                pop["y"] = -200.0
            else:
                pop["y"] += pop["vy"] * dt

            if canvas:
                for t in canvas.text_items:
                    if t.ip == pop["ip"]:
                        t.x = int(pop["x"])
                        t.y = int(pop["y"])

    # If game is paused or over, repaint and return
    if state["status"] != "PLAYING":
        if canvas:
            canvas.update()
        return

    # ── State 2: PLAYING — Keyboard Senses Processing ─────────────────────────
    for ch, sense in letter_senses.items():
        if sense.consume():
            upper_char = ch.upper()
            # Find matching active letter on screen closest to the bottom (highest threat!)
            matching_letters = [
                let for let in letter_pool
                if let["active"] and let["char"] == upper_char and let["y"] > HEADER_H - 10
            ]
            if matching_letters:
                # Target the lowest one first
                target = max(matching_letters, key=lambda l: l["y"])
                shatter_letter(target)
            else:
                # Penalty for misfire on empty air: minor danger bump & break streak
                state["streak"] = 0
                state["danger"] = min(100.0, state["danger"] + 1.5)
                update_hud_display()

    # ── Spawn Letters ─────────────────────────────────────────────────────────
    cur_interval = max(
        SPAWN_INTERVAL_MIN,
        SPAWN_INTERVAL_BASE - (state["score"] // 500) * 0.08
    )
    state["spawn_timer"] += dt
    if state["spawn_timer"] >= cur_interval:
        state["spawn_timer"] = 0.0
        spawn_letter()

    # ── Update Flying Letters & Check Screen Exit Misses ──────────────────────
    for let in letter_pool:
        if not let["active"]:
            continue

        # Sine wave horizontal drift + vertical descent
        let["y"] += let["speed"] * dt
        let["wave_phase"] += let["wave_freq"] * dt
        let["x"] = let["base_x"] + math.sin(let["wave_phase"]) * let["wave_amp"]

        # Clamp inside arena walls
        let["x"] = max(10.0, min(float(WIN_WIDTH - LETTER_SIZE - 10), let["x"]))

        # Update shape badge positions
        s_box = Draw.shapes.get_by_ip(WIN_TAG, let["box_ip"])
        s_glow = Draw.shapes.get_by_ip(WIN_TAG, let["glow_ip"])
        if s_box:
            s_box.x = int(let["x"])
            s_box.y = int(let["y"])
            s_box.dirty = True
        if s_glow:
            s_glow.x = int(let["x"] - 3)
            s_glow.y = int(let["y"] - 3)
            s_glow.dirty = True

        if canvas:
            for t in canvas.text_items:
                if t.ip == let["txt_ip"]:
                    t.x = int(let["x"] + LETTER_SIZE // 2 - 7)
                    t.y = int(let["y"] + LETTER_SIZE // 2 - 12)

        # Check if letter escaped past bottom boundary (MISSED!)
        if let["y"] > WIN_HEIGHT:
            let["active"] = False
            let["x"] = -200.0
            let["y"] = -200.0
            if s_box:
                s_box.x = -200
                s_box.y = -200
                s_box.dirty = True
            if s_glow:
                s_glow.x = -200
                s_glow.y = -200
                s_glow.dirty = True
            if canvas:
                for t in canvas.text_items:
                    if t.ip == let["txt_ip"]:
                        t.x = -200
                        t.y = -200

            # Miss penalty: Overload Danger increases!
            state["streak"] = 0
            state["danger"] += 16.0
            state["lives"] = max(0, state["lives"] - 1)
            spawn_popup("MISS! +DANGER", let["base_x"], WIN_HEIGHT - 60, "#EF4444")
            update_hud_display()

            # Check 100% Danger / Zero Lives Game Over Condition
            if state["danger"] >= 100.0 or state["lives"] <= 0:
                state["danger"] = 100.0
                trigger_game_over()
                break

    # Trigger canvas repaint
    if canvas:
        canvas.update()


# ══════════════════════════════════════════════════════════════════════════════
#  Main Entrypoint
# ══════════════════════════════════════════════════════════════════════════════
def main():
    print("[INFO] Initializing Neon Letter Shatter arcade game with Draw...")
    init_game_scene()

    # Register 60 FPS Game Loop
    Draw.every(0.016, game_tick)

    # Launch Application
    print("[READY] Game ready! Type matching letters to shatter them!")
    Draw.window.run(WIN_TAG)


if __name__ == "__main__":
    main()
