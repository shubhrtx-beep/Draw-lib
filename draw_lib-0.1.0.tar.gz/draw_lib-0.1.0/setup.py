﻿from setuptools import setup, find_packages

setup(
    name="Draw-lib",
    version="0.1.0",
    description="Declarative 2D Canvas, Layout, Physics & UI Library built on PySide6",
    packages=find_packages(),
    install_requires=[
        "PySide6>=6.5.0",
        "numpy>=1.20.0",
        "PyOpenGL>=3.1.5",
    ],
    python_requires=">=3.9",
)
