﻿# Draw-lib

A high-performance, declarative 2D Canvas, Relative Layout, Procedural Motion, Physics & UI framework built on PySide6 and OpenGL.

## Features
- **Declarative 2D Canvas**: Shapes, borders, bends, arcs, mesh warps, and radial symmetry.
- **Hardware OpenGL Acceleration (`Draw.super`)**: Dynamic 2D GPU Geometry Batching with GLSL shaders.
- **Visibility Optimization Engine (`Draw.veo`)**: 5-phase spatial hierarchy, viewport culling, and 2D occlusion culling.
- **Procedural Motion Physics (`Draw.motion`)**: 38 motion physics presets, springs, wiggles, and benzene rings.
- **Physics Links & Joints (`Draw.connectors`)**: Springs, pendulums, orbits, ropes, and distance locks.
- **Declarative Graphing (`Draw.graph`)**: 11 chart types (bar, line, pie, donut, radar, spider).
- **Reactive State (`Draw.live`)**: High-speed 60Hz reactive state bindings.

## Quickstart
```python
import Draw

Draw.window(tag="main", width=800, height=600)
Draw.shape(
    display="main",
    shape=[{
        "ip": "hex", "vertices": 6, "size": [120, 120], "align": "center",
        "color": "#38BDF8", "rotation": "time * 45"
    }]
)
Draw.window.run("main")
```
